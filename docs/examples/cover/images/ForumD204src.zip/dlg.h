	fsoftsettxt
	fsofttxt
	script_init
	trans_txt

sh32	db	'shell32.dll',0
o32	db	'ole32.dll',0
shbr	db	'SHBrowseForFolder',0
shgp	db	'SHGetPathFromIDList',0
ctmem	db	'CoTaskMemFree',0
_pause	db	'*** Paused',13,10,0
nofile	db	'*** No address entered',13,10,0
lb01	db	'Download forum',0
lb02	db	'Posted links',0
lb03	db	'HTTP debugger',0
lb04	db	'Script editor',0
lb05	db	'Detection',0
lb06	db	'Options',0
lb08	db	'Blocked content',0
frame1	dw	10,100,5,12,102,13,103,9,14,1300,15,1301,1003,200,1010,1011,1001,1200,1012,1002,-1
frame1a	dw	10,100,5,12,102,13,103,9,14,1300,15,1301,1003,200,-1
frame1b	dw	1010,1011,1001,1200,1012,1002,-1
frame1c	dw	10,100,5,12,102,13,103,9,14,1300,15,1301,1003,200,1010,1011,1001,1012,1002,-1
frame2	dw	2010,2100,2011,2101,-1
frame3	dw	3011,3100,3007,3008,3009,3012,3001,3002,3003,3004,3005,3101,3050,3102,3400,3103,3006,-1
frame4	dw	4010,4300,4001,4100,-1
frame5	dw	5058,5300,5059,5400,5100,5401,5101,5402,5102,5403,5103,5404,5104,5405,5105,5406,5106,5407,5107,5408,5108,5409,5109,5410,5110,5411,5111,5417,5118,5010,5060,5062,-1
frame6	dw	6011,6101,6003,6058,6146,6401,6402,6403,6404,6405,6400,6053,6052,6139,6415,6140,6054,6056,6141,6416,6143,6412,6137,6413,6414,6138,6059,6300,6057,6301,6060,6302,6420,6417,6421,6422,-1
frame8	dw	8050,8051,8052,8053,8100,8101,8102,8103,-1
showframe:
	push	eax
	.while word ptr[ebx]!=-1
		movzx	eax,word ptr[ebx]
		push	ebx
		invoke	GetDlgItem,esi,eax
		invoke	ShowWindow,eax,1
		pop	ebx
		inc	ebx
		inc	ebx
	.endw
	pop	eax
	ret

hideframe:
	push	eax
	.while word ptr[ebx]!=-1
		movzx	eax,word ptr[ebx]
		push	ebx
		invoke	GetDlgItem,esi,eax
		invoke	ShowWindow,eax,0
		pop	ebx
		inc	ebx
		inc	ebx
	.endw
	pop	eax
	ret

showhide:
	mov	cframe,eax
	lea	ebx,frame1
	.if eax==1
		.if operation==0
			lea	ebx,frame1b
			call	hideframe
			lea	ebx,frame1a
		.elseif operation==1
			push	eax
			invoke	GetDlgItem,esi,1200
			invoke	ShowWindow,eax,0
			pop	eax
			lea	ebx,frame1c
		.endif
		call	showframe
	.else
		call	hideframe
	.endif
	lea	ebx,frame2
	.if eax==2
		call	showframe
	.else
		call	hideframe
	.endif
	lea	ebx,frame3
	.if eax==3
		push	eax
		push	edi
		push	esi
		push	ebx
		call	clpchk
		pop	ebx
		pop	esi
		pop	edi
		pop	eax
		call	showframe
	.else
		call	hideframe
	.endif
	lea	ebx,frame4
	.if eax==4
		call	showframe
	.else
		call	hideframe
	.endif
	lea	ebx,frame5
	.if eax==5
		call	showframe
	.else
		call	hideframe
	.endif
	lea	ebx,frame6
	.if eax==6
		call	showframe
	.else
		call	hideframe
	.endif
	lea	ebx,frame8
	.if eax==8
		call	showframe
	.else
		call	hideframe
	.endif
	ret


dlgf1	PROC	uses esi edi ebx hDlg:DWORD,uMsg:DWORD,wParam:DWORD,lParam:DWORD
	inc	s_reent
	.if uMsg==WM_INITDIALOG
		invoke	SetTimer,hDlg,100,100,0
		invoke	SendDlgItemMessage,hDlg,1000,LB_ADDSTRING,0,addr lb01
		invoke	SendDlgItemMessage,hDlg,1000,LB_SETITEMDATA,eax,1
		invoke	SendDlgItemMessage,hDlg,1000,LB_ADDSTRING,0,addr lb02
		invoke	SendDlgItemMessage,hDlg,1000,LB_SETITEMDATA,eax,2
		invoke	SendDlgItemMessage,hDlg,1000,LB_ADDSTRING,0,addr lb03
		invoke	SendDlgItemMessage,hDlg,1000,LB_SETITEMDATA,eax,3
		invoke	SendDlgItemMessage,hDlg,1000,LB_ADDSTRING,0,addr lb04
		invoke	SendDlgItemMessage,hDlg,1000,LB_SETITEMDATA,eax,4
		invoke	SendDlgItemMessage,hDlg,1000,LB_ADDSTRING,0,addr lb05
		invoke	SendDlgItemMessage,hDlg,1000,LB_SETITEMDATA,eax,5
		invoke	SendDlgItemMessage,hDlg,1000,LB_ADDSTRING,0,addr lb08
		invoke	SendDlgItemMessage,hDlg,1000,LB_SETITEMDATA,eax,8
		invoke	SendDlgItemMessage,hDlg,1000,LB_ADDSTRING,0,addr lb06
		invoke	SendDlgItemMessage,hDlg,1000,LB_SETITEMDATA,eax,6
		invoke	SendDlgItemMessage,hDlg,1000,LB_SETCURSEL,0,0
		mov	esi,hDlg
		mov	eax,1
		call	showhide
		forumdetectinit
		ua_init

		invoke	SendDlgItemMessage,hDlg,6101,EM_LIMITTEXT,8192,0
		invoke	SetDlgItemText,hDlg,6101,addr defdir
		invoke	SetDlgItemInt,hDlg,6146,maxfile,0
		.if pflag&16
			invoke	CheckDlgButton,hDlg,6401,BST_CHECKED
		.endif
		.if pflag&32
			invoke	CheckDlgButton,hDlg,6402,BST_CHECKED
		.endif
		.if pflag&64
			invoke	CheckDlgButton,hDlg,6403,BST_CHECKED
		.endif
		.if pflag&128
			invoke	CheckDlgButton,hDlg,6404,BST_CHECKED
		.endif
		.if translit&1
			invoke	CheckDlgButton,hDlg,6405,BST_CHECKED
		.endif
		mov	eax,delayd
		xor	edx,edx
		mov	ecx,1000
		div	ecx
		invoke	SetDlgItemInt,hDlg,6138,eax,0
		invoke	SetDlgItemInt,hDlg,6139,maxretries,0
		invoke	SetDlgItemInt,hDlg,6140,rdelay1,0
		invoke	SetDlgItemInt,hDlg,6141,maxctimeout,0
		invoke	SetDlgItemInt,hDlg,6143,rdelay,0
		.if fflag&32
			invoke	CheckDlgButton,hDlg,6414,BST_CHECKED
		.else
			invoke	GetDlgItem,hDlg,6138
			invoke	EnableWindow,eax,0
		.endif
		.if fflag&64
			invoke	CheckDlgButton,hDlg,6415,BST_CHECKED
		.else
			invoke	GetDlgItem,hDlg,6140
			invoke	EnableWindow,eax,0
		.endif
		.if fflag&128
			invoke	CheckDlgButton,hDlg,6416,BST_CHECKED
		.else
			invoke	GetDlgItem,hDlg,6143
			invoke	EnableWindow,eax,0
		.endif
		.if proxyflag&1
			invoke	CheckDlgButton,hDlg,6412,BST_CHECKED
		.else
			invoke	GetDlgItem,hDlg,6137
			invoke	EnableWindow,eax,0
			invoke	GetDlgItem,hDlg,6413
			invoke	EnableWindow,eax,0
		.endif
		.if proxyflag&2
			invoke	CheckDlgButton,hDlg,6413,BST_CHECKED
		.endif
		.if proxyflag&4
			invoke	CheckDlgButton,hDlg,6420,BST_CHECKED
		.endif
		invoke	SendDlgItemMessage,hDlg,6137,EM_LIMITTEXT,255,0
		invoke	SetDlgItemText,hDlg,6137,addr _proxy
		.if lsave&1
			invoke	CheckDlgButton,hDlg,6400,BST_CHECKED
		.endif

		invoke	SetDlgItemText,hDlg,5010,addr _wcards
		invoke	GetWindowText,hDlg,addr buftmp,8192
		mov	nid.cbSize,0
		invoke	SendMessage,hDlg,WM_SETICON,ICON_BIG,hIcon
		invoke	SetWindowText,hDlg,addr buftmp
		mov	started,0
		push	hDlg
		pop	hDialog
		invoke	SendDlgItemMessage,hDlg,100,EM_LIMITTEXT,8192,0
		invoke	SendDlgItemMessage,hDlg,200,EM_LIMITTEXT,65530,0
		invoke	SendDlgItemMessage,hDlg,102,EM_LIMITTEXT,255,0
		invoke	SendDlgItemMessage,hDlg,103,EM_LIMITTEXT,255,0
		mov	shbrowseforfolder,0
		mov	cotaskmemfree,0
		mov	shell32,0
		mov	ole32,0
		mov	f_info,0
		invoke	SetDlgItemText,hDlg,100,addr fname
		invoke	SendDlgItemMessage,hDialog,1200,PBM_SETRANGE,0,100*65536
		invoke	SendDlgItemMessage,hDialog,1200,PBM_SETSTEP,1,0
		initdlgbans
		test_dlginit
		save_init
		trans_init
		idxgen_init
		call	initscr
		call	initclp
	.elseif (uMsg==WM_TIMER)&&(bufmsgs!=0)
		invoke	EnterCriticalSection,addr critical
		invoke	SendDlgItemMessage,hDialog,200,WM_GETTEXTLENGTH,0,0
		.if eax==-1
			invoke	SetDlgItemText,hDlg,200,addr fname
			xor	eax,eax
		.endif
		mov	edx,eax
		add	edx,bufmsgs
		.if edx>60000
			invoke	SendDlgItemMessage,hDialog,200,EM_SETSEL,0,16384
			push	0
			mov	edx,esp
			invoke	SendDlgItemMessage,hDialog,200,EM_REPLACESEL,0,edx
			pop	eax
			invoke	SendDlgItemMessage,hDialog,200,WM_GETTEXTLENGTH,0,0
		.endif
		invoke	SendDlgItemMessage,hDialog,200,EM_SETSEL,eax,eax
		invoke	SendDlgItemMessage,hDialog,200,EM_REPLACESEL,0,addr bufmsg
		mov	bufmsg,0
		mov	bufmsgs,0
		invoke	LeaveCriticalSection,addr critical
	.elseif uMsg==WM_COMMAND
		mov	eax,wParam
		mov	ebx,eax
		rol	ebx,16
		.if ax==2
			.if f_info
				mov	edi,f_info
				invoke	TerminateThread,[edi].hThread,0
				invoke	GlobalFree,f_info
			.endif
			invoke	EndDialog,hDlg,0
		.elseif ax==6003
			.if shbrowseforfolder==0
				.if shell32==0
					invoke	LoadLibrary,addr sh32
					mov	shell32,eax
				.endif
				.if shell32
					invoke	GetProcAddress,shell32,addr shbr
					mov	shbrowseforfolder,eax
					invoke	GetProcAddress,shell32,addr shgp
					mov	shgetpathfromidlist,eax
				.endif
			.endif
			.if shbrowseforfolder
				invoke	GlobalAlloc,GPTR,8192
				push	eax
				invoke	GetCurrentDirectory,8192,eax
				mov	eax,hDlg
				mov	shbff.hwndOwner,eax
				push	offset shbff
				call	shbrowseforfolder
				.if eax!=0
					push	eax
					push	offset defdir
					push	eax
					call	shgetpathfromidlist
					.if cotaskmemfree==0
						.if ole32==0
							invoke	LoadLibrary,addr o32
							mov	ole32,eax
						.endif
						.if eax
							invoke	GetProcAddress,ole32,addr ctmem
							mov	cotaskmemfree,eax
						.endif
					.endif
					pop	eax
					.if cotaskmemfree
						push	eax
						call	cotaskmemfree
					.endif
					invoke	SetDlgItemText,hDlg,6101,addr defdir
					lea	esi,defdir
					lea	edi,savedir
					.while byte ptr[esi]
						movsb
					.endw
					movsb
				.endif
				pop	eax
				push	eax
				invoke	SetCurrentDirectory,eax
				call	GlobalFree
			.endif
		.elseif ax==4
			mov	nid.cbSize,sizeof nid
			mov	eax,hDlg
			mov	nid.hwnd,eax
			mov	nid.uID,100
			mov	nid.uFlags,NIF_ICON or NIF_MESSAGE or NIF_TIP
			mov	nid.uCallbackMessage,WM_USER+10
			mov	eax,hIcon
			mov	nid.hIcon,eax
			invoke	GetWindowText,hDlg,addr nid.szTip,63
			invoke	Shell_NotifyIcon,NIM_ADD,addr nid
			invoke	ShowWindow,hDlg,SW_HIDE
		.elseif ax==6400
			invoke	IsDlgButtonChecked,hDlg,6400
			.if eax==BST_CHECKED
				mov	lsave,1
			.else
				mov	lsave,0
			.endif
		.elseif ax==401
			invoke	IsDlgButtonChecked,hDlg,401
			.if eax==BST_CHECKED
				or	translit,1
			.else
				and	translit,1 xor -1
			.endif
		.elseif ax==5
			.if f_info==0
				invoke	GlobalAlloc,GPTR,sizeof foruminfo
				mov	edi,eax
				mov	f_info,eax
			.else
				mov	edi,f_info
			.endif
			push	edi
			invoke	GetDlgItemText,hDlg,100,addr [edi]._addr,8192
			mov	defdir,0
			.if byte ptr[edi]._addr==0
				lea	edx,nofile
				call	showmsg
			.else
				xor	eax,eax
				inc	eax
				mov	ecx,recvbuf
				.if (byte ptr[ecx]!=0)&&(fsize!=0)
					invoke	SendDlgItemMessage,hDlg,100,EM_GETMODIFY,0,0
				.endif
				.if eax
					push	edi
					movzx	eax,dltype
					push	eax
					mov	dltype,3
					mov	fsize,0
					forumindexdownload
					mov	dltype,3
					.if fsize==0
						invoke	getfile,addr recvbuf,0,0,8192
						mov	edi,[esp+4]
						forumindexdownloadcomplete
					.endif
					pop	eax
					mov	dltype,al
					mov	hfile,0
					pop	edi
					mov	esi,recvbuf
					lea	edx,[edi]._addr
					call	_detect
					.if blogdet==1
						mov	esi,recvbuf
						call	detect_wp
					.elseif blogdet==2
						mov	esi,recvbuf
						call	detect_wp1
					.elseif blogdet==3
						mov	esi,recvbuf
						call	detect_bs
					.endif
				.endif
				.if fsize
					invoke	DialogBoxParam,hInstance,1011,hDlg,addr dlgsf1,edi
				.endif
			.endif
			invoke	SendDlgItemMessage,hDlg,100,EM_SETMODIFY,0,0
		.elseif ax==9
			invoke	GetDlgItemText,hDlg,102,addr _user,255
			invoke	GetDlgItemText,hDlg,103,addr _password,255
			mov	_cookies,0
			invoke	GetDlgItemText,hDlg,100,addr _cookies[1],8192
			invoke	CreateThread,0,0,addr loginproc,0,0,addr hLogin
		.elseif ax==1
			.if started==0
				mov	started,1
				invoke	SetDlgItemText,hDlg,1,addr start2
				.if f_info==0
					invoke	GlobalAlloc,GPTR,sizeof foruminfo
					mov	f_info,eax
				.else
					mov	eax,f_info
				.endif
				mov	edi,eax
				invoke	GetDlgItemText,hDlg,100,addr [edi]._addr,8192
				invoke	GetDlgItemText,hDlg,6101,addr defdir,8192
				invoke	GetWindowText,hDlg,addr buftmp,8192
				lea	edx,[edi]._addr
				push	edi
				lea	edi,buftmp
				xor	ecx,ecx
				.while byte ptr[edi]
					.if byte ptr[edi]==32
						inc	ecx
						.break .if ecx==3
					.endif
					inc	edi
				.endw
				mov	eax,' - '
				stosd
				dec	edi
				call	copyedx
				mov	al,0
				stosb
				invoke	SetWindowText,hDlg,addr buftmp
				pop	edi
				.if cframe!=2
					mov	dltype,1
					invoke	CreateThread,0,0,addr getforum,edi,0,addr [edi].hThread
				.else
					mov	dltype,2
					invoke	CreateThread,0,0,addr getrs,edi,0,addr [edi].hThread
				.endif
				.if cframe!=1
					invoke	SendDlgItemMessage,hDlg,1000,LB_SETCURSEL,0,0
					mov	esi,hDlg
					mov	eax,1
					call	showhide
				.endif
				mov	[edi].hThread,eax
				invoke	GetDlgItem,hDlg,3
				invoke	EnableWindow,eax,0
				invoke	GetDlgItem,hDlg,5
				invoke	EnableWindow,eax,0
				invoke	GetDlgItem,hDlg,6101
				invoke	EnableWindow,eax,0
				invoke	GetDlgItem,hDlg,6003
				invoke	EnableWindow,eax,0
				invoke	SendDlgItemMessage,hDlg,2100,EM_SETREADONLY,1,0
			.elseif started==1
				mov	started,2
			.else
				mov	started,1
			.endif
		.elseif ax==1000
			rol	eax,16
			.if ax==LBN_SELCHANGE
				invoke	SendDlgItemMessage,hDlg,1000,LB_GETCURSEL,0,0
				.if eax!=LB_ERR
					invoke	SendDlgItemMessage,hDlg,1000,LB_GETITEMDATA,eax,0
					.if (eax!=0)&&(eax!=-1)
						mov	esi,hDlg
						call	showhide
					.endif
				.endif
			.endif
		.elseif ax==1900
			invoke	SendDlgItemMessage,hDlg,1000,LB_SETCURSEL,0,0
			mov	esi,hDlg
			mov	eax,1
			call	showhide
			invoke	GetDlgItem,hDlg,100
			invoke	SetFocus,eax
		.elseif ax==1901
			invoke	SendDlgItemMessage,hDlg,1000,LB_SETCURSEL,1,0
			mov	esi,hDlg
			mov	eax,2
			call	showhide
			invoke	GetDlgItem,hDlg,100
			invoke	SetFocus,eax
		.elseif ax==1902
			invoke	SendDlgItemMessage,hDlg,1000,LB_SETCURSEL,2,0
			mov	esi,hDlg
			mov	eax,3
			call	showhide
			invoke	SendDlgItemMessage,hDlg,3100,WM_GETTEXTLENGTH,0,0
			.if eax
				invoke	GetDlgItem,hDlg,3007
			.else
				invoke	GetDlgItem,hDlg,3100
			.endif
			invoke	SetFocus,eax
		.elseif ax==1903
			invoke	SendDlgItemMessage,hDlg,1000,LB_SETCURSEL,3,0
			mov	esi,hDlg
			mov	eax,4
			call	showhide
			invoke	GetDlgItem,hDlg,100
			invoke	SetFocus,eax
		.elseif ax==1904
			invoke	SendDlgItemMessage,hDlg,1000,LB_SETCURSEL,4,0
			mov	esi,hDlg
			mov	eax,5
			call	showhide
			invoke	GetDlgItem,hDlg,5300
			invoke	SetFocus,eax
		.elseif ax==1905
			invoke	SendDlgItemMessage,hDlg,1000,LB_SETCURSEL,5,0
			mov	esi,hDlg
			mov	eax,8
			call	showhide
			invoke	GetDlgItem,hDlg,8100
			invoke	SetFocus,eax
		.elseif ax==1906
			invoke	SendDlgItemMessage,hDlg,1000,LB_SETCURSEL,6,0
			mov	esi,hDlg
			mov	eax,6
			call	showhide
			invoke	GetDlgItem,hDlg,6101
			invoke	SetFocus,eax
		.elseif ax==6401
			invoke	IsDlgButtonChecked,hDlg,6401
			.if eax==BST_CHECKED
				or	pflag,16
			.else
				and	pflag,16 xor -1
			.endif
		.elseif ax==6402
			invoke	IsDlgButtonChecked,hDlg,6402
			.if eax==BST_CHECKED
				or	pflag,32
			.else
				and	pflag,32 xor -1
			.endif
		.elseif ax==6403
			invoke	IsDlgButtonChecked,hDlg,6403
			.if eax==BST_CHECKED
				or	pflag,64
			.else
				and	pflag,64 xor -1
			.endif
		.elseif ax==6404
			invoke	IsDlgButtonChecked,hDlg,6404
			.if eax==BST_CHECKED
				or	pflag,128
			.else
				and	pflag,128 xor -1
			.endif
		.elseif ax==6405
			invoke	IsDlgButtonChecked,hDlg,6405
			.if eax==BST_CHECKED
				or	translit,1
			.else
				and	translit,1 xor -1
			.endif
		.elseif ax==6412
			invoke	IsDlgButtonChecked,hDlg,6412
			.if eax==BST_CHECKED
				invoke	GetDlgItem,hDlg,6137
				invoke	EnableWindow,eax,1
				invoke	GetDlgItem,hDlg,6413
				invoke	EnableWindow,eax,1
				or	proxyflag,1
			.else
				invoke	GetDlgItem,hDlg,6137
				invoke	EnableWindow,eax,0
				invoke	GetDlgItem,hDlg,6413
				invoke	EnableWindow,eax,0
				and	proxyflag,1 xor -1
			.endif
			mov	proxyip,0
			mov	proxyport,0
		.elseif ax==6413
			invoke	IsDlgButtonChecked,hDlg,6413
			.if eax==BST_CHECKED
				or	proxyflag,2
			.else
				and	proxyflag,2 xor -1
			.endif
			mov	proxyip,0
			mov	proxyport,0
		.elseif ax==6414
			invoke	IsDlgButtonChecked,hDlg,6414
			.if eax==BST_CHECKED
				invoke	GetDlgItem,hDlg,6138
				invoke	EnableWindow,eax,1
				or	fflag,32
			.else
				invoke	GetDlgItem,hDlg,6138
				invoke	EnableWindow,eax,0
				and	fflag,32 xor -1
			.endif
		.elseif ax==6415
			invoke	IsDlgButtonChecked,hDlg,6415
			.if eax==BST_CHECKED
				invoke	GetDlgItem,hDlg,6140
				invoke	EnableWindow,eax,1
				or	fflag,64
			.else
				invoke	GetDlgItem,hDlg,6140
				invoke	EnableWindow,eax,0
				and	fflag,64 xor -1
			.endif
		.elseif ax==6416
			invoke	IsDlgButtonChecked,hDlg,6416
			.if eax==BST_CHECKED
				invoke	GetDlgItem,hDlg,6143
				invoke	EnableWindow,eax,1
				or	fflag,128
			.else
				invoke	GetDlgItem,hDlg,6143
				invoke	EnableWindow,eax,0
				and	fflag,128 xor -1
			.endif
		.elseif ax==6420
			invoke	IsDlgButtonChecked,hDlg,6420
			.if eax==BST_CHECKED
				or	proxyflag,4
			.else
				and	proxyflag,4 xor -1
			.endif
		.elseif (ax==6101)&&(bx==EN_CHANGE)
			invoke	GetDlgItemText,hDlg,6101,addr savedir,8192
		.elseif (ax==6146)&&(bx==EN_CHANGE)
			invoke	GetDlgItemInt,hDlg,6146,0,0
			mov	maxfile,eax
		.elseif (ax==6137)&&(bx==EN_CHANGE)
			invoke	GetDlgItemText,hDlg,6137,addr _proxy,255
			mov	proxyip,0
			mov	proxyport,0
		.elseif (ax==6138)&&(bx==EN_CHANGE)
			invoke	GetDlgItemInt,hDlg,6138,0,0
			xor	edx,edx
			mov	ecx,1000
			mul	ecx
			mov	delayd,eax
		.elseif (ax==6139)&&(bx==EN_CHANGE)
			invoke	GetDlgItemInt,hDlg,6139,0,0
			mov	maxretries,eax
		.elseif (ax==6141)&&(bx==EN_CHANGE)
			invoke	GetDlgItemInt,hDlg,6141,0,0
			mov	maxctimeout,eax
		.elseif (ax==6140)&&(bx==EN_CHANGE)
			invoke	GetDlgItemInt,hDlg,6140,0,0
			mov	rdelay1,eax
		.elseif (ax==6143)&&(bx==EN_CHANGE)
			invoke	GetDlgItemInt,hDlg,6143,0,0
			mov	rdelay,eax
		.elseif (ax==1001)&&((operation==1)||(operation==2))
			mov	operation,3
			mov	fsize,0
			.if wsocket
				invoke	closesocket,wsocket
			.endif
		.elseif (ax==1002)&&((operation==1)||(operation==2))
			mov	operation,3
			.if wsocket
				invoke	closesocket,wsocket
			.endif
		.elseif ax==1004
			call	savecfg
			call	_showsmsg
			db	'*** Settings are saved',13,10,0
_showsmsg:		pop	edx
			call	showmsg
		.elseif ax==1005
			invoke	IsDlgButtonChecked,hDlg,1005
			.if eax==BST_CHECKED
				invoke	SetWindowPos,hDlg,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE or SWP_NOSIZE
			.else
				invoke	SetWindowPos,hDlg,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE or SWP_NOSIZE
			.endif
		forumdetectchange
		dlgupdatebans
		test_dlgcmd
		save_dlg
		ua_dlg
		script_dlg
		lang_dlg
		idxgen_dlg
		.endif
	.elseif uMsg==(WM_USER+10)&&(wParam==100)
		mov	eax,lParam
		.if (eax==WM_LBUTTONUP)||(eax==WM_RBUTTONUP)||(eax==WM_LBUTTONDBLCLK)
			invoke	Shell_NotifyIcon,NIM_DELETE,addr nid
			mov	nid.cbSize,0
			invoke	ShowWindow,hDlg,SW_SHOW
			invoke	BringWindowToTop,hDlg
			invoke	SendDlgItemMessage,hDlg,200,EM_SCROLLCARET,0,0
		.endif
	test_dlgmsg
	.elseif uMsg==WM_DESTROY
		invoke	KillTimer,hDlg,100
	.endif
	dec	s_reent
	xor	eax,eax
	ret
dlgf1	ENDP




col1	db	'Name',0
col2	db	'Address',0
dlgsf1	PROC	uses esi edi ebx hDlg:DWORD,uMsg:DWORD,wParam:DWORD,lParam:DWORD
	mov	eax,uMsg
	.if eax==WM_INITDIALOG
		call	reinit
		invoke	SendDlgItemMessage,hDlg,400,LVM_SETEXTENDEDLISTVIEWSTYLE,LVS_EX_ONECLICKACTIVATE or LVS_EX_CHECKBOXES or LVS_EX_FULLROWSELECT,LVS_EX_ONECLICKACTIVATE or LVS_EX_CHECKBOXES or LVS_EX_FULLROWSELECT
		mov	lvcol.imask,LVCF_FMT or LVCF_TEXT or LVCF_WIDTH
		mov	lvcol.fmt,LVCFMT_LEFT
		mov	lvcol.lx,183
		mov	lvcol.pszText,offset col1
		mov	lvcol.cchTextMax,12
		mov	lvcol.iSubItem,0
		invoke	SendDlgItemMessage,hDlg,400,LVM_INSERTCOLUMN,0,addr lvcol
		mov	lvcol.lx,162
		mov	lvcol.pszText,offset col2
		mov	lvcol.cchTextMax,3
		invoke	SendDlgItemMessage,hDlg,400,LVM_INSERTCOLUMN,1,addr lvcol
		push	hDlg
		pop	maxfsize
		push	ebp
		mov	edi,lParam
		lea	ebp,lvins_
		mov	diridx,1
		call	testforums
		pop	ebp
		.if eax==0
			push	ebp
			mov	edi,lParam
			mov	tbltopic,0
			mov	tbltopic[4],0
			mov	tbltopicf,0
			mov	tbltopicf[4],0
			mov	tblposts,0
			mov	tblposts[4],0
			mov	edi,lParam
			mov	diridx,1
			mov	forum_sim,0
			mov	topic_sim,0
			inithist
			mov	edi,lParam
			mov	esi,recvbuf
			call	getformat
			pop	ebp
			push	ebp
			mov	edi,lParam
			lea	edx,[edi].tdtbl
			mov	stbl,edx
			lea	ebp,chkdirs
			mov	esi,recvbuf
			call	checkdirs
			pop	ebp
			push	ebp
			mov	edi,lParam
			lea	edx,[edi].tdtbl
			call	scantbl
			pop	ebp
			push	ebp
			mov	edi,lParam
			lea	edx,[edi].tdtbl
			mov	stbl,edx
			lea	ebp,showdirs
			mov	esi,recvbuf
			lea	edx,defdir
			.while byte ptr[edx]
				inc	edx
			.endw
			call	savedirs
			pop	ebp
		.endif
		invoke	SendDlgItemMessage,hDlg,400,LVM_GETITEMCOUNT,0,0
		.if eax<100
			mov	w2num,0
		.elseif eax<1000
			mov	w2num,1
		.elseif eax<10000
			mov	w2num,2
		.else
			mov	w2num,3
		.endif
	.elseif eax==WM_COMMAND
		mov	eax,wParam
		.if eax==2
			invoke	EndDialog,hDlg,0
		.elseif eax==1
			lea	edi,forums
			invoke	SendDlgItemMessage,hDlg,400,LVM_GETITEMCOUNT,0,0
			xor	ecx,ecx
			mov	edx,eax
			.while ecx<edx
				push	ecx
				push	edx
				invoke	SendDlgItemMessage,hDlg,400,LVM_GETITEMSTATE,ecx,LVIS_STATEIMAGEMASK
				pop	edx
				and	eax,8192
				shr	eax,13
				stosb
				pop	ecx
				inc	ecx
			.endw
			invoke	EndDialog,hDlg,0
		.endif
	.endif
	xor	eax,eax
	ret
dlgsf1	ENDP

getform:push	0
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			inc	esi
			mov	eax,[esi]
			or	eax,20202020h
			.break .if eax=='rof/'
			.if eax=='upni'
				lea	esi,[esi+4]
				mov	al,[esi]
				or	al,20h
				.if (al=='t')&&(byte ptr[esi+1]==32)
					inc	esi
					inc	esi
					xor	ecx,ecx
					.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='<')&&(byte ptr[esi+ecx]!='>')
						mov	eax,[esi+ecx]
						or	eax,20202020h
						.if eax=='eman'
							lea	ecx,[ecx+4]
							.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]<33)
								inc	ecx
							.endw
							.if (byte ptr[esi+ecx]=='=')
								inc	ecx
								.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]<33)
									inc	ecx
								.endw
								mov	dl,[esi+ecx]
								.if (byte ptr[esi+ecx]==34)||(byte ptr[esi+ecx]==39)
									inc	ecx
								.endif
								.if (byte ptr[edi-1]!='&')&&(byte ptr[edi-1]!='?')
									mov	al,'&'
									stosb
								.endif
								.while (byte ptr[esi+ecx]!=39)&&(byte ptr[esi+ecx]!=34)&&(byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='<')&&(byte ptr[esi+ecx]!='>')
									.if (dl!=34)&&(dl!=39)
										.break .if byte ptr[esi+ecx]<33
									.endif
									mov	al,[esi+ecx]
									stosb
									inc	ecx
								.endw
								mov	al,'='
								stosb
								.break
							.endif
						.endif
						inc	ecx
					.endw
					.if byte ptr[edi-1]=='='
						xor	ecx,ecx
						xor	eax,eax
						.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='<')&&(byte ptr[esi+ecx]!='>')
							mov	eax,[esi+ecx]
							or	eax,20202020h
							.if eax=='epyt'
								lea	ecx,[ecx+4]
								.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]<33)
									inc	ecx
								.endw
								.if (byte ptr[esi+ecx]=='=')
									inc	ecx
									.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]<33)
										inc	ecx
									.endw
									.if (byte ptr[esi+ecx]==34)||(byte ptr[esi+ecx]==39)
										inc	ecx
									.endif
									mov	eax,[esi+ecx]
									.break
								.endif
							.endif
							inc	ecx
						.endw
						.if eax=='ssap'
							lea	edx,_password
							call	copyedx
						.elseif eax=='txet'
							lea	edx,_user
							call	copyedx
						.else
							xor	ecx,ecx
							.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='<')&&(byte ptr[esi+ecx]!='>')
								mov	eax,[esi+ecx]
								or	eax,20202020h
								.if eax=='ulav'
									lea	ecx,[ecx+4]
									mov	al,[esi+ecx]
									or	al,20h
									.if al=='e'
										inc	ecx
										.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]<33)
											inc	ecx
										.endw
										.if (byte ptr[esi+ecx]=='=')
											inc	ecx
											.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]<33)
												inc	ecx
											.endw
											.if (byte ptr[esi+ecx]==34)||(byte ptr[esi+ecx]==39)
												inc	ecx
											.endif
											.while (byte ptr[esi+ecx]!=39)&&(byte ptr[esi+ecx]!=34)&&(byte ptr[esi+ecx]>32)&&(byte ptr[esi+ecx]!='<')&&(byte ptr[esi+ecx]!='>')
												mov	al,[esi+ecx]
												stosb
												inc	ecx
											.endw
											.break
										.endif
									.endif
								.endif
								inc	ecx
							.endw
						.endif
					.endif
				.endif
			.elseif eax=='eles'
				xor	ecx,ecx
				.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='<')&&(byte ptr[esi+ecx]!='>')
					mov	eax,[esi+ecx]
					or	eax,20202020h
					.if eax=='eman'
						lea	ecx,[ecx+4]
						.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]<33)
							inc	ecx
						.endw
						.if (byte ptr[esi+ecx]=='=')
							inc	ecx
							.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]<33)
								inc	ecx
							.endw
							.if (byte ptr[esi+ecx]==34)||(byte ptr[esi+ecx]==39)
								inc	ecx
							.endif
							mov	dword ptr[esp],esi
							.break
						.endif
					.endif
					inc	ecx
				.endw
			.elseif eax=='itpo'
				xor	ecx,ecx
				.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='<')&&(byte ptr[esi+ecx]!='>')
					mov	eax,[esi+ecx]
					or	eax,20202020h
					.if (eax=='eles')&&(dword ptr[esp]!=0)
						xor	ecx,ecx
						.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='<')&&(byte ptr[esi+ecx]!='>')
							mov	eax,[esi+ecx]
							or	eax,20202020h
							.if eax=='ulav'
								lea	ecx,[ecx+4]
								mov	al,[esi+ecx]
								or	al,20h
								.if al=='e'
									.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]<33)
										inc	ecx
									.endw
									.if (byte ptr[esi+ecx]=='=')
										mov	edx,[esp]
										.if (byte ptr[edi-1]!='&')&&(byte ptr[edi-1]!='?')
											mov	al,'&'
											stosb
										.endif
										.while (byte ptr[edx]!=39)&&(byte ptr[edx]!=34)&&(byte ptr[edx]>32)&&(byte ptr[edx]!='<')&&(byte ptr[edx]!='>')
											mov	al,[edx]
											stosb
											inc	edx
										.endw
										mov	al,'='
										stosb
										inc	ecx
										.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]<33)
											inc	ecx
										.endw
										.if (byte ptr[esi+ecx]==34)||(byte ptr[esi+ecx]==39)
											inc	ecx
										.endif
										.while (byte ptr[esi+ecx]!=39)&&(byte ptr[esi+ecx]!=34)&&(byte ptr[esi+ecx]>32)&&(byte ptr[esi+ecx]!='<')&&(byte ptr[esi+ecx]!='>')
											mov	al,[esi+ecx]
											stosb
											inc	ecx
										.endw
										mov	dword ptr[esp],0
										.break
									.endif
								.endif
							.endif
							inc	ecx
						.endw
					.endif
					inc	ecx
				.endw
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	eax
	ret

lstate1	db	'*** Loading forum index...',13,10,0
lstate2	db	'[ X ] Login form was not found',13,10,0
lstate3	db	'*** Sending login information...',13,10,0
lstate4	db	'[ X ] No cookies were returned by server',13,10,0
lstate5	db	'*** Cookies:',13,10,0
lstate6	db	'*** Searching for login page...',13,10,0
lstate7	db	'[ X ] Login apparently failed.',13,10,0
assume	edi:ptr foruminfo
get_lform:
	push	edi
	movzx	eax,dltype
	push	eax
	mov	dltype,3
	push	edx
	invoke	getfile,edx,1,0,8192
	pop	edx
	pop	eax
	mov	dltype,al
	mov	hfile,0
	pop	edi
	push	edi
	lea	edi,[edi].saddr
	mov	ecx,sizeof sockaddr_in
	xor	eax,eax
	stosb
	pop	edi
	mov	[edi].saddr.sin_port,80*256
	mov	[edi].saddr.sin_family,AF_INET
	lea	esi,[edi]._addr
	mov	eax,[esi]
	or	eax,20202020h
	.if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+6]=='/')
		lea	esi,[esi+7]
	.endif
	push	edi
	lea	edi,[edi]._dns
	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=':')&&(byte ptr[esi]!='/')&&(byte ptr[esi]!='\')
		movsb
	.endw
	mov	al,0
	stosb
	pop	edi
	push	edi
	.if byte ptr[esi]==':'
		inc	esi
		call	atoi
		xchg	al,ah
		mov	[edi].saddr.sin_port,ax
	.endif
	pop	edi
	push	edi
	lea	edi,[edi]._file
	.while byte ptr[esi]
		movsb
	.endw
	mov	al,0
	stosb
	pop	edi
	ret


loginproc	PROC	lParam:DWORD
	local	r_buf:DWORD
	lea	edx,lstate1
	call	showmsg
	invoke	GlobalAlloc,GPTR,8192
	mov	r_buf,eax
	invoke	GlobalAlloc,GPTR,sizeof foruminfo
	mov	lParam,eax
	mov	edi,eax

	mov	edi,lParam
	push	edi
	lea	edx,_cookies[1]
	lea	edi,[edi]._addr
	call	copyedx
	mov	al,0
	stosb
	pop	edi
	lea	edx,r_buf
	call	get_lform
	mov	esi,r_buf
	call	_detect

	lea	edx,r_buf
	mov	esi,r_buf
	invoke	lform,lParam
	.if eax==0
		lea	edx,lstate6
		call	showmsg
		mov	esi,r_buf
		.while byte ptr[esi]
			mov	ax,[esi]
			or	ax,2000h
			.if (ax=='a<')&&(byte ptr[esi+2]<33)
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					mov	eax,[esi]
					or	eax,20202020h
					.if eax=='ferh'
						lodsd
						.while ((byte ptr[esi]<33)&&(byte ptr[esi]!=0))||(byte ptr[esi]==34)||(byte ptr[esi]==39)
							inc	esi
						.endw
						push	esi
						call	is_internal
						.if eax
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								inc	esi
							.endw
							.if byte ptr[esi]=='>'
								inc	esi
								.while byte ptr[esi]
									.if byte ptr[esi]=='&'
										.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=';')
											inc	esi
										.endw
										.if byte ptr[esi]==';'
											inc	esi
										.endif
									.elseif byte ptr[esi]<=32
										inc	esi
									.else
										.break
									.endif
								.endw
								mov	ax,[esi]
								or	ax,2020h
								.if (ax=='ol')&&((byte ptr[esi+2]=='g')||(byte ptr[esi+2]=='G'))
									lea	esi,[esi+3]
									.while byte ptr[esi]
										.if byte ptr[esi]=='&'
											.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=';')
												inc	esi
											.endw
											.if byte ptr[esi]==';'
												inc	esi
											.endif
										.elseif byte ptr[esi]<=32
											inc	esi
										.else
											.break
										.endif
									.endw
									mov	ax,[esi]
									or	ax,2020h
									.if ax=='ni'
										pop	esi
										push	esi
										mov	edi,lParam
										push	edi
										lea	edi,[edi]._addr
										call	copylink
										pop	edi
										call	get_lform
										mov	esi,r_buf
										lea	edx,r_buf
										push	r_buf
										invoke	lform,lParam
										pop	edx
										sub	edx,r_buf
										sub	esi,edx
										.if eax
											pop	edx
											jmp	log_ex
										.endif
									.endif
								.endif
							.endif
						.endif
						pop	eax
					.endif
					inc	esi
				.endw
			.else
				inc	esi
			.endif
		.endw
		lea	edx,lstate2
		call	showmsg
	.endif
log_ex:	invoke	GlobalFree,r_buf
	invoke	GlobalFree,lParam
	invoke	CloseHandle,hLogin
	invoke	ExitThread,0
	ret
loginproc	ENDP

lform	PROC	uses esi lParam:DWORD
	local	r_buf:DWORD,lastform:DWORD,b_read:DWORD,f_size:DWORD,rbsize:DWORD,rbptr:DWORD
	mov	r_buf,esi
	mov	rbptr,edx
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			mov	eax,[esi+1]
			or	eax,20202020h
			.if eax=='mrof'
				mov	lastform,esi
				.while byte ptr[esi]
					.if byte ptr[esi]=='<'
						.if byte ptr[esi+1]=='/'
							mov	eax,[esi+2]
							or	eax,20202020h
							.break .if eax=='mrof'
							inc	esi
						.else
							inc	esi
							mov	eax,[esi]
							or	eax,20202020h
							.if eax=='upni'
								.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='<')
									mov	eax,[esi]
									or	eax,20202020h
									.if eax=='pyt '
										lea	esi,[esi+4]
										mov	al,[esi]
										or	al,20h
										.if al=='e'
											inc	esi
											.while (byte ptr[esi]!=0)&&(byte ptr[esi]<33)
												inc	esi
											.endw
											.if byte ptr[esi]=='='
												inc	esi
												.while (byte ptr[esi]!=0)&&(byte ptr[esi]<33)
													inc	esi
												.endw
												.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
													inc	esi
												.endif
												mov	eax,[esi]
												or	eax,20202020h
												.if eax=='ssap'
													jmp	_ffound
												.endif
											.endif
										.endif
									.else
										inc	esi
									.endif
								.endw
							.else
								inc	esi
							.endif
						.endif
					.else
						inc	esi
					.endif
				.endw
			.else
				inc	esi
			.endif
		.else
			inc	esi
		.endif
	.endw
	xor	eax,eax
	ret

_ffound:mov	esi,lastform
	.if byte ptr[esi]=='<'
		inc	esi
	.endif
	mov	edi,r_buf
	mov	byte ptr[edi],0
	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='<')
		mov	eax,[esi]
		or	eax,20202020h
		.if ax=='ca'
			mov	eax,[esi+2]
			or	eax,20202020h
			.if eax=='noit'
				lea	esi,[esi+6]
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]<33)
					inc	esi
				.endw
				.if byte ptr[esi]=='='
					inc	esi
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]<33)
						inc	esi
					.endw
					.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
						inc	esi
					.endif
					mov	edi,lParam
					lea	edi,[edi]._addr
					mov	eax,dword ptr[edi]
					or	eax,20202020h
					.if (eax=='ptth')&&(word ptr[edi+4]=='/:')&&(byte ptr[edi+6]=='/')
						lea	edi,[edi+7]
					.endif
					mov	eax,[esi]
					or	eax,20202020h
					.if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+6]=='/')
						lea	esi,[esi+7]
					;	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
					;		.break .if byte ptr[esi]=='/'
					;		inc	esi
					;	.endw
					;	mov	edx,edi
					;	.while byte ptr[edi]
					;		.if byte ptr[edi]=='/'
					;			mov	edx,edi
					;		.endif
					;		inc	edi
					;	.endw
					;	mov	edi,edx
					;	mov	al,'/'
					;	stosb
					.elseif byte ptr[esi]=='/'
						.while (byte ptr[edi]!='/')&&(byte ptr[edi]!=0)
							inc	edi
						.endw
					.else
						mov	edx,edi
						mov	eax,edi
						.while byte ptr[edi]
							.if byte ptr[edi]=='/'
								mov	edx,edi
							.endif
							inc	edi
						.endw
						.if eax!=edx
							mov	edi,edx
						.endif
						mov	al,'/'
						stosb
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
						lodsb
						.if al=='&'
							mov	eax,[esi]
							or	eax,202020h
							.if eax==';pma'
								lodsd
							.endif
							mov	al,'&'
						.else
							mov	eax,[esi-1]
							or	eax,20202020h
							.if eax=='=dis'
								.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
									inc	esi
								.endw
								.continue
							.elseif eax=='sphp'
								mov	eax,[esi+3]
								or	eax,20202020h
								.if eax=='isse'
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
										inc	esi
									.endw
									.continue
								.endif
							.elseif ax=='=s'
								mov	eax,2
								.while ((byte ptr[esi+eax]>='0')&&(byte ptr[esi+eax]<='9'))||((byte ptr[esi+eax]>='a')&&(byte ptr[esi+eax]<='f'))||((byte ptr[esi+eax]>='A')&&(byte ptr[esi+eax]<='F'))
									inc	eax
								.endw
								.if eax>8
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
										inc	esi
									.endw
									.continue
								.endif
							.endif
							mov	al,[esi-1]
						.endif
						stosb
					.endw
					.if byte ptr[edi-1]=='&'
						dec	edi
					.endif
					.if byte ptr[edi-1]=='?'
						dec	edi
					.endif
					mov	al,0
					stosb
				.endif
			.else
				inc	esi
			.endif
		.elseif eax=='htem'
			mov	ax,[esi+4]
			or	ax,2020h
			.if ax=='do'
				lea	esi,[esi+6]
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]<33)
					inc	esi
				.endw
				.if byte ptr[esi]=='='
					inc	esi
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]<33)
						inc	esi
					.endw
					.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
						inc	esi
					.endif
					mov	ax,[esi]
					or	ax,2020h
					.if ax=='eg'
						mov	edi,r_buf
						mov	eax,' TEG'
						stosd
						mov	al,0
						stosb
					.elseif ax=='op'
						mov	edi,r_buf
						mov	eax,'TSOP'
						stosd
						mov	ax,32
						stosw
					.else
						int 3
					.endif
				.endif
			.else
				inc	esi
			.endif
		.else
			inc	esi
		.endif
	.endw
	lea	edx,lstate3
	call	showmsg
	mov	lastform,esi
	mov	edi,r_buf
	.if byte ptr[edi]=='G'
		lea	edi,[edi+4]
	.else
		lea	edi,[edi+5]
	.endif
	push	edi
	mov	edi,lParam
	.if proxyflag&1
		lea	edx,[edi]._addr
		pop	edi
		mov	eax,[edx]
		or	eax,20202020h
		.if eax!='ptth'
			mov	eax,'ptth'
			stosd
			mov	eax,'//:'
			stosd
			dec	edi
		.endif
	.else
		lea	edx,[edi]._addr
		mov	eax,[edx]
		or	eax,20202020h
		.if eax=='ptth'
			lea	edx,[edx+4]
			.if byte ptr[edx]==':'
				inc	edx
			.endif
			.if byte ptr[edx]=='/'
				inc	edx
			.endif
			.if byte ptr[edx]=='/'
				inc	edx
			.endif
		.endif
		.while (byte ptr[edx]!='/')&&(byte ptr[edx]!=0)
			inc	edx
		.endw
		pop	edi
		.if byte ptr[edx]!='/'
			mov	al,'/'
			stosb
		.endif
	.endif
	call	copyedx
	mov	eax,r_buf
	.if byte ptr[eax]=='G'
		mov	edx,edi
		dec	edx
		.while edx>r_buf
			.break .if byte ptr[edx]=='?'
			dec	edx
		.endw
		.if byte ptr[edx]!='?'
			mov	al,'?'
			stosb
		.endif
		push	edi
		mov	esi,lastform
		call	getform
		pop	edx
		mov	ecx,edi
		sub	ecx,edx
		mov	lastform,ecx
	.endif
	assume	ebx:nothing

	call	ua_01
	push	edi
	mov	edi,lParam
	lea	edx,[edi]._dns
	pop	edi
	call	copyedx
	mov	ax,0a0dh
	stosw
	lea	edx,http8
	call	copyedx
	call	ua_02
	call	ua_03b
	mov	edx,r_buf
	.if byte ptr[edx]=='P'
		dec	edi
		dec	edi
		lea	edx,http7
		call	copyedx
		mov	byte ptr[edi-1],'&'
		push	edi
		mov	esi,lastform
		call	getform
		mov	ecx,edi
		pop	edi
		mov	byte ptr[edi-1],32
		sub	ecx,edi
		mov	eax,ecx
		call	itoa
		mov	ax,0a0dh
		stosw
		stosw
		mov	byte ptr[edi-1],'&'
		push	edi
		mov	esi,lastform
		call	getform
		pop	edx
		mov	byte ptr[edx-1],10
	.else
		mov	ax,0a0dh
		stosw
	.endif
	mov	al,0
	stosb
	mov	edi,lParam
re_res:	.if proxyflag&1
		mov	eax,proxyip
		.if eax==0
			push	edi
			lea	edi,buftmp
			lea	edx,_proxy
			.while (byte ptr[edx]!=0)&&(byte ptr[edx]!=':')
				mov	al,[edx]
				stosb
				inc	edx
			.endw
			mov	al,0
			stosb
			.if byte ptr[edx]==':'
				inc	edx
				push	esi
				mov	esi,edx
				call	atoi
				pop	esi
				xchg	al,ah
				pop	edi
				push	edi
				mov	[edi].saddr.sin_port,ax
				mov	proxyport,ax
			.endif
			pop	edi
			invoke	inet_addr,addr buftmp
			.if eax==INADDR_NONE
				invoke	gethostbyname,addr buftmp
				.if eax!=0
					mov	eax,[eax+12]
					mov	eax,[eax]
					mov	eax,[eax]
				.endif
			.endif
		.endif
	.else
		invoke	inet_addr,addr [edi]._dns
		.if eax==INADDR_NONE
			invoke	gethostbyname,addr [edi]._dns
			.if eax!=0
				mov	eax,[eax+12]
				mov	eax,[eax]
				mov	eax,[eax]
			.endif
		.endif
	.endif
	.if eax==0
		push	edi
		lea	edi,[edi]._msg
		push	edi
		lea	edx,wsaerr2
		call	copyedx
		push	edi
		mov	edi,lParam
		lea	edx,[edi]._dns
		pop	edi
		call	copyedx
		lea	edx,wsaerr2a
		call	copyedx
		invoke	WSAGetLastError
		push	eax
		call	itoa
		mov	ax,0a0dh
		stosw
		mov	al,0
		stosb
		pop	eax
		pop	edx
		push	eax
		call	showmsg
		pop	eax
		pop	edi
		xor	eax,eax
		ret
	;	invoke	CloseHandle,hLogin
	;	invoke	ExitThread,0
	;	ret
	.endif
	mov	[edi].saddr.sin_addr,eax
	mov	fsize,0
	mov	maxfsize,0
	invoke	socket,PF_INET,SOCK_STREAM,IPPROTO_TCP
	.if eax==INVALID_SOCKET
		push	edi
		lea	edi,[edi]._msg
		push	edi
		lea	edx,wsaerr1
		call	copyedx
		call	wsaerr
		mov	ax,0a0dh
		stosw
		mov	al,0
		stosb
		pop	edx
		call	showmsg
		pop	edi
		xor	eax,eax
		ret
	;	invoke	CloseHandle,hLogin
	;	invoke	ExitThread,0
	;	ret
	.endif
	mov	[edi].hSocket,eax
	invoke	ioctlsocket,[edi].hSocket,FIONBIO,addr _blocking
	invoke	connect,[edi].hSocket,addr [edi].saddr,sizeof sockaddr_in
	.if eax!=0
		push	edi
		lea	edi,[edi]._msg
		push	edi
		lea	edx,wsaerr5
		call	copyedx
		push	edi
		mov	edi,lParam
		lea	edx,[edi]._dns
		pop	edi
		call	copyedx
		lea	edx,wsaerr6
		call	copyedx
		call	wsaerr
		mov	ax,0a0dh
		stosw
		mov	al,0
		stosb
		pop	edx
		call	showmsg
		pop	edi
		invoke	closesocket,[edi].hSocket
		xor	eax,eax
		ret
	;	invoke	CloseHandle,hLogin
	;	invoke	ExitThread,0
	;	ret
	.endif
	xor	ecx,ecx
	mov	eax,r_buf
	.while byte ptr[eax+ecx]
		inc	ecx
	.endw
;	mov edx,r_buf
;	call showmsg
	invoke	send,[edi].hSocket,r_buf,ecx,0
	.if eax==SOCKET_ERROR
		push	edi
		lea	edi,[edi]._msg
		push	edi
		lea	edx,wsaerr3
		call	copyedx
		call	wsaerr
		lea	edx,wsaerra
		call	copyedx
		mov	ax,0a0dh
		stosw
		mov	al,0
		stosb
		pop	edx
		call	showmsg
		pop	edi
		invoke	closesocket,[edi].hSocket
		xor	eax,eax
		ret
	;	invoke	CloseHandle,hLogin
	;	invoke	ExitThread,0
	;	ret
	.endif
	mov	f_size,0

	mov	edx,[edi].hSocket
	mov	[edi]._file,0
	mov	edi,r_buf
	mov	rbsize,8192
	.while 1
		mov	eax,f_size
		lea	ecx,[eax+8192]
		.if ecx>=rbsize
			push	edx
			push	eax
			mov	eax,rbsize
			lea	eax,[eax+65536]
			invoke	GlobalAlloc,GPTR,eax
			pop	ecx
			push	esi
			mov	edi,eax
			mov	esi,r_buf
			push	esi
			mov	r_buf,eax
			mov	edx,rbptr
			mov	[edx],eax
			cld
			.if ecx
				rep	movsb
			.endif
			call	GlobalFree
			add	rbsize,65536
			pop	esi
			pop	edx
		.endif
		assume	edi:ptr fd_set
		push	edx
		mov	[edi].fd_count,1
		mov	[edi].fd_array,edx
		lea	ecx,[edi+100]
		assume	ecx:ptr timeval
		mov	[ecx].tv_sec,timeout
		mov	[ecx].tv_usec,0
		invoke	select,1,edi,0,0,ecx
		pop	edx
		assume	edi:ptr foruminfo
		.if eax==0
			lea	edx,wsaerr7a
			call	showmsg
			.break
		.elseif eax==SOCKET_ERROR
r_err:			mov	edi,lParam
			lea	edi,[edi]._msg
			push	edi
			lea	edx,wsaerr4
			call	copyedx
			call	wsaerr
			lea	edx,wsaerra
			call	copyedx
			mov	ax,0a0dh
			stosw
			mov	al,0
			stosb
			pop	edx
			call	showmsg
			xor	eax,eax
			.break
		.endif
		assume	edx:nothing
		push	edx
		mov	b_read,0
		invoke	ioctlsocket,edx,FIONREAD,addr b_read
		pop	edx
		.if eax==SOCKET_ERROR
			jmp	r_err
		.endif
		.if b_read>8192
			mov	b_read,8192
		.endif
		mov	eax,b_read
		mov	edi,r_buf
		add	edi,f_size
		.if eax
			push	edx
			invoke	recv,edx,edi,b_read,0
			pop	edx
		.endif
		.break .if eax==0
		.if eax==SOCKET_ERROR
			xor	eax,eax
		.endif
		add	f_size,eax
		mov	edi,r_buf
		mov	ecx,f_size
		mov	byte ptr[edi+ecx],0
		lea	edi,[edi+ecx]
	;	.if ecx>4
	;		sub	ecx,4
	;		.while ecx
	;			.break .if dword ptr[edi]==0a0d0a0dh
	;			inc	edi
	;			dec	ecx
	;		.endw
	;		.break .if dword ptr[edi]==0a0d0a0dh
	;	.endif
	.endw
	mov	edi,lParam
	invoke	closesocket,[edi].hSocket

	mov	esi,r_buf
	mov	ecx,f_size
	mov	byte ptr[esi+ecx],0
	xor	edx,edx
	.while byte ptr[esi+edx]
		.break .if dword ptr[esi+edx]==0a0d0a0dh
		inc	edx
	.endw
	.while byte ptr[esi+edx]
		mov	eax,[esi+edx+1]
		or	eax,20202020h
		.if (byte ptr[esi+edx]=='<')&&(eax=='mrof')
			.while byte ptr[esi+edx]
				mov	eax,[esi+edx+2]
				or	eax,20202020h
				.break .if (word ptr[esi+edx]=='/<')&&(eax=='mrof')
				mov	eax,[esi+edx+1]
				or	eax,20202020h
				.if (byte ptr[esi+edx]=='<')&&(eax=='upni')
					.while byte ptr[esi+edx]
						mov	eax,[esi+edx]
						or	eax,20202020h
						.if eax=='epyt'
							lea	edx,[edx+4]
							.while ((byte ptr[esi+edx]!=0)&&(byte ptr[esi+edx]<33))||(byte ptr[esi+edx]==39)||(byte ptr[esi+edx]==34)||(byte ptr[esi+edx]=='=')
								inc	edx
							.endw
							mov	eax,[esi+edx]
							or	eax,20202020h
							.if eax=='ssap'
								mov	rbsize,0
								.break
							.endif
						.else
							inc	edx
						.endif
					.endw
				.else
					inc	edx
				.endif
				.break .if rbsize==0
			.endw
		.elseif (ax==' a')&&(byte ptr[esi+edx]=='<')
			.while byte ptr[esi+edx]
				mov	al,[esi+edx+2]
				or	al,20h
				.break .if (word ptr[esi+edx]=='/<')&&(al=='a')
				inc	edx
			.endw
		.else
			mov	eax,[esi+edx]
			or	eax,20202020h
			.if (eax=='resu')||(eax=='avni')||(eax=='ocni')||(eax=='ssap')||(eax=='orre')
				push	0
				.while (byte ptr[esi+edx]!=0)&&(byte ptr[esi+edx]!='<')&&(byte ptr[esi+edx]!='>')
					mov	eax,[esi+edx]
					or	eax,20202020h
					.if (eax=='ocni')
						mov	eax,[esi+edx+4]
						or	eax,20202020h
						.if eax=='cerr'
							or	byte ptr[esp],1
						.endif
					.elseif eax=='avni'
						mov	ax,[esi+edx+4]
						or	ax,2020h
						.if ax=='il'
							or	byte ptr[esp],1
						.endif
					.elseif eax=='orre'
						mov	al,[esi+edx+4]
						or	al,20h
						.if al=='r'
							or	byte ptr[esp],1
						.endif
					.elseif eax=='ssap'
						mov	eax,[esi+edx+4]
						or	eax,20202020h
						.if eax=='drow'
							or	byte ptr[esp],2
						.endif
					.endif
					inc	edx
				.endw
				pop	eax
				.if al==3
					mov	rbsize,0
					.break
				.endif
			.else
				inc	edx
			.endif
		.endif
		.break .if rbsize==0
	.endw
	lea	edi,_cookies
	mov	eax,'kooC'
	stosd
	mov	eax,' :ei'
	stosd
	.if ecx>4
		sub	ecx,4
		xor	edx,edx
		.while ecx
			.if (byte ptr[esi]==13)||(byte ptr[esi]==10)
				mov	dl,0
			.elseif dl==0
				mov	eax,[esi]
				or	eax,202020h
				.if eax=='-tes'
					mov	eax,[esi+4]
					or	eax,20202020h
					.if eax=='kooc'
						mov	ax,[esi+8]
						or	ax,2020h
						.if ax=='ei'
							lea	esi,[esi+10]
							.if byte ptr[esi]==':'
								inc	esi
							.endif
							.while byte ptr[esi]==32
								inc	esi
							.endw
							.if (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=';')&&(byte ptr[esi]!=0)
								.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=';')&&(byte ptr[esi]!=0)
									movsb
								.endw
								mov	ax,' ;'
								stosw
								mov	dh,1
							.endif
						.endif
					.endif
				.endif
				mov	dl,1
			.endif
			.break .if dword ptr[esi]==0a0d0a0dh
			inc	esi
			dec	ecx
		.endw
	.endif
	.if dh==1
		.if word ptr[edi-2]==' ;'
			sub	edi,2
		.endif
		mov	ax,0a0dh
		stosw
		push	edi
		push	edi
		lea	edx,lstate5
		call	copyedx
		lea	edx,_cookies[8]
		.while byte ptr[edx]>=32
			mov	al,9
			stosb
			.while (byte ptr[edx]>=32)&&(byte ptr[edx]!=';')&&(byte ptr[edx]!='=')
				mov	al,[edx]
				stosb
				inc	edx
			.endw
			.while (byte ptr[edx]>=32)&&(byte ptr[edx]!=';')
				inc	edx
			.endw
			.while (byte ptr[edx]==32)||(byte ptr[edx]==';')
				inc	edx
			.endw
			mov	ax,0a0dh
			stosw
		.endw
		mov	al,0
		stosb
		pop	edx
		call	showmsg
		pop	edi
	.else
		lea	edi,_cookies
		lea	edx,lstate4
		call	showmsg
	.endif
	mov	al,0
	stosb
	lea	edi,_cookies[8]
	.while byte ptr[edi]
		lea	edx,[edi+1]
		.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=0)
			.while (byte ptr[edx]!=';')&&(byte ptr[edx]!=13)&&(byte ptr[edx]!=0)
				inc	edx
			.endw
			.break .if byte ptr[edx]!=';'
			.while (byte ptr[edx]==';')||(byte ptr[edx]==' ')
				inc	edx
			.endw
			xor	ecx,ecx
			.while (byte ptr[edi+ecx]!='=')&&(byte ptr[edi+ecx]!=13)&&(byte ptr[edi+ecx]!=';')
				mov	al,byte ptr [edi+ecx]
				mov	ah,byte ptr [edx+ecx]
				or	ax,2020h
				.break .if al!=ah
				inc	ecx
			.endw
			.if (byte ptr[edx+ecx]=='=')&&(byte ptr[edi+ecx]=='=')
				push	esi
				push	edi
				mov	esi,edi
				.while (byte ptr[esi]!=';')&&(byte ptr[esi]!=13)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
				.while (byte ptr[esi]==';')||(byte ptr[esi]==32)
					inc	esi
				.endw
				.while byte ptr[esi]
					movsb
				.endw
				movsb
				pop	edi
				pop	esi
				lea	edx,[edi+1]
			.endif
		.endw
		.while (byte ptr[edi]!=';')&&(byte ptr[edi]!=13)&&(byte ptr[edi]!=0)
			inc	edi
		.endw
		.break .if byte ptr[edi]!=';'
		.while (byte ptr[edi]==';')||(byte ptr[edi]==' ')
			inc	edi
		.endw
	.endw
	.if rbsize==0
		lea	edx,lstate7
		call	showmsg
	.endif

	xor	eax,eax
	inc	eax
	ret
;	invoke	CloseHandle,hLogin
;	invoke	ExitThread,0
;	ret

lform	ENDP

newcookies	PROC	uses esi edi eax edx
	mov	esi,edi
	mov	ecx,eax
	.if ecx<4
		ret
	.endif
	lea	edi,_cookies
	.while (byte ptr[edi]!=0)&&(byte ptr[edi]!=13)&&(byte ptr[edi]!=10)
		inc	edi
	.endw
		sub	ecx,4
		xor	edx,edx
		.while ecx
			.if (byte ptr[esi]==13)||(byte ptr[esi]==10)
				mov	dl,0
			.elseif dl==0
				mov	eax,[esi]
				or	eax,202020h
				.if eax=='-tes'
					mov	eax,[esi+4]
					or	eax,20202020h
					.if eax=='kooc'
						mov	ax,[esi+8]
						or	ax,2020h
						.if ax=='ei'
							lea	esi,[esi+10]
							.if byte ptr[esi]==':'
								inc	esi
							.endif
							.while byte ptr[esi]==32
								inc	esi
							.endw
							.if (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=';')&&(byte ptr[esi]!=0)
								xor	eax,eax
								.while (byte ptr[esi+eax]!=13)&&(byte ptr[esi+eax]!=10)&&(byte ptr[esi+eax]!=';')&&(byte ptr[esi+eax]!=0)
									inc	eax
								.endw
								.if eax<300
									.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=';')&&(byte ptr[esi]!=0)
										movsb
									.endw
									mov	ax,' ;'
									stosw
									mov	dh,1
								.endif
							.endif
						.endif
					.endif
				.endif
				mov	dl,1
			.endif
			.break .if dword ptr[esi]==0a0d0a0dh
			inc	esi
			dec	ecx
		.endw
		.if word ptr[edi-2]==' ;'
			sub	edi,2
		.endif
		mov	ax,0a0dh
		stosw

	mov	al,0
	stosb
	lea	edi,_cookies[8]
	.while byte ptr[edi]
		lea	edx,[edi+1]
		.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=0)
			.while (byte ptr[edx]!=';')&&(byte ptr[edx]!=13)&&(byte ptr[edx]!=0)
				inc	edx
			.endw
			.break .if byte ptr[edx]!=';'
			.while (byte ptr[edx]==';')||(byte ptr[edx]==' ')
				inc	edx
			.endw
			xor	ecx,ecx
			.while (byte ptr[edi+ecx]!='=')&&(byte ptr[edi+ecx]!=13)&&(byte ptr[edi+ecx]!=';')
				mov	al,byte ptr [edi+ecx]
				mov	ah,byte ptr [edx+ecx]
				or	ax,2020h
				.break .if al!=ah
				inc	ecx
			.endw
			.if (byte ptr[edx+ecx]=='=')&&(byte ptr[edi+ecx]=='=')
				push	esi
				push	edi
				mov	esi,edi
				.while (byte ptr[esi]!=';')&&(byte ptr[esi]!=13)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
				.while (byte ptr[esi]==';')||(byte ptr[esi]==32)
					inc	esi
				.endw
				.while byte ptr[esi]
					movsb
				.endw
				movsb
				pop	edi
				pop	esi
				lea	edx,[edi+1]
			.endif
		.endw
		.while (byte ptr[edi]!=';')&&(byte ptr[edi]!=13)&&(byte ptr[edi]!=0)
			inc	edi
		.endw
		.break .if byte ptr[edi]!=';'
		.while (byte ptr[edi]==';')||(byte ptr[edi]==' ')
			inc	edi
		.endw
	.endw
	ret
newcookies	ENDP


loadcfg:invoke	GlobalAlloc,GPTR,8192
	push	eax
	lea	esi,logfile
	mov	edi,eax
	.while byte ptr[esi]
		movsb
	.endw
	mov	dword ptr[edi-4],'tad.'
	movsb
	mov	edi,[esp]
	invoke	GetFileAttributes,edi
	.if eax!=-1
		invoke	CreateFile,edi,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0
		.if eax!=INVALID_HANDLE_VALUE
			push	eax
			mov	esi,eax
			mov	edx,lensave
			mov	ecx,startsave
			invoke	ReadFile,esi,ecx,edx,addr bread,0
			loadbans
			call	CloseHandle
		.endif
	.endif
	call	GlobalFree
	ret

savecfg:invoke	GlobalAlloc,GPTR,8192
	push	eax
	mov	edi,eax
	invoke	GetModuleFileName,0,edi,8192
	mov	esi,edi
	.while byte ptr[esi]
		.if (byte ptr[esi]=='\')||(byte ptr[esi]=='/')||(byte ptr[esi]=='.')
			mov	edi,esi
		.endif
		inc	esi
	.endw
	.if (byte ptr[edi]!='.')
		mov	edi,esi
	.endif
	mov	eax,'tad.'
	stosd
	mov	al,0
	stosb
	mov	edi,[esp]
	invoke	CreateFile,edi,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0
	.if eax!=INVALID_HANDLE_VALUE
		push	eax
		mov	esi,eax
		mov	edx,lensave
		mov	ecx,startsave
		invoke	WriteFile,esi,ecx,edx,addr bread,0
		savebans
		call	CloseHandle
	.endif
	call	GlobalFree
	ret

