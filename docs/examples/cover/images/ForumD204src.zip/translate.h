trans_txt	macro
	tr_ip	db	'>>> Translator',39,'s IP: ',0
	trans_1	db	'translate.google.com',0
	trans_2	db	'/translate_c?hl=en&u=http://',0
	tr_txt	db	'Detect',0,1		;auto
	tr_txt1	db	'Arabic',0,2		;ar
		db	'Bulgarian',0,3		;bg
		db	'Catalan',0,4		;ca
		db	'Chinese',0,5		;zh-CN
		db	'Croatian',0,6		;hr
		db	'Czech',0,7		;cs
		db	'Danish',0,8		;da
		db	'Dutch',0,9		;nl
		db	'English',0,10		;en
		db	'Filipino',0,11		;tl
		db	'Finnish',0,12		;fi
		db	'French',0,13		;fr
		db	'German',0,14		;de
		db	'Greek',0,15		;el
		db	'Hebrew',0,16		;iw
		db	'Hindi',0,17		;hi
		db	'Indonesian',0,18	;id
		db	'Italian',0,19		;it
		db	'Japanese',0,20		;ja
		db	'Korean',0,21		;ko
		db	'Latvian',0,22		;lv
		db	'Lithuanian',0,23	;lt
		db	'Norwegian',0,24	;no
		db	'Polish',0,25		;pl
		db	'Portuguese',0,26	;pt
		db	'Romanian',0,27		;ro
		db	'Russian',0,28		;ru
		db	'Serbian',0,29		;sr
		db	'Slovak',0,30		;sk
		db	'Slovenian',0,31	;sl
		db	'Spanish',0,32		;es
		db	'Swedish',0,33		;sv
		db	'Ukrainian',0,34	;uk
		db	'Vietnamese',0,35	;vi
		db	0

	tr_01	db	'auto',0
	tr_02	db	'ar',0
	tr_03	db	'bg',0
	tr_04	db	'ca',0
	tr_05	db	'zh-CN',0
	tr_06	db	'hr',0
	tr_07	db	'cs',0
	tr_08	db	'da',0
	tr_09	db	'nl',0
	tr_10	db	'en',0
	tr_11	db	'tl',0
	tr_12	db	'fi',0
	tr_13	db	'fr',0
	tr_14	db	'de',0
	tr_15	db	'el',0
	tr_16	db	'iw',0
	tr_17	db	'hi',0
	tr_18	db	'id',0
	tr_19	db	'it',0
	tr_20	db	'ja',0
	tr_21	db	'ko',0
	tr_22	db	'lv',0
	tr_23	db	'lt',0
	tr_24	db	'no',0
	tr_25	db	'pl',0
	tr_26	db	'pt',0
	tr_27	db	'ro',0
	tr_28	db	'ru',0
	tr_29	db	'sr',0
	tr_30	db	'sk',0
	tr_31	db	'sl',0
	tr_32	db	'es',0
	tr_33	db	'sv',0
	tr_34	db	'uk',0
	tr_35	db	'vi',0

	tr_lang	dd	offset tr_01
		dd	offset tr_02
		dd	offset tr_03
		dd	offset tr_04
		dd	offset tr_05
		dd	offset tr_06
		dd	offset tr_07
		dd	offset tr_08
		dd	offset tr_09
		dd	offset tr_10
		dd	offset tr_11
		dd	offset tr_12
		dd	offset tr_13
		dd	offset tr_14
		dd	offset tr_15
		dd	offset tr_16
		dd	offset tr_17
		dd	offset tr_18
		dd	offset tr_19
		dd	offset tr_20
		dd	offset tr_21
		dd	offset tr_22
		dd	offset tr_23
		dd	offset tr_24
		dd	offset tr_25
		dd	offset tr_26
		dd	offset tr_27
		dd	offset tr_28
		dd	offset tr_29
		dd	offset tr_30
		dd	offset tr_31
		dd	offset tr_32
		dd	offset tr_33
		dd	offset tr_34
		dd	offset tr_35
endm

trans_init	macro
	lea	esi,tr_txt
	.while byte ptr[esi]
		invoke	SendDlgItemMessage,hDlg,1300,CB_ADDSTRING,0,esi
		.while byte ptr[esi]
			inc	esi
		.endw
		inc	esi
		mov	dl,[esi]
		inc	esi
		movzx	edx,dl
		invoke	SendDlgItemMessage,hDlg,1300,CB_SETITEMDATA,eax,edx
	.endw
	movzx	eax,srclang
	.if eax
		dec	eax
	.endif
	invoke	SendDlgItemMessage,hDlg,1300,CB_SETCURSEL,eax,0
	lea	esi,tr_txt1
	.while byte ptr[esi]
		invoke	SendDlgItemMessage,hDlg,1301,CB_ADDSTRING,0,esi
		.while byte ptr[esi]
			inc	esi
		.endw
		inc	esi
		mov	dl,[esi]
		inc	esi
		movzx	edx,dl
		invoke	SendDlgItemMessage,hDlg,1301,CB_SETITEMDATA,eax,edx
	.endw
	movzx	eax,destlang
	.if eax==0
		mov	al,8
		mov	destlang,10
	.elseif eax>2
		sub	eax,2
	.endif
	invoke	SendDlgItemMessage,hDlg,1301,CB_SETCURSEL,eax,0
	.if translit&2
		invoke	CheckDlgButton,hDlg,1003,BST_CHECKED
	.endif
endm

lang_dlg	macro
	.elseif (ax==1300)&&(bx==CBN_SELCHANGE)
		invoke	SendDlgItemMessage,hDlg,1300,CB_GETCURSEL,0,0
		.if eax!=CB_ERR
			invoke	SendDlgItemMessage,hDlg,1300,CB_GETITEMDATA,eax,0
			.if eax!=CB_ERR
				mov	srclang,al
			.endif
		.endif
	.elseif (ax==1301)&&(bx==CBN_SELCHANGE)
		invoke	SendDlgItemMessage,hDlg,1301,CB_GETCURSEL,0,0
		.if eax!=CB_ERR
			invoke	SendDlgItemMessage,hDlg,1301,CB_GETITEMDATA,eax,0
			.if eax!=CB_ERR
				mov	destlang,al
			.endif
		.endif
	.elseif ax==1003
		invoke	IsDlgButtonChecked,hDlg,1003
		.if eax==BST_CHECKED
			or	translit,2
		.else
			and	translit,2 xor -1
		.endif
endm

trans_proxy	macro
	.if ((isforum!=0)||(dltype==3))&&(translit&2)
		.if google_ip
			mov	eax,google_ip
			call	w_ip
		.else
			lea	edx,trans_1
			call	copyedx
		.endif
		lea	edx,trans_2
		call	copyedx
		push	edi
		mov	edi,lParam
		lea	edx,[edi]._dns
		pop	edi
		call	copyedx
		push	edi
		mov	edi,lParam
		lea	edx,[edi]._file
		pop	edi
		.if byte ptr[edx]!='/'
			mov	al,'/'
			stosb
		.endif
		.while byte ptr[edx]
			mov	al,[edx]
			.if al=='&'
				mov	ax,'2%'
				stosw
				mov	al,'6'
			.elseif al=='='
				mov	ax,'3%'
				stosw
				mov	al,'d'
			.elseif al=='?'
				mov	ax,'3%'
				stosw
				mov	al,'f'
			.elseif al==32
				mov	ax,'2%'
				stosw
				mov	al,'0'
			.endif
			stosb
			inc	edx
		.endw
	.endif
endm

trans_noproxy	macro
	.if ((isforum!=0)||(dltype==3))&&(translit&2)
		lea	edx,trans_2
		call	copyedx
		push	edi
		mov	edi,lParam
		lea	edx,[edi]._dns
		pop	edi
		call	copyedx
		push	edi
		mov	edi,lParam
		lea	edx,[edi]._file
		pop	edi
		.if byte ptr[edx]!='/'
			mov	al,'/'
			stosb
		.endif
		.while byte ptr[edx]
			mov	al,[edx]
			.if al=='&'
				mov	ax,'2%'
				stosw
				mov	al,'6'
			.elseif al=='='
				mov	ax,'3%'
				stosw
				mov	al,'d'
			.elseif al=='?'
				mov	ax,'3%'
				stosw
				mov	al,'f'
			.elseif al==32
				mov	ax,'2%'
				stosw
				mov	al,'0'
			.endif
			stosb
			inc	edx
		.endw
	.endif
endm

trans_host	macro
	.if ((isforum!=0)||(dltype==3))&&(translit&2)
		.if google_ip
			mov	eax,google_ip
			call	w_ip
			lea	edx,trans_2-1
		.else
			lea	edx,trans_1
		.endif
	.endif
endm

trans_lang	macro
	.if ((isforum!=0)||(dltype==3))&&(translit&2)
		mov	eax,'=ls&'
		stosd
		movzx	eax,srclang
		.if eax<=35
			.if eax
				dec	eax
			.endif
			mov	edx,tr_lang[eax*4]
			call	copyedx
		.endif
		mov	eax,'=lt&'
		stosd
		movzx	eax,destlang
		.if eax<=35
			.if eax
				dec	eax
			.endif
			mov	edx,tr_lang[eax*4]
			call	copyedx
		.endif
	.endif
endm

trans_dns	macro
	.elseif ((isforum!=0)||(dltype==3))&&(translit&2)
		.if google_ip
			mov	eax,google_ip
		.else
			invoke	inet_addr,addr trans_1
			.if eax==INADDR_NONE
				invoke	gethostbyname,addr trans_1
				.if eax!=0
					mov	eax,[eax+12]
					mov	eax,[eax]
					mov	eax,[eax]
				.endif
			.endif
		.endif
endm

trans_redir	macro
	.if ((isforum!=0)||(dltype==3))&&(translit&2)	;&&(google_ip==0)
		push	edi
		mov	edi,lParam
		lea	edx,[edi]._addr
		mov	eax,[edx]
		or	eax,20202020h
		.if (eax=='ptth')&&(word ptr[edx+4]=='/:')&&(byte ptr[edx+4+2]=='/')
			lea	edx,[edx+7]
		.endif
		.if (byte ptr[edx]<='9')&&(byte ptr[edx]>='0')
			push	esi
			mov	esi,edx
			push	edx
			call	getrange
			pop	edx
			.if (eax==ebx)&&(eax!=0)&&(eax!=-1)
				.while (byte ptr[edx]!='/')&&(byte ptr[edx]!=0)
					inc	edx
				.endw
				.if (dword ptr[edx]=='art/')&&(dword ptr[edx+4]=='alsn')
					mov	google_ip,eax
					mov	edi,lParam
					lea	edi,[edi]._msg
					push	edi
					lea	edx,tr_ip
					call	copyedx
					mov	eax,google_ip
					call	w_ip
					mov	eax,0a0dh
					stosd
					pop	edx
				.endif
			.endif
			pop	esi
		.endif
		pop	edi
	.endif
endm

trans_redir1	macro
	.if ((isforum!=0)||(dltype==3))&&(translit&2)	;&&(google_ip==0)
		push	edi
		mov	eax,[edx]
		or	eax,20202020h
		push	edx
		.if (eax=='ptth')&&(word ptr[edx+4]=='/:')&&(byte ptr[edx+4+2]=='/')
			lea	edx,[edx+7]
		.endif
		.if (byte ptr[edx]<='9')&&(byte ptr[edx]>='0')
			pop	eax
			push	esi
			push	ebx
			mov	esi,edx
			push	edx
			call	getrange
			pop	edx
			.if (eax==ebx)&&(eax!=0)&&(eax!=-1)
				.while (byte ptr[edx]!='/')&&(byte ptr[edx]!=0)
					inc	edx
				.endw
				.if (dword ptr[edx]=='art/')&&(dword ptr[edx+4]=='alsn')
					mov	google_ip,eax
					mov	edi,lParam
					lea	edi,[edi]._msg
					push	edi
					lea	edx,tr_ip
					call	copyedx
					mov	eax,google_ip
					call	w_ip
					mov	eax,0a0dh
					stosd
					pop	edx
					pop	ebx
					pop	esi
					pop	edi

					mov	fsize,0
					pop	edi
					pop	eax
					pop	edi
					mov	edi,lParam
					mov	eax,redirects
					inc	eax
					invoke	getfile,rbuf_,isforum,eax,rbsize
					set_operation	0
					ret
				.endif
			.endif
			pop	ebx
			pop	esi
		.else
			pop	edx
		.endif
		pop	edi
	.endif
endm

trans_finalize	macro
	.if (translit&2)&&(google_ip!=0)
		push	esi
		mov	esi,rbuf
		mov	edi,esi
		.while byte ptr[esi]
			.if byte ptr[esi]=='<'
				mov	eax,[esi+1]
				or	eax,20202020h
				.if eax=='naps'
					xor	ecx,ecx
					.while (byte ptr[esi+ecx]!='>')&&(byte ptr[esi+ecx]!=0)
						.if (dword ptr[esi+ecx]=='og"=')&&(dword ptr[esi+ecx+4]=='elgo')&&(dword ptr[esi+ecx+8]=='crs-')&&(dword ptr[esi+ecx+12]=='xet-')
							lea	esi,[esi+ecx]
							.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
								inc	esi
							.endw
							.if (byte ptr[esi]=='>')
								inc	esi
							.endif
							push	esi
							push	0		;span
							.while byte ptr[esi]
								mov	eax,[esi]
								or	eax,20202000h
								.if (eax=='ps/<')
									.if dword ptr[esp]
										dec	dword ptr[esp]
									.else
										.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
											inc	esi
										.endw
										.if byte ptr[esi]=='>'
											inc	esi
										.endif
										.break
									.endif
								.elseif eax=='aps<'
									inc	dword ptr[esp]
								.endif
								inc	esi
							.endw
							pop	eax

							push	esi
							push	0
							push	0		;span
							.while byte ptr[esi]
								mov	eax,[esi]
								or	eax,20202000h
								.if (eax=='ps/<')
									.if dword ptr[esp]
										dec	dword ptr[esp]
									.else
										.break
									.endif
								.elseif eax=='aps<'
									inc	dword ptr[esp]
								.elseif ((dword ptr[esi]=='>a/<')||(dword ptr[esi]=='>A/<'))&&((dword ptr[esi+4]=='>a/<')||(dword ptr[esi+4]=='>A/<'))
									inc	dword ptr[esp+4]
								.endif
								inc	esi
							.endw
							pop	eax
							pop	eax
							.if eax
								mov	edx,esi
								mov	esi,[esp+4]
								push	0
								.while esi<[esp+4]
									mov	eax,[esi]
									or	eax,20202000h
									.if (eax=='ps/<')
										.if dword ptr[esp]
											dec	dword ptr[esp]
										.else
											.break
										.endif
									.elseif eax=='aps<'
										inc	dword ptr[esp]
									.elseif ((dword ptr[esi]=='>a/<')||(dword ptr[esi]=='>A/<'))&&((dword ptr[esi+4]=='>a/<')||(dword ptr[esi+4]=='>A/<'))
										inc	dword ptr[esp+4]
									.endif
									movsb
								.endw
								pop	eax
								mov	[esp],edx
							.endif
							pop	esi
							pop	eax
							xor	ecx,ecx
							.break
						.endif
						inc	ecx
					.endw
					.if byte ptr[esi+ecx]=='>'
						movsb
					.endif
				.else
					movsb
				.endif
			.else
				movsb
			.endif
		.endw
		movsb
		mov	esi,rbuf
		mov	edi,esi
		.while byte ptr[esi]
			mov	eax,[esi]
			or	eax,20202020h
			.if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+4+2]=='/')
				movsd
				movsw
				movsb
			.endif
			.if (byte ptr[esi]>='0')&&(byte ptr[esi]<='9')
				push	esi
				call	getrange
				.if (eax==ebx)&&(eax==google_ip)&&(dword ptr[esi]=='art/')&&(dword ptr[esi+4]=='alsn')&&(dword ptr[esi+8]=='c_et')&&(byte ptr[esi+12]=='?')
					lea	esi,[esi+13]
					.while (byte ptr[esi]>32)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='<')
						.if word ptr[esi]=='=u'
							lodsw
							mov	eax,[esi]
							or	eax,20202020h
							.if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+6]=='/')
								lodsd
								lodsw
								lodsb
							.endif
							.while (byte ptr[esi]>32)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!='&')&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='<')
								lodsb
								mov	dx,[esi]
								or	dx,2020h
								.if (al=='%')&&(dx=='f2')
									mov	al,'/'
									stosb
									lodsw
								.elseif (al=='%')&&(dx=='a3')
									mov	al,':'
									stosb
									lodsw
								.elseif (al=='%')&&(dx=='d3')
									mov	al,'='
									stosb
									lodsw
								.elseif (al=='%')&&(dx=='62')
									mov	al,'&'
									stosb
									mov	eax,';pma'
									stosd
									lodsw
								.elseif (al=='%')&&(dx=='f3')
									mov	al,'?'
									stosb
									lodsw
								.else
									stosb
								.endif
							.endw
							.while (byte ptr[esi]>32)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='<')
								inc	esi
							.endw
							.break
						.else
							.while (byte ptr[esi]>32)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!='&')&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='<')
								inc	esi
							.endw
							.if byte ptr[esi]=='&'
								inc	esi
								.if dword ptr[esi]==';pma'
									lodsd
								.endif
							.endif
						.endif
					.endw
				.else
					pop	esi
					movsb
				.endif
			.else
				movsb
			.endif
		.endw
		mov	eax,edi
		sub	eax,rbuf
		mov	fsize,eax
		mov	al,0
		stosb
		pop	esi
	.endif
endm
