blockedmem	macro
	blocked1	dd	?
	blocked1s	dd	?
	blocked2	dd	?
	blocked2s	dd	?
	blocked3	dd	?
	blocked3s	dd	?
	blocked4	dd	?
	blocked4s	dd	?
	iplist		dd	?
	ipcount		dd	?
	oldeditproc	dd	?
	setban_txt0	db	11 dup(?)
	setban_txt1	db	1024 dup(?)
endm

banmsgs	macro
blockedmsg1		db	'[ X ] The link ',0
blockedmsg2		db	' has forbidden words ( "',0
blockedmsg2a		db	' points to a forbidden file ( "*.',0
blockedmsg2b		db	' resolves to a blacklisted IP: ',0
blockedmsg3		db	'" ) and was not downloaded',0

block1	db	'edit.yahoo.com',13,10
	db	'wwp.icq.com',13,10
	db	'web.icq.com',13,10
	db	'status.icq.com',13,10
	db	'danasoft.com',13,10
	db	'adbrite.com',13,10
	db	'last.fm/user',13,10
	db	'feeds.feedburner.com',13,10
	db	'http://www.mysql.com/',13,10
	db	'http://www.php.net/',13,10
	db	'http://validator.w3.org/check/referer',13,10
	db	'http://jigsaw.w3.org/css-validator/check/referer',13,10
	db	'action=search',13,10
	db	'action=register',13,10
	db	'action=login',13,10
	db	'action=help',13,10
	db	'action=printpage',13,10
	db	'action=profile',13,10
	db	'action=editWidget',13,10
	db	'act=Post',13,10
	db	'act=Login',13,10
	db	'act=report',13,10
	db	'topic=#.msg#',0
	db	'view=getlastpost',13,10
	db	'showuser=#',13,10
	db	'posting.php',0
	db	'privmsg.php',0
	db	'profile.php',0
	db	'newreply.php',0
	db	'danasoft.com',13,10
	db	'javascript:',13,10
	db	'sitemeter.com',13,10
	db	'log#.countomat.com',13,10
	db	'/ads/',13,10
	db	'http://www.addtoany.com/bookmark?linkname=',13,10
	db	'http://www.addtoany.com/bookmark.gif',13,10
	db	'http://del.icio.us/post?url=',13,10
	db	'http://digg.com/submit?',13,10
	db	'http://furl.net/storeIt.jsp?',13,10
	db	'http://blinklist.com/index.php?Action=Blink/addblink.php',13,10
	db	'http://reddit.com/submit?url=',13,10
	db	'http://feedmelinks.com/categorize?',13,10
	db	'http://www.technorati.com/faves?add',13,10
	db	'http://myweb2.search.yahoo.com/myresults/bookmarklet?',13,10
	db	'http://www.newsvine.com/_wine/save?',13,10
	db	'http://ekstreme.com/socializer/?url=',13,10
	db	'http://ma.gnolia.com/bookmarklet/add?',13,10
	db	'http://www.stumbleupon.com/submit?url=',13,10
	db	'http://www.google.com/bookmarks/mark?',13,10
	db	'http://blinkbits.com/bookmarklets/save.php?',13,10
	db	'http://netvouz.com/action/submitBookmark?url=',13,10
	db	'http://www.bloglines.com/sub/',13,10
	db	'http://www.bookmark.it/bookmark.php?url=',13,10
	db	'http://mystuff.ask.com/mysearch/QuickWebSave?',13,10
	db	'http://de.lirio.us/rubric/post?',13,10
	db	'http://slashdot.org/bookmark.pl?',13,10
	db	'http://www.facebook.com/share.php?',13,10
	db	'http://www.mixx.com/submit?page_url=',13,10
	db	'http://www.myspace.com/Modules/PostTo/Pages/',13,10
	db	'http://www.newsgator.com/ngs/subscriber',13,10
	db	'http://add.my.yahoo.com/content?',13,10
	db	'http://www.netvibes.com/subscribe.php',13,10
	db	'http://www.mister-wong.com/addurl/?bm_url=',13,10
	db	'http://blogsearch.google.com/?',13,10
	db	'clustrmaps.com/counter/',13,10
	db	'.g?blogID=',13,10
	db	'http://www.blogger.com/profile/',13,10
	db	0

block2	db	'Last post by:',13,10
	db	'Forum Options',13,10
	db	'Next Oldest',13,10
	db	'Next Newest',13,10
	db	'View Parent Forum',13,10
	db	0

block3	db	'10.*',13,10
	db	'192.168.*',13,10
	db	'172.16.0.0-172.31.255.255',13,10
	db	'127.*',13,10
	db	0

block4	db	'js',13,10
	db	0

m_copy	db	'Copy',0

newEditProc	PROC	hDlg:DWORD,uMsg:DWORD,wParam:DWORD,lParam:DWORD
	pushad
	.if (uMsg==WM_RBUTTONUP)
		invoke	GlobalAlloc,GPTR,65536
		mov	edi,eax
		push	eax
		lea	edx,dword ptr[edi+4]
		invoke	CallWindowProc,oldeditproc,hDlg,EM_GETSEL,edi,edx
		mov	eax,dword ptr [edi]
		.if eax>dword ptr [edi+4]
			xchg	eax,dword ptr[edi+4]
			xchg	eax,dword ptr[edi]
			mov	eax,dword ptr[edi]
		.endif
		invoke	CallWindowProc,oldeditproc,hDlg,EM_LINEFROMCHAR,eax,0
		lea	edi,dword ptr[edi+8]
		mov	dword ptr[edi],1024
		push	eax
		invoke	CallWindowProc,oldeditproc,hDlg,EM_GETLINE,eax,edi
		pop	edx
		invoke	CallWindowProc,oldeditproc,hDlg,EM_LINEINDEX,edx,0
		mov	edx,eax
		sub	edi,8
		mov	eax,dword ptr[edi]
		.if eax>=edx
			mov	ecx,dword ptr[edi+4]
			sub	ecx,dword ptr[edi]
			sub	eax,edx
			.if eax<1024
				push	edi
				push	esi
				lea	esi,dword ptr[edi+eax+8]
				.while ecx
					.if (byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)
					.else
						.break
					.endif
					inc	esi
					dec	ecx
				.endw
				.while ecx
					.if byte ptr[esi]=='&'
						mov	al,'&'
						stosb
					.endif
					movsb
					dec	ecx
				.endw
				.while (edi!=offset setban_txt1)&&((byte ptr[edi-1]==32)||(byte ptr[edi-1]==9)||(byte ptr[edi-1]==','))
					dec	edi
				.endw
				mov	al,0
				stosb
				pop	esi
				pop	edi
			.else
				mov	byte ptr[edi],0
			.endif
		.else
			mov	byte ptr[edi],0
		.endif
		invoke	CreatePopupMenu
		push	eax
		mov	esi,eax
		invoke	AppendMenu,esi,MF_STRING or MF_UNCHECKED or MF_ENABLED,1500,addr m_copy
		lea	edi,setban_txt1
		mov	ecx,100
		mov	edx,[esp+4]
		.if byte ptr[edx]
			.while (byte ptr[edx]!=0)&&(byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(ecx!=0)
				mov	al,[edx]
				stosb
				inc	edx
				dec	ecx
			.endw
			.if ecx!=100
				mov	ax,39
				stosw
				invoke	AppendMenu,esi,MF_SEPARATOR,0,0
				invoke	AppendMenu,esi,MF_STRING or MF_UNCHECKED or MF_ENABLED,1501,addr setban_txt0
				mov	edx,[esp+4]
				xor	ecx,ecx
				.while (ecx<5)&&(byte ptr[edx+ecx]!=0)
					.break .if word ptr[edx+ecx]=='/:'
					inc	ecx
				.endw
				.if word ptr[edx+ecx]=='/:'
					lea	ecx,[ecx+2]
					.if byte ptr[edx+ecx]=='/'
						inc	ecx
					.endif
				.endif
				.while byte ptr[edx+ecx]
					.break .if byte ptr[edx+ecx]=='/'
					inc	ecx
				.endw
				.if (byte ptr[edx+ecx]=='/')&&(byte ptr[edx+ecx+1]!=0)
					push	edx
					push	ecx
					inc	ecx
					xor	eax,eax
					.while byte ptr[edx+ecx]
						.if byte ptr[edx+ecx]=='/'
							mov	eax,ecx
						.endif
						inc	ecx
					.endw
					.if eax
						.if (byte ptr[edx+eax]=='/')&&(byte ptr[edx+eax+1]!=0)
							mov	ecx,eax
							push	edi
							push	esi
							lea	edi,setban_txt1
							mov	esi,edx
							rep	movsb
							movsb
							pop	esi
							mov	ax,39
							stosw
							invoke	AppendMenu,esi,MF_STRING or MF_UNCHECKED or MF_ENABLED,1503,addr setban_txt0
							pop	edi
						.endif
					.endif
					pop	ecx
					pop	edx
					push	edi
					push	esi
					lea	edi,setban_txt1
					mov	esi,edx
					rep	movsb
					movsb
					pop	esi
					mov	ax,39
					stosw
					invoke	AppendMenu,esi,MF_STRING or MF_UNCHECKED or MF_ENABLED,1502,addr setban_txt0
					pop	edi

					mov	edx,[esp+4]
					lea	edi,setban_txt1
					.while (byte ptr[edx]!=0)&&(byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(ecx!=0)
						mov	al,[edx]
						stosb
						inc	edx
						dec	ecx
					.endw
					mov	ax,39
					stosw
				.endif
			.endif
		.endif
		invoke	GetCursorPos,edi
		invoke	TrackPopupMenu,esi,TPM_LEFTALIGN,dword ptr[edi],dword ptr[edi+4],0,hDialog,0
		call	DestroyMenu
		call	GlobalFree
		popad
		xor	eax,eax
		ret
	.endif
	popad
	invoke	CallWindowProc,oldeditproc,hDlg,uMsg,wParam,lParam
	ret
newEditProc	ENDP

forbid_anchor:
	push	edx
	push	ecx
	push	ebx
	mov	ebx,esi
	.while (byte ptr[ebx]!=0)&&(byte ptr[ebx]!='>')
		inc	ebx
	.endw
	.if byte ptr[ebx]=='>'
		inc	ebx
	.endif
	.while (byte ptr[ebx]!=0)
		mov	eax,[ebx]
		or	eax,200000h
		.break .if eax=='>a/<'
		.if al=='<'
			.while (byte ptr[ebx]!=0)&&(byte ptr[ebx]!='>')
				inc	ebx
			.endw
			.if byte ptr[ebx]=='>'
				inc	ebx
			.endif
			.continue
		.endif
		mov	edx,blocked2
		.while byte ptr[edx]
			.while (byte ptr[edx]==32)||(byte ptr[edx]==13)||(byte ptr[edx]==10)||(byte ptr[edx]==9)||(byte ptr[edx]=='*')||(byte ptr[edx]=='.')
				inc	edx
			.endw
			.break .if byte ptr[edx]==0
			xor	ecx,ecx
			push	ebx
			.while (byte ptr[ebx+ecx]!=0)&&(byte ptr[edx+ecx]>32)
				mov	al,byte ptr [ebx+ecx]
				mov	ah,byte ptr [edx+ecx]
				.if ah=='#'
					.break .if (byte ptr[ebx+ecx]<'0')||(byte ptr[ebx+ecx]>'9')
					.while (byte ptr[ebx+ecx]>='0')&&(byte ptr[ebx+ecx]<='9')
						inc	ebx
					.endw
					dec	ebx
					inc	ecx
				.else
					or	ax,2020h
					.break .if al!=ah
				.endif
				inc	ecx
			.endw
			pop	ebx
			.if (ecx!=0)&&(byte ptr[edx+ecx]<=32)
				pop	ebx
				pop	ecx
				pop	edx
				xor	eax,eax
				inc	eax
				ret
			.endif
			.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
				inc	edx
			.endw
		.endw
		inc	ebx
	.endw
	xor	eax,eax
	pop	ebx
	pop	ecx
	pop	edx
	ret

parseips:
	mov	ipcount,0
	mov	esi,blocked3
	xor	ecx,ecx
	xor	edx,edx
	.while byte ptr[esi+ecx]
		.if (byte ptr[esi+ecx]==13)||(byte ptr[esi+ecx]==10)
			.while (byte ptr[esi+ecx]==13)||(byte ptr[esi+ecx]==10)
				inc	ecx
			.endw
			inc	edx
		.else
			inc	ecx
		.endif
	.endw
	shl	edx,3
	lea	edx,[edx+16]
	invoke	GlobalAlloc,GPTR,edx
	mov	iplist,eax
	mov	edi,eax
	.while byte ptr[esi]
		.while (byte ptr[esi]!=0)&&(byte ptr[esi]<=32)
			inc	esi
		.endw
		.if byte ptr[esi]
			call	getrange
			.if (byte ptr[esi]<=32)
				xchg	al,ah
				rol	eax,16
				xchg	al,ah
				stosd
				mov	eax,ebx
				xchg	al,ah
				rol	eax,16
				xchg	al,ah
				stosd
				inc	ipcount
			.else
				.while (byte ptr[esi]>32)
					inc	esi
				.endw
			.endif
		.endif
	.endw
	ret


isbanneddns:
	push	esi
	.while byte ptr[esi]
		mov	edx,blocked1
		.while byte ptr[edx]
			.while (byte ptr[edx]==32)||(byte ptr[edx]==13)||(byte ptr[edx]==10)||(byte ptr[edx]==9)
				inc	edx
			.endw
			.break .if byte ptr[edx]==0
			xor	ecx,ecx
			push	esi
			.while (byte ptr[esi+ecx]!=0)&&(byte ptr[edx+ecx]>32)
				mov	al,byte ptr [esi+ecx]
				mov	ah,byte ptr [edx+ecx]
				.if ah=='#'
					.break .if (byte ptr[esi+ecx]<'0')||(byte ptr[esi+ecx]>'9')
					.while (byte ptr[esi+ecx]>='0')&&(byte ptr[esi+ecx]<='9')
						inc	esi
					.endw
					dec	esi
					inc	ecx
				.else
					or	ax,2020h
					.break .if al!=ah
				.endif
				inc	ecx
			.endw
			pop	esi
			.if (ecx!=0)&&(byte ptr[edx+ecx]<=32)
				pop	esi
				xor	eax,eax
				inc	eax
				ret
			.endif
			.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
				inc	edx
			.endw
		.endw
		inc	esi
	.endw
	pop	esi
	xor	eax,eax
	ret
endm

blockedfree	macro
	.if blocked1
		invoke	GlobalFree,blocked1
	.endif
	.if blocked2
		invoke	GlobalFree,blocked2
	.endif
	.if blocked3
		invoke	GlobalFree,blocked3
	.endif
	.if blocked4
		invoke	GlobalFree,blocked4
	.endif
	.if iplist
		invoke	GlobalFree,iplist
	.endif
endm

initbans	macro
	mov	iplist,0
	invoke	GlobalAlloc,GPTR,1024
	mov	blocked1,eax
	mov	edi,eax
	lea	esi,block1
	.while byte ptr[esi]
		movsb
		inc	ecx
	.endw
	movsb
	inc	ecx
	mov	blocked1s,ecx

	invoke	GlobalAlloc,GPTR,1024
	mov	blocked2,eax
	mov	edi,eax
	lea	esi,block2
	.while byte ptr[esi]
		movsb
		inc	ecx
	.endw
	movsb
	inc	ecx
	mov	blocked2s,ecx

	invoke	GlobalAlloc,GPTR,1024
	mov	blocked3,eax
	mov	edi,eax
	lea	esi,block3
	.while byte ptr[esi]
		movsb
		inc	ecx
	.endw
	movsb
	inc	ecx
	mov	blocked3s,ecx

	invoke	GlobalAlloc,GPTR,1024
	mov	blocked4,eax
	mov	edi,eax
	lea	esi,block4
	.while byte ptr[esi]
		movsb
		inc	ecx
	.endw
	movsb
	inc	ecx
	mov	blocked4s,ecx
endm

loadbans	macro
	mov	dword ptr buftmp,0
	invoke	ReadFile,esi,addr buftmp,4,addr bread,0
	.if dword ptr buftmp
		invoke	GlobalFree,blocked1
		mov	eax,dword ptr buftmp
		lea	eax,[eax+1024]
		mov	blocked1s,eax
		invoke	GlobalAlloc,GPTR,eax
		mov	blocked1,eax
		mov	edx,eax
		invoke	ReadFile,esi,edx,dword ptr buftmp,addr bread,0
	.else
		mov	edx,blocked1
		mov	byte ptr[edx],0
	.endif

	mov	dword ptr buftmp,0
	invoke	ReadFile,esi,addr buftmp,4,addr bread,0
	.if dword ptr buftmp
		invoke	GlobalFree,blocked2
		mov	eax,dword ptr buftmp
		lea	eax,[eax+1024]
		mov	blocked2s,eax
		invoke	GlobalAlloc,GPTR,eax
		mov	blocked2,eax
		mov	edx,eax
		invoke	ReadFile,esi,edx,dword ptr buftmp,addr bread,0
	.else
		mov	edx,blocked2
		mov	byte ptr[edx],0
	.endif

	mov	dword ptr buftmp,0
	invoke	ReadFile,esi,addr buftmp,4,addr bread,0
	.if dword ptr buftmp
		invoke	GlobalFree,blocked3
		mov	eax,dword ptr buftmp
		lea	eax,[eax+1024]
		mov	blocked3s,eax
		invoke	GlobalAlloc,GPTR,eax
		mov	blocked3,eax
		mov	edx,eax
		invoke	ReadFile,esi,edx,dword ptr buftmp,addr bread,0
	.else
		mov	edx,blocked3
		mov	byte ptr[edx],0
	.endif

	mov	dword ptr buftmp,0
	invoke	ReadFile,esi,addr buftmp,4,addr bread,0
	.if dword ptr buftmp
		invoke	GlobalFree,blocked4
		mov	eax,dword ptr buftmp
		lea	eax,[eax+1024]
		mov	blocked4s,eax
		invoke	GlobalAlloc,GPTR,eax
		mov	blocked4,eax
		mov	edx,eax
		invoke	ReadFile,esi,edx,dword ptr buftmp,addr bread,0
	.else
		mov	edx,blocked4
		mov	byte ptr[edx],0
	.endif
endm

savebans	macro
	.if blocked1
		mov	edx,blocked1
		xor	ecx,ecx
		.while byte ptr[edx+ecx]
			inc	ecx
		.endw
		inc	ecx
		mov	dword ptr buftmp,ecx
		invoke	WriteFile,esi,addr buftmp,4,addr bread,0
		invoke	WriteFile,esi,blocked1,dword ptr buftmp,addr bread,0
	.endif
	.if blocked2
		mov	edx,blocked2
		xor	ecx,ecx
		.while byte ptr[edx+ecx]
			inc	ecx
		.endw
		inc	ecx
		mov	dword ptr buftmp,ecx
		invoke	WriteFile,esi,addr buftmp,4,addr bread,0
		invoke	WriteFile,esi,blocked2,dword ptr buftmp,addr bread,0
	.endif
	.if blocked3
		mov	edx,blocked3
		xor	ecx,ecx
		.while byte ptr[edx+ecx]
			inc	ecx
		.endw
		inc	ecx
		mov	dword ptr buftmp,ecx
		invoke	WriteFile,esi,addr buftmp,4,addr bread,0
		invoke	WriteFile,esi,blocked3,dword ptr buftmp,addr bread,0
	.endif
	.if blocked4
		mov	edx,blocked4
		xor	ecx,ecx
		.while byte ptr[edx+ecx]
			inc	ecx
		.endw
		inc	ecx
		mov	dword ptr buftmp,ecx
		invoke	WriteFile,esi,addr buftmp,4,addr bread,0
		invoke	WriteFile,esi,blocked4,dword ptr buftmp,addr bread,0
	.endif
endm

initdlgbans	macro
	call	parseips
	invoke	SetDlgItemText,hDlg,8100,blocked1
	invoke	SetDlgItemText,hDlg,8101,blocked2
	invoke	SetDlgItemText,hDlg,8102,blocked3
	invoke	SetDlgItemText,hDlg,8103,blocked4
	lea	edi,setban_txt0
	mov	eax,'calB'
	stosd
	mov	eax,'silk'
	stosd
	mov	ax,' t'
	stosw
	mov	al,39
	stosb
	mov	al,0
	stosb
	invoke	GetDlgItem,hDlg,200
	push	eax
	invoke	GetWindowLong,eax,GWL_WNDPROC
	mov	oldeditproc,eax
	pop	eax
	invoke	SetWindowLong,eax,GWL_WNDPROC,addr newEditProc
endm

dlgupdatebans	macro
	.elseif (ax==8100)&&(bx==EN_CHANGE)
		invoke	SendDlgItemMessage,hDlg,8100,WM_GETTEXTLENGTH,0,0
		inc	eax
		.if eax<blocked1s
			lea	eax,[eax+1024]
			mov	blocked1s,eax
			invoke	GlobalFree,blocked1
			invoke	GlobalAlloc,GPTR,blocked1s
			mov	blocked1,eax
		.endif
		invoke	GetDlgItemText,hDlg,8100,blocked1,blocked1s
	.elseif (ax==8101)&&(bx==EN_CHANGE)
		invoke	SendDlgItemMessage,hDlg,8101,WM_GETTEXTLENGTH,0,0
		inc	eax
		.if eax<blocked2s
			lea	eax,[eax+1024]
			mov	blocked2s,eax
			invoke	GlobalFree,blocked2
			invoke	GlobalAlloc,GPTR,blocked2s
			mov	blocked2,eax
		.endif
		invoke	GetDlgItemText,hDlg,8101,blocked2,blocked2s
	.elseif (ax==8102)&&(bx==EN_CHANGE)
		invoke	SendDlgItemMessage,hDlg,8102,WM_GETTEXTLENGTH,0,0
		inc	eax
		.if eax<blocked3s
			lea	eax,[eax+1024]
			mov	blocked3s,eax
			invoke	GlobalFree,blocked3
			invoke	GlobalAlloc,GPTR,blocked3s
			mov	blocked3,eax
		.endif
		invoke	GetDlgItemText,hDlg,8102,blocked3,blocked3s
		.if iplist
			invoke	GlobalFree,iplist
		.endif
		call	parseips
	.elseif (ax==8103)&&(bx==EN_CHANGE)
		invoke	SendDlgItemMessage,hDlg,8103,WM_GETTEXTLENGTH,0,0
		inc	eax
		.if eax<blocked4s
			lea	eax,[eax+1024]
			mov	blocked4s,eax
			invoke	GlobalFree,blocked4
			invoke	GlobalAlloc,GPTR,blocked4s
			mov	blocked4,eax
		.endif
		invoke	GetDlgItemText,hDlg,8103,blocked4,blocked4s
	.elseif ax==1500
		invoke	SendDlgItemMessage,hDlg,200,WM_COPY,0,0
	.elseif (ax==1501)||(ax==1502)||(ax==1503)
		xor	ecx,ecx
		.while byte ptr setban_txt1[ecx]
			inc	ecx
		.endw
		.if ecx
			dec	ecx
		.endif
		.if (ax==1502)||(ax==1503)
			push	ecx
			lea	edx,setban_txt1
			xor	ecx,ecx
			.while (ecx<5)&&(ecx<dword ptr[esp])
				.break .if word ptr[edx+ecx]=='/:'
				inc	ecx
			.endw
			.if word ptr[edx+ecx]=='/:'
				lea	ecx,[ecx+2]
				.if byte ptr[edx+ecx]=='/'
					inc	ecx
				.endif
			.endif
			.while ecx<dword ptr[esp]
				.break .if byte ptr[edx+ecx]=='/'
				inc	ecx
			.endw
			.if (byte ptr[edx+ecx]=='/')&&(byte ptr[edx+ecx+1]!=39)&&(byte ptr[edx+ecx+1]!=0)
				inc	ecx
				.if ax==1502
					mov	[esp],ecx
				.else
					xor	eax,eax
					.while ecx<dword ptr[esp]
						.if byte ptr[edx+ecx]=='/'
							mov	eax,ecx
						.endif
						inc	ecx
					.endw
					.if eax
						.if (byte ptr[edx+eax]=='/')&&(byte ptr[edx+eax+1]!=0)&&(byte ptr[edx+eax+1]!=39)
							lea	ecx,[eax+1]
							mov	[esp],ecx
						.endif
					.endif
				.endif
				pop	ecx
			.endif
		.endif
		xor	edx,edx
		mov	edi,blocked1
		.while byte ptr[edi+edx]
			inc	edx
		.endw
		lea	eax,[edx+ecx+1+4]
		.if eax<blocked1s
			push	ecx
			lea	eax,[eax+1024]
			mov	blocked1s,eax
			invoke	GlobalFree,blocked1
			invoke	GlobalAlloc,GPTR,blocked1s
			mov	blocked1,eax
			invoke	GetDlgItemText,hDlg,8100,blocked1,blocked1s
			pop	ecx
		.endif
		mov	edi,blocked1
		xor	edx,edx
		.while byte ptr[edi]
			inc	edi
			inc	edx
		.endw
		.while (edx!=0)&&((byte ptr[edi-1]==13)||(byte ptr[edi-1]==10)||(byte ptr[edi-1]==32)||(byte ptr[edi-1]==9)||(byte ptr[edi-1]==','))
			dec	edx
			dec	edi
		.endw
		mov	ax,0a0dh
		stosw
		lea	edx,setban_txt1
		.while ecx
			mov	al,[edx]
			.if (al=='&')&&(byte ptr[edx]=='&')
				inc	edx
			.endif
			stosb
			inc	edx
			dec	ecx
		.endw
		mov	ax,0a0dh
		stosw
		mov	al,0
		stosb
		invoke	SetDlgItemText,hDlg,8100,blocked1
endm

blockedaddr	macro
	push	esi
	.while byte ptr[esi]
		mov	edx,blocked1
		.while byte ptr[edx]
			.while (byte ptr[edx]==32)||(byte ptr[edx]==13)||(byte ptr[edx]==10)||(byte ptr[edx]==9)
				inc	edx
			.endw
			.break .if byte ptr[edx]==0
			xor	ecx,ecx
			push	esi
			.while (byte ptr[esi+ecx]!=0)&&(byte ptr[edx+ecx]>32)
				mov	al,byte ptr [esi+ecx]
				mov	ah,byte ptr [edx+ecx]
				.if ah=='#'
					.break .if (byte ptr[esi+ecx]<'0')||(byte ptr[esi+ecx]>'9')
					.while (byte ptr[esi+ecx]>='0')&&(byte ptr[esi+ecx]<='9')
						inc	esi
					.endw
					dec	esi
					inc	ecx
				.else
					or	ax,2020h
					.break .if al!=ah
				.endif
				inc	ecx
			.endw
			pop	esi
			.if (ecx!=0)&&(byte ptr[edx+ecx]<=32)
				pop	esi
				push	edi
				lea	edi,[edi]._msg
				push	edi
				push	edx
				lea	edx,blockedmsg1
				call	copyedx
				mov	edx,esi
				call	copyedx
				lea	edx,blockedmsg2
				call	copyedx
				pop	edx
				.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
					mov	al,[edx]
					stosb
					inc	edx
				.endw
				lea	edx,blockedmsg3
				call	copyedx
				mov	ax,0a0dh
				stosw
				mov	al,0
				stosb
				pop	edx
				call	showmsg
				pop	edi
				set_operation	0
				ret
			.endif
			.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
				inc	edx
			.endw
		.endw
		inc	esi
	.endw
	pop	esi
endm

blockedaddr1	macro
	push	esi
	.while byte ptr[esi]
		mov	edx,blocked1
		.while byte ptr[edx]
			.while (byte ptr[edx]==32)||(byte ptr[edx]==13)||(byte ptr[edx]==10)||(byte ptr[edx]==9)
				inc	edx
			.endw
			.break .if byte ptr[edx]==0
			xor	ecx,ecx
			push	esi
			.while (byte ptr[esi+ecx]!=0)&&(byte ptr[edx+ecx]>32)
				mov	al,byte ptr [esi+ecx]
				mov	ah,byte ptr [edx+ecx]
				.if ah=='#'
					.break .if (byte ptr[esi+ecx]<'0')||(byte ptr[esi+ecx]>'9')
					.while (byte ptr[esi+ecx]>='0')&&(byte ptr[esi+ecx]<='9')
						inc	esi
					.endw
					dec	esi
					inc	ecx
				.else
					or	ax,2020h
					.break .if al!=ah
				.endif
				inc	ecx
			.endw
			pop	esi
			.if (ecx!=0)&&(byte ptr[edx+ecx]<=32)
				pop	esi
				push	edi
				lea	edi,[edi]._msg
				push	edi
				push	edx
				lea	edx,blockedmsg1
				call	copyedx
				mov	edx,esi
				call	copyedx
				lea	edx,blockedmsg2
				call	copyedx
				pop	edx
				.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
					mov	al,[edx]
					stosb
					inc	edx
				.endw
				lea	edx,blockedmsg3
				call	copyedx
				mov	ax,0a0dh
				stosw
				mov	al,0
				stosb
				pop	edx
				call	showmsg
				pop	edi
				mov	edi,_edi
				set_operation	0
				ret
			.endif
			.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
				inc	edx
			.endw
		.endw
		inc	esi
	.endw
	pop	esi
endm


blockedext	macro
	push	esi
	xor	edx,edx
	.while byte ptr[esi]
		.if byte ptr[esi]=='.'
			mov	edx,esi
		.elseif (byte ptr[esi]=='\')||(byte ptr[esi]=='/')
			xor	edx,edx
		.endif
		inc	esi
	.endw
	.if edx
		mov	edx,blocked4
		.while byte ptr[edx]
			.while (byte ptr[edx]==32)||(byte ptr[edx]==13)||(byte ptr[edx]==10)||(byte ptr[edx]==9)||(byte ptr[edx]=='*')||(byte ptr[edx]=='.')
				inc	edx
			.endw
			.break .if byte ptr[edx]==0
			xor	ecx,ecx
			.while (byte ptr[esi+ecx]!=0)&&(byte ptr[edx+ecx]>32)
				mov	al,byte ptr [esi+ecx]
				mov	ah,byte ptr [edx+ecx]
				or	ax,2020h
				.break .if al!=ah
				inc	ecx
			.endw
			.if (byte ptr[esi+ecx]==0)&&(ecx!=0)&&(byte ptr[edx+ecx]<=32)
				pop	esi
				push	edi
				lea	edi,[edi]._msg
				push	edi
				push	edx
				lea	edx,blockedmsg1
				call	copyedx
				mov	edx,esi
				call	copyedx
				lea	edx,blockedmsg2a
				call	copyedx
				pop	edx
				.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
					mov	al,[edx]
					stosb
					inc	edx
				.endw
				lea	edx,blockedmsg3
				call	copyedx
				mov	ax,0a0dh
				stosw
				mov	al,0
				stosb
				pop	edx
				call	showmsg
				pop	edi
				set_operation	0
				ret
			.endif
			.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
				inc	edx
			.endw
		.endw
	.endif
	pop	esi
endm

blockedext1	macro
	push	esi
	xor	edx,edx
	.while byte ptr[esi]
		.if byte ptr[esi]=='.'
			mov	edx,esi
		.elseif (byte ptr[esi]=='\')||(byte ptr[esi]=='/')
			xor	edx,edx
		.endif
		inc	esi
	.endw
	.if edx
		mov	edx,blocked4
		.while byte ptr[edx]
			.while (byte ptr[edx]==32)||(byte ptr[edx]==13)||(byte ptr[edx]==10)||(byte ptr[edx]==9)||(byte ptr[edx]=='*')||(byte ptr[edx]=='.')
				inc	edx
			.endw
			.break .if byte ptr[edx]==0
			xor	ecx,ecx
			.while (byte ptr[esi+ecx]!=0)&&(byte ptr[edx+ecx]>32)
				mov	al,byte ptr [esi+ecx]
				mov	ah,byte ptr [edx+ecx]
				or	ax,2020h
				.break .if al!=ah
				inc	ecx
			.endw
			.if (byte ptr[esi+ecx]==0)&&(ecx!=0)&&(byte ptr[edx+ecx]<=32)
				pop	esi
				push	edi
				lea	edi,[edi]._msg
				push	edi
				push	edx
				lea	edx,blockedmsg1
				call	copyedx
				mov	edx,esi
				call	copyedx
				lea	edx,blockedmsg2a
				call	copyedx
				pop	edx
				.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
					mov	al,[edx]
					stosb
					inc	edx
				.endw
				lea	edx,blockedmsg3
				call	copyedx
				mov	ax,0a0dh
				stosw
				mov	al,0
				stosb
				pop	edx
				call	showmsg
				pop	edi
				mov	edi,_edi
				set_operation	0
				ret
			.endif
			.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
				inc	edx
			.endw
		.endw
	.endif
	pop	esi
endm

forbid_file	macro
	push	eax
	push	esi
	mov	edx,lParam
	assume	edx:ptr foruminfo
	lea	esi,[edx]._file
	assume	edx:nothing
	xor	edx,edx
	.while byte ptr[esi]
		.if byte ptr[esi]=='.'
			mov	edx,esi
		.elseif (byte ptr[esi]=='\')||(byte ptr[esi]=='/')
			xor	edx,edx
		.endif
		inc	esi
	.endw
	.if edx
		mov	edx,blocked4
		.while byte ptr[edx]
			.while (byte ptr[edx]==32)||(byte ptr[edx]==13)||(byte ptr[edx]==10)||(byte ptr[edx]==9)||(byte ptr[edx]=='*')||(byte ptr[edx]=='.')
				inc	edx
			.endw
			.break .if byte ptr[edx]==0
			xor	ecx,ecx
			.while (byte ptr[esi+ecx]!=0)&&(byte ptr[edx+ecx]>32)
				mov	al,byte ptr [esi+ecx]
				mov	ah,byte ptr [edx+ecx]
				or	ax,2020h
				.break .if al!=ah
				inc	ecx
			.endw
			.if (byte ptr[esi+ecx]==0)&&(ecx!=0)&&(byte ptr[edx+ecx]<=32)
				pop	esi
				push	edi
				lea	edi,[edi]._msg
				push	edi
				push	edx
				lea	edx,blockedmsg1
				call	copyedx
				mov	edx,esi
				call	copyedx
				lea	edx,blockedmsg2a
				call	copyedx
				pop	edx
				.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
					mov	al,[edx]
					stosb
					inc	edx
				.endw
				lea	edx,blockedmsg3
				call	copyedx
				mov	ax,0a0dh
				stosw
				mov	al,0
				stosb
				pop	edx
				call	showmsg
				pop	edi
				pop	eax
				pop	edx
				pop	edi
				pop	eax
				pop	edi
				invoke	closesocket,[edi].hSocket
				set_operation	0
				ret
			.endif
			.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
				inc	edx
			.endw
		.endw
	.endif
	pop	esi
	pop	eax
endm

forbid_file1	macro
	push	eax
	push	esi
	mov	edx,lParam
	assume	edx:ptr foruminfo
	lea	esi,[edx]._file
	assume	edx:nothing
	xor	edx,edx
	.while byte ptr[esi]
		.if byte ptr[esi]=='.'
			mov	edx,esi
		.elseif (byte ptr[esi]=='\')||(byte ptr[esi]=='/')
			xor	edx,edx
		.endif
		inc	esi
	.endw
	.if edx
		mov	edx,blocked4
		.while byte ptr[edx]
			.while (byte ptr[edx]==32)||(byte ptr[edx]==13)||(byte ptr[edx]==10)||(byte ptr[edx]==9)||(byte ptr[edx]=='*')||(byte ptr[edx]=='.')
				inc	edx
			.endw
			.break .if byte ptr[edx]==0
			xor	ecx,ecx
			.while (byte ptr[esi+ecx]!=0)&&(byte ptr[edx+ecx]>32)
				mov	al,byte ptr [esi+ecx]
				mov	ah,byte ptr [edx+ecx]
				or	ax,2020h
				.break .if al!=ah
				inc	ecx
			.endw
			.if (byte ptr[esi+ecx]==0)&&(ecx!=0)&&(byte ptr[edx+ecx]<=32)
				pop	esi
				push	edi
				lea	edi,[edi]._msg
				push	edi
				push	edx
				lea	edx,blockedmsg1
				call	copyedx
				mov	edx,esi
				call	copyedx
				lea	edx,blockedmsg2a
				call	copyedx
				pop	edx
				.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
					mov	al,[edx]
					stosb
					inc	edx
				.endw
				lea	edx,blockedmsg3
				call	copyedx
				mov	ax,0a0dh
				stosw
				mov	al,0
				stosb
				pop	edx
				call	showmsg
				pop	edi
				pop	eax
				pop	edx
				pop	edi
				pop	eax
				pop	edi
				invoke	closesocket,[edi].hSocket
				.if hfile
					invoke	CloseHandle,hfile
					mov	hfile,0
				.endif
				mov	fsize,0
				mov	edi,_edi
				set_operation	0
				ret
			.endif
			.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
				inc	edx
			.endw
		.endw
	.endif
	pop	esi
	pop	eax
endm

isbannedip	macro
	push	eax
	xchg	al,ah
	rol	eax,16
	xchg	al,ah
	mov	ecx,ipcount
	mov	edx,iplist
	.while ecx
		.if (eax>=[edx])&&(eax<=[edx+4])
			lea	edx,[edi]._addr
			push	edi
			lea	edi,[edi]._msg
			push	edi
			push	edx
			lea	edx,blockedmsg1
			call	copyedx
			pop	edx
			call	copyedx
			lea	edx,blockedmsg2b
			call	copyedx
			mov	eax,[esp+4+4]
			call	w_ip
			mov	ax,'( '
			stosw
			mov	edx,ipcount
			sub	edx,ecx
			mov	ecx,edx
			mov	edx,iplist
			lea	edx,[edx+ecx*8]
			mov	eax,[edx]
			xchg	al,ah
			rol	eax,16
			xchg	al,ah
			push	edx
			call	w_ip
			pop	edx
			mov	al,'-'
			stosb
			mov	eax,[edx+4]
			xchg	al,ah
			rol	eax,16
			xchg	al,ah
			call	w_ip
			lea	edx,blockedmsg3+1
			call	copyedx
			mov	ax,0a0dh
			stosw
			mov	al,0
			stosb
			pop	edx
			call	showmsg
			pop	edi
			pop	eax
			set_operation	0
			ret
		.endif
		dec	ecx
		lea	edx,[edx+8]
	.endw
	pop	eax
endm

isbannedip1	macro
	push	eax
	xchg	al,ah
	rol	eax,16
	xchg	al,ah
	mov	ecx,ipcount
	mov	edx,iplist
	.while ecx
		.if (eax>=[edx])&&(eax<=[edx+4])
			lea	edx,[edi]._addr
			push	edi
			lea	edi,[edi]._msg
			push	edi
			push	edx
			lea	edx,blockedmsg1
			call	copyedx
			pop	edx
			call	copyedx
			lea	edx,blockedmsg2b
			call	copyedx
			mov	eax,[esp+4+4]
			call	w_ip
			mov	ax,'( '
			stosw
			mov	edx,ipcount
			sub	edx,ecx
			mov	ecx,edx
			mov	edx,iplist
			lea	edx,[edx+ecx*8]
			mov	eax,[edx]
			xchg	al,ah
			rol	eax,16
			xchg	al,ah
			push	edx
			call	w_ip
			pop	edx
			mov	al,'-'
			stosb
			mov	eax,[edx+4]
			xchg	al,ah
			rol	eax,16
			xchg	al,ah
			call	w_ip
			lea	edx,blockedmsg3+1
			call	copyedx
			mov	ax,0a0dh
			stosw
			mov	al,0
			stosb
			pop	edx
			call	showmsg
			pop	edi
			pop	eax
			mov	edi,_edi
			.if hfile
				invoke	CloseHandle,hfile
				mov	hfile,0
				mov	fsize,0
			.endif
			set_operation	0
			ret
		.endif
		dec	ecx
		lea	edx,[edx+8]
	.endw
	pop	eax
endm

