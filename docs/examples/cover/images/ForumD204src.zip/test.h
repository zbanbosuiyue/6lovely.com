thread_info	struct
	next_thr	dd	?
	thrstat		db	?
	opcode		db	?
	state		db	?
	hThread		dd	?
	socket		dd	?
	bytes		dd	?
	tmpbytes	dd	?
	tmpdata		dd	?
	hdrsize		dd	?
	fds		fd_set	<>
	twait		timeval	<>
	res_ip		dd	?
	filename	db	8192 dup(?)
	address		db	8192 dup(?)
	hostname	db	1024 dup(?)
	path		db	8192 dup(?)
	saddr		sockaddr_in <>
	psaddr		sockaddr_in <>
	recvbuf		db	16384 dup(?)
thread_info	ends

test_udata	macro
	ofn	OPENFILENAME	<>
	thrsend	thread_info	<>
	iplive	dd	?
	ipchk	db	?
	autoupd	db	?
endm

test_data	macro
httpidx	db	'index.html',0
flthtml	db	'HTML files (*.html)',0,'*.html;*.htm;*.txt',0,'All files (*.*)',0,'*.*',0,0
s_stat1	db	'Resolving ...',0
s_stat1a db	'Gathering information about hosts ...',0
s_stat2	db	'Connecting to ',0
s_stat3	db	'Sending data ...',0
s_stat4	db	'Connected',0
s_stat5	db	'Disconnected',0
s_stat6	db	', bytes received: ',0
s_stat7	db	'Bytes received: ',0
s_stat8	db	'Host information',0
s_chgstate1 db	'Dis&connect',0
s_chgstate2 db	'&Connect',0

auto_upd	PROC	_addr:DWORD
	invoke	SetDlgItemText,hDialog,3100,_addr
	ret
auto_upd	ENDP

send_upd	PROC	uses esi edi ecx lpBuf:DWORD,bufsize:DWORD
	mov	ecx,bufsize
	lea	ecx,[ecx+1024]
	invoke	GlobalAlloc,GPTR,ecx
	push	eax
	mov	edi,eax
	mov	esi,lpBuf
	mov	ecx,bufsize
	rep	movsb
	mov	al,0
	stosb
	mov	edx,[esp]
	invoke	SetDlgItemText,hDialog,3101,edx
	call	GlobalFree
	ret
send_upd	ENDP

send_upd1	PROC	uses esi edi ecx
	mov	ecx,_3._data
	add	ecx,_4._data
	lea	ecx,[ecx+1024]
	invoke	GlobalAlloc,GPTR,ecx
	push	eax
	mov	edi,eax
	mov	esi,_3._ptr
	mov	ecx,_3._data
	rep	movsb
	mov	esi,_4._ptr
	mov	ecx,_4._data
	rep	movsb
	mov	al,0
	stosb
	mov	edx,[esp]
	invoke	SetDlgItemText,hDialog,3101,edx
	call	GlobalFree
	ret
send_upd1	ENDP

recv_upd	PROC	uses eax esi edi ecx bufBase:DWORD,lpBuf:DWORD,bufsize:DWORD
	.if (eax==0)||(eax==SOCKET_ERROR)
		ret
	.endif
	mov	eax,lpBuf
	sub	eax,bufBase
	add	bufsize,eax
	mov	ecx,bufsize
	lea	ecx,[ecx+1024]
	invoke	GlobalAlloc,GPTR,ecx
	push	eax
	mov	edi,eax
	mov	esi,lpBuf
	mov	ecx,bufsize
	.while ecx
		lodsb
		.if al==0
			mov	al,32
		.endif
		stosb
		dec	ecx
	.endw
	mov	al,0
	stosb
	mov	edx,[esp]
	invoke	SetDlgItemText,hDialog,3102,edx
	call	GlobalFree
	ret
recv_upd	ENDP

;opcode = 1 => send
sendThread	PROC	lParam:DWORD
	.while thrsend.thrstat
		.if thrsend.opcode==1
			mov	thrsend.opcode,0
			mov	thrsend.bytes,0
			invoke	SetDlgItemText,hDialog,3102,addr s_stat2-1
			.if thrsend.state==0
				lea	edx,thrsend
				call	parsepath
				invoke	SetDlgItemText,hDialog,3050,addr s_stat1
				lea	edx,thrsend
				call	resolvepath
				.break .if thrsend.thrstat==0
				lea	edi,thrsend.recvbuf
				lea	edx,s_stat2
				call	copyedx
				mov	eax,dword ptr thrsend.saddr.sin_addr
				call	w_ip
				mov	eax,'... '
				stosd
				mov	al,0
				stosb
				invoke	SetDlgItemText,hDialog,3050,addr thrsend.recvbuf
				invoke	socket,PF_INET,SOCK_STREAM,0
				.if eax!=INVALID_SOCKET
					mov	thrsend.socket,eax
					invoke	connect,eax,addr thrsend.saddr,sizeof sockaddr_in
					.if eax==SOCKET_ERROR
						lea	edi,thrsend.recvbuf
						invoke	WSAGetLastError
						push	eax
						lea	edx,s_err0
						call	copyedx
						pop	eax
						push	eax
						call	itoa
						pop	eax
						call	wserr
						mov	al,0
						stosb
						invoke	SetDlgItemText,hDialog,3102,addr thrsend.recvbuf
						invoke	closesocket,thrsend.socket
						mov	thrsend.socket,0
						mov	thrsend.state,0
						invoke	SetDlgItemText,hDialog,3002,addr s_chgstate2
					.else
						mov	thrsend.state,1
						invoke	SetDlgItemText,hDialog,3002,addr s_chgstate1
					.endif
				.endif
			.endif
			.if (thrsend.state==1)||(thrsend.state==2)
				invoke	SetDlgItemText,hDialog,3050,addr s_stat3
				invoke	SendDlgItemMessage,hDialog,3101,WM_GETTEXTLENGTH,0,0
				mov	esi,eax
				inc	esi
				lea	eax,[eax+1024]
				invoke	GlobalAlloc,GPTR,eax
				push	eax
				mov	edi,eax
				invoke	GetDlgItemText,hDialog,3101,edi,esi
				xor	eax,eax
				.while byte ptr[edi+eax]
					inc	eax
				.endw
				mov	esi,eax
				xor	eax,eax
				.while eax<esi
					invoke	send,thrsend.socket,edi,esi,0
					.if (eax==SOCKET_ERROR)||(eax==0)
						lea	edi,thrsend.recvbuf
						invoke	WSAGetLastError
						push	eax
						lea	edx,s_err0
						call	copyedx
						pop	eax
						push	eax
						call	itoa
						pop	eax
						call	wserr
						mov	al,0
						stosb
						invoke	SetDlgItemText,hDialog,3102,addr thrsend.recvbuf
						invoke	closesocket,thrsend.socket
						mov	thrsend.socket,0
						mov	thrsend.state,0
						invoke	SetDlgItemText,hDialog,3002,addr s_chgstate2
						jmp	_thr_end_s
					.endif
					add	edi,eax
					sub	esi,eax
					xor	eax,eax
				.endw
				invoke	SetDlgItemText,hDialog,3050,addr s_stat4
_thr_end_s:			call	GlobalFree
			.endif
		.elseif thrsend.opcode==2
			mov	thrsend.opcode,0
			mov	thrsend.bytes,0
			invoke	SetDlgItemText,hDialog,3102,addr s_stat2-1
			lea	edx,thrsend
			call	parsepath
			invoke	SetDlgItemText,hDialog,3050,addr s_stat1
			invoke	GetDlgItem,hDialog,3009
			invoke	EnableWindow,eax,0
			invoke	GetDlgItem,hDialog,3002
			invoke	EnableWindow,eax,0
			invoke	GetDlgItem,hDialog,3003
			invoke	EnableWindow,eax,0
			invoke	GetDlgItem,hDialog,3004
			invoke	EnableWindow,eax,0
			invoke	GetDlgItem,hDialog,3005
			invoke	EnableWindow,eax,0
			invoke	GetDlgItem,hDialog,3008
			invoke	EnableWindow,eax,0
			pop	edx
			push	edx
			mov	ipchk,-1
			call	resolve_addr
			invoke	GetDlgItem,hDialog,3009
			invoke	EnableWindow,eax,1
			invoke	GetDlgItem,hDialog,3002
			invoke	EnableWindow,eax,1
			invoke	GetDlgItem,hDialog,3003
			invoke	EnableWindow,eax,1
			invoke	GetDlgItem,hDialog,3004
			invoke	EnableWindow,eax,1
			invoke	GetDlgItem,hDialog,3005
			invoke	EnableWindow,eax,1
			invoke	GetDlgItem,hDialog,3008
			invoke	EnableWindow,eax,1
		.elseif thrsend.opcode==5
			mov	thrsend.opcode,0
			mov	thrsend.bytes,0
			invoke	SetDlgItemText,hDialog,3102,addr s_stat2-1
			lea	edx,thrsend
			call	parsepath
			invoke	SetDlgItemText,hDialog,3050,addr s_stat1
			invoke	GetDlgItem,hDialog,3001
			invoke	EnableWindow,eax,0
		;	invoke	GetDlgItem,hDialog,3009
		;	invoke	EnableWindow,eax,0
			invoke	GetDlgItem,hDialog,3002
			invoke	EnableWindow,eax,0
			invoke	GetDlgItem,hDialog,3003
			invoke	EnableWindow,eax,0
			invoke	GetDlgItem,hDialog,3004
			invoke	EnableWindow,eax,0
			invoke	GetDlgItem,hDialog,3005
			invoke	EnableWindow,eax,0
			invoke	GetDlgItem,hDialog,3008
			invoke	EnableWindow,eax,0
			pop	edx
			push	edx
			mov	ipchk,0
			call	resolve_addr
			invoke	GetDlgItem,hDialog,3001
			invoke	EnableWindow,eax,1
		;	invoke	GetDlgItem,hDialog,3009
		;	invoke	EnableWindow,eax,1
			invoke	GetDlgItem,hDialog,3002
			invoke	EnableWindow,eax,1
			invoke	GetDlgItem,hDialog,3003
			invoke	EnableWindow,eax,1
			invoke	GetDlgItem,hDialog,3004
			invoke	EnableWindow,eax,1
			invoke	GetDlgItem,hDialog,3005
			invoke	EnableWindow,eax,1
			invoke	GetDlgItem,hDialog,3008
			invoke	EnableWindow,eax,1
			mov	iplive,0
		.elseif thrsend.opcode==3
			mov	thrsend.opcode,0
			mov	thrsend.bytes,0
			invoke	SetDlgItemText,hDialog,3102,addr s_stat2-1
			.if thrsend.state==0
				lea	edx,thrsend
				call	parsepath
				invoke	SetDlgItemText,hDialog,3050,addr s_stat1
				lea	edx,thrsend
				call	resolvepath
				.break .if thrsend.thrstat==0
				lea	edi,thrsend.recvbuf
				lea	edx,s_stat2
				call	copyedx
				mov	eax,dword ptr thrsend.saddr.sin_addr
				call	w_ip
				mov	eax,'... '
				stosd
				mov	al,0
				stosb
				invoke	SetDlgItemText,hDialog,3050,addr thrsend.recvbuf
				invoke	socket,PF_INET,SOCK_STREAM,0
				.if eax!=INVALID_SOCKET
					mov	thrsend.socket,eax
					invoke	connect,eax,addr thrsend.saddr,sizeof sockaddr_in
					.if eax==SOCKET_ERROR
						lea	edi,thrsend.recvbuf
						invoke	WSAGetLastError
						push	eax
						lea	edx,s_err0
						call	copyedx
						pop	eax
						push	eax
						call	itoa
						pop	eax
						call	wserr
						mov	al,0
						stosb
						invoke	SetDlgItemText,hDialog,3102,addr thrsend.recvbuf
						invoke	SetDlgItemText,hDialog,3050,addr s_stat5
						invoke	closesocket,thrsend.socket
						mov	thrsend.state,0
						mov	thrsend.socket,0
						invoke	SetDlgItemText,hDialog,3002,addr s_chgstate2
					.else
						invoke	SetDlgItemText,hDialog,3050,addr s_stat4
						invoke	SetDlgItemText,hDialog,3002,addr s_chgstate1
						mov	thrsend.state,1
					.endif
				.endif
			.elseif (thrsend.state==1)||(thrsend.state==2)
				invoke	closesocket,thrsend.socket
				mov	thrsend.socket,0
				mov	thrsend.state,0
				invoke	SetDlgItemText,hDialog,3002,addr s_chgstate2
				invoke	SetDlgItemText,hDialog,3050,addr s_stat5
			.endif
		.elseif thrsend.opcode==4
			mov	thrsend.opcode,0
			mov	thrsend.bytes,0
			invoke	SetDlgItemText,hDialog,3102,addr s_stat2-1
			.if thrsend.state==0
				lea	edx,thrsend
				call	parsepath
				invoke	SetDlgItemText,hDialog,3050,addr s_stat1
				lea	edx,thrsend
				call	resolvepath
				.break .if thrsend.thrstat==0
				lea	edi,thrsend.recvbuf
				lea	edx,s_stat2
				call	copyedx
				mov	eax,dword ptr thrsend.saddr.sin_addr
				call	w_ip
				mov	eax,'... '
				stosd
				mov	al,0
				stosb
				invoke	SetDlgItemText,hDialog,3050,addr thrsend.recvbuf
				invoke	socket,PF_INET,SOCK_STREAM,0
				.if eax!=INVALID_SOCKET
					mov	thrsend.socket,eax
					invoke	connect,eax,addr thrsend.saddr,sizeof sockaddr_in
					.if eax==SOCKET_ERROR
						lea	edi,thrsend.recvbuf
						invoke	WSAGetLastError
						push	eax
						lea	edx,s_err0
						call	copyedx
						pop	eax
						push	eax
						call	itoa
						pop	eax
						call	wserr
						mov	al,0
						stosb
						invoke	SetDlgItemText,hDialog,3102,addr thrsend.recvbuf
						invoke	closesocket,thrsend.socket
						mov	thrsend.socket,0
						mov	thrsend.state,0
						invoke	SetDlgItemText,hDialog,3002,addr s_chgstate2
					.else
						mov	thrsend.state,1
						invoke	SetDlgItemText,hDialog,3002,addr s_chgstate1
					.endif
				.endif
			.endif
			.if (thrsend.state==1)||(thrsend.state==2)
				invoke	SetDlgItemText,hDialog,3050,addr s_stat3
				invoke	GetFileSize,thrsend.tmpdata,0
				mov	esi,eax
				inc	esi
				lea	eax,[eax+1024]
				invoke	GlobalAlloc,GPTR,eax
				push	eax
				mov	edi,eax
				invoke	ReadFile,thrsend.tmpdata,edi,esi,addr thrsend.tmpbytes,0
				invoke	CloseHandle,thrsend.tmpdata
				mov	thrsend.tmpdata,0
				mov	esi,thrsend.tmpbytes
				xor	eax,eax
				.while eax<esi
					invoke	send,thrsend.socket,edi,esi,0
					.if (eax==SOCKET_ERROR)||(eax==0)
						lea	edi,thrsend.recvbuf
						invoke	WSAGetLastError
						push	eax
						lea	edx,s_err0
						call	copyedx
						pop	eax
						push	eax
						call	itoa
						pop	eax
						call	wserr
						mov	al,0
						stosb
						invoke	SetDlgItemText,hDialog,3102,addr thrsend.recvbuf
						invoke	closesocket,thrsend.socket
						mov	thrsend.socket,0
						mov	thrsend.state,0
						invoke	SetDlgItemText,hDialog,3002,addr s_chgstate2
						jmp	_thr_end_sf
					.endif
					add	edi,eax
					sub	esi,eax
					xor	eax,eax
				.endw
				invoke	SetDlgItemText,hDialog,3050,addr s_stat4
_thr_end_sf:			call	GlobalFree
			.endif
		.elseif (thrsend.state==1)||(thrsend.state==2)
			mov	thrsend.fds.fd_count,1
			mov	eax,thrsend.socket
			mov	thrsend.fds.fd_array,eax
			mov	thrsend.twait.tv_sec,0
			mov	thrsend.twait.tv_usec,0
			invoke	select,0,addr thrsend.fds,0,0,addr thrsend.twait
			mov	ecx,thrsend.socket
			.if (eax==SOCKET_ERROR)
				jmp	s_recverr
			.elseif (eax==1)&&(thrsend.fds.fd_count==1)&&(ecx==thrsend.fds.fd_array)
				invoke	recv,thrsend.socket,addr thrsend.tmpbytes,1,MSG_PEEK
				.if eax==0
					jmp	s_disconn
				.elseif eax==SOCKET_ERROR
					jmp	s_recverr
				.endif
			.endif
			mov	thrsend.tmpbytes,0
			invoke	ioctlsocket,thrsend.socket,FIONREAD,addr thrsend.tmpbytes
			.if eax==SOCKET_ERROR
s_recverr:			lea	edi,thrsend.recvbuf
				lea	edx,s_stat5
				call	copyedx
				mov	ax,' ,'
				stosw
				invoke	WSAGetLastError
				push	eax
				lea	edx,s_err0
				call	copyedx
				pop	eax
				push	eax
				call	itoa
				pop	eax
				call	wserr
				mov	al,0
				stosb
				invoke	SetDlgItemText,hDialog,3050,addr thrsend.recvbuf
				invoke	closesocket,thrsend.socket
				mov	thrsend.socket,0
				mov	thrsend.state,0
				invoke	SetDlgItemText,hDialog,3002,addr s_chgstate2
			.elseif thrsend.tmpbytes!=0
				.if thrsend.state==2
					mov	ecx,thrsend.tmpbytes
					.if ecx>8192
						mov	ecx,8192
					.endif
					lea	edi,thrsend.recvbuf
				.else
					mov	eax,thrsend.bytes
					add	eax,thrsend.tmpbytes
					.if eax>10000
						mov	thrsend.state,2
						.if thrsend.tmpbytes>4096
							mov	ecx,1024
						.else
							mov	ecx,thrsend.tmpbytes
						.endif
					.else
						mov	ecx,thrsend.tmpbytes
					.endif
					mov	eax,thrsend.bytes
					lea	edi,thrsend.recvbuf[eax]
				.endif
				invoke	recv,thrsend.socket,edi,ecx,0
				.if eax==0
s_disconn:				lea	edi,thrsend.recvbuf
					lea	edx,s_stat5
					call	copyedx
					lea	edx,s_stat6
					call	copyedx
					mov	eax,thrsend.bytes
					call	itoa
					mov	al,0
					stosb
					invoke	SetDlgItemText,hDialog,3050,addr thrsend.recvbuf
					invoke	closesocket,thrsend.socket
					mov	thrsend.socket,0
					mov	thrsend.state,0
					invoke	SetDlgItemText,hDialog,3002,addr s_chgstate2
				.elseif eax==SOCKET_ERROR
					jmp	s_recverr
				.else
					mov	edx,thrsend.bytes
					lea	edx,[edx+eax]
					.if (thrsend.state==1)&&(edx>=4)
						lea	edx,thrsend.recvbuf
						.if (dword ptr[edx]=='PTTH')
							push	eax
							add	eax,thrsend.bytes
							sub	eax,4
							.if eax<7fffffffh
								xor	ecx,ecx
								.while ecx<=eax
									.if dword ptr[edx+ecx]==0a0d0a0dh
										mov	thrsend.state,2
										lea	ecx,[ecx+4]
										mov	thrsend.hdrsize,ecx
										invoke	IsDlgButtonChecked,hDialog,3400
										.if eax==BST_CHECKED
											invoke	GetDlgItemText,hDialog,3103,addr thrsend.filename,8191
											invoke	SetFileAttributes,addr thrsend.filename,0
											invoke	DeleteFile,addr thrsend.filename
											pop	ecx
											push	ecx
											add	ecx,thrsend.bytes
											sub	ecx,thrsend.hdrsize
											.if ecx
												push	ecx
												lea	edx,thrsend.filename
												call	mkdirs
												invoke	CreateFile,addr thrsend.filename,GENERIC_READ or GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0
												pop	ecx
												push	eax
												push	edi
												add	edi,thrsend.hdrsize
												invoke	WriteFile,eax,edi,ecx,addr thrsend.tmpbytes,0
												pop	edi
												call	CloseHandle
											.endif
										.endif
										.break
									.endif
									inc	ecx
								.endw
							.endif
							pop	eax
						.else
							mov	thrsend.state,2
						.endif
						push	eax
						mov	ecx,eax
						add	ecx,thrsend.bytes
						lea	edx,thrsend.recvbuf
						.while ecx
							.if byte ptr[edx]==0
								mov	byte ptr[edx],32
							.endif
							inc	edx
							dec	ecx
						.endw
						mov	byte ptr[edx],0
						invoke	SetDlgItemText,hDialog,3102,addr thrsend.recvbuf
						pop	eax
					.elseif thrsend.state==2
						push	eax
						invoke	IsDlgButtonChecked,hDialog,3400
						.if eax==BST_CHECKED
							invoke	CreateFile,addr thrsend.filename,GENERIC_READ or GENERIC_WRITE,FILE_SHARE_READ,0,OPEN_ALWAYS,0,0
							push	eax
							invoke	SetFilePointer,eax,0,0,FILE_END
							pop	eax
							pop	ecx
							push	ecx
							push	eax
							invoke	WriteFile,eax,edi,ecx,addr thrsend.tmpbytes,0
							call	CloseHandle
						.endif
						.if thrsend.bytes<1024*1024/4
							mov	ecx,[esp]
							lea	edx,thrsend.recvbuf
							.while ecx
								.if byte ptr[edx]==0
									mov	byte ptr[edx],32
								.endif
								inc	edx
								dec	ecx
							.endw
							mov	byte ptr[edx],0
							invoke	SendDlgItemMessage,hDialog,3102,EM_GETLIMITTEXT,0,0
							push	eax
							invoke	SendDlgItemMessage,hDialog,3102,WM_GETTEXTLENGTH,0,0
							pop	edx
							sub	edx,eax
							.if edx<dword ptr[esp]
								push	eax
								add	edx,[esp]
								lea	edx,[edx+eax+8192]
								invoke	SendDlgItemMessage,hDialog,3102,EM_SETLIMITTEXT,edx,0
								pop	eax
							.endif
							invoke	SendDlgItemMessage,hDialog,3102,EM_SETSEL,eax,eax
							invoke	SendDlgItemMessage,hDialog,3102,EM_REPLACESEL,0,addr thrsend.recvbuf
							mov	eax,[esp]
							add	eax,thrsend.bytes
							.if eax>=1024*1024
								invoke	SendDlgItemMessage,hDialog,3102,WM_GETTEXTLENGTH,0,0
								invoke	SendDlgItemMessage,hDialog,3102,EM_SETSEL,eax,eax
								mov	word ptr thrsend.recvbuf,0a0dh
								mov	dword ptr thrsend.recvbuf[2],'...'
								invoke	SendDlgItemMessage,hDialog,3102,EM_REPLACESEL,0,addr thrsend.recvbuf
							.endif
						.endif
						pop	eax
					.endif
					add	thrsend.bytes,eax
					mov	eax,thrsend.bytes
					lea	edi,thrsend.recvbuf[65500]
					lea	edx,s_stat7
					call	copyedx
					mov	eax,thrsend.bytes
					call	itoa
					mov	al,0
					stosb
					invoke	SetDlgItemText,hDialog,3050,addr thrsend.recvbuf[65500]
				.endif
			.endif
		.endif
		invoke	Sleep,10
	.endw
	mov	thrsend.opcode,0
	xor	eax,eax
	xchg	eax,thrsend.hThread
	invoke	CloseHandle,eax
	invoke	ExitThread,0
	ret
sendThread	ENDP

makehdr:invoke	GetDlgItemText,hDialog,3100,addr thrsend.address,8191
	lea	edx,thrsend
	call	parsepath
	lea	edi,thrsend.recvbuf
	lea	edx,http1
	call	copyedx
	lea	edx,thrsend.path
	.if byte ptr[edx]==0
		mov	al,'/'
		stosb
	.else
		.while (byte ptr[edx]>32)&&(byte ptr[edx]!='#')
			mov	al,[edx]
			stosb
			inc	edx
		.endw
	.endif
	call	ua_01
	lea	edx,thrsend.hostname
	call	copyedx
	call	ua_02
;	.if (_cookies!=0)
;		lea	edx,_cookies
;		call	copyedx
;	.endif
	call	ua_03a
	mov	al,0
	stosb
	invoke	SetDlgItemText,hDialog,3101,addr thrsend.recvbuf
	ret

resolvepath:
	assume	edx:ptr thread_info
	push	edx
	invoke	inet_addr,addr [edx].hostname
	.if eax==INADDR_NONE
		pop	edx
		push	edx
		invoke	gethostbyname,addr [edx].hostname
		.if eax!=0
			mov	eax,[eax+12]
			mov	eax,[eax]
			mov	eax,[eax]
		.endif
	.endif
	pop	edx
	mov	dword ptr [edx].saddr.sin_addr,eax
	mov	[edx].saddr.sin_family,PF_INET
	assume	edx:nothing
	ret

parsepath:
	assume	edx:ptr thread_info
	push	esi
	push	edi
	cld
	lea	edi,[edx].saddr
	mov	ecx,sizeof sockaddr_in
	xor	eax,eax
	rep	stosb
	lea	esi,[edx].address
	mov	eax,[esi]
	or	eax,20202020h
	.if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+6]=='/')
		lea	esi,[esi+7]
	.endif
	lea	edi,[edx].hostname
	mov	ecx,1023
	.while (ecx!=0)&&(byte ptr[esi]!='/')&&(byte ptr[esi]!='\')&&(byte ptr[esi]!=0)&&(byte ptr[esi]!=':')
		movsb
		dec	ecx
	.endw
	mov	al,0
	stosb
	.if byte ptr[esi]==':'
		inc	esi
		push	edx
		call	atoi
		pop	edx
		xchg	al,ah
		mov	[edx].saddr.sin_port,ax
	.else
		mov	[edx].saddr.sin_port,80*256
	.endif
	.if (byte ptr[esi]=='/')||(byte ptr[esi]=='\')
		lea	edi,[edx].path
		.while byte ptr[esi]>32
			lodsb
			.if al=='\'
				mov	al,'/'
			.endif
			stosb
		.endw
	.else
		mov	byte ptr[edx].path,0
	.endif
	mov	al,0
	stosb
	pop	edi
	pop	esi
	assume	edx:nothing
	ret


clpchk:	invoke	OpenClipboard,hDialog
	invoke	GetClipboardData,CF_OEMTEXT
	.if eax
		mov	edi,eax
		invoke	GlobalLock,edi
		.if eax
			mov	esi,eax
			mov	eax,[esi]
			or	eax,20202020h
			.if (eax=='ptth')||(eax=='.www')
				xor	ecx,ecx
				.while (ecx<8192)&&(byte ptr[esi+ecx]!=0)
					.break .if (byte ptr[esi+ecx]<32)
					inc	ecx
				.endw
				.if byte ptr[esi+ecx]==0
					push	ecx
					invoke	SetDlgItemText,hDialog,3100,esi
					pop	ecx
					invoke	SendDlgItemMessage,hDialog,3100,EM_SETSEL,-1,ecx
				.endif
			.endif
			invoke	GlobalUnlock,edi
		.endif
	.endif
	invoke	CloseClipboard
	ret

initclp:invoke	GetCommandLine
	.if byte ptr[eax]==34
		inc	eax
		.while (byte ptr[eax]!=0)&&(byte ptr[eax]!=34)
			inc	eax
		.endw
		.if byte ptr[eax]==34
			inc	eax
		.endif
	.else
		.while (byte ptr[eax]>32)
			inc	eax
		.endw
	.endif
	.while (byte ptr[eax]==32)||(byte ptr[eax]==9)||(byte ptr[eax]==13)||(byte ptr[eax]==10)
		inc	eax
	.endw
	.if byte ptr[eax]
		.if byte ptr[eax]==34
			lea	edi,buftmp
			lea	edx,[eax+1]
			.while (byte ptr[edx]!=0)&&(byte ptr[edx]!=34)
				mov	al,[edx]
				stosb
				inc	edx
			.endw
			mov	al,0
			stosb
			invoke	SetDlgItemText,hDialog,100,addr buftmp
		.else
			lea	edi,buftmp
			mov	edx,eax
			.while (byte ptr[edx]>32)
				mov	al,[edx]
				stosb
				inc	edx
			.endw
			mov	al,0
			stosb
			invoke	SetDlgItemText,hDialog,100,addr buftmp
		.endif
		invoke	GetDlgItem,hDialog,5
	.else
		invoke	OpenClipboard,hDialog
		invoke	GetClipboardData,CF_OEMTEXT
		.if eax
			mov	edi,eax
			invoke	GlobalLock,edi
			.if eax
				push	edi
				mov	esi,eax
				xor	ecx,ecx
				.while byte ptr[esi+ecx]
					inc	ecx
				.endw
				push	ecx
				inc	ecx
				lea	ecx,[ecx*2+1024]
				invoke	GlobalAlloc,GPTR,ecx
				pop	ecx
				push	eax
				mov	byte ptr[eax],0
				mov	edx,esi
				invoke	savelinked,eax
				pop	esi
				push	esi
				.while byte ptr[esi]
					.break .if (byte ptr[esi]!=32)&&(byte ptr[esi]!=9)&&(byte ptr[esi]!=13)&&(byte ptr[esi]!=10)
					inc	esi
				.endw
				xor	ecx,ecx
				xor	eax,eax
				.while (byte ptr[esi+ecx]!=0)
					.if (byte ptr[esi+ecx]==13)&&(byte ptr[esi+ecx+1]==10)&&(byte ptr[esi+ecx+2]!=0)
						inc	eax
					.elseif ((byte ptr[esi+ecx]==13)||(byte ptr[esi+ecx]==10))&&(byte ptr[esi+ecx+2]!=0)
						inc	eax
					.endif
					inc	ecx
				.endw
				.if eax
					push	esi
					invoke	SendDlgItemMessage,hDialog,1000,LB_SETCURSEL,1,0
					mov	esi,hDialog
					mov	eax,2
					call	showhide
					pop	esi
					invoke	SetDlgItemText,hDialog,2100,esi
					invoke	SendDlgItemMessage,hDialog,2100,WM_GETTEXTLENGTH,0,0
					invoke	SendDlgItemMessage,hDialog,2100,EM_SETSEL,-1,eax
					invoke	GetDlgItem,hDialog,1
				.else
					mov	ebx,esi
					call	is_ip
					mov	edx,eax
					mov	eax,[esi]
					or	eax,20202020h
					.if (eax=='ptth')||(eax=='.www')||(edx==1)
						xor	ecx,ecx
						.while byte ptr[esi+ecx]
							mov	eax,[esi+ecx]
							or	eax,20202020h
							.break .if (eax=='bphp')||(eax=='raob')||(eax=='urof')||(eax=='golb')||(eax=='serp')
							inc	ecx
						.endw
						.if byte ptr[esi+ecx]
							invoke	SetDlgItemText,hDialog,100,esi
							invoke	SendDlgItemMessage,hDialog,100,WM_GETTEXTLENGTH,0,0
							invoke	SendDlgItemMessage,hDialog,100,EM_SETSEL,-1,eax
							invoke	GetDlgItem,hDialog,100
						.else
							push	esi
							invoke	SendDlgItemMessage,hDialog,1000,LB_SETCURSEL,2,0
							mov	esi,hDialog
							mov	eax,3
							call	showhide
							pop	esi
							invoke	SetDlgItemText,hDialog,3100,esi
							invoke	SendDlgItemMessage,hDialog,3100,WM_GETTEXTLENGTH,0,0
							invoke	SendDlgItemMessage,hDialog,3100,EM_SETSEL,-1,eax
							invoke	GetDlgItem,hDialog,3007
						.endif
					.else
						invoke	GetDlgItem,hDialog,100
					.endif
				.endif
				pop	edx
				push	eax
				invoke	GlobalFree,edx
				pop	eax
				pop	edi
				push	eax
				invoke	GlobalUnlock,edi
				pop	eax
			.else
				invoke	GetDlgItem,hDialog,100
			.endif
		.else
			invoke	GetDlgItem,hDialog,100
		.endif
		push	eax
		invoke	CloseClipboard
		pop	eax
	.endif
	invoke	SetFocus,eax
	ret

resolve_addr:
	mov	thrsend.res_ip,0
	push	edx
	lea	edi,thrsend.recvbuf
	invoke	inet_addr,addr thrsend.hostname
	.if eax==INADDR_NONE
		pop	edx
		push	edx
		invoke	gethostbyname,addr thrsend.hostname
		.if eax!=0
			mov	edx,eax
			mov	edx,[edx+12]
			mov	edx,[edx]
			mov	edx,[edx]
			mov	thrsend.res_ip,edx
		.endif
	.else
		mov	dword ptr thrsend.saddr.sin_addr,eax
		mov	thrsend.res_ip,eax
		invoke	gethostbyaddr,addr thrsend.saddr.sin_addr,4,AF_INET
	.endif
	.if eax
		mov	esi,eax
		assume	esi:ptr hostent
		mov	edx,[esi].h_name
		call	copyedx
		push	esi
		mov	esi,[esi].h_alias
		.while dword ptr[esi]!=0
			mov	eax,' , '
			stosd
			dec	edi
			lodsd
			mov	edx,eax
			call	copyedx
		.endw
		pop	esi
		mov	eax,0a0d0a0dh
		stosd
		mov	esi,dword ptr[esi+12]
		push	edi
		lea	edi,thrsend.recvbuf[16380]
		.while dword ptr[esi]!=0
			lodsd
			mov	eax,[eax]
			mov	dword ptr[edi],eax
			sub	edi,4
		.endw
		lea	esi,[edi+4]
		pop	edi
		.if ipchk!=-1
			mov	byte ptr[edi],0
			invoke	SendDlgItemMessage,hDialog,3102,WM_GETTEXTLENGTH,0,0
			invoke	SendDlgItemMessage,hDialog,3102,EM_SETSEL,eax,eax
			invoke	SendDlgItemMessage,hDialog,3102,EM_REPLACESEL,0,addr thrsend.recvbuf
			lea	edi,thrsend.recvbuf
		.endif
		.while esi<offset thrsend.recvbuf[16384]
			lodsd
			push	eax
			mov	thrsend.res_ip,eax
			call	w_ip
			mov	eax,' = '
			stosd
			dec	edi
			pop	eax
			mov	dword ptr thrsend.saddr.sin_addr,eax
			invoke	gethostbyaddr,addr thrsend.saddr.sin_addr,4,AF_INET
			.if eax
				push	esi
				mov	esi,eax
				assume	esi:ptr hostent
				mov	edx,[esi].h_name
				call	copyedx
				mov	esi,[esi].h_alias
				.while dword ptr[esi]!=0
					mov	eax,' , '
					stosd
					dec	edi
					lodsd
					mov	edx,eax
					call	copyedx
				.endw
				pop	esi
			.endif
			mov	ax,0a0dh
			stosw
			.if ipchk!=-1
				mov	byte ptr[edi],0
				invoke	SendDlgItemMessage,hDialog,3102,WM_GETTEXTLENGTH,0,0
				invoke	SendDlgItemMessage,hDialog,3102,EM_SETSEL,eax,eax
				invoke	SendDlgItemMessage,hDialog,3102,EM_REPLACESEL,0,addr thrsend.recvbuf
				lea	edi,thrsend.recvbuf
				invoke	SetDlgItemText,hDialog,3050,addr s_stat1a
				mov	ipchk,0
				call	get_h_info
				lea	edi,thrsend.recvbuf
			.endif
		.endw
		.if ipchk==-1
			mov	al,0
			stosb
			invoke	SetDlgItemText,hDialog,3102,addr thrsend.recvbuf
		.endif
		assume	esi:nothing
	.else
		lea	edi,thrsend.recvbuf
		invoke	WSAGetLastError
		push	eax
		lea	edx,s_err0
		call	copyedx
		pop	eax
		push	eax
		call	itoa
		pop	eax
		call	wserr
		mov	al,0
		stosb
		invoke	SetDlgItemText,hDialog,3102,addr thrsend.recvbuf
		.if thrsend.res_ip
			.if ipchk!=-1
				mov	byte ptr[edi],0
				lea	edi,thrsend.recvbuf
				invoke	SetDlgItemText,hDialog,3050,addr s_stat1a
				mov	ipchk,0
				call	get_h_info
			.endif
		.endif
	.endif
	pop	edx
	ret

s_live	db	'GET /results.aspx?q=ip%3A',0
s_live1	db	' HTTP/1.0',13,10,'Accept: */*',13,10,'Accept-Language: en-us',13,10,'UA-CPU: x86',13,10,'Cookie: SRCHHPGUSR=NEWWND=0&ADLT=',0
s_live2	db	'OFF',0
s_live2a db	'STRICT',0
s_live2b db	'DEMOTE',0
s_live3	db	'&NRSLT=200',13,10
	db	'Accept-Encoding: identity',13,10,'User-Agent: Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) )',13,10
	db	'Host: search.live.com',13,10,'Connection: Keep-Alive',13,10,13,10,0
live_	db	'search.live.com',0
live_r	db	13,10,'The following websites were found on ',0
live_t	db	13,10,'Total: ',0
live_t1	db	' websites.',13,10,13,10,0

get_h_info	PROC	uses esi edi
	local	r_edx:DWORD,hMem:DWORD,hMem1:DWORD,size1:DWORD,init1:DWORD,hosts1:DWORD
	.if thrsend.res_ip==0
		ret
	.endif
	mov	r_edx,edx
	.if iplive==0
		invoke	gethostbyname,addr live_
		.if eax!=0
			mov	eax,[eax+12]
			mov	eax,[eax]
			mov	eax,[eax]
			mov	iplive,eax
		.else
			ret
		.endif
	.endif
	invoke	GlobalAlloc,GPTR,1024*1024
	mov	hMem,eax
	mov	size1,32768
	invoke	GlobalAlloc,GPTR,size1
	mov	hMem1,eax
	mov	edi,eax
	lea	edx,live_r
	call	copyedx
	mov	eax,thrsend.res_ip
	call	w_ip
	mov	al,':'
	stosb
	mov	eax,0a0dh
	stosd
	mov	ecx,edi
	sub	ecx,hMem1
	sub	ecx,2
	mov	init1,ecx
	mov	hosts1,0
	xor	ecx,ecx
	.while (ecx<=100)&&(thrsend.res_ip!=0)
		push	ecx
		mov	edi,hMem
		lea	edx,s_stat1a
		call	copyedx
		mov	ax,'[ '
		stosw
		movzx	eax,ipchk
		inc	eax
		call	itoa
		mov	al,':'
		stosb
		mov	eax,[esp]
		call	itoa
		mov	ax,']'
		stosw
		invoke	SetDlgItemText,hDialog,3050,hMem
		mov	edi,hMem
		call	get_live_page
		.if edi==hMem
			pop	ecx
			inc	ipchk
			xor	ecx,ecx
			.break .if ipchk==3
			.continue
		.endif
		mov	al,0
		stosb
		mov	edx,hMem
		.while byte ptr[edx]
			mov	eax,[edx+1]
			or	eax,20202020h
			.if (byte ptr[edx]=='<')&&(eax=='etic')&&(byte ptr[edx+1+4]=='>')
				lea	edx,[edx+6]
				mov	eax,[edx]
				or	eax,20202020h
				.if (word ptr[edx+4]=='/:')&&(byte ptr[edx+6]=='/')
					lea	edx,[edx+7]
				.elseif (word ptr[edx+3]=='/:')&&(byte ptr[edx+5]=='/')
					lea	edx,[edx+6]
				.elseif (word ptr[edx+5]=='/:')&&(byte ptr[edx+7]=='/')
					lea	edx,[edx+8]
				.endif
				mov	edi,hMem1
				add	edi,init1
				.while byte ptr[edi]
					xor	ecx,ecx
					.while byte ptr[edi+ecx]>32
						mov	al,[edi+ecx]
						mov	ah,[edx+ecx]
						or	ax,2020h
						.break .if al!=ah
						inc	ecx
					.endw
					.if (byte ptr[edi+ecx]<33)&&((byte ptr[edx+ecx]=='<')||(byte ptr[edx+ecx]=='&')||(byte ptr[edx+ecx]<33)||(byte ptr[edx+ecx]=='/'))
						.break
					.else
						.while (byte ptr[edi]>32)
							inc	edi
						.endw
						.while (byte ptr[edi]<33)&&(byte ptr[edi]!=0)
							inc	edi
						.endw
					.endif
				.endw
				.if byte ptr[edi]==0
					mov	ax,0a0dh
					stosw
					xor	ecx,ecx
					.while 1
						.break .if ((byte ptr[edx]=='<')||(byte ptr[edx]=='&')||(byte ptr[edx]<33)||(byte ptr[edx]=='/')||(ecx>255))
						mov	al,[edx]
						stosb
						inc	ecx
						inc	edx
					.endw
					mov	al,0
					stosb
					mov	eax,edi
					sub	eax,hMem1
					add	eax,512
					.if eax>size1
						push	edx
						add	size1,32768
						invoke	GlobalAlloc,GPTR,size1
						mov	edi,eax
						mov	edx,hMem1
						mov	hMem1,eax
						push	edx
						call	copyedx
						mov	al,0
						stosb
						call	GlobalFree
						pop	edx
					.endif
					inc	hosts1
				.endif
			.else
				inc	edx
			.endif
		.endw

		push	0
		mov	edx,hMem
		.while byte ptr[edx]
			mov	ax,[edx]
			or	ax,2000h
			.if (ax=='a<')
				inc	edx
				.while (byte ptr[edx]!='>')&&(byte ptr[edx]!=0)
					mov	eax,[edx]
					or	eax,20202020h
					.if (dword ptr[edx]=='p_bs')&&(dword ptr[edx+4]=='"Nga')
				;		inc	dword ptr[esp]
						lea	edx,[edx+4]
				;		.break
					.elseif (eax=='srif')&&((word ptr[edx+4]=='=t')||(word ptr[edx+4]=='=T'))
						add	edx,6
						push	edx
						mov	esi,edx
						call	atoi
						push	eax
						mov	eax,200
						mov	ecx,dword ptr[esp+4+4+4]
						inc	ecx
						xor	edx,edx
						mul	ecx
						inc	eax
						pop	edx
						.if (eax<=edx)
							inc	dword ptr[esp+4]
							pop	edx
							.break
						.endif
						pop	edx
					.else
						inc	edx
					.endif
				.endw
			.else
				inc	edx
			.endif
		.endw
		pop	eax
		pop	ecx
		.if eax==0
			inc	ipchk
			xor	ecx,ecx
			.break .if ipchk==3
			.continue
		.endif
		inc	ecx
		.if ecx==100
			inc	ipchk
			.break .if ipchk==3
		.endif
	.endw
	mov	edi,hMem1
	xor	ecx,ecx
	.while byte ptr[edi+ecx]
		inc	ecx
	.endw
	inc	ecx
	push	ecx
	shl	ecx,1
	invoke	GlobalAlloc,GPTR,ecx
	pop	ecx
	push	eax
	mov	esi,hMem1
	mov	edi,eax
	rep	movsb
	mov	edi,[esp]
	add	edi,init1
	inc	edi
	inc	edi
	.while 1
		mov	esi,hMem1
		add	esi,init1
		.while (byte ptr[esi]==13)||(byte ptr[esi]==10)
			inc	esi
		.endw
		.break .if byte ptr[esi]==0
		mov	edx,esi
		.while 1
			.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
				inc	esi
			.endw
			.while (byte ptr[esi]==13)||(byte ptr[esi]==10)
				inc	esi
			.endw
			.break .if byte ptr[esi]==0
			xor	ecx,ecx
			.while (byte ptr[esi+ecx]!=13)&&(byte ptr[esi+ecx]!=10)&&(byte ptr[esi+ecx]!=0)&&(byte ptr[edx+ecx]!=13)&&(byte ptr[edx+ecx]!=10)&&(byte ptr[edx+ecx]!=0)
				mov	al,[esi+ecx]
				mov	ah,[edx+ecx]
				or	ax,2020h
				.break .if al!=ah
				inc	ecx
			.endw
			.if (byte ptr[esi+ecx]!=13)&&(byte ptr[esi+ecx]!=10)&&(byte ptr[esi+ecx]!=0)&&(byte ptr[edx+ecx]!=13)&&(byte ptr[edx+ecx]!=10)&&(byte ptr[edx+ecx]!=0)
				mov	al,[esi+ecx]
				mov	ah,[edx+ecx]
				or	ax,2020h
				.if al<ah
					mov	edx,esi
				.endif
			.endif
		.endw
		push	edx
		mov	al,9
		stosb
		.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
			mov	al,[edx]
			mov	byte ptr[edx],13
			stosb
			inc	edx
		.endw
		mov	ax,0a0dh
		stosw
		pop	edx
	.endw
	mov	al,0
	stosb
	mov	eax,[esp]
	xchg	eax,hMem1
	xchg	eax,[esp]
	call	GlobalFree
	mov	edi,hMem1
	.while byte ptr[edi]
		inc	edi
	.endw
	lea	edx,live_t
	call	copyedx
	mov	eax,hosts1
	call	itoa
	lea	edx,live_t1
	call	copyedx
	mov	al,0
	stosb
	invoke	SetDlgItemText,hDialog,3050,addr s_stat8
	invoke	SendDlgItemMessage,hDialog,3102,WM_GETTEXTLENGTH,0,0
	invoke	SendDlgItemMessage,hDialog,3102,EM_SETSEL,eax,eax
	invoke	SendDlgItemMessage,hDialog,3102,EM_REPLACESEL,0,hMem1
	invoke	GlobalFree,hMem
	invoke	GlobalFree,hMem1
	ret
get_h_info	ENDP

get_live_page:
	push	ecx
	invoke	socket,PF_INET,SOCK_STREAM,0
	.if eax==INVALID_SOCKET
		pop	ecx
		ret
	.endif
	mov	thrsend.socket,eax
	push	edi
	lea	edi,thrsend.saddr
	mov	ecx,sizeof sockaddr_in
	xor	eax,eax
	rep	stosb
	pop	edi
	mov	eax,iplive
	mov	thrsend.saddr.sin_addr,eax
	mov	thrsend.saddr.sin_family,PF_INET
	mov	thrsend.saddr.sin_port,80*256
	invoke	ioctlsocket,thrsend.socket,FIONBIO,addr _blocking
	invoke	connect,thrsend.socket,addr thrsend.saddr,sizeof sockaddr_in
	.if eax==0
		push	edi
		lea	edx,s_live
		call	copyedx
		mov	eax,thrsend.res_ip
		call	w_ip
		mov	ecx,[esp+4]
		.if ecx
			mov	eax,'rif&'
			stosd
			mov	eax,'=ts'
			stosd
			dec	edi
			mov	eax,200
			xor	edx,edx
			mul	ecx
			inc	eax
			call	itoa
		.endif
		lea	edx,s_live1
		call	copyedx
		.if ipchk==0
			lea	edx,s_live2
		.elseif ipchk==1
			lea	edx,s_live2a
		.else
			lea	edx,s_live2b
		.endif
		call	copyedx
		lea	edx,s_live3
		call	copyedx
		mov	ecx,edi
		pop	edi
		sub	ecx,edi
		invoke	send,thrsend.socket,edi,ecx,0
		xor	ecx,ecx
		.while ecx<1024*1024-32770
			push	ecx
			mov	thrsend.fds.fd_count,1
			mov	eax,thrsend.socket
			mov	thrsend.fds.fd_array,eax
			mov	thrsend.twait.tv_sec,0
			mov	thrsend.twait.tv_usec,0
			invoke	select,0,addr thrsend.fds,0,0,addr thrsend.twait
			mov	ecx,thrsend.socket
			.if (eax==SOCKET_ERROR)
				pop	ecx
				.break
			.elseif (eax==1)&&(thrsend.fds.fd_count==1)&&(ecx==thrsend.fds.fd_array)
				invoke	recv,thrsend.socket,addr thrsend.tmpbytes,1,MSG_PEEK
				.if eax==0
					pop	ecx
					.break
				.elseif eax==SOCKET_ERROR
					pop	ecx
					.break
				.endif
			.endif
			mov	thrsend.tmpbytes,0
			invoke	ioctlsocket,thrsend.socket,FIONREAD,addr thrsend.tmpbytes
			.if eax==SOCKET_ERROR
				pop	ecx
				.break
			.elseif thrsend.tmpbytes!=0
				.if thrsend.tmpbytes>32768
					mov	thrsend.tmpbytes,32768
				.endif
				invoke	recv,thrsend.socket,edi,thrsend.tmpbytes,0
				pop	ecx
				.if (eax==0)||(eax==SOCKET_ERROR)
					.break
				.endif
				add	ecx,eax
				add	edi,eax
				.if ecx>10
					.while (ecx!=0)&&(byte ptr[edi-1]<33)
						dec	edi
						dec	ecx
					.endw
					mov	eax,dword ptr[edi-5]
					or	eax,20202020h
					.if (eax=='lmth')&&(word ptr[edi-7]=='/<')
						.break
					.endif
				.endif
				push	ecx
			.else
				invoke	Sleep,10
			.endif
			pop	ecx
		.endw
	.endif
	invoke	closesocket,thrsend.socket
	pop	ecx
	ret
endm


test_dlginit	macro
	invoke	GetDlgItem,hDlg,3103
	invoke	EnableWindow,eax,0
	invoke	GetDlgItem,hDlg,3006
	invoke	EnableWindow,eax,0
	invoke	GlobalAlloc,GPTR,8192
	mov	edi,eax
	push	edi
	lea	edx,savedir
	call	copyedx
	cld
	.if byte ptr[edi-1]!='\'
		mov	al,'\'
		stosb
	.endif
	lea	edx,httpidx
	call	copyedx
	pop	edi
	invoke	SetDlgItemText,hDlg,3103,edi
	invoke	GlobalFree,edi
	mov	thrsend.thrstat,1
	mov	thrsend.opcode,0
	mov	thrsend.state,0
	mov	thrsend.tmpdata,0
	mov	iplive,0
	mov	autoupd,0
	invoke	CreateThread,0,0,addr sendThread,0,0,addr thrsend.hThread
	mov	thrsend.hThread,eax
endm

test_exit	macro
	mov	thrsend.thrstat,0
	mov	thrsend.opcode,0
	.if thrsend.socket
		invoke	closesocket,thrsend.socket
		mov	thrsend.socket,0
	.endif
	xor	ecx,ecx
	.while ecx<250
		push	ecx
		invoke	Sleep,20
		pop	ecx
		inc	ecx
		.break .if thrsend.hThread==0
	.endw
	.if thrsend.hThread
		invoke	TerminateThread,thrsend.hThread,0
		invoke	CloseHandle,thrsend.hThread
		mov	thrsend.hThread,0
	.endif
	.if thrsend.tmpdata
		invoke	CloseHandle,thrsend.tmpdata
	.endif
endm

test_dlgcmd	macro
	.elseif ax==3001
		invoke	GetDlgItemText,hDialog,3100,addr thrsend.address,8191
		mov	thrsend.opcode,2
	.elseif ax==3009
		invoke	GetDlgItemText,hDialog,3100,addr thrsend.address,8191
		.if iplive
			mov	thrsend.res_ip,0
		.else
			mov	thrsend.opcode,5
		.endif
	.elseif ax==3008
		invoke	IsDlgButtonChecked,hDlg,3008
		.if eax==BST_CHECKED
			or	autoupd,1
		.else
			and	autoupd,1 xor -1
		.endif
	.elseif ax==3002
		invoke	GetDlgItemText,hDialog,3100,addr thrsend.address,8191
		mov	thrsend.opcode,3
	.elseif ax==3003
		call	makehdr
	.elseif ax==3004
		invoke	GetDlgItemText,hDialog,3100,addr thrsend.address,8191
		mov	thrsend.opcode,1
	.elseif ax==3005
		.if thrsend.tmpdata==0
			invoke	GetDlgItemText,hDialog,3100,addr thrsend.address,8191
			invoke	GlobalAlloc,GPTR,8192
			push	eax
			mov	edi,eax
			mov	byte ptr[edi],0
			mov	ofn.lStructSize,sizeof OPENFILENAME
			push	hDialog
			pop	ofn.hwndOwner
			push	hInstance
			pop	ofn.hInstance
			mov	ofn.lpstrFilter,offset flthtml
			mov	ofn.lpstrCustomFilter,0
			mov	ofn.nMaxCustFilter,0
			mov	ofn.nFilterIndex,1
			mov	ofn.lpstrFile,edi
			mov	ofn.nMaxFile,8191
			mov	ofn.lpstrFileTitle,0
			mov	ofn.lpstrFileTitle,0
			mov	ofn.lpstrInitialDir,0
			mov	ofn.lpstrTitle,0
			mov	ofn.Flags,OFN_EXPLORER or OFN_HIDEREADONLY or OFN_LONGNAMES or OFN_NOCHANGEDIR or OFN_PATHMUSTEXIST or OFN_FILEMUSTEXIST
			mov	ofn.nFileOffset,0
			mov	ofn.nFileExtension,0
			mov	ofn.lpstrDefExt,0
			mov	ofn.lCustData,0
			mov	ofn.lpfnHook,0
			mov	ofn.lpTemplateName,0
			mov	thrsend.tmpdata,0
			invoke	GetOpenFileName,addr ofn
			.if eax!=0
				invoke	CreateFile,edi,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0
				.if eax==INVALID_HANDLE_VALUE
					xor	eax,eax
				.endif
				mov	thrsend.tmpdata,eax
			.endif
			call	GlobalFree
			.if thrsend.tmpdata
				mov	thrsend.opcode,4
			.endif
		.endif
	.elseif ax==3006
		invoke	GlobalAlloc,GPTR,8192
		push	eax
		mov	edi,eax
		invoke	GetDlgItemText,hDlg,3103,edi,8191
		mov	ofn.lStructSize,sizeof OPENFILENAME
		push	hDlg
		pop	ofn.hwndOwner
		push	hInstance
		pop	ofn.hInstance
		mov	ofn.lpstrFilter,offset flthtml
		mov	ofn.lpstrCustomFilter,0
		mov	ofn.nMaxCustFilter,0
		mov	ofn.nFilterIndex,1
		mov	ofn.lpstrFile,edi
		mov	ofn.nMaxFile,8191
		mov	ofn.lpstrFileTitle,0
		mov	ofn.lpstrFileTitle,0
		mov	ofn.lpstrInitialDir,0
		mov	ofn.lpstrTitle,0
		mov	ofn.Flags,OFN_EXPLORER or OFN_HIDEREADONLY or OFN_LONGNAMES or OFN_NOCHANGEDIR or OFN_PATHMUSTEXIST
		mov	ofn.nFileOffset,0
		mov	ofn.nFileExtension,0
		mov	ofn.lpstrDefExt,0
		mov	ofn.lCustData,0
		mov	ofn.lpfnHook,0
		mov	ofn.lpTemplateName,0
		invoke	GetSaveFileName,addr ofn
		.if eax!=0
			invoke	SetDlgItemText,hDlg,3103,edi
		.endif
		call	GlobalFree
	.elseif ax==3007
		call	makehdr
		invoke	GetDlgItemText,hDialog,3100,addr thrsend.address,8191
		mov	thrsend.opcode,1
	.elseif (ax==3100)&&(bx==EN_CHANGE)
		invoke	GlobalAlloc,GPTR,16384
		push	eax
		mov	edi,eax
		invoke	GetDlgItemText,hDlg,3103,edi,8191
		lea	ecx,[edi+8192]
		invoke	GetDlgItemText,hDlg,3100,ecx,8191
		lea	edx,[edi+8192]
		mov	ebx,edi
		.while byte ptr[edi]!=0
			.if (byte ptr[edi]=='\')||(byte ptr[edi]=='/')
				mov	ebx,edi
			.endif
			inc	edi
		.endw
		mov	edi,ebx
		.if (byte ptr[edi]=='/')||(byte ptr[edi]=='\')
			inc	edi
		.else
			mov	al,'\'
			stosb
		.endif
		mov	ecx,edx
		.while byte ptr[edx]!=0
			.if (byte ptr[edx]=='/')||(byte ptr[edx]=='\')
				mov	ecx,edx
			.endif
			inc	edx
		.endw
		.if (byte ptr[ecx]=='/')||(byte ptr[ecx]=='\')
			.if byte ptr[ecx+1]==0
				lea	ecx,httpidx
				xchg	ecx,edx
				call	copyedx
			.else
				inc	ecx
				xchg	ecx,edx
				call	copyfilename
			.endif
		.endif
		mov	al,0
		stosb
		pop	edi
		push	edi
		invoke	SetDlgItemText,hDlg,3103,edi
		call	GlobalFree
	.elseif ax==3400
		invoke	IsDlgButtonChecked,hDlg,3400
		.if eax==BST_CHECKED
			invoke	GetDlgItem,hDlg,3103
			invoke	EnableWindow,eax,1
			invoke	GetDlgItem,hDlg,3006
			invoke	EnableWindow,eax,1
		.else
			invoke	GetDlgItem,hDlg,3103
			invoke	EnableWindow,eax,0
			invoke	GetDlgItem,hDlg,3006
			invoke	EnableWindow,eax,0
		.endif
endm

dsafhkjsdf macro
		.elseif ax==1005
			call	thr_sendfile
endm

test_dlgmsg	macro
	.elseif (uMsg==WM_ACTIVATEAPP)&&(wParam!=0)&&(cframe==3)
		call	clpchk
endm
