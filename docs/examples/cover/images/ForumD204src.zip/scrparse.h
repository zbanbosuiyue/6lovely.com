ctype1	db	'Content-Type: application/x-www-form-urlencoded',13,10,0
err_res	db	'<X> Error resolving hostname ',0
err_con	db	'<X> Error connecting to ',0
err_send db	'<X> Error sending request headers',13,10,0
errsave	db	'<X> '
errsave_ db	'Error saving file',13,10,0
errsave1 db	'<X> Error saving file ',13,10,0

mkdirs:	push	edx
	.if byte ptr[edx+1]==':'
		inc	edx
		inc	edx
	.endif
	.if (byte ptr[edx]=='\')||(byte ptr[edx]=='/')
		inc	edx
	.endif
	.while byte ptr[edx]
		.if (byte ptr[edx]=='\')||(byte ptr[edx]=='/')
			pop	eax
			push	eax
			push	edx
			mov	byte ptr[edx],0
			invoke	CreateDirectory,eax,0
			pop	edx
			mov	byte ptr[edx],'\'
		.endif
		inc	edx
	.endw
	pop	edx
	ret

setredirect:
	mov	edx,_1._ptr
	.if edx==0
		inc	lasterror
	.else
		.while byte ptr[edx]
			.while (byte ptr[edx]==13)||(byte ptr[edx]==10)||(byte ptr[edx]==32)||(byte ptr[edx]==9)
				inc	edx
			.endw
			mov	eax,[edx]
			or	eax,20202020h
			mov	ecx,[edx+4]
			or	ecx,20202020h
			.if (eax=='acol')&&(ecx=='noit')&&(byte ptr[edx+8]==':')
				lea	edx,[edx+9]
				.while (byte ptr[edx]==32)||(byte ptr[edx]==9)
					inc	edx
				.endw
				.if (byte ptr[edx]>32)
					mov	eax,[edx]
					or	eax,20202020h
					push	esi
					push	edi
					.if (eax=='ptth')&&(byte ptr[edx+4]==':')
						mov	edi,_5._ptr
						xor	ecx,ecx
						.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)&&(ecx<8191)
							mov	al,[edx]
							stosb
							inc	edx
							inc	ecx
						.endw
						mov	al,0
						stosb
					.elseif byte ptr[edx]=='/'
						mov	edi,_5._ptr
						xor	ecx,ecx
						.while (byte ptr[edi]!=0)&&(byte ptr[edi]!='/')&&(byte ptr[edi]!='\')
							inc	edi
							inc	ecx
						.endw
						.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)&&(ecx<8191)
							mov	al,[edx]
							stosb
							inc	edx
							inc	ecx
						.endw
						mov	al,0
						stosb
					.else
						mov	edi,_5._ptr
						xor	ecx,ecx
						xor	eax,eax
						.while (byte ptr[edi]!=0)
							.if byte ptr[edi]=='/'
								mov	eax,edi
							.endif
							inc	edi
							inc	ecx
						.endw
						.if eax==0
							mov	al,'/'
							stosb
							inc	ecx
						.else
							lea	edi,[eax+1]
						.endif
						.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)&&(ecx<8191)
							mov	al,[edx]
							stosb
							inc	edx
							inc	ecx
						.endw
						mov	al,0
						stosb
					.endif
					call	mk_headers
					pop	edi
					pop	esi
				.else
					inc	lasterror
				.endif
				.break
			.else
				.while (byte ptr[edx]!=0)&&(byte ptr[edx]!=13)&&(byte ptr[edx]!=10)
					inc	edx
				.endw
			.endif
		.endw
	.endif
	ret

get_head:
	push	edi
	mov	_2._data,0
	mov	_2._pos,0
	push	eax
	mov	eax,3
	call	gbptr
	mov	_1._data,0
	mov	_1._pos,0
	mov	bread,0
	.while 1
		mov	ecx,10
		.while ecx
			pop	eax
			push	eax
			push	ecx
			mov	scrfds.fd_count,0
			mov	ecx,scrfds.fd_count
			shl	ecx,2
			mov	scrfds.fd_array[ecx],eax
			inc	scrfds.fd_count
			mov	scrtimewait.tv_sec,10	;10 secunde
			mov	scrtimewait.tv_usec,0
			invoke	select,10h,addr scrfds,0,0,addr scrtimewait
			pop	ecx
			.break .if eax==1
			dec	ecx
		.endw
		.if eax==1
			pop	eax
			push	eax
			mov	dword ptr buftmp,0
			invoke	ioctlsocket,eax,FIONREAD,addr buftmp
			mov	edx,dword ptr buftmp
			pop	eax
			push	eax
			mov	ecx,65536
			sub	ecx,bread
			.if edx>ecx
				mov	edx,ecx
			.endif
			lea	ebx,buftmp
			add	ebx,bread
			push	ebx
			invoke	recv,eax,ebx,edx,0
			pop	ebx
			.if (autoupd&1)
				invoke	recv_upd,addr buftmp,ebx,eax
			.endif
			.if (eax!=SOCKET_ERROR)&&(eax!=0)
				add	bread,eax
				lea	ebx,buftmp
				add	ebx,bread
				mov	byte ptr[ebx],0
				mov	ecx,bread
				.if ecx>4
					sub	ecx,4
				.endif
				lea	edx,buftmp
				.while ecx
					.break .if dword ptr[edx]==0a0d0a0dh
					inc	edx
					dec	ecx
				.endw
				.if (dword ptr[edx]==0a0d0a0dh)
					lea	edx,[edx+4]
					sub	edx,offset buftmp
					.if edx>_1._size
						push	edx
						lea	edx,[edx+8192]
						mov	_1._size,edx
						invoke	GlobalAlloc,GPTR,edx
						push	esi
						push	edi
						mov	ecx,_1._data
						mov	esi,_1._ptr
						mov	edi,eax
						mov	_1._ptr,eax
						cld
						push	esi
						rep	movsb
						call	GlobalFree
						mov	al,0
						stosb
						pop	edi
						pop	esi
						pop	edx
					.endif
					mov	_1._data,edx
					mov	ecx,edx
					push	esi
					push	edi
					lea	esi,buftmp
					mov	edi,_1._ptr
					cld
					rep	movsb
					pop	edi
					pop	esi
					mov	eax,_1._data
					sub	bread,eax
					.if bread
						mov	eax,bread
						.if eax>_2._size
							push	eax
							lea	edx,[eax+8192]
							mov	_2._size,eax
							invoke	GlobalAlloc,GPTR,edx
							push	_2._ptr
							mov	_2._ptr,eax
							call	GlobalFree
							pop	eax
						.endif
						mov	_2._data,eax
						push	esi
						push	edi
						mov	ecx,eax
						lea	esi,buftmp
						add	esi,_1._data
						mov	edi,_2._ptr
						cld
						rep	movsb
						pop	edi
						pop	esi
					.endif
					.break
				.endif
			.else
				mov	lasterror,1
				.break
			.endif
		.else
			.if eax==SOCKET_ERROR
				mov	lasterror,1
			.endif
			.break
		.endif
	.endw
	pop	eax
	pop	edi
	ret

get_data:
	push	edi
	push	eax
	.while 1
		mov	ecx,10
		.while ecx
			pop	eax
			push	eax
			push	ecx
			mov	scrfds.fd_count,0
			mov	ecx,scrfds.fd_count
			shl	ecx,2
			mov	scrfds.fd_array[ecx],eax
			inc	scrfds.fd_count
			mov	scrtimewait.tv_sec,10	;10 secunde
			mov	scrtimewait.tv_usec,0
			invoke	select,10h,addr scrfds,0,0,addr scrtimewait
			pop	ecx
			.break .if eax==1
			dec	ecx
		.endw
		.if eax==1
			pop	eax
			push	eax
			mov	dword ptr buftmp,0
			invoke	ioctlsocket,eax,FIONREAD,addr buftmp
			mov	edx,dword ptr buftmp
			.break .if edx==0
			jmp	_tnext_
_tnext:			pop	eax
			push	eax
			mov	dword ptr buftmp,0
			invoke	ioctlsocket,eax,FIONREAD,addr buftmp
			mov	edx,dword ptr buftmp
_tnext_:		.if edx>65536
				mov	edx,65536
			.endif
			mov	eax,edx
			add	eax,_2._data
			.if eax>_2._size
				push	edx
				lea	edx,[eax+8192]
				mov	_2._size,edx
				invoke	GlobalAlloc,GPTR,edx
				push	esi
				push	edi
				mov	ecx,_2._data
				mov	esi,_2._ptr
				mov	edi,eax
				mov	_2._ptr,eax
				cld
				push	esi
				rep	movsb
				call	GlobalFree
				mov	al,0
				stosb
				pop	edi
				pop	esi
				pop	edx
			.endif
			pop	eax
			push	eax
			mov	ebx,_2._ptr
			add	ebx,_2._data
			.continue .if edx==0
			invoke	recv,eax,ebx,edx,0
			.if (eax!=SOCKET_ERROR)&&(eax!=0)
				add	_2._data,eax
				jmp	_tnext
			.else
				.if eax==SOCKET_ERROR
					mov	lasterror,1
				.endif
				.break
			.endif
		.else
			mov	lasterror,1
			.break
		.endif
	.endw
	pop	eax
	pop	edi
	ret


scrsave_file	PROC uses esi edi ebx
	local	lParam:DWORD,r_buf:DWORD,srcdup:DWORD
	mov	srcdup,eax
	invoke	GlobalAlloc,GPTR,sizeof foruminfo
	mov	lParam,eax
	invoke	GlobalAlloc,GPTR,8192
	mov	r_buf,eax
	mov	ebx,lParam
	assume	ebx:ptr foruminfo
	lea	edi,[ebx]._addr
	mov	[ebx]._loc,0
	mov	edx,_5._ptr
	call	copyedx
	lea	edx,[ebx]._addr
	.while (edi>edx)&&((byte ptr[edi-1]<33)||(byte ptr[edi-1]==',')||(byte ptr[edi-1]=='&'))
		dec	edi
	.endw
	mov	al,0
	stosb
	.if srcdup
		call	issaved
		.if eax
			invoke	GlobalFree,lParam
			invoke	GlobalFree,r_buf
			ret
		.endif
	.endif

	mov	edi,lParam
	invoke	get_afile,addr r_buf,desturls,10,0,8192
	mov	hfile,0
	.if fsize
		idx_savefile
		mov	ebx,lParam
		lea	edx,[ebx]._save
		mov	edi,desturls
		call	copyedx
		mov	al,0
		stosb
		call	addurl
	.else
		inc	lasterror
	.endif
	invoke	GlobalFree,lParam
	invoke	GlobalFree,r_buf
	ret
scrsave_file	ENDP



hostchk:
	push	edi
	lea	edi,scrsaddr
	mov	ecx,sizeof scrsaddr
	xor	eax,eax
	rep	stosb
	.if _5._ptr
		mov	edx,_5._ptr
		mov	eax,[edx]
		or	eax,20202020h
		.if (eax=='ptth')&&(byte ptr[edx+4]==':')||(byte ptr[edx+4]=='/')||(byte ptr[edx+4]=='\')
			lea	edx,[edx+5]
			.while (byte ptr[edx]==':')||(byte ptr[edx]=='/')||(byte ptr[edx]=='\')
				inc	edx
			.endw
		.endif
		lea	edi,buftmp
		.while (byte ptr[edx]>32)&&(byte ptr[edx]!=':')&&(byte ptr[edx]!='/')&&(byte ptr[edx]!='\')
			mov	al,[edx]
			stosb
			inc	edx
		.endw
		mov	al,0
		stosb
		.if byte ptr[edx]==':'
			push	esi
			lea	esi,[edx+1]
			call	atoi
			pop	esi
		.else
			mov	ax,80
		.endif
		xchg	al,ah
		mov	scrsaddr.sin_port,ax

		.if (proxyflag&1)&&(!(proxyflag&2))
			mov	eax,proxyip
			.if eax==0
				push	edi
				lea	edi,buftmp
				lea	edx,_proxy
				.while (byte ptr[edx]!=0)&&(byte ptr[edx]!=':')
					mov	al,[edx]
					stosb
					inc	edx
				.endw
				mov	al,0
				stosb
				.if byte ptr[edx]==':'
					inc	edx
					push	esi
					mov	esi,edx
					call	atoi
					pop	esi
				.else
					mov	eax,1080
				.endif
				xchg	al,ah
				mov	scrsaddr.sin_port,ax
				mov	proxyport,ax
				pop	edi
				invoke	inet_addr,addr buftmp
				.if eax==INADDR_NONE
					invoke	gethostbyname,addr buftmp
					.if eax!=0
						mov	eax,[eax+12]
						mov	eax,[eax]
						mov	eax,[eax]
					.endif
				.endif
			.endif
		.else
			invoke	inet_addr,addr buftmp
			.if eax==INADDR_NONE
				invoke	gethostbyname,addr buftmp
				.if eax!=0
					mov	eax,[eax+12]
					mov	eax,[eax]
					mov	eax,[eax]
				.endif
			.endif
		.endif
		.if eax
			mov	dword ptr scrsaddr.sin_addr,eax
			mov	scrsaddr.sin_family,AF_INET
		.else
			lea	edi,buftmp[1000]
			lea	edx,err_res
			call	copyedx
			lea	edx,buftmp
			call	copyedx
			mov	eax,0a0dh
			stosd
			lea	edx,buftmp[1000]
			call	showmsg
			inc	lasterror
		.endif
	.else
		inc	lasterror
	.endif
	pop	edi
	ret

mk_headers:
	mov	eax,3
	call	gbptr
	mov	edi,ebx
	mov	eax,'TEG '
	stosd
	mov	al,' '
	stosb
	push	edi
	mov	edx,_5._ptr
	mov	eax,[edx]
	or	eax,20202020h
	.if (eax=='ptth')&&(word ptr[edx+4]=='/:')
		lea	edx,[edx+6]
		.if byte ptr[edx]=='/'
			inc	edx
		.endif
	.endif

	.if (proxyflag&1)&&(!(proxyflag&2))
		mov	eax,'ptth'
		stosd
		mov	eax,'//:'
		stosd
		dec	edi
	.else
		.while (byte ptr[edx]!=0)&&(byte ptr[edx]!='/')
			inc	edx
		.endw
	.endif

	.if byte ptr[edx]==0
		mov	al,'/'
		stosb
	.else
		.while byte ptr[edx]
			mov	al,[edx]
			.if al=='&'
				.if dword ptr[edx+1]==';pma'
					lea	edx,[edx+4]
				.elseif (dword ptr[edx+1]=='psbn')&&(byte ptr[edx+1+4]==';')
					lea	edx,[edx+5]
					mov	al,32
				.endif
			.endif
			stosb
			inc	edx
		.endw
	.endif
	call	ua_01
	mov	edx,_5._ptr
	mov	eax,[edx]
	or	eax,20202020h
	.if (eax=='ptth')&&(word ptr[edx+4]=='/:')
		lea	edx,[edx+6]
		.if byte ptr[edx]=='/'
			inc	edx
		.endif
	.endif
	.while (byte ptr[edx]!=0)&&(byte ptr[edx]!='/')&&(byte ptr[edx]!=':')
		mov	al,[edx]
		stosb
		inc	edx
	.endw
	call	ua_02
	push	edi

	mov	eax,'kooC'
	stosd
	mov	eax,' :ei'
	stosd
	push	esi
	mov	esi,_1._ptr
	.if esi
		xor	edx,edx
		.while byte ptr[esi]
			.if (byte ptr[esi]==13)||(byte ptr[esi]==10)
				mov	dl,0
			.elseif dl==0
				mov	eax,[esi]
				or	eax,202020h
				.if eax=='-tes'
					mov	eax,[esi+4]
					or	eax,20202020h
					.if eax=='kooc'
						mov	ax,[esi+8]
						or	ax,2020h
						.if ax=='ei'
							lea	esi,[esi+10]
							.if byte ptr[esi]==':'
								inc	esi
							.endif
							.while byte ptr[esi]==32
								inc	esi
							.endw
							.if (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=';')&&(byte ptr[esi]!=0)
								.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=';')&&(byte ptr[esi]!=0)
									movsb
								.endw
								mov	ax,' ;'
								stosw
								mov	dh,1
							.endif
						.endif
					.endif
				.endif
				mov	dl,1
			.endif
			.break .if dword ptr[esi]==0a0d0a0dh
			inc	esi
		.endw
	.endif
	pop	esi
	.if dh
		.if word ptr[edi-2]==' ;'
			sub	edi,2
		.endif
		mov	ax,0a0dh
		stosw
		pop	eax
	.else
		pop	edi
	.endif

	.if _4._data
		lea	edx,ctype1
		call	copyedx
		lea	edx,http7
		call	copyedx
		mov	eax,_4._data
		call	itoa
		mov	ax,0a0dh
		stosw
	.endif
	call	ua_03
	mov	ecx,edi
	mov	al,0
	stosb
	sub	ecx,_3._ptr
	mov	_3._data,ecx
	mov	_3._pos,0
	pop	edi
	ret

testlnk:mov	eax,[esi]
	or	eax,20202020h
	.if eax=='ptth'
		ret
	.elseif eax=='.www'
		ret
	.endif
	xor	ecx,ecx
	.while (byte ptr[esi+ecx])
		.if byte ptr[esi+ecx]<33
			xor	eax,eax
			ret
		.elseif byte ptr[esi+ecx]=='.'
			xor	edx,edx
			push	ecx
			lea	ecx,[esi+ecx+1]
			.while ((byte ptr[ecx+edx]>='A')&&(byte ptr[ecx+edx]<='Z'))||((byte ptr[ecx+edx]>='a')&&(byte ptr[ecx+edx]<='z'))
				inc	edx
			.endw
			pop	ecx
			.if edx<5
				xor	eax,eax
				inc	eax
				ret
			.endif
		.elseif (byte ptr[esi+ecx]==34)||(byte ptr[esi+ecx]==39)
			xor	eax,eax
			ret
		.elseif (byte ptr[esi+ecx]=='<')||(byte ptr[esi+ecx]=='>')||(byte ptr[esi+ecx]=='=')||(byte ptr[esi+ecx]=='#')
			xor	eax,eax
			ret
		.elseif (byte ptr[esi+ecx]=='*')||(byte ptr[esi+ecx]=='+')||(byte ptr[esi+ecx]=='?')||(byte ptr[esi+ecx]>'z')
			xor	eax,eax
			ret
		.elseif (byte ptr[esi+ecx]=='$')||(byte ptr[esi+ecx]=='(')||(byte ptr[esi+ecx]==')')||(byte ptr[esi+ecx]==',')
			xor	eax,eax
			ret
		.elseif (byte ptr[esi+ecx]==';')||(byte ptr[esi+ecx]=='`')||((byte ptr[esi+ecx]>'Z')&&(byte ptr[esi+ecx]<'_'))
			xor	eax,eax
			ret
		.endif
		inc	ecx
	.endw
	xor	eax,eax
	ret

seeklnk:
	push	esi
	.while (byte ptr[esi]!=0)
		call	testlnk
		.break .if eax
		inc	esi
	.endw
	mov	edx,esi
	pop	esi
	sub	edx,esi
	ret

showlnk:push	esi
;	push	edi
;	lea	edi,[edi+7]
	.while (byte ptr[esi]>32)&&(byte ptr[esi]!='<')&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=34)
		mov	al,[esi]
		inc	esi
		.if al=='%'
			mov	dl,[esi]
			.if (dl>='A')&&(dl<='F')
				sub	dl,'A'-10
				inc	esi
			.elseif (dl>='a')&&(dl<='f')
				sub	dl,'a'-10
				inc	esi
			.elseif (dl>='0')&&(dl<='9')
				sub	dl,'0'
				inc	esi
			.else
				mov	dl,16
			.endif
			.if dl<16
				mov	al,dl
				mov	dl,[esi]
				.if (dl>='A')&&(dl<='F')
					sub	dl,'A'-10
					inc	esi
					shl	al,4
					or	al,dl
				.elseif (dl>='a')&&(dl<='f')
					sub	dl,'a'-10
					inc	esi
					shl	al,4
					or	al,dl
				.elseif (dl>='0')&&(dl<='9')
					sub	dl,'0'
					inc	esi
					shl	al,4
					or	al,dl
				.else
					dec	esi
					mov	al,'%'
				.endif
				.if al<32
					dec	esi
					dec	esi
					mov	al,'%'
				.endif
			.endif
		.elseif al=='&'
			mov	eax,[esi]
			or	eax,202020h
			.if eax==';pma'
				mov	al,'&'
				lea	esi,[esi+4]
			.elseif (ax=='tg')&&(byte ptr[esi+2]==';')
				pop	eax
				pop	esi
				ret
			.elseif (ax=='tl')&&(byte ptr[esi+2]==';')
				pop	eax
				pop	esi
				ret
			.elseif (byte ptr[esi]>='0')&&(byte ptr[esi]<='9')
				push	esi
				call	atoi
				.if al>=32
					pop	edx
				.else
					pop	esi
					mov	al,'&'
				.endif
			.else
				mov	al,'&'
			.endif
		.endif
		stosb
	.endw
	mov	al,0
	stosb
	dec	edi
;	pop	edi
	pop	esi
;	lea	edx,[edi+7]
;	mov	eax,[edx]
;	or	eax,20202020h
;	.if (eax=='ptth')&&(byte ptr[edx+4]==':')
;		call	copyedx
;	.else
;		mov	eax,'ptth'
;		stosd
;		mov	ax,'/:'
;		stosw
;		mov	al,'/'
;		stosb
;		.while byte ptr[edi]
;			inc	edi
;		.endw
;	.endif
	ret

;ebx = ptr to data
getbptr:mov	eax,lastidx
gbptr:	.if eax>6
		int 3
	.endif
	shl	eax,4
	lea	eax,_0[eax]
	assume	eax:ptr bufstruc
	mov	ebx,[eax]._ptr
	.if ebx==0
		push	eax
		invoke	GlobalAlloc,GPTR,8192
		mov	ebx,eax
		pop	eax
		mov	[eax]._size,8192
		mov	[eax]._ptr,ebx
		mov	[eax]._data,0
		mov	[eax]._pos,0
		mov	byte ptr[ebx],0
	.else
		add	ebx,[eax]._pos
	.endif
	ret

;ecx=count
addbptr:.if eax>6
		int 3
	.endif
	shl	eax,4
	lea	eax,_0[eax]
	add	[eax]._pos,ecx
	ret
assume	eax:nothing

;edi,ecx,esi
;returns: edi,ecx
scr_replace	PROC	uses esi ebx
	local	_bufsize,_var,_varsize,_strptr,_tmpalloc,_tmpallocsize:DWORD
	mov	_strptr,esi
	mov	_bufsize,ecx
	mov	_tmpalloc,edi
	mov	_tmpallocsize,ecx
	.while ecx
		inc	edi
		dec	ecx
	.endw
	ret
scr_replace	ENDP
