fsofttxt	macro
	fsoft0	db	'Auto-detect forum software',0
	fsoft1	db	'Parse forum tables to detect its structure',0
	fsoft2	db	'Generic: Invision Power Board',0
	;fsoft2a	db	'Generic: Invision Power Board lo-fi version',0
	fsoft3	db	'Generic: Simple Machines Forum',0
	fsoft3a	db	'Generic: SMF, SEO4SMF Mod',0
	fsoft4	db	'Generic: vBulletin',0
	;fsoft4a	db	'Generic: vBulletin Archive',0
	;fsoft5	db	'Generic: phpBB',0
	fsoft6	db	'Generic: punBB',0
	fsoft6a	db	'Generic: myBB',0
	fsoft7	db	'Unknown / user-defined configuration',0
	fsoft8	db	'3xForum',0
	fsoft9	db	'Generic: WordPress 2.6.x blog',0
	fsoft9a	db	'Generic: WordPress 2.0.x blog',0
	fsoft10	db	'Blogger.com / Blogspot.com blog',0
	fs01	db	0
	agent01	db	'Forum Downloader 2.00',0
	agent02	db	'Internet Explorer 5.0',0
	agent03	db	'Internet Explorer 6.0',0
	agent04	db	'Internet Explorer 7.0',0
	agent05	db	'Opera v9.52',0
	agent06	db	'Firefox 3.0.3',0
	agent07	db	'Chrome v0.2.149.30',0
	agent08	db	'libwww-perl 5.805',0
	agent09	db	'Googlebot 2.1',0
	agent10	db	'Google',39,'s Feed Grabber',0
	agent11	db	'Yahoo!',39,'s Web Crawler',0

	http1	db	'GET ',0
	http2	db	' HTTP/1.0',13,10,0
	http3	db	'Host: ',0
	http4	db	'Accept: */*',13,10,0
	http4a	db	'Accept-Language: en-us',13,10,0
	http4b	db	'Accept-Encoding: identity',13,10,0
	http4c	db	'UA-CPU: x86',13,10,0
	http6	db	'Connection: Close',13,10,0
	http6a	db	'Connection: Keep-Alive',13,10,0
	http6b	db	'Connection: Close',13,10,0
	http7	db	'Content-Length: ',0
	http8	db	'Content-Type: application/x-www-form-urlencoded',0
	http_o1	db	'Accept: text/html, application/xml;q=0.9, application/xhtml+xml, image/png, image/jpeg, image/gif, image/x-xbitmap, */*;q=0.1',13,10
		db	'Accept-Language: en-EN,en;q=0.9,en;q=0.8',13,10
		db	'Accept-Charset: iso-8859-1, utf-8, utf-16, *;q=0.1',13,10
		db	'Accept-Encoding: identity, *;q=0',13,10,0
	http_f1	db	'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',13,10
		db	'Accept-Language: en-us,en;q=0.5',13,10
		db	'Accept-Encoding: identity',13,10
		db	'Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7',13,10,0
	http_f2	db	'Keep-Alive: 300',13,10,0
	http_c1	db	'Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5',13,10
		db	'Accept-Language: en-US,en',13,10
		db	'Accept-Charset: ISO-8859-1,*,utf-8',13,10
		db	'Accept-Encoding: identity',13,10,0
	http_y1	db	'LLF-Cache-Control: ',13,10,0
ua00	db	'User-Agent: ',0
ua01	db	'ForumDownloader/2.00',0
ua02	db	'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)',0
ua03	db	'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)',0
ua04	db	'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) )',0
ua05	db	'Opera/9.52 (Windows NT 5.1; U; en)',0
ua06	db	'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3',0
ua07	db	'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.2.149.30 Safari/525.13',0
ua08	db	'libwww-perl/5.805',0
ua09	db	'From: googlebot(at)googlebot.com',13,10,'User-Agent: Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',0
ua10	db	'Feedfetcher-Google; (+http://www.google.com/feedfetcher.html)',0
ua11	db	'Mozilla/5.0 (compatible; Yahoo! Slurp; http://help.yahoo.com/help/us/ysearch/slurp)',0
uagents	dd	offset ua01
	dd	offset ua02
	dd	offset ua03
	dd	offset ua04
	dd	offset ua05
	dd	offset ua06
	dd	offset ua07
	dd	offset ua08
	dd	offset ua09
	dd	offset ua10
	dd	offset ua11
	dd	0
endm

fsoftsettxt	macro
	_wcards	db	'To change detection settings you need to view the HTML source of the forum'
		db	' you want to download. You can use the following wildcards:',13,10,13,10
		db	'  ? = one character',9,'  @ = a hexadecimal number (like in SID)',13,10
		db	'  * = group of characters',9,'  | = link terminator, after this a quote or apostrophe must be present',13,10
		db	'  # = a number (decimal)',9,'  $ = optional SID parameter (&s=@& / &sid=@& / etc.), not always present',0

	forum_tbl	db	0,0
			db	0,0
			db	0,0
			db	0,0
			db	0,0
			db	0,0
			db	0,0
			db	0,0
			db	0,0
			db	0,0
			db	0,0
			db	0,0
			db	0,0

	forum_vb	db	'href',0,1
			db	'forumdisplay.php?$f=#|',0,1
			db	'strong>',0,1
			db	'&amp;page=#|',0,1
			db	'href',0,1
			db	'showthread.php?$t=#|',0,1
			db	0,0
			db	'&amp;page=#|',0,1
			db	'<!-- user info -->',0,1
			db	'<!-- / user info -->',0,1
			db	'<!-- message -->',0,1
			db	'<!-- / message -->',0,1
			db	'daysprune=-1',0,1

	forum_mybb	db	'href',0,1
			db	'forumdisplay.php?$fid=#|',0,1
			db	'strong>',0,1
			db	'&amp;page=#|',0,1
			db	'href',0,1
			db	'showthread.php?$tid=#|',0,1
			db	0,0
			db	'&amp;page=#|',0,1
			db	'<!-- start: postbit_posturl -->',0,1
			db	'<!-- AWARDS -->',0,1
			db	'<!-- end: postbit_author_user -->',0,1
			db	'<!-- start: postbit_signature -->',0,1
			db	0,0

	forum_ipb	db	'href',0,1
			db	'index.php?$showforum=#|',0,1
			db	0,0
			db	'prune_day=100&amp;sort_by=Z-A&amp;sort_key=last_post&amp;topicfilter=all&amp;st=',0,1
			db	'href',0,1
			db	'index.php?$showtopic=#|',0,1
			db	0,0
			db	'index.php?$showtopic=#&amp;st=',0,1
			db	'<span class="normalname">',0,1
			db	'</td>',0,1
			db	'<!-- THE POST # -->',0,1
			db	0,0
			db	0,0

	forum_se	db	'<td class="windowbg2">',0,1
			db	'board=#.#|',0,1
			db	'</td>',0,1
			db	0,0
			db	'<span id="msg_',0,1
			db	'topic=#.#|',0,1
			db	0,0
			db	0,0
			db	'<td valign="top" width="16%" rowspan="2" style="overflow: hidden;">',0,1
			db	'</td>',0,1
			db	'<div class="post">',0,1
			db	0,0
			db	0,0

	forum_sm	db	'href',0,1
			db	'/forum/',0,0
			db	'class="custom1"',0,1
			db	0,0
			
			db	'<span class="custom3"',0,1
			db	'/forum/',0,0
			db	0,0
			db	0,0
			
			db	'<td valign="top" width="16%" rowspan="2" style="overflow: hidden;">',0,1
			db	'</td>',0,1
			db	'<div class="post">',0,1
			db	0,0
			db	0,0

	forum_pu	db	0,0
			db	0,0
			db	0,0
			db	'&amp;p=#|',0,1
			
			db	0,0
			db	0,0
			db	0,0
			db	'&amp;p=#|',0,1
			
			db	'<div class="postleft">',0,1
			db	'</strong>',0,1
			db	'<div class="postright">',0,1
			db	'<div class="postfootleft">',0,1
			db	0,0

	forum_3x	db	'punheadline',0,1
			db	'/topic/#/*/',0,1
			db	'</span>',0,1
			db	'/topic/#/*/#',0,1
			db	'puncon2',0,1
			db	'/post/#/',0,1
			db	0,0
			db	'/post/#/*/#',0,1
			db	'<span class="punheadline">',0,1
			db	'</span>',0,1
			db	'<span class="puntext">',0,1
			db	'</span>',0,1
			db	0,0

	forum_wp	db	'<ul class="wp"><li><a href=',0,1
			db	0,0
			db	'</a>',0,1
			db	'/page/#',0,1

			db	'href',0,1
			db	0,0
			db	'rel="bookmark" title="',0,1	;permanent link',0
			db	'/comment-page-#/',0,1

			db	'<head',0,1
			db	'</head',0,1
			db	'<body',0,1
			db	'</body',0,1
			db	0,0

	forum_wp1	db	'<ul class="wp"><li><a href=',0,1
			db	0,0
			db	'</a>',0,1
			db	'?paged=#',0,1

			db	'<div class="post">',0,1
			db	'/?p=#',0,1
			db	'rel="bookmark" title="',0,1	;'</h2>',0,1	;'rel="bookmark" title="',0	;permanent link',0
			db	'/comment-page-#/',0,1

			db	'<head',0,1
			db	'</head',0,1
			db	'<body',0,1
			db	'</body',0,1
			db	0,0

	forum_bs	db	'<ul class="bs"><li><a href=',0,1
			db	0,0
			db	'</a>',0,1
			db	'search?updated-max=#-#-#T',0,1

			db	'<h3 class=?post-title',0,1
			db	'.html',0,1
			db	'</h3>',0,1
			db	'/comment-page-#/',0,1

			db	'<head',0,1
			db	'</head',0,1
			db	'<body',0,1
			db	'</body',0,1
			db	0,0
	forum_bs1	db	'<ul class="bs"><li><a href=',0,1
			db	0,0
			db	'</a>',0,1
			db	'search?updated-max=#-#-#T',0,1

			db	'href',0,1
			db	'.html',0,1
			db	'title=?permanent link?',0,1
			db	'/comment-page-#/',0,1

			db	'<head',0,1
			db	'</head',0,1
			db	'<body',0,1
			db	'</body',0,1
			db	0,0


set_txt_esi:
	push	edx
	push	eax
	invoke	SetDlgItemText,hDialog,eax,esi
	.while byte ptr[esi]
		inc	esi
	.endw
	inc	esi
	push	hDialog
	call	GetDlgItem
	xchg	eax,edx
	lodsb
	movzx	eax,al
	push	eax
	invoke	EnableWindow,edx,eax
	pop	eax
	pop	edx
	.if eax
		mov	eax,BST_CHECKED
	.else
		mov	eax,BST_UNCHECKED
	.endif
	invoke	CheckDlgButton,hDialog,edx,eax
	ret

;esi=ptr table
set_params:
	set_text_esi	5100,5400
	set_text_esi	5101,5401
	set_text_esi	5102,5402
	set_text_esi	5103,5403

	set_text_esi	5104,5404
	set_text_esi	5105,5405
	set_text_esi	5106,5406
	set_text_esi	5107,5407

	set_text_esi	5108,5408
	set_text_esi	5109,5409
	set_text_esi	5110,5410
	set_text_esi	5111,5411

	set_text_esi	5118,5417
	ret

dlgcbset:
	invoke	IsDlgButtonChecked,esi,5400
	.if eax==BST_CHECKED
		or	fflag,1
	.else
		and	fflag,1 xor -1
	.endif
	invoke	IsDlgButtonChecked,esi,5401
	.if eax==BST_CHECKED
		or	fflag,2
	.else
		and	fflag,2 xor -1
	.endif
	invoke	IsDlgButtonChecked,esi,5402
	.if eax==BST_CHECKED
		or	fflag,4
	.else
		and	fflag,4 xor -1
	.endif
	invoke	IsDlgButtonChecked,esi,5403
	.if eax==BST_CHECKED
		or	fflag,8
	.else
		and	fflag,8 xor -1
	.endif
	invoke	IsDlgButtonChecked,esi,5404
	.if eax==BST_CHECKED
		or	tflag,1
	.else
		and	tflag,1 xor -1
	.endif
	invoke	IsDlgButtonChecked,esi,5405
	.if eax==BST_CHECKED
		or	tflag,2
	.else
		and	tflag,2 xor -1
	.endif
	invoke	IsDlgButtonChecked,esi,5406
	.if eax==BST_CHECKED
		or	tflag,4
	.else
		and	tflag,4 xor -1
	.endif
	invoke	IsDlgButtonChecked,esi,5407
	.if eax==BST_CHECKED
		or	tflag,8
	.else
		and	tflag,8 xor -1
	.endif
	invoke	IsDlgButtonChecked,esi,5408
	.if eax==BST_CHECKED
		or	pflag,1
	.else
		and	pflag,1 xor -1
	.endif
	invoke	IsDlgButtonChecked,esi,5409
	.if eax==BST_CHECKED
		or	pflag,2
	.else
		and	pflag,2 xor -1
	.endif
	invoke	IsDlgButtonChecked,esi,5410
	.if eax==BST_CHECKED
		or	pflag,4
	.else
		and	pflag,4 xor -1
	.endif
	invoke	IsDlgButtonChecked,esi,5411
	.if eax==BST_CHECKED
		or	pflag,8
	.else
		and	pflag,8 xor -1
	.endif
	invoke	IsDlgButtonChecked,esi,5417
	.if eax==BST_CHECKED
		or	fflag,16
	.else
		and	fflag,16 xor -1
	.endif
	invoke	GetDlgItemText,esi,5100,addr flink1,255
	invoke	GetDlgItemText,esi,5101,addr flink2,255
	invoke	GetDlgItemText,esi,5102,addr flink3,255
	invoke	GetDlgItemText,esi,5103,addr flink4,255
	invoke	GetDlgItemText,esi,5104,addr tlink1,255
	invoke	GetDlgItemText,esi,5105,addr tlink2,255
	invoke	GetDlgItemText,esi,5106,addr tlink3,255
	invoke	GetDlgItemText,esi,5107,addr tlink4,255
	invoke	GetDlgItemText,esi,5108,addr plink1,255
	invoke	GetDlgItemText,esi,5109,addr plink2,255
	invoke	GetDlgItemText,esi,5110,addr plink3,255
	invoke	GetDlgItemText,esi,5111,addr plink4,255
	invoke	GetDlgItemText,esi,5118,addr flink5,255
	ret

endm

set_text_esi	macro	n,m
	mov	eax,n
	mov	edx,m
	call	set_txt_esi
endm

forumdetectchange	macro
	.elseif (ax==5300)&&(bx==CBN_SELCHANGE)
		invoke	SendDlgItemMessage,hDlg,5300,CB_GETCURSEL,0,0
		.if eax!=CB_ERR
			invoke	SendDlgItemMessage,hDlg,5300,CB_GETITEMDATA,eax,0
			mov	fdetect,al
			.if eax==0
				lea	esi,forum_tbl
				call	set_params
			.elseif eax==1
				lea	esi,forum_tbl
				call	set_params
			.elseif eax==2
				lea	esi,forum_ipb
				call	set_params
			.elseif eax==3
				lea	esi,forum_se
				call	set_params
			.elseif eax==7
				lea	esi,forum_sm
				call	set_params
			.elseif eax==4
				lea	esi,forum_vb
				call	set_params
			.elseif eax==5
			.elseif eax==6
				lea	esi,forum_pu
				call	set_params
			.elseif eax==8
				lea	esi,forum_mybb
				call	set_params
			.elseif eax==9
				lea	esi,forum_3x
				call	set_params
			.elseif eax==20
				lea	esi,forum_wp
				call	set_params
				mov	blogdet,1
			.elseif eax==21
				lea	esi,forum_wp1
				call	set_params
				mov	blogdet,2
			.elseif eax==22
				lea	esi,forum_bs
				call	set_params
				mov	blogdet,3
			.endif
			mov	esi,hDlg
			call	dlgcbset
		.endif
	.elseif ax==5400
		invoke	IsDlgButtonChecked,hDlg,5400
		.if eax==BST_CHECKED
			invoke	GetDlgItem,hDlg,5100
			invoke	EnableWindow,eax,1
			or	fflag,1
		.else
			invoke	GetDlgItem,hDlg,5100
			invoke	EnableWindow,eax,0
			and	fflag,1 xor -1
		.endif
	.elseif ax==5401
		invoke	IsDlgButtonChecked,hDlg,5401
		.if eax==BST_CHECKED
			invoke	GetDlgItem,hDlg,5101
			invoke	EnableWindow,eax,1
			or	fflag,2
		.else
			invoke	GetDlgItem,hDlg,5101
			invoke	EnableWindow,eax,0
			and	fflag,2 xor -1
		.endif
	.elseif ax==5402
		invoke	IsDlgButtonChecked,hDlg,5402
		.if eax==BST_CHECKED
			invoke	GetDlgItem,hDlg,5102
			invoke	EnableWindow,eax,1
			or	fflag,4
		.else
			invoke	GetDlgItem,hDlg,5102
			invoke	EnableWindow,eax,0
			and	fflag,4 xor -1
		.endif
	.elseif ax==5403
		invoke	IsDlgButtonChecked,hDlg,5403
		.if eax==BST_CHECKED
			invoke	GetDlgItem,hDlg,5103
			invoke	EnableWindow,eax,1
			or	fflag,8
		.else
			invoke	GetDlgItem,hDlg,5103
			invoke	EnableWindow,eax,0
			and	fflag,8 xor -1
		.endif
	.elseif ax==5404
		invoke	IsDlgButtonChecked,hDlg,5404
		.if eax==BST_CHECKED
			invoke	GetDlgItem,hDlg,5104
			invoke	EnableWindow,eax,1
			or	tflag,1
		.else
			invoke	GetDlgItem,hDlg,5104
			invoke	EnableWindow,eax,0
			and	tflag,1 xor -1
		.endif
	.elseif ax==5405
		invoke	IsDlgButtonChecked,hDlg,5405
		.if eax==BST_CHECKED
			invoke	GetDlgItem,hDlg,5105
			invoke	EnableWindow,eax,1
			or	tflag,2
		.else
			invoke	GetDlgItem,hDlg,5105
			invoke	EnableWindow,eax,0
			and	tflag,2 xor -1
		.endif
	.elseif ax==5406
		invoke	IsDlgButtonChecked,hDlg,5406
		.if eax==BST_CHECKED
			invoke	GetDlgItem,hDlg,5106
			invoke	EnableWindow,eax,1
			or	tflag,4
		.else
			invoke	GetDlgItem,hDlg,5106
			invoke	EnableWindow,eax,0
			and	tflag,4 xor -1
		.endif
	.elseif ax==5407
		invoke	IsDlgButtonChecked,hDlg,5407
		.if eax==BST_CHECKED
			invoke	GetDlgItem,hDlg,5107
			invoke	EnableWindow,eax,1
			or	tflag,8
		.else
			invoke	GetDlgItem,hDlg,5107
			invoke	EnableWindow,eax,0
			and	tflag,8 xor -1
		.endif
	.elseif ax==5408
		invoke	IsDlgButtonChecked,hDlg,5408
		.if eax==BST_CHECKED
			invoke	GetDlgItem,hDlg,5108
			invoke	EnableWindow,eax,1
			or	pflag,1
		.else
			invoke	GetDlgItem,hDlg,5108
			invoke	EnableWindow,eax,0
			and	pflag,1 xor -1
		.endif
	.elseif ax==5409
		invoke	IsDlgButtonChecked,hDlg,5409
		.if eax==BST_CHECKED
			invoke	GetDlgItem,hDlg,5109
			invoke	EnableWindow,eax,1
			or	pflag,2
		.else
			invoke	GetDlgItem,hDlg,5109
			invoke	EnableWindow,eax,0
			and	pflag,2 xor -1
		.endif
	.elseif ax==5410
		invoke	IsDlgButtonChecked,hDlg,5410
		.if eax==BST_CHECKED
			invoke	GetDlgItem,hDlg,5110
			invoke	EnableWindow,eax,1
			or	pflag,4
		.else
			invoke	GetDlgItem,hDlg,5110
			invoke	EnableWindow,eax,0
			and	pflag,4 xor -1
		.endif
	.elseif ax==5411
		invoke	IsDlgButtonChecked,hDlg,5411
		.if eax==BST_CHECKED
			invoke	GetDlgItem,hDlg,5111
			invoke	EnableWindow,eax,1
			or	pflag,8
		.else
			invoke	GetDlgItem,hDlg,5111
			invoke	EnableWindow,eax,0
			and	pflag,8 xor -1
		.endif
	.elseif ax==5417
		invoke	IsDlgButtonChecked,hDlg,5417
		.if eax==BST_CHECKED
			invoke	GetDlgItem,hDlg,5118
			invoke	EnableWindow,eax,1
			or	fflag,16
		.else
			invoke	GetDlgItem,hDlg,5118
			invoke	EnableWindow,eax,0
			and	fflag,16 xor -1
		.endif
	.elseif (ax==5100)&&(bx==EN_CHANGE)
		invoke	GetDlgItemText,hDlg,5100,addr flink1,255
	.elseif (ax==5101)&&(bx==EN_CHANGE)
		invoke	GetDlgItemText,hDlg,5101,addr flink2,255
	.elseif (ax==5102)&&(bx==EN_CHANGE)
		invoke	GetDlgItemText,hDlg,5102,addr flink3,255
	.elseif (ax==5103)&&(bx==EN_CHANGE)
		invoke	GetDlgItemText,hDlg,5103,addr flink4,255
	.elseif (ax==5104)&&(bx==EN_CHANGE)
		invoke	GetDlgItemText,hDlg,5104,addr tlink1,255
	.elseif (ax==5105)&&(bx==EN_CHANGE)
		invoke	GetDlgItemText,hDlg,5105,addr tlink2,255
	.elseif (ax==5106)&&(bx==EN_CHANGE)
		invoke	GetDlgItemText,hDlg,5106,addr tlink3,255
	.elseif (ax==5107)&&(bx==EN_CHANGE)
		invoke	GetDlgItemText,hDlg,5107,addr tlink4,255
	.elseif (ax==5108)&&(bx==EN_CHANGE)
		invoke	GetDlgItemText,hDlg,5108,addr plink1,255
	.elseif (ax==5109)&&(bx==EN_CHANGE)
		invoke	GetDlgItemText,hDlg,5109,addr plink2,255
	.elseif (ax==5110)&&(bx==EN_CHANGE)
		invoke	GetDlgItemText,hDlg,5110,addr plink3,255
	.elseif (ax==5111)&&(bx==EN_CHANGE)
		invoke	GetDlgItemText,hDlg,5111,addr plink4,255
	.elseif (ax==5118)&&(bx==EN_CHANGE)
		invoke	GetDlgItemText,hDlg,5118,addr flink5,255
endm

forumdetectinit	macro
	invoke	SendDlgItemMessage,hDlg,5300,CB_RESETCONTENT,0,0
	invoke	SendDlgItemMessage,hDlg,5300,CB_ADDSTRING,0,addr fsoft0
	invoke	SendDlgItemMessage,hDlg,5300,CB_SETITEMDATA,eax,0
	invoke	SendDlgItemMessage,hDlg,5300,CB_ADDSTRING,0,addr fsoft1
	invoke	SendDlgItemMessage,hDlg,5300,CB_SETITEMDATA,eax,1
	invoke	SendDlgItemMessage,hDlg,5300,CB_ADDSTRING,0,addr fsoft2
	invoke	SendDlgItemMessage,hDlg,5300,CB_SETITEMDATA,eax,2
	invoke	SendDlgItemMessage,hDlg,5300,CB_ADDSTRING,0,addr fsoft3
	invoke	SendDlgItemMessage,hDlg,5300,CB_SETITEMDATA,eax,3
	invoke	SendDlgItemMessage,hDlg,5300,CB_ADDSTRING,0,addr fsoft3a
	invoke	SendDlgItemMessage,hDlg,5300,CB_SETITEMDATA,eax,7
	invoke	SendDlgItemMessage,hDlg,5300,CB_ADDSTRING,0,addr fsoft4
	invoke	SendDlgItemMessage,hDlg,5300,CB_SETITEMDATA,eax,4
;	invoke	SendDlgItemMessage,hDlg,5300,CB_ADDSTRING,0,addr fsoft5
;	invoke	SendDlgItemMessage,hDlg,5300,CB_SETITEMDATA,eax,5
	invoke	SendDlgItemMessage,hDlg,5300,CB_ADDSTRING,0,addr fsoft6
	invoke	SendDlgItemMessage,hDlg,5300,CB_SETITEMDATA,eax,6
	invoke	SendDlgItemMessage,hDlg,5300,CB_ADDSTRING,0,addr fsoft6a
	invoke	SendDlgItemMessage,hDlg,5300,CB_SETITEMDATA,eax,8
	invoke	SendDlgItemMessage,hDlg,5300,CB_ADDSTRING,0,addr fsoft8
	invoke	SendDlgItemMessage,hDlg,5300,CB_SETITEMDATA,eax,9
	invoke	SendDlgItemMessage,hDlg,5300,CB_ADDSTRING,0,addr fsoft9a
	invoke	SendDlgItemMessage,hDlg,5300,CB_SETITEMDATA,eax,21
	invoke	SendDlgItemMessage,hDlg,5300,CB_ADDSTRING,0,addr fsoft10
	invoke	SendDlgItemMessage,hDlg,5300,CB_SETITEMDATA,eax,22
	invoke	SendDlgItemMessage,hDlg,5300,CB_ADDSTRING,0,addr fsoft9
	invoke	SendDlgItemMessage,hDlg,5300,CB_SETITEMDATA,eax,20
	invoke	SendDlgItemMessage,hDlg,5300,CB_ADDSTRING,0,addr fsoft7
	invoke	SendDlgItemMessage,hDlg,5300,CB_SETITEMDATA,eax,100
	xor	eax,eax
	.while 1
		push	eax
		invoke	SendDlgItemMessage,hDlg,5300,CB_GETITEMDATA,eax,0
		mov	edx,eax
		pop	eax
		.if dl==fdetect
			invoke	SendDlgItemMessage,hDlg,5300,CB_SETCURSEL,eax,0
			.break
		.endif
		.break .if edx==CB_ERR
		inc	eax
	.endw
	invoke	SendDlgItemMessage,hDlg,5100,EM_LIMITTEXT,255,0
	invoke	SendDlgItemMessage,hDlg,5101,EM_LIMITTEXT,255,0
	invoke	SendDlgItemMessage,hDlg,5102,EM_LIMITTEXT,255,0
	invoke	SendDlgItemMessage,hDlg,5103,EM_LIMITTEXT,255,0
	invoke	SendDlgItemMessage,hDlg,5104,EM_LIMITTEXT,255,0
	invoke	SendDlgItemMessage,hDlg,5105,EM_LIMITTEXT,255,0
	invoke	SendDlgItemMessage,hDlg,5106,EM_LIMITTEXT,255,0
	invoke	SendDlgItemMessage,hDlg,5107,EM_LIMITTEXT,255,0
	invoke	SendDlgItemMessage,hDlg,5108,EM_LIMITTEXT,255,0
	invoke	SendDlgItemMessage,hDlg,5109,EM_LIMITTEXT,255,0
	invoke	SendDlgItemMessage,hDlg,5110,EM_LIMITTEXT,255,0
	invoke	SendDlgItemMessage,hDlg,5111,EM_LIMITTEXT,255,0
	invoke	SendDlgItemMessage,hDlg,5112,EM_LIMITTEXT,255,0
	invoke	SendDlgItemMessage,hDlg,5117,EM_LIMITTEXT,255,0
	.if fflag&1
		invoke	CheckDlgButton,hDlg,5400,BST_CHECKED
	.else
		invoke	GetDlgItem,hDlg,5100
		invoke	EnableWindow,eax,0
	.endif
	.if fflag&2
		invoke	CheckDlgButton,hDlg,5401,BST_CHECKED
	.else
		invoke	GetDlgItem,hDlg,5101
		invoke	EnableWindow,eax,0
	.endif
	.if fflag&4
		invoke	CheckDlgButton,hDlg,5402,BST_CHECKED
	.else
		invoke	GetDlgItem,hDlg,5102
		invoke	EnableWindow,eax,0
	.endif
	.if fflag&8
		invoke	CheckDlgButton,hDlg,5403,BST_CHECKED
	.else
		invoke	GetDlgItem,hDlg,5103
		invoke	EnableWindow,eax,0
	.endif
	.if fflag&16
		invoke	CheckDlgButton,hDlg,5417,BST_CHECKED
	.else
		invoke	GetDlgItem,hDlg,5118
		invoke	EnableWindow,eax,0
	.endif
	.if tflag&1
		invoke	CheckDlgButton,hDlg,5404,BST_CHECKED
	.else
		invoke	GetDlgItem,hDlg,5104
		invoke	EnableWindow,eax,0
	.endif
	.if tflag&2
		invoke	CheckDlgButton,hDlg,5405,BST_CHECKED
	.else
		invoke	GetDlgItem,hDlg,5105
		invoke	EnableWindow,eax,0
	.endif
	.if tflag&4
		invoke	CheckDlgButton,hDlg,5406,BST_CHECKED
	.else
		invoke	GetDlgItem,hDlg,5106
		invoke	EnableWindow,eax,0
	.endif
	.if tflag&8
		invoke	CheckDlgButton,hDlg,5407,BST_CHECKED
	.else
		invoke	GetDlgItem,hDlg,5107
		invoke	EnableWindow,eax,0
	.endif
	.if pflag&1
		invoke	CheckDlgButton,hDlg,5408,BST_CHECKED
	.else
		invoke	GetDlgItem,hDlg,5108
		invoke	EnableWindow,eax,0
	.endif
	.if pflag&2
		invoke	CheckDlgButton,hDlg,5409,BST_CHECKED
	.else
		invoke	GetDlgItem,hDlg,5109
		invoke	EnableWindow,eax,0
	.endif
	.if pflag&4
		invoke	CheckDlgButton,hDlg,5410,BST_CHECKED
	.else
		invoke	GetDlgItem,hDlg,5110
		invoke	EnableWindow,eax,0
	.endif
	.if pflag&8
		invoke	CheckDlgButton,hDlg,5411,BST_CHECKED
	.else
		invoke	GetDlgItem,hDlg,5111
		invoke	EnableWindow,eax,0
	.endif
	invoke	SetDlgItemText,hDlg,5100,addr flink1
	invoke	SetDlgItemText,hDlg,5101,addr flink2
	invoke	SetDlgItemText,hDlg,5102,addr flink3
	invoke	SetDlgItemText,hDlg,5103,addr flink4
	invoke	SetDlgItemText,hDlg,5104,addr tlink1
	invoke	SetDlgItemText,hDlg,5105,addr tlink2
	invoke	SetDlgItemText,hDlg,5106,addr tlink3
	invoke	SetDlgItemText,hDlg,5107,addr tlink4
	invoke	SetDlgItemText,hDlg,5108,addr plink1
	invoke	SetDlgItemText,hDlg,5109,addr plink2
	invoke	SetDlgItemText,hDlg,5110,addr plink3
	invoke	SetDlgItemText,hDlg,5111,addr plink4
	invoke	SetDlgItemText,hDlg,5112,addr _proxy
	invoke	SetDlgItemText,hDlg,5118,addr flink5
endm

softdetect	macro
sd1	db	'[ X ] No known copyright information was found',13,10,0
sd01	db	'*** Forum structure is common to phpBB forums',13,10,0
sd01a	db	'*** Forum structure is common to punBB forums',13,10,0
sd02	db	'*** Forum structure is common to SMF forums',13,10,0
sd02a	db	'*** Forum structure is common to SMF forums, SEO4SMF mod',13,10,0
sd03	db	'*** Forum structure is common to Invision Power Board forums',13,10,0
sd04	db	'*** Forum structure is common to vBulletin forums',13,10,0
sd04c	db	'*** Forum structure is common to myBB forums',13,10,0
sd05	db	'*** Forum structure is common to 3x.ro forums',13,10,0
sd06	db	'*** Forum structure is common to WordPress 2.6.x blogs',13,10,0
sd06a	db	'*** Forum structure is common to WordPress 2.0.x blogs',13,10,0
sd07	db	'*** Forum structure is common to blogger.com blogs',13,10,0
sd0s	db	'[ X ] Failed to detect the forum software',13,10,0
sd0c	db	'[ X ] A copyright string specific for detected forum software was not found.',13,10,0
;esi=source
_detect	PROC	uses esi edi
	local	_copyright:DWORD
	mov	blogdet,0
	.if fdetect
		.if fdetect==20
			mov	blogdet,1
		.elseif fdetect==21
			mov	blogdet,2
		.elseif fdetect==22
			mov	blogdet,3
		.endif
		ret
	.endif
	xor	ecx,ecx
	.while (byte ptr[edx+ecx]!=0)&&(byte ptr[edx+ecx]!='.')
		inc	ecx
	.endw
	.while (byte ptr[edx+ecx]!=0)&&(byte ptr[edx+ecx]!='/')
		mov	eax,[edx+ecx]
		or	eax,20202020h
		.if eax=='olb.'
			mov	eax,[edx+ecx+4]
			or	eax,20202020h
			.if eax=='opsg'
				mov	eax,[edx+ecx+8]
				or	eax,20202020h
				.if eax=='oc.t'
					mov	al,[edx+ecx+12]
					or	al,32
					.if (al=='m')&&((byte ptr[edx+ecx+12+1]==0)||(byte ptr[edx+ecx+12+1]=='/'))
						lea	edx,sd07
						call	showmsg
						lea	esi,forum_bs
						call	set_params
						mov	esi,hDialog
						call	dlgcbset
						mov	blogdet,3
						ret
					.endif
				.endif
			.endif
		.endif
		inc	ecx
	.endw
	mov	blogdet,0
	push	0
	xor	ecx,ecx
	.while byte ptr[esi+ecx]
		mov	eax,[esi+ecx]
		.if (eax=='poc&')&&(word ptr[esi+ecx+4]==';y')
			lea	edx,[ecx+4+2]
_d_copy:		.while (byte ptr[esi+edx]==32)||(byte ptr[esi+edx]==9)||(byte ptr[esi+edx]==13)||(byte ptr[esi+edx]==10)||(byte ptr[esi+edx]==',')||((byte ptr[esi+edx]>='0')&&(byte ptr[esi+edx]<='9'))
				inc	edx
			.endw
			.if (word ptr[esi+edx]=='yb')
				inc	edx
				inc	edx
				jmp	_d_copy
			.elseif (dword ptr[esi+edx]=='sbn&')&&(word ptr[esi+edx+4]==';p')
				lea	edx,[edx+6]
				jmp	_d_copy
			.endif
			.if byte ptr[esi+edx]=='<'
				.while (byte ptr[esi+edx]!=0)&&(byte ptr[esi+edx]!='>')
					mov	eax,[esi+edx]
					or	eax,20202020h
					.if eax=='bphp'
						mov	eax,[esi+edx+4]
						or	eax,20202020h
						.if eax=='oc.b'
							or	byte ptr[esp],1
						.endif
					.elseif eax=='bnup'
						mov	eax,[esi+edx+4]
						or	eax,20202020h
						.if eax=='ro.b'
							or	byte ptr[esp],16
						.endif
					.elseif eax=='pmis'
						mov	eax,[esi+edx+4]
						or	eax,20202020h
						.if eax=='amel'
							or	byte ptr[esp],2
						.endif
					.elseif eax=='ivni'
						mov	eax,[esi+edx+4]
						or	eax,20202020h
						.if eax=='nois'
							or	byte ptr[esp],4
						.endif
					.elseif eax=='bbym'
						mov	eax,[esi+edx+4]
						or	eax,20202020h
						.if eax=='ten.'
							or	byte ptr[esp],8
						.endif
					.elseif eax=='drow'
						mov	eax,[esi+edx+4]
						or	eax,20202020h
						.if eax=='serp'
							mov	eax,[esi+edx+8]
							or	eax,20200020h
							.if eax=='ro.s'
								or	byte ptr[esp],32
							.endif
						.endif
					.endif
					inc	edx
				.endw
				.if byte ptr[esi+edx]=='>'
					inc	edx
				.endif
				.while (byte ptr[esi+edx]==32)||(byte ptr[esi+edx]==9)||(byte ptr[esi+edx]==13)||(byte ptr[esi+edx]==10)||(byte ptr[esi+edx]==',')
					inc	edx
				.endw
			.endif
			mov	eax,[esi+edx]
			or	eax,20202020h
			mov	_copyright,0
			.if eax=='bphp'
				mov	_copyright,ecx
				or	dword ptr[esp],100h
			.elseif eax=='bnup'
				mov	_copyright,ecx
				or	dword ptr[esp],1000h
			.elseif (ax=='ms')&&((byte ptr[esi+edx+2]=='f')||(byte ptr[esi+edx+2]=='F'))
				mov	_copyright,ecx
				or	dword ptr[esp],200h
			.elseif eax=='b.pi'
				mov	_copyright,ecx
				or	dword ptr[esp],400h
			.elseif (eax==',spi')&&(dword ptr[esi+edx+4]=='cnI ')
				mov	_copyright,ecx
				or	dword ptr[esp],400h
			.elseif (eax=='lubv')
				mov	eax,[esi+edx+4]
				or	eax,20202020h
				.if eax=='itel'
					mov	_copyright,ecx
					or	dword ptr[esp],800h
				.endif
			.elseif (eax=='drow')
				mov	eax,[esi+edx+4]
				or	eax,20202020h
				.if eax=='serp'
					mov	_copyright,ecx
					or	dword ptr[esp],1000h
				.endif
			.elseif (eax=='bbym')
				mov	_copyright,ecx
				or	dword ptr[esp],800h
			.endif
			.if _copyright
				lea	edi,buftmp
				mov	eax,' ***'
				stosd
				mov	edx,_copyright
				push	0
				.while (byte ptr[esi+edx]!=0)
					.if (dword ptr[esi+edx]=='poc&')&&(word ptr[esi+edx+4]==';y')
						mov	al,'�'
						stosb
						lea	edx,[edx+4+1]
					.elseif (word ptr[esi+edx]=='a<')||(word ptr[esi+edx]=='A<')
						.while (byte ptr[esi+edx]!=0)&&(byte ptr[esi+edx]!='>')
							inc	edx
						.endw
						.if byte ptr[esi+edx]=='>'
							inc	edx
						.endif
						.while (byte ptr[esi+edx]!=0)&&(word ptr[esi+edx]!='/<')
							mov	al,[esi+edx]
							stosb
							inc	edx
						.endw
						.break
					.elseif (byte ptr[esi+edx]==13)||(byte ptr[esi+edx]==10)||(byte ptr[esi+edx]==32)||(byte ptr[esi+edx]==9)
						.if (edi!=offset buftmp)&&(byte ptr[edi-1]!=32)
							mov	al,32
							stosb
						.else
							dec	dword ptr[esp]
						.endif
					.elseif (dword ptr[esi+edx]=='sbn&')&&(word ptr[esi+edx+4]==';p')
						lea	edx,[edx+5]
						mov	al,32
						stosb
					.elseif (dword ptr[esi+edx]=='pma&')&&(byte ptr[esi+edx+4]==';')
						lea	edx,[edx+4]
						mov	al,'&'
						stosb
					.elseif byte ptr[esi+edx]=='<'
						.break
					.else
						mov	al,[esi+edx]
						stosb
					.endif
					inc	edx
					inc	dword ptr[esp]
					.break .if dword ptr[esp]>200
				.endw
				mov	ax,0a0dh
				stosw
				mov	al,0
				stosb
				lea	edx,buftmp
				push	ecx
				call	showmsg
				pop	ecx
				pop	eax
			.endif
		.elseif byte ptr[esi+ecx]=='<'
			mov	ax,[esi+ecx+1]
			or	al,20h
			.if ax==' a'
				lea	edx,[ecx+2]
				.while (byte ptr[esi+edx]!=0)&&(byte ptr[esi+edx]!='>')
					mov	eax,[esi+edx]
					or	eax,20202020h
					.if eax=='weiv'
						mov	eax,[esi+edx+4]
						or	eax,20202020h
						.if eax=='urof'
							mov	eax,[esi+edx+8]
							or	eax,20202020h
							.if eax=='hp.m'
								or	dword ptr[esp],10000h
							.endif
						.endif
					.elseif (eax=='aob?')||(eax=='aob&')
						mov	ax,[esi+edx+4]
						or	ax,2020h
						.if (ax=='dr')&&(byte ptr[esi+edx+6]=='=')
							or	dword ptr[esp],20000h
						.endif
					.elseif eax=='pma&'
						mov	eax,[esi+edx+4]
						or	eax,20202000h
						.if (eax=='aob;')
							mov	ax,[esi+edx+4+4]
							or	ax,2020h
							.if (ax=='dr')&&(byte ptr[esi+edx+4+6]=='=')
								or	dword ptr[esp],20000h
							.endif
						.endif
					.elseif eax=='wohs'
						mov	eax,[esi+edx+4]
						or	eax,20202020h
						.if eax=='urof'
							mov	ax,[esi+edx+8]
							or	al,20h
							.if ax=='=m'
								or	dword ptr[esp],40000h
							.endif
						.endif
					.elseif eax=='urof'
						mov	eax,[esi+edx+4]
						or	eax,20202020h
						.if eax=='sidm'
							mov	eax,[esi+edx+8]
							or	eax,20202020h
							.if eax=='yalp'
								mov	eax,[esi+edx+12]
								or	eax,20202000h
								.if eax=='php.'
									mov	eax,[esi+edx+12+4]
									or	eax,20202000h
									.if eax=='dif?'
										mov	byte ptr[esp+3],1
									.endif
									or	dword ptr[esp],80000h
								.endif
							.endif
						.endif
					.elseif eax=='gap/'
						mov	ax,[esi+edx+4]
						or	ax,20h
						.if (ax=='/e')&&(byte ptr[esi+edx+6]>='0')&&(byte ptr[esi+edx+6]<='9')
							or	byte ptr[esp],10h
							or	byte ptr[esp+2],40h
						.endif
					.elseif (eax=='gat/')&&(byte ptr[esi+edx+4]=='/')&&(byte ptr[esi+edx+4]>'A')
						or	byte ptr[esp],20h
						or	byte ptr[esp+2],40h
					.elseif (eax=='mrep')&&(dword ptr[esi+edx+4]=='nena')&&(dword ptr[esi+edx+8]=='il t')&&(dword ptr[esi+edx+12]=='t kn')
						or	byte ptr[esp+2],10h
					.elseif (eax=='gap?')&&(word ptr[esi+edx+4]=='de')&&(byte ptr[esi+edx+6]=='=')&&((byte ptr[esi+edx+7]>='0')&&(byte ptr[esi+edx+7]<='9'))
						or	byte ptr[esp],10h
						or	byte ptr[esp+2],40h
						or	byte ptr[esp+3],8
					.elseif (eax=='tac?')&&(byte ptr[esi+edx+4]=='=')&&((byte ptr[esi+edx+5]>='0')&&(byte ptr[esi+edx+5]<='9'))
						or	byte ptr[esp],20h
						or	byte ptr[esp+2],40h
						or	byte ptr[esp+3],8
					.endif
					inc	edx
				.endw
			.endif
		.elseif (dword ptr[esi+ecx]=='4OES')&&(dword ptr[esi+ecx+3]=='FMS4')
			or	byte ptr[esp+2],80h
		.elseif (dword ptr[esi+ecx]=='mnup')&&(dword ptr[esi+ecx+4]=='"nia')
			or	byte ptr[esp+3],1
		.elseif (dword ptr[esi+ecx]=='cnup')&&(dword ptr[esi+ecx+4]=='"1no')
			or	byte ptr[esp+3],2
		.elseif (dword ptr[esi+ecx]=='pnup')&&(dword ptr[esi+ecx+4]=='nial')
			or	byte ptr[esp+3],4
		.else
			or	eax,20202020h
			.if eax=='ewop'
				mov	eax,[esi+ecx+4]
				or	eax,20202020h
				.if eax==' der'
					mov	eax,[esi+ecx+7]
					or	eax,20202020h
					.if eax==' yb '
						lea	edx,[ecx+4+4+3]
						jmp	_d_copy
					.endif
				.endif
			.endif
		.endif
		inc	ecx
	.endw
	mov	blogdet,0
	movzx	eax,byte ptr[esp+2]
	.if byte ptr[esp+3]==7
		lea	edx,sd05
		call	showmsg
		lea	esi,forum_3x
		call	set_params
		mov	esi,hDialog
		call	dlgcbset
	.elseif al==0
_nodet:		lea	edx,sd0s
		call	showmsg
		.if (byte ptr[esp]==1)||(byte ptr[esp+1]==1)
			lea	esi,forum_tbl
			call	set_params
			mov	esi,hDialog
			call	dlgcbset
		.elseif (byte ptr[esp]==2)||(byte ptr[esp+1]==2)
			lea	esi,forum_tbl
			call	set_params
			mov	esi,hDialog
			call	dlgcbset
		.elseif (byte ptr[esp]==4)||(byte ptr[esp+1]==4)
			lea	esi,forum_ipb
			call	set_params
			mov	esi,hDialog
			call	dlgcbset
		.elseif (byte ptr[esp]==8)||(byte ptr[esp+1]==8)
			lea	esi,forum_vb
			.if byte ptr[esp+3]==1
				lea	esi,forum_mybb
			.endif
			call	set_params
			mov	esi,hDialog
			call	dlgcbset
		.endif
	.elseif al==1
		.if (byte ptr[esp+1]==0)||(((byte ptr[esp+1]!=0)&&(!(byte ptr[esp+1]&1)))&&(byte ptr[esp+1]!=16))
			lea	edx,sd0c
			call	showmsg
		.endif
		.if byte ptr[esp+1]==16
			lea	edx,sd01a
			call	showmsg
			lea	esi,forum_pu
			call	set_params
		.else
			lea	edx,sd01
			call	showmsg
			lea	esi,forum_tbl
			call	set_params
		.endif
		mov	esi,hDialog
		call	dlgcbset
	.elseif ((al==80h)&&((byte ptr[esp]==2)||(byte ptr[esp+1]==2)))
		lea	edx,sd02a
		call	showmsg
		lea	esi,forum_sm
		call	set_params
		mov	esi,hDialog
		call	dlgcbset
	.elseif (al==2)||(al==82h)
		lea	edx,sd02
		call	showmsg
		.if (byte ptr[esp+1]==0)||((byte ptr[esp+1]!=0)&&(!(byte ptr[esp+1]&2)))
			lea	edx,sd0c
			call	showmsg
		.endif
		lea	esi,forum_tbl
		call	set_params
		mov	esi,hDialog
		call	dlgcbset
	.elseif al==4
		lea	edx,sd03
		call	showmsg
		.if (byte ptr[esp+1]==0)||((byte ptr[esp+1]!=0)&&(!(byte ptr[esp+1]&4)))
			lea	edx,sd0c
			call	showmsg
		.endif
		lea	esi,forum_ipb
		call	set_params
		mov	esi,hDialog
		call	dlgcbset
	.elseif al==8
		lea	edx,sd04
		.if byte ptr[esp+3]==1
			lea	edx,sd04c
		.endif
		call	showmsg
		.if (byte ptr[esp+1]==0)||((byte ptr[esp+1]!=0)&&(!(byte ptr[esp+1]&8)))
			lea	edx,sd0c
			call	showmsg
		.endif
		lea	esi,forum_vb
		.if byte ptr[esp+3]==1
			lea	esi,forum_mybb
		.endif
		call	set_params
		mov	esi,hDialog
		call	dlgcbset
	.elseif al&10h
		.if byte ptr[esp+3]&8
			mov	blogdet,2
			lea	edx,sd06a
			call	showmsg
			lea	esi,forum_wp1
		.else
			mov	blogdet,1
			lea	edx,sd06
			call	showmsg
			lea	esi,forum_wp
		.endif
		call	set_params
		mov	esi,hDialog
		call	dlgcbset
	.elseif (byte ptr[esp]&30h)
		.if byte ptr[esp+3]&8
			mov	blogdet,2
			lea	edx,sd06a
			call	showmsg
			lea	esi,forum_wp1
		.else
			mov	blogdet,1
			lea	edx,sd06
			call	showmsg
			lea	esi,forum_wp
		.endif
		call	set_params
		mov	esi,hDialog
		call	dlgcbset
	.else
		jmp	_nodet
	.endif
	pop	eax
	ret
;	00000000 00000000 00000001	phpbb link
;	00000000 00000000 00000010	smf link
;	00000000 00000001 00000000	phpbb copyright
;	00000001 00000000 00000000	phpbb structure
;	10000010 00000000 00000000	smf, seo4smf mod
_detect	ENDP
endm

ua_init	macro
	invoke	SendDlgItemMessage,hDlg,6301,CB_ADDSTRING,0,addr agent01
	invoke	SendDlgItemMessage,hDlg,6301,CB_SETITEMDATA,eax,0
	invoke	SendDlgItemMessage,hDlg,6301,CB_ADDSTRING,0,addr agent02
	invoke	SendDlgItemMessage,hDlg,6301,CB_SETITEMDATA,eax,1
	invoke	SendDlgItemMessage,hDlg,6301,CB_ADDSTRING,0,addr agent03
	invoke	SendDlgItemMessage,hDlg,6301,CB_SETITEMDATA,eax,2
	invoke	SendDlgItemMessage,hDlg,6301,CB_ADDSTRING,0,addr agent04
	invoke	SendDlgItemMessage,hDlg,6301,CB_SETITEMDATA,eax,3
	invoke	SendDlgItemMessage,hDlg,6301,CB_ADDSTRING,0,addr agent05
	invoke	SendDlgItemMessage,hDlg,6301,CB_SETITEMDATA,eax,4
	invoke	SendDlgItemMessage,hDlg,6301,CB_ADDSTRING,0,addr agent06
	invoke	SendDlgItemMessage,hDlg,6301,CB_SETITEMDATA,eax,5
	invoke	SendDlgItemMessage,hDlg,6301,CB_ADDSTRING,0,addr agent07
	invoke	SendDlgItemMessage,hDlg,6301,CB_SETITEMDATA,eax,6
	invoke	SendDlgItemMessage,hDlg,6301,CB_ADDSTRING,0,addr agent08
	invoke	SendDlgItemMessage,hDlg,6301,CB_SETITEMDATA,eax,7
	invoke	SendDlgItemMessage,hDlg,6301,CB_ADDSTRING,0,addr agent09
	invoke	SendDlgItemMessage,hDlg,6301,CB_SETITEMDATA,eax,8
	invoke	SendDlgItemMessage,hDlg,6301,CB_ADDSTRING,0,addr agent10
	invoke	SendDlgItemMessage,hDlg,6301,CB_SETITEMDATA,eax,9
	invoke	SendDlgItemMessage,hDlg,6301,CB_ADDSTRING,0,addr agent11
	invoke	SendDlgItemMessage,hDlg,6301,CB_SETITEMDATA,eax,10
	movzx	eax,_agent
	invoke	SendDlgItemMessage,hDlg,6301,CB_SETCURSEL,eax,0
endm

ua_dlg	macro
	.elseif (ax==6301)&&(bx==CBN_SELCHANGE)
		invoke	SendDlgItemMessage,hDlg,6301,CB_GETCURSEL,0,0
		.if eax!=CB_ERR
			invoke	SendDlgItemMessage,hDlg,6301,CB_GETITEMDATA,eax,0
			.if eax!=CB_ERR
				mov	_agent,al
			.endif
		.endif
endm

;ua01 / host / ua02 / cookies
ua_hdr	macro
ua_01:	lea	edx,http2
	call	copyedx
	.if (_agent==1)||(_agent==2)||(_agent==3)
		lea	edx,http4
		call	copyedx
		lea	edx,http4a
		call	copyedx
		.if _agent==3
			lea	edx,http4c
			call	copyedx
		.endif
		lea	edx,http4b
		call	copyedx
		lea	edx,ua00
		call	copyedx
		movzx	eax,_agent
		mov	edx,uagents[eax*4]
		call	copyedx
		mov	ax,0a0dh
		stosw
	.elseif (_agent==4)||(_agent==5)||(_agent==6)
		lea	edx,ua00
		call	copyedx
		movzx	eax,_agent
		mov	edx,uagents[eax*4]
		call	copyedx
		mov	ax,0a0dh
		stosw
	.elseif _agent==10
		lea	edx,http4
		call	copyedx
		lea	edx,ua00
		call	copyedx
		movzx	eax,_agent
		mov	edx,uagents[eax*4]
		call	copyedx
		mov	ax,0a0dh
		stosw
		lea	edx,http4b
		call	copyedx
		lea	edx,http_y1
		call	copyedx
	.endif
	.if _agent==6
		lea	edx,http_c1
		call	copyedx
	.endif
	lea	edx,http3
	call	copyedx
	ret

;host
ua_02:	mov	ax,0a0dh
	stosw
	.if (_agent==1)||(_agent==2)||(_agent==3)||(_agent==6)
	.elseif _agent==4
		lea	edx,http_o1
		call	copyedx
	.elseif _agent==5
		lea	edx,http_f1
		call	copyedx
	.elseif (_agent==8)||(_agent==9)
		lea	edx,http4
		call	copyedx
		.if _agent==9
			lea	edx,ua00
			call	copyedx
		.endif
		movzx	eax,_agent
		mov	edx,uagents[eax*4]
		call	copyedx
		mov	ax,0a0dh
		stosw
		lea	edx,http4b
		call	copyedx
	.elseif _agent==10
	.else
		lea	edx,http4
		call	copyedx
	.endif
	ret

ua_03:	.if (_agent==1)||(_agent==2)||(_agent==3)
	.elseif _agent==4
	.elseif _agent==5
	.elseif _agent==6
	.elseif _agent==7
	.elseif _agent==8
	.elseif _agent==9
	.elseif _agent==10
	.else
		lea	edx,ua00
		call	copyedx
		movzx	eax,_agent
		mov	edx,uagents[eax*4]
		call	copyedx
		mov	ax,0a0dh
		stosw
	.endif
	lea	edx,http6a
	.if proxyflag&4
		lea	edx,http6
	.endif
	call	copyedx
	mov	ax,0a0dh
	stosw
	ret

;cookies
ua_03a:	.if (_agent==1)||(_agent==2)||(_agent==3)
	.elseif _agent==4
	.elseif _agent==5
		lea	edx,http_f2
		call	copyedx
	.elseif _agent==6
	.elseif _agent==7
	.elseif _agent==8
	.elseif _agent==9
	.elseif _agent==10
	.else
		lea	edx,ua00
		call	copyedx
		movzx	eax,_agent
		mov	edx,uagents[eax*4]
		call	copyedx
		mov	ax,0a0dh
		stosw
	.endif
	lea	edx,http6a
	call	copyedx
	mov	ax,0a0dh
	stosw
	ret
ua_03b:	.if (_agent==1)||(_agent==2)||(_agent==3)
	.elseif _agent==4
	.elseif _agent==5
		lea	edx,http_f2
		call	copyedx
	.elseif _agent==6
	.elseif _agent==7
	.elseif _agent==8
	.elseif _agent==9
	.elseif _agent==10
	.else
		lea	edx,ua00
		call	copyedx
		movzx	eax,_agent
		mov	edx,uagents[eax*4]
		call	copyedx
		mov	ax,0a0dh
		stosw
	.endif
	lea	edx,http6a
	.if proxyflag&4
		lea	edx,http6
	.endif
	call	copyedx
	mov	ax,0a0dh
	stosw
	ret
endm

ua_03_	macro
	.if (_agent==1)||(_agent==2)||(_agent==3)
	.elseif _agent==4
	.elseif _agent==5
	.elseif _agent==6
	.elseif _agent==7
	.elseif _agent==8
	.elseif _agent==9
	.elseif _agent==10
	.else
		lea	edx,ua00
		call	copyedx
		movzx	eax,_agent
		mov	edx,uagents[eax*4]
		call	copyedx
		mov	ax,0a0dh
		stosw
	.endif
	lea	edx,http6a
	.if ((proxyflag&4)&&(!(got_hdr&4)))
		lea	edx,http6
	.endif
	call	copyedx
	mov	ax,0a0dh
	stosw
endm

detect_blog	macro
detect_wp:
	mov	esi,recvbuf
	mov	edi,esi
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			mov	eax,[esi+1]
			or	eax,20202020h
			.if eax=='ltit'
			.break
			.endif
		.endif
		inc	esi
	.endw
	.if byte ptr[esi]
		xor	ecx,ecx
		.while (byte ptr[esi]!=0)&&(word ptr[esi]!='/<')&&(ecx<256)
			movsb
			inc	ecx
		.endw
		mov	eax,'IT/<'
		stosd
		mov	eax,'>ELT'
		stosd
	.endif
	invoke	GetLocalTime,addr systime
	movzx	eax,systime.wYear
	.while eax>=2003
		push	eax
		movzx	eax,systime.wYear
		.if eax==[esp]
			movzx	eax,systime.wMonth
		.else
			mov	eax,12
		.endif
		.while eax
			push	eax
			mov	eax,' lu<'
			stosd
			mov	eax,'salc'
			stosd
			mov	eax,'w"=s'
			stosd
			mov	eax,'>"p'
			stosd
			dec	edi
			mov	eax,'>il<'
			stosd
			mov	eax,'h A<'
			stosd
			mov	eax,'=fer'
			stosd
			mov	al,34
			stosb
			mov	eax,[esp+4]
			call	w4
			mov	al,'/'
			stosb
			mov	eax,[esp]
			call	w2
			mov	ax,'>"'
			stosw
			mov	eax,[esp+4]
			call	w4
			mov	al,'-'
			stosb
			mov	eax,[esp]
			call	w2
			mov	eax,'>A/<'
			stosd
			mov	eax,'IL/<'
			stosd
			mov	eax,'U/<>'
			stosd
			mov	ax,'>L'
			stosw
			pop	eax
			dec	eax
		.endw
		pop	eax
		dec	eax
	.endw
	mov	al,0
	stosb
	ret
detect_wp1:
	mov	esi,recvbuf
	mov	edi,esi
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			mov	eax,[esi+1]
			or	eax,20202020h
			.if eax=='ltit'
			.break
			.endif
		.endif
		inc	esi
	.endw
	.if byte ptr[esi]
		xor	ecx,ecx
		.while (byte ptr[esi]!=0)&&(word ptr[esi]!='/<')&&(ecx<256)
			movsb
			inc	ecx
		.endw
		mov	eax,'IT/<'
		stosd
		mov	eax,'>ELT'
		stosd
	.endif
	invoke	GetLocalTime,addr systime
	movzx	eax,systime.wYear
	.while eax>=2003
		push	eax
		movzx	eax,systime.wYear
		.if eax==[esp]
			movzx	eax,systime.wMonth
		.else
			mov	eax,12
		.endif
		.while eax
			push	eax
			mov	eax,' lu<'
			stosd
			mov	eax,'salc'
			stosd
			mov	eax,'w"=s'
			stosd
			mov	eax,'>"p'
			stosd
			dec	edi
			mov	eax,'>il<'
			stosd
			mov	eax,'h A<'
			stosd
			mov	eax,'=fer'
			stosd
			mov	al,34
			stosb
			mov	ax,'m?'
			stosw
			mov	al,'='
			stosb
			mov	eax,[esp+4]
			call	w4
			mov	eax,[esp]
			call	w2
			mov	ax,'>"'
			stosw
			mov	eax,[esp+4]
			call	w4
			mov	al,'-'
			stosb
			mov	eax,[esp]
			call	w2
			mov	eax,'>A/<'
			stosd
			mov	eax,'IL/<'
			stosd
			mov	eax,'U/<>'
			stosd
			mov	ax,'>L'
			stosw
			pop	eax
			dec	eax
		.endw
		pop	eax
		dec	eax
	.endw
	mov	al,0
	stosb
	ret

src_bs	db	'/search?updated-min=',0
src_bs1	db	'-01T00%3A00%3A00%2B01%3A00&updated-max=',0
src_bs2	db	'T23%3A59%3A59%2B01%3A00&max-results=5000',0
detect_bs:
	mov	esi,recvbuf
	mov	edi,esi
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			mov	eax,[esi+1]
			or	eax,20202020h
			.if eax=='ltit'
			.break
			.endif
		.endif
		inc	esi
	.endw
	.if byte ptr[esi]
		xor	ecx,ecx
		.while (byte ptr[esi]!=0)&&(word ptr[esi]!='/<')&&(ecx<256)
			movsb
			inc	ecx
		.endw
		mov	eax,'IT/<'
		stosd
		mov	eax,'>ELT'
		stosd
	.endif
	push	0
	.while byte ptr[esi]
		mov	ax,[esi+1]
		or	ax,2020h
		.if (byte ptr[esi]=='<')&&((ax==' a')||(ax=='po'))
			mov	edx,esi
			.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
				.if ((byte ptr[esi]>='0')&&(byte ptr[esi]<='9'))&&((byte ptr[esi+1]>='0')&&(byte ptr[esi+1]<='9'))
					.if ((byte ptr[esi+2]>='0')&&(byte ptr[esi+2]<='9'))&&((byte ptr[esi+3]>='0')&&(byte ptr[esi+3]<='9'))
					.if (byte ptr[esi+4]=='_')&&((byte ptr[esi+5]>='0')&&(byte ptr[esi+5]<='9'))&&((byte ptr[esi+6]>='0')&&(byte ptr[esi+6]<='9'))
						.if (byte ptr[esi+7]=='_')&&((byte ptr[esi+8]>='0')&&(byte ptr[esi+8]<='9'))&&((byte ptr[esi+9]>='0')&&(byte ptr[esi+9]<='9'))
							.if (dword ptr[esi+10]=='cra_')&&(dword ptr[esi+14]=='evih')&&(dword ptr[esi+18]=='mth.')&&(byte ptr[esi+22]=='l')
								mov	eax,' lu<'
								stosd
								mov	eax,'salc'
								stosd
								mov	eax,'b"=s'
								stosd
								mov	eax,'>"s'
								stosd
								dec	edi
								mov	eax,'>il<'
								stosd
								mov	eax,'h A<'
								stosd
								mov	eax,'=fer'
								stosd
								mov	al,34
								stosb
								mov	edx,esi
								.while (byte ptr[esi]!=39)&&(byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]>32)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='<')
									movsb
								.endw
								mov	ax,'>"'
								stosw
								.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='<')&&(byte ptr[esi]!='>')
									inc	esi
								.endw
								.if byte ptr[esi]=='>'
									inc	esi
								;	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='<')&&(byte ptr[esi]!='>')
								;		movsb
								;	.endw
										mov	esi,edx
										movsd
										lodsb
										mov	al,'-'
										stosb
										movsw
										lodsb
										mov	al,'-'
										stosb
										movsw
								.else
									mov	esi,edx
									movsd
									movsd
									movsw
								.endif
								mov	eax,'>A/<'
								stosd
								mov	eax,'IL/<'
								stosd
								mov	eax,'U/<>'
								stosd
								mov	ax,'>L'
								stosw
								mov	byte ptr[esp],1
							.else
								inc	esi
							.endif
						.else
							inc	esi
						.endif
					.else
						inc	esi
					.endif
					.else
						inc	esi
					.endif
				.else
					inc	esi
				.endif
			.endw
		.elseif (dword ptr[esi]==' 3h<')&&(dword ptr[esi+4]=='salc')&&(word ptr[esi+8]=='=s')&&(dword ptr[esi+11]=='tsop')&&(dword ptr[esi+15]=='tit-')&&(word ptr[esi+19]=='el')
			xor	ecx,ecx
			.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='>')
				inc	ecx
			.endw
			.if byte ptr[esi+ecx]=='>'
				inc	ecx
				.while 1
					.if (byte ptr[esi+ecx]==32)||(byte ptr[esi+ecx]==13)||(byte ptr[esi+ecx]==10)||(byte ptr[esi+ecx]==9)
						inc	ecx
					.elseif (dword ptr[esi+ecx]=='sbn&')&&(word ptr[esi+ecx+4]==';p')
						lea	ecx,[ecx+4]
					.else
						.break
					.endif
				.endw
				.if (word ptr[esi+ecx]=='a<')||(word ptr[esi+ecx]=='A<')
					mov	byte ptr[esp+1],1
				.endif
			.endif
			inc	esi
		.else
			inc	esi
		.endif
	.endw
	pop	eax
	.if (ah==0)&&(fdetect==0)
		push	eax
		push	edi
		lea	esi,forum_bs1
		call	set_params
		mov	esi,hDialog
		call	dlgcbset
		pop	edi
		pop	eax
	.endif
	.if al==1
		mov	al,0
		stosb
		ret
	.endif
	invoke	GetLocalTime,addr systime
	movzx	eax,systime.wYear
	.while eax>=2000
		push	eax
		movzx	eax,systime.wYear
		.if eax==[esp]
			movzx	eax,systime.wMonth
		.else
			mov	eax,12
		.endif
		.while eax
			push	eax
			mov	eax,' lu<'
			stosd
			mov	eax,'salc'
			stosd
			mov	eax,'b"=s'
			stosd
			mov	eax,'>"s'
			stosd
			dec	edi
			mov	eax,'>il<'
			stosd
			mov	eax,'h A<'
			stosd
			mov	eax,'=fer'
			stosd
			mov	al,34
			stosb
			lea	edx,src_bs
			call	copyedx
			mov	eax,[esp+4]
			call	w4
			mov	al,'-'
			stosb
			mov	eax,[esp]
			call	w2
			lea	edx,src_bs1
			call	copyedx
			mov	eax,[esp+4]
			call	w4
			mov	al,'-'
			stosb
			mov	eax,[esp]
			call	w2
			mov	al,'-'
			stosb
			mov	eax,[esp]
			.if (eax==1)||(eax==3)||(eax==5)||(eax==7)||(eax==8)||(eax==10)||(eax==12)
				mov	ax,'13'
				stosw
			.elseif (eax==4)||(eax==6)||(eax==9)||(eax==11)
				mov	ax,'03'
				stosw
			.elseif al==2
				mov	eax,[esp+4]
				.if eax&3
					mov	ax,'82'
				.else
					mov	ax,'92'
				.endif
				stosw
			.endif
			lea	edx,src_bs2
			call	copyedx
			mov	ax,'>"'
			stosw
			mov	eax,[esp+4]
			call	w4
			mov	al,'-'
			stosb
			mov	eax,[esp]
			call	w2
			mov	eax,'>A/<'
			stosd
			mov	eax,'IL/<'
			stosd
			mov	eax,'U/<>'
			stosd
			mov	ax,'>L'
			stosw
			pop	eax
			dec	eax
		.endw
		pop	eax
		dec	eax
	.endw
	mov	al,0
	stosb
	ret

bs_adj:	push	esi
	push	edi
	mov	edi,esi
	.while byte ptr[esi]
		mov	ax,[esi+1]
		or	ax,2020h
		.if (dword ptr[esi]==' 3h<')&&(dword ptr[esi+4]=='salc')&&(word ptr[esi+8]=='=s')&&(dword ptr[esi+11]=='tsop')&&(dword ptr[esi+15]=='tit-')&&(word ptr[esi+19]=='el')
			.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
				inc	esi
			.endw
			.if byte ptr[esi]
				inc	esi
			.endif
			.while 1
				.if (byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.elseif (dword ptr[esi]=='sbn&')&&(word ptr[esi+4]==';p')
					lodsd
					lodsw
				.else
					.break
				.endif
			.endw
			.break .if (word ptr[esi]=='a<')||(word ptr[esi]=='A<')
			push	edi
			push	esi
			lea	edi,buftmp
			.while (byte ptr[esi]!=0)
				mov	ax,[esi+1]
				or	al,20h
				.if (byte ptr[esi]=='<')&&(ax==' a')
					mov	ecx,esi
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						mov	eax,[esi]
						or	eax,20202020h
						mov	dx,[esi+4]
						or	dx,20h
						.if (eax=='ltit')&&(dx=='=e')
							lodsd
							lodsw
							.if byte ptr[esi]
								lodsb
							.endif
							mov	eax,[esi]
							or	eax,20202020h
							.if eax=='mrep'
								lodsd
								mov	eax,[esi]
								or	eax,20202020h
								.if eax=='nena'
									lodsd
									mov	eax,[esi]
									or	eax,20202020h
									mov	dx,[esi+4]
									or	dx,2020h
									.if (eax=='il t')&&(dx=='kn')
										mov	esi,ecx
										.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
											movsb
										.endw
										mov	al,'>'
										stosb
										xor	ecx,ecx
										.break
									.endif
								.endif
							.endif
						.else
							inc	esi
						.endif
					.endw
					.break .if ecx==0
				.else
					inc	esi
				.endif
			.endw
			pop	esi
			.while 1
				.if (byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.elseif (dword ptr[esi]=='sbn&')&&(word ptr[esi+4]==';p')
					lodsd
					lodsw
				.else
					.break
				.endif
			.endw
			.while (word ptr[esi]!='/<')&&(byte ptr[esi]!=0)
				movsb
			.endw
			mov	eax,'>A/<'
			stosd
			mov	al,0
			stosb
			pop	edi
			lea	edx,buftmp
			call	copyedx
		.elseif (dword ptr[esi]==' 3h<')&&(dword ptr[esi+4]=='salc')&&(word ptr[esi+8]=='=s')&&(dword ptr[esi+11]=='tsop')&&(dword ptr[esi+15]=='tit-')&&(dword ptr[esi+19]=='e el')
			pop	edi
			pop	esi
			xor	eax,eax
			ret
		.else
			inc	esi
		.endif
	.endw
	.if edi!=dword ptr[esp+4]
		mov	ecx,edi
		sub	ecx,dword ptr[esp+4]
		mov	fsize,ecx
		mov	al,0
		stosb
	.endif
	pop	edi
	pop	esi
	ret
endm
