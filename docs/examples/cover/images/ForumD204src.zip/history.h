hist_attach	struct
	ptr_next	dd	?
	str1size	dw	?
	histtype	dw	?
	histlnk		db	100 dup(?)
	histfile	db	100 dup(?)
hist_attach	ends

hist_data	macro
	histattach	dd	?
	histforum	dd	?
	savet		dd	?
	tmphist		db	1024 dup(?)
endm

hist_init	macro
	mov	histforum,0
	mov	savet,0
	mov	histattach,0
endm

inithist	macro
	call	hist_free
endm

freehist	macro
	call	hist_free
endm
debug	equ	1

hist_procs	macro
assume	ebx:ptr foruminfo
_relinkmsg	db	'*** Correcting links...',13,10,0
ifdef debug
hname	db	'history.txt',0
hist1	db	'Forums',13,10,13,10
hist2	db	13,10,13,10,'Topics',13,10,13,10
htab	db	9,9
endif

hist_upd:
	ifdef debug
	invoke	CreateFile,addr hname,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0
	push	eax
	invoke	WriteFile,eax,addr hist1,sizeof hist1,addr bread,0
	mov	edx,histforum
	.while edx
		push	edx
		lea	edx,[edx+4+1+4+4+4+4]
		xor	ecx,ecx
		.while byte ptr[edx+ecx]
			inc	ecx
		.endw
		mov	eax,[esp+4]
		invoke	WriteFile,eax,edx,ecx,addr bread,0
		mov	eax,[esp+4]
		invoke	WriteFile,eax,addr hist2,2,addr bread,0
		mov	edx,[esp]
		lea	edx,[edx+4+1]
		push	edx
		.if dword ptr[edx]
			mov	eax,[esp+4+4]
			push	dword ptr[edx]
			invoke	WriteFile,eax,addr htab,1,addr bread,0
			pop	edx
			xor	ecx,ecx
			.while byte ptr[edx+ecx]
				inc	ecx
			.endw
			mov	eax,[esp+4+4]
			invoke	WriteFile,eax,edx,ecx,addr bread,0
			mov	eax,[esp+4+4]
			invoke	WriteFile,eax,addr hist2,2,addr bread,0
		.endif
		pop	edx
		lea	edx,[edx+4]
		.if dword ptr[edx]
			mov	eax,[esp+4]
			push	dword ptr[edx]
			invoke	WriteFile,eax,addr htab,1,addr bread,0
			pop	edx
		.endif
		.while edx
			push	dword ptr[edx]
			lea	edx,[edx+4]
			mov	eax,[esp+4+4]
			xor	ecx,ecx
			.while byte ptr[edx+ecx]
				inc	ecx
			.endw
			mov	eax,[esp+4+4]
			invoke	WriteFile,eax,edx,ecx,addr bread,0
			pop	edx
		.endw
		mov	eax,[esp+4]
		invoke	WriteFile,eax,addr hist2,2,addr bread,0
		pop	edx
		mov	edx,[edx]
	.endw
	mov	eax,[esp]
	invoke	WriteFile,eax,addr hist2,sizeof hist2,addr bread,0
	mov	edx,savet
	.while edx
		push	edx
		lea	edx,[edx+4+1+4+4+4+4]
		xor	ecx,ecx
		.while byte ptr[edx+ecx]
			inc	ecx
		.endw
		mov	eax,[esp+4]
		invoke	WriteFile,eax,edx,ecx,addr bread,0
		mov	eax,[esp+4]
		invoke	WriteFile,eax,addr hist2,2,addr bread,0
		mov	edx,[esp]
		lea	edx,[edx+4+1]
		push	edx
		.if dword ptr[edx]
			mov	eax,[esp+4+4]
			push	dword ptr[edx]
			invoke	WriteFile,eax,addr htab,1,addr bread,0
			pop	edx
			xor	ecx,ecx
			.while byte ptr[edx+ecx]
				inc	ecx
			.endw
			mov	eax,[esp+4+4]
			invoke	WriteFile,eax,edx,ecx,addr bread,0
			mov	eax,[esp+4+4]
			invoke	WriteFile,eax,addr hist2,2,addr bread,0
		.endif
		pop	edx
		lea	edx,[edx+4]
		.if dword ptr[edx]
			mov	eax,[esp+4]
			push	dword ptr[edx]
			invoke	WriteFile,eax,addr htab,1,addr bread,0
			pop	edx
		.endif
		.while edx
			push	dword ptr[edx]
			lea	edx,[edx+4]
			mov	eax,[esp+4+4]
			xor	ecx,ecx
			.while byte ptr[edx+ecx]
				inc	ecx
			.endw
			mov	eax,[esp+4+4]
			invoke	WriteFile,eax,edx,ecx,addr bread,0
			pop	edx
		.endw
		mov	eax,[esp+4]
		invoke	WriteFile,eax,addr hist2,2,addr bread,0
		pop	edx
		mov	edx,[edx]
	.endw
	call	CloseHandle
	endif
	.if savetype==1
		lea	edx,_relinkmsg
		call	showmsg
		mov	esi,savet
		.while esi
			lea	edx,[esi+4+16+1]
			.if dword ptr[esi+4+1]
				mov	edx,[esi+4+1]
				invoke	CreateFile,edx,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0
				.if eax!=INVALID_HANDLE_VALUE
					push	eax
					invoke	GetFileSize,eax,0
					mov	bread,eax
					lea	edx,[eax+1024]
					invoke	GlobalAlloc,GPTR,edx
					mov	edi,eax
					mov	edx,[esp]
					invoke	ReadFile,edx,edi,bread,addr bread,0
					mov	eax,bread
					mov	byte ptr[edi+eax],0
					call	CloseHandle
					push	edi
					mov	eax,bread
					shl	eax,1
					invoke	GlobalAlloc,GPTR,eax
					push	eax
					push	esi
					mov	esi,edi
					mov	edi,eax
					.while byte ptr[esi]
						mov	eax,[esi]
						or	eax,20202020h
						.if eax=='ferh'
							movsd
							.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
								movsb
							.endw
							.if byte ptr[esi]=='='
								movsb
								.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==39)||(byte ptr[esi]==34)
									movsb
								.endw
								mov	edx,[esp]
								mov	edx,[edx+4+1]
								push	edi
								lea	edi,tmphist
								call	copyedx
								.while (byte ptr[edi-1]!='/')&&(byte ptr[edi-1]!='\')&&(edi>offset tmphist)
									dec	edi
								.endw
								mov	edx,esi
								mov	ecx,edi
								sub	ecx,offset tmphist
								.while (byte ptr[edx]!=0)&&(byte ptr[edx]!=34)&&(byte ptr[edx]!=39)&&(ecx<1020)
									mov	al,[edx]
									stosb
									inc	edx
									inc	ecx
								.endw
								mov	al,0
								stosb
								pop	edi
								invoke	GetFileAttributes,addr tmphist
								.if (eax&FILE_ATTRIBUTE_DIRECTORY)
									call	is_internal
									push	edi
									mov	edx,histforum
									call	scmp
									.if edx==0
										mov	edx,savet
										call	scmp
									.endif
									pop	edi
									.if (edx!=0)&&(dword ptr[edx+1+4]!=0)
										mov	ebx,[esp]
										mov	edx,[edx+1+4]
										mov	ebx,dword ptr[ebx+1+4]
										mov	ecx,edx
										push	edx
										.while (byte ptr[ebx]!=0)&&(byte ptr[edx]!=0)
											mov	al,[ebx]
											mov	ah,[edx]
											or	ax,2020h
											.break .if al!=ah
											mov	al,[ebx]
											.if (al=='/')||(al=='\')
												mov	ecx,ebx
												mov	[esp],edx
											.endif
											inc	ebx
											inc	edx
										.endw
										pop	ebx
										.if (byte ptr[ecx]=='\')||(byte ptr[ecx]=='/')
											inc	ecx
										.endif
										.while byte ptr[ecx]
											.if (byte ptr[ecx]=='\')||(byte ptr[ecx]=='/')
												mov	eax,'\..'
												stosd
												dec	edi
											.endif
											inc	ecx
										.endw
										.if (byte ptr[ebx]=='\')||(byte ptr[ebx]=='/')
											inc	ebx
										.endif
										.while byte ptr[ebx]
											mov	al,[ebx]
											stosb
											inc	ebx
										.endw
										.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)
											lodsb
										.endw
									.endif
								.endif
							.endif
						.else
							movsb
						.endif
					.endw
					pop	esi
					mov	edx,[esi+4+1]
					invoke	CreateFile,edx,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0
					.if eax!=INVALID_HANDLE_VALUE
						mov	ecx,edi
						mov	edx,[esp]
						sub	ecx,edx
						push	eax
						invoke	WriteFile,eax,edx,ecx,addr bread,0
						call	CloseHandle
					.endif
					call	GlobalFree
					call	GlobalFree
				.endif
			.endif
			mov	esi,[esi]
		.endw
	.endif
	ret
hist_free:
	push	esi
	mov	esi,histforum
	.while esi
		push	dword ptr[esi]
		.if dword ptr[esi+4+1]
			invoke	GlobalFree,dword ptr[esi+4+1]
		.endif
		.if dword ptr[esi+4+1+4]
			invoke	GlobalFree,dword ptr[esi+4+1+4]
		.endif
		invoke	GlobalFree,esi
		pop	esi
	.endw
	mov	histforum,0
	lea	esi,histattach
	.while esi
		push	dword ptr[esi]
		invoke	GlobalFree,esi
		pop	esi
	.endw
	mov	histattach,0
	lea	esi,savet
	.while esi
		push	dword ptr[esi]
		.if dword ptr[esi+4+1]
			invoke	GlobalFree,dword ptr[esi+4+1]
		.endif
		.if dword ptr[esi+4+1+4]
			invoke	GlobalFree,dword ptr[esi+4+1+4]
		.endif
		invoke	GlobalFree,esi
		pop	esi
	.endw
	mov	savet,0
	pop	esi
	ret

scmp:	push	edx
	call	is_internal
	pop	edx
	push	esi
	lea	edi,tmphist
	push	edx
	.if eax
		mov	eax,[esi]
		or	eax,20202020h
		.if byte ptr[esi]=='/'
			mov	edx,f_info
			assume	edx:ptr foruminfo
			lea	edx,[edx]._addr
			assume	edx:nothing
			mov	eax,[edx]
			or	eax,20202020h
			.if eax=='ptth'
				lea	edx,[edx+4]
				.while (byte ptr[edx]==':')||(byte ptr[edx]=='/')
					inc	edx
				.endw
			.endif
			mov	eax,[edx]
			or	eax,202020h
			.if eax=='.www'
				lea	edx,[edx+4]
			.endif
			.while (byte ptr[edx]!=0)&&(byte ptr[edx]!='/')
				mov	al,[edx]
				stosb
				inc	edx
			.endw
		.elseif (eax!='ptth')||(word ptr[esi+4]!='/:')||(byte ptr[esi+6]!='/')
			mov	edx,f_info
			assume	edx:ptr foruminfo
			lea	edx,[edx]._addr
			assume	edx:nothing
			mov	eax,[edx]
			or	eax,20202020h
			.if eax=='ptth'
				lea	edx,[edx+4]
				.while (byte ptr[edx]==':')||(byte ptr[edx]=='/')
					inc	edx
				.endw
			.endif
			mov	eax,[edx]
			or	eax,202020h
			.if eax=='.www'
				lea	edx,[edx+4]
			.endif
			.while (byte ptr[edx]!=0)&&(byte ptr[edx]!='/')
				mov	al,[edx]
				stosb
				inc	edx
			.endw
			mov	al,'/'
			stosb
		.else
			lea	esi,[esi+7]
			mov	eax,[esi]
			or	eax,202020h
			.if eax=='.www'
				lodsd
			.endif
		.endif
	.else
		mov	eax,[esi]
		or	eax,20202020h
		.if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+4+2]=='/')
			movsd
			movsw
			movsb
			mov	eax,[esi]
			or	eax,202020h
			.if eax=='.www'
				lodsd
			.endif
		.endif
	.endif
	xor	ecx,ecx
	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!='<')&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='#')&&(ecx<1020)
		mov	eax,[esi]
		or	eax,20202020h
		.if eax=='=dis'
			.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')&&(byte ptr[esi]!='<')&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='#')
				inc	esi
			.endw
		.elseif eax=='sphp'
			mov	eax,[esi+4]
			or	eax,20202020h
			.if eax=='isse'
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')&&(byte ptr[esi]!='<')&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='#')
					inc	esi
				.endw
			.else
				movsb
			.endif
		.elseif ax=='=s'
			xor	eax,eax
			.while ((byte ptr[esi+eax+2]>='0')&&(byte ptr[esi+eax+2]<='9'))||((byte ptr[esi+eax+2]>='a')&&(byte ptr[esi+eax+2]<='f'))||((byte ptr[esi+eax+2]>='A')&&(byte ptr[esi+eax+2]<='F'))
				inc	eax
			.endw
			.if eax>8
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')&&(byte ptr[esi]!='<')&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='#')
					inc	esi
				.endw
			.else
				movsb
			.endif
		.elseif byte ptr[esi]=='&'
			.while byte ptr[esi]=='&'
				inc	esi
				.while dword ptr[esi]==';pma'
					lea	esi,[esi+4]
				.endw
			.endw
			.if (edi!=offset tmphist)&&(byte ptr[edi-1]!='&')&&(byte ptr[edi-1]!='?')
				mov	al,'&'
				stosb
			.endif
			inc	ecx
		.else
			movsb
			inc	ecx
		.endif
	.endw
	.while (edi!=offset tmphist)&&((byte ptr[edi-1]=='&')||(byte ptr[edi-1]=='?')||(byte ptr[edi-1]=='/'))
		dec	edi
	.endw
	pop	edx
	mov	al,0
	stosb
	.while edx
		xor	ecx,ecx
		xor	eax,eax
		inc	eax
		.while (byte ptr[edx+ecx+4+17]!=0)&&(byte ptr tmphist[ecx]!=0)
			mov	al,[edx+ecx+4+17]
			mov	ah,tmphist[ecx]
			or	ax,2020h
			.break .if al!=ah
			inc	ecx
		.endw
		.if (al==ah)&&(byte ptr[edx+ecx+4+17]==0)&&(byte ptr tmphist[ecx]==0)
			mov	eax,edx
			pop	esi
			ret
		.endif
		mov	edx,[edx]
	.endw
	xor	eax,eax
	pop	esi
	ret


issaved:
	lea	edx,[ebx]._addr
is_saved:
	push	esi
	mov	esi,histattach
	xor	ecx,ecx
	.while (byte ptr[edx+ecx]!=0)&&(byte ptr[edx+ecx]!='#')
		inc	ecx
	.endw
	.while esi
		.if cx==[esi+4]
			push	ecx
			.while ecx
				mov	al,byte ptr[esi+8+ecx-1]
				mov	ah,[edx+ecx-1]
				or	ax,2020h
				.break .if al!=ah
				dec	ecx
			.endw
			pop	ecx
			.break .if al==ah
		.endif
		mov	esi,dword ptr[esi]
	.endw
	.if esi==0
		push	edi
		push	ebx
		push	edx
		push	ecx
		lea	ecx,[ecx+20]
		invoke	GlobalAlloc,GPTR,ecx
		lea	edx,histattach
		.while dword ptr[edx]
			mov	edx,[edx]
		.endw
		mov	[edx],eax
		mov	edi,eax
		xor	eax,eax
		stosd
		pop	ecx
		mov	ax,cx
		stosd
		pop	esi
		rep	movsb
		xor	eax,eax
		stosd
		pop	ebx
		pop	edi
	.else
		xor	eax,eax
		inc	eax
	.endif
	pop	esi
	ret

issaved1:
	push	esi
	lea	edx,[ebx]._addr
	mov	esi,histattach
	xor	ecx,ecx
	.while (byte ptr[edx+ecx]!=0)&&(byte ptr[edx+ecx]!='#')
		inc	ecx
	.endw
	.while esi
		.if cx==[esi+4]
			push	ecx
			.while ecx
				mov	al,byte ptr[esi+8+ecx-1]
				mov	ah,[edx+ecx-1]
				or	ax,2020h
				.break .if al!=ah
				dec	ecx
			.endw
			pop	ecx
			.break .if al==ah
		.endif
		mov	esi,[esi]
	.endw
	mov	eax,esi
	.if eax
		movzx	eax,word ptr[esi+4]
		lea	eax,[esi+8+eax+1]
	.endif
	pop	esi
	ret

is_saved2:
	push	esi
	mov	esi,histattach
	xor	ecx,ecx
	.while (byte ptr[edx+ecx]!=0)&&(byte ptr[edx+ecx]!='#')
		inc	ecx
	.endw
	inc	ecx
	.while esi
		.if byte ptr[esi+4+2]==3
			.if cx==[esi+4]
				push	ecx
				.while ecx>1
					mov	al,byte ptr[esi+8+ecx-2]
					mov	ah,[edx+ecx-2]
					or	ax,2020h
					.break .if al!=ah
					dec	ecx
				.endw
				pop	ecx
				.break .if al==ah
			.endif
		.endif
		mov	esi,dword ptr[esi]
	.endw
	.if esi==0
		push	edi
		push	ebx
		push	edx
		push	ecx
		lea	ecx,[ecx+20]
		invoke	GlobalAlloc,GPTR,ecx
		lea	edx,histattach
		.while dword ptr[edx]
			mov	edx,[edx]
		.endw
		mov	[edx],eax
		mov	edi,eax
		xor	eax,eax
		stosd
		pop	ecx
		dec	ecx
		mov	ax,cx
		inc	eax
		stosw
		mov	ax,3
		stosw
		pop	esi
		rep	movsb
		mov	al,255
		stosb
		xor	eax,eax
		stosd
		pop	ebx
		pop	edi
	.else
		xor	eax,eax
		inc	eax
	.endif
	pop	esi
	ret

hist_add0:
	push	edi
	push	esi
	push	ebx
	.if [ebx]._loc
		lea	edx,[ebx]._loc
	.else
		lea	edx,[ebx]._addr
	.endif
	xor	ecx,ecx
	.while byte ptr[edx+ecx]
		inc	ecx
	.endw
	push	edx
	push	ecx
	lea	ecx,[ecx+20]
	invoke	GlobalAlloc,GPTR,ecx
	lea	edx,histattach
	.while dword ptr[edx]
		mov	edx,[edx]
	.endw
	mov	[edx],eax
	mov	edi,eax
	xor	eax,eax
	stosd
	pop	ecx
	mov	ax,cx
	stosd
	pop	esi
	rep	movsb
	xor	eax,eax
	stosd
	pop	ebx
	pop	esi
	pop	edi
	ret

;returns edx
hist_topics:
	push	esi
	push	edi
	push	ebx
	mov	esi,edx
	mov	edx,savet
	call	scmp
	.if edx==0
		xor	ecx,ecx
		.while (byte ptr tmphist[ecx]!=0)
			inc	ecx
		.endw
		lea	ecx,[ecx+10+1+4+4+4+4]
		invoke	GlobalAlloc,GPTR,ecx
		lea	edx,savet
		.while dword ptr[edx]
			mov	edx,[edx]
		.endw
		mov	[edx],eax
		push	eax
		mov	edi,eax
		xor	eax,eax
		stosd
		mov	al,1
		stosb
		mov	al,0
		stosd
		stosd
		stosd
		stosd
		lea	edx,tmphist
		call	copyedx
		mov	al,0
		stosb
		pop	eax
		xor	edx,edx
	.elseif 0 ;(dword ptr[edx+4+1+4]!=0)&&(hIndex!=0)
		mov	eax,[edx+4+1+4+4]
		add	idxtotal1,eax
		mov	eax,[edx+4+1+4+4+4]
		add	idxtotal2,eax
		push	edx
		push	edx
		mov	edx,[edx+4+1]
		lea	ebx,defdir
		push	edx
		mov	ecx,ebx
		.while (byte ptr[ebx]!=0)&&(byte ptr[edx]!=0)
			mov	al,[ebx]
			mov	ah,[edx]
			or	ax,2020h
			.break .if al!=ah
			mov	al,[ebx]
			.if (al=='/')||(al=='\')
				mov	ecx,ebx
				mov	[esp],edx
			.endif
			inc	ebx
			inc	edx
		.endw
		pop	ebx
	;	.if (byte ptr[ecx]=='\')||(byte ptr[ecx]=='/')
	;		inc	ecx
	;	.endif
		pop	edx
		push	ebx
		push	ecx
		push	edx
		invoke	GlobalAlloc,GPTR,65536
		pop	edx
		push	eax
		mov	edx,[edx+4+1+4]
		.while	edx
			push	dword ptr[edx]
			lea	edx,[edx+4]
			xor	ecx,ecx
			mov	edi,[esp+4]
			.while byte ptr[edx+ecx]
				mov	al,[edx+ecx]
				stosb
				.if (al=='=')&&(byte ptr[edx+ecx+1]=='"')
					mov	al,'"'
					stosb
					inc	ecx
					mov	ebx,[esp+4+4]
					.while byte ptr[ebx]
						.if (byte ptr[ebx]=='\')||(byte ptr[ebx]=='/')
							mov	eax,'/..'
							stosd
							dec	edi
						.endif
						inc	ebx
					.endw
					mov	ebx,[esp+4+4+4]
					.while byte ptr[ebx]
						mov	al,[ebx]
						stosb
						inc	ebx
					.endw
				.endif
				inc	ecx
			.endw
			mov	ecx,edi
			mov	edi,[esp+4]
			sub	ecx,edi
			push	0
			mov	eax,esp
			invoke	WriteFile,hIndex,edi,ecx,eax,0
			pop	eax
			pop	edx
		.endw
		call	GlobalFree
		pop	ecx
		pop	eax
		pop	eax
		mov	edx,eax
	.endif
	pop	ebx
	pop	edi
	pop	esi
	ret

hist_forums:
	push	esi
	push	edi
	push	ebx
	mov	esi,edx
	mov	edx,histforum
	call	scmp
	.if edx==0
		xor	ecx,ecx
		.while (byte ptr tmphist[ecx]!=0)
			inc	ecx
		.endw
		lea	ecx,[ecx+10+1+4+4+4+4]
		invoke	GlobalAlloc,GPTR,ecx
		lea	edx,histforum
		.while dword ptr[edx]
			mov	edx,[edx]
		.endw
		push	eax
		mov	[edx],eax
		mov	edi,eax
		xor	eax,eax
		stosd
		stosb
		stosd		;file name
		stosd		;html
		stosd		;links
		stosd		;attachments
		lea	edx,tmphist
		call	copyedx
		mov	al,0
		stosb
		pop	eax
		xor	edx,edx
	.elseif 0 ;(dword ptr[edx+4+1+4]!=0)&&(hIndex!=0)
		mov	eax,[edx+4+1+4+4]
		add	idxtotal1,eax
		mov	eax,[edx+4+1+4+4+4]
		add	idxtotal2,eax
		push	edx
		push	edx
		mov	edx,[edx+4+1]
		lea	ebx,defdir
		push	edx
		mov	ecx,ebx
		.while (byte ptr[ebx]!=0)&&(byte ptr[edx]!=0)
			mov	al,[ebx]
			mov	ah,[edx]
			or	ax,2020h
			.break .if al!=ah
			mov	al,[ebx]
			.if (al=='/')||(al=='\')
				mov	ecx,ebx
				mov	[esp],edx
			.endif
			inc	ebx
			inc	edx
		.endw
		pop	ebx
	;	.if (byte ptr[ecx]=='\')||(byte ptr[ecx]=='/')
	;		inc	ecx
	;	.endif
		pop	edx
		push	ebx
		push	ecx
		push	edx
		invoke	GlobalAlloc,GPTR,65536
		pop	edx
		push	eax
		mov	edx,[edx+4+1+4]
		.while	edx
			push	dword ptr[edx]
			lea	edx,[edx+4]
			xor	ecx,ecx
			mov	edi,[esp+4]
			.while byte ptr[edx+ecx]
				mov	al,[edx+ecx]
				stosb
				.if (al=='=')&&(byte ptr[edx+ecx+1]=='"')
					mov	al,'"'
					stosb
					inc	ecx
					mov	ebx,[esp+4+4]
					.while byte ptr[ebx]
						.if (byte ptr[ebx]=='\')||(byte ptr[ebx]=='/')
							mov	eax,'/..'
							stosd
							dec	edi
						.endif
						inc	ebx
					.endw
					mov	ebx,[esp+4+4+4]
					.while byte ptr[ebx]
						mov	al,[ebx]
						stosb
						inc	ebx
					.endw
				.endif
				inc	ecx
			.endw
			mov	ecx,edi
			mov	edi,[esp+4]
			sub	ecx,edi
			push	0
			mov	eax,esp
			invoke	WriteFile,hIndex,edi,ecx,eax,0
			pop	eax
			pop	edx
		.endw
		call	GlobalFree
		pop	ecx
		pop	eax
		pop	eax
		mov	edx,eax
	.endif
	pop	ebx
	pop	edi
	pop	esi
	ret
assume	ebx:nothing
endm

check_hist	macro
	mov	ebx,lParam
	call	issaved
	.if eax
		invoke	GlobalFree,lParam
		invoke	GlobalFree,r_buf
		mov	edi,_edi
		xor	eax,eax
		ret
	.endif
endm

check_hist1	macro
	mov	ebx,lParam
	call	issaved1
	.if eax
		invoke	GlobalFree,lParam
		invoke	GlobalFree,r_buf
		mov	edi,_edi
		xor	eax,eax
		ret
	.endif
endm

add_hist	macro
	mov	ebx,lParam
	call	hist_add0
endm

;edx=_addr
istopicsaved	macro
	call	hist_topics
endm

isforumsaved	macro
	call	hist_forums
endm

isforumsaved1	macro
	call	hist_forums
endm

hist_addfile	macro
	mov	edi,lParam
	.if 0 ;[edi].histptr
		xor	ecx,ecx
		.while defdir[ecx]
			inc	ecx
		.endw
		lea	ecx,[ecx+10]
		invoke	GlobalAlloc,GPTR,ecx
		mov	edx,[edi].histptr
		mov	[edx+4+1],eax
		push	edi
		mov	edi,eax
		lea	edx,defdir
		call	copyedx
		mov	al,0
		stosb
		pop	edi
	.endif
endm

;ebx=foruminfo
hist_adddir	macro
	.if 0 ;[ebx].histptr
		xor	ecx,ecx
		.while htmltmp[ecx]
			inc	ecx
		.endw
		lea	ecx,[ecx+10]
		push	ebx
		invoke	GlobalAlloc,GPTR,ecx
		pop	ebx
		mov	edx,[ebx].histptr
		mov	[edx+4+1],eax
		push	edi
		mov	edi,eax
		lea	edx,htmltmp
		call	copyedx
		mov	al,0
		stosb
		pop	edi
	.endif
endm

hist_adddir1	macro
	.if 0 ;[ebx].histptr
		xor	ecx,ecx
		.while defdir[ecx]
			inc	ecx
		.endw
		lea	ecx,[ecx+10]
		push	ebx
		invoke	GlobalAlloc,GPTR,ecx
		pop	ebx
		mov	edx,[ebx].histptr
		mov	[edx+4+1],eax
		push	edi
		mov	edi,eax
		lea	edx,defdir
		call	copyedx
		mov	al,0
		stosb
		pop	edi
	.endif
endm

isalreadylinked	macro
	push	esi
	mov	edx,esi
	mov	esi,histattach
	xor	ecx,ecx
	.while ((byte ptr[edx+ecx]!=0)&&(byte ptr[edx+ecx]!='<')&&(byte ptr[edx+ecx]!='>')&&(byte ptr[edx+ecx]!=34)&&(byte ptr[edx+ecx]!=39)&&(byte ptr[edx+ecx]!='#'))
		inc	ecx
	.endw
	.while esi
		.if (cx==[esi+4])&&((byte ptr[esi+6]==1)||(byte ptr[esi+6]==2))
			push	ecx
			.while ecx
				mov	al,byte ptr[esi+8+ecx-1]
				mov	ah,[edx+ecx-1]
				or	ax,2020h
				.break .if al!=ah
				dec	ecx
			.endw
			pop	ecx
			.break .if (al==ah)||(cx==0)
		.endif
		mov	esi,[esi]
	.endw
	.if esi!=0
		.if (byte ptr[esi+4+2]==1)
			movzx	ecx,word ptr[esi+4]
			lea	esi,[esi+8+ecx+1]
			xor	ecx,ecx
			.while byte ptr defdir[ecx]
				mov	al,defdir[ecx]
				mov	ah,byte ptr[esi+ecx]
				or	ax,2020h
				.break .if al!=ah
				inc	ecx
			.endw
			.while (ecx!=0)&&(byte ptr [esi+ecx]!='\')
				dec	ecx
			.endw
			mov	edx,ecx
			xor	eax,eax
			.while byte ptr[esi+edx+1]
				.if byte ptr[esi+edx+1]=='\'
					inc	eax
				.endif
				inc	edx
			.endw
			mov	edx,eax
			.while edx
				mov	eax,'/..'
				stosd
				dec	edi
				dec	edx
			.endw
			.if byte ptr[esi+ecx]=='\'
				inc	ecx
			.endif
			.while byte ptr[esi+ecx]
				mov	al,[esi+ecx]
				.if al=='\'
					mov	al,'/'
				.endif
				stosb
				inc	ecx
			.endw
			pop	esi
			.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)
				inc	esi
			.endw
			.continue
		.elseif byte ptr[esi+4+2]==2
			pop	esi
			.break
		.endif
	.endif
	pop	esi
endm

addlinkwithpath	macro
	push	esi
	xor	ecx,ecx
	.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='>')&&(byte ptr[esi+ecx]!='<')&&(byte ptr[esi+ecx]!=34)&&(byte ptr[esi+ecx]!=39)&&(byte ptr[esi+ecx]!='#')
		inc	ecx
	.endw
	push	ecx
	inc	ecx
	inc	ecx
	lea	edx,defdir
	.while byte ptr[edx]
		inc	edx
		inc	ecx
	.endw
	mov	eax,edi
	sub	eax,dword ptr buftmp0
	inc	eax
	lea	ecx,[ecx+eax+20]
	invoke	GlobalAlloc,GPTR,ecx
	pop	ecx
	lea	edx,histattach
	.while dword ptr[edx]
		mov	edx,[edx]
	.endw
	mov	[edx],eax
	push	edi
	mov	edi,eax
	xor	eax,eax
	stosd
	mov	ax,cx
	stosw
	mov	ax,1
	stosw
	push	esi
	rep	movsb
	pop	esi
	mov	al,0
	stosb
	lea	edx,defdir
	mov	ecx,edi
	.while byte ptr[edx]!=0
		mov	al,[edx]
		.if al=='\'
			mov	ecx,edi
		.endif
		stosb
		inc	edx
	.endw
	mov	edi,ecx
	.if edx!=offset defdir
		mov	al,'\'
		stosb
	.endif
	mov	edx,dword ptr buftmp0
	dec	edx
	.if byte ptr[edx]=='<'
		.while (byte ptr[edx]!=34)&&(byte ptr[edx]!=39)&&(byte ptr[edx]!=0)
			inc	edx
		.endw
		.if byte ptr[edx]
			inc	edx
		.endif
	.endif
	.while (edx<dword ptr[esp])&&(byte ptr[edx]!=34)&&(byte ptr[edx]!=39)
		mov	al,[edx]
		stosb
		inc	edx
	.endw
	mov	al,0
	stosb
	pop	edi
	pop	esi
endm

addlinkwithoutpath	macro
	xor	ecx,ecx
	.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='>')&&(byte ptr[esi+ecx]!='<')&&(byte ptr[esi+ecx]!=34)&&(byte ptr[esi+ecx]!=39)&&(byte ptr[esi+ecx]!='#')
		inc	ecx
	.endw
	push	ecx
	lea	ecx,[ecx+20]
	invoke	GlobalAlloc,GPTR,ecx
	pop	ecx
	lea	edx,histattach
	.while dword ptr[edx]
		mov	edx,[edx]
	.endw
	mov	[edx],eax
	push	edi
	mov	edi,eax
	xor	eax,eax
	stosd
	mov	ax,cx
	stosw
	mov	ax,2
	stosw
	push	esi
	rep	movsb
	pop	esi
	mov	al,0
	stosb
	pop	edi
endm

gethistptr	macro
	call	issaved1
	mov	edx,eax
endm

addlocation	macro
	push	esi
	mov	ebx,lParam
	.if [ebx]._loc
		lea	edx,[ebx]._loc
	.else
		lea	edx,[ebx]._addr
	.endif
	xor	ecx,ecx
	.while byte ptr[edx+ecx]
		inc	ecx
	.endw
	push	edx
	push	ecx
	inc	ecx
	lea	edx,[ebx]._save
	push	edx
	.while byte ptr[edx]
		inc	edx
		inc	ecx
	.endw
	lea	ecx,[ecx+20]
	invoke	GlobalAlloc,GPTR,ecx
	lea	edx,histattach
	.while dword ptr[edx]
		mov	edx,[edx]
	.endw
	mov	[edx],eax
	mov	edi,eax
	xor	eax,eax
	stosd
	pop	edx
	pop	ecx
	mov	ax,cx
	stosd
	pop	esi
	rep	movsb
	mov	al,0
	stosb
	call	copyedx
	mov	al,0
	stosb
	pop	esi
endm
