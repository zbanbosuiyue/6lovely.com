saveline	macro
	.if _nline
		.while (byte ptr[edi-1]==32)||(byte ptr[edi-1]==9)
			dec	edi
		.endw
		.if (word ptr[edi-2]!=0a0dh)
			mov	ax,0a0dh
			stosw
		.endif
		mov	_nline,0
		mov	edx,_indent
		.while edx
			mov	al,9
			stosb
			dec	edx
		.endw
	.endif
endm

css_spaces	macro
	.while 1
		.if (byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)
			movsb
		.elseif word ptr[esi]=='//'
			movsw
			.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=13)&&(byte ptr[esi]!=10)
				movsb
			.endw
		.elseif word ptr[esi]=='*/'
			.while (byte ptr[esi]!=0)&&(word ptr[esi]!='/*')
				movsb
			.endw
			.if word ptr[esi]=='/*'
				movsw
			.endif
		.else
			.break
		.endif
	.endw
endm

save_data	macro
	savetype1	db	'Original thread pages, no changes',0
	savetype2	db	'Original thread pages, local images, no javascript',0
	savetype3	db	'HTML tables, each containing all pages of a thread',0
	savetype4	db	'Text files, each containing all pages of a thread',0
	include	webtbl.h
	save_fn
savechr:.if savetype==2
		movsb
	.elseif savetype<2
		inc	esi
	.elseif savetype==3
		saveline
			.if byte ptr[esi]=='&'
				inc	esi
				.if byte ptr[esi]=='#'
					push	esi
					inc	esi
					call	atoi
					.if byte ptr[esi]==';'
						.if eax<80h
							stosb
						.elseif eax<800h
							shl	ax,2
							shr	al,2
							or	ax,1100000010000000b
							xchg	al,ah
							stosw
						.elseif eax<10000h
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+2],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	ax,0e080h
							xchg	al,ah
							stosw
							inc	edi
						.elseif eax<200000h
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+3],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+2],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	ax,0f080h
							xchg	al,ah
							stosw
							inc	edi
							inc	edi
						.elseif eax<4000000h
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+4],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+3],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+2],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	ax,0f880h
							xchg	al,ah
							stosw
							add	edi,3
						.else
							push	eax
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+5],al
							pop	eax
							shr	eax,6
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+4],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+3],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+2],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	ax,0f880h
							xchg	al,ah
							stosw
							add	edi,4
						.endif
						inc	esi
						pop	eax
					.else
						pop	esi
						mov	al,'&'
						stosb
					.endif
				.else
					lea	edx,webtbl
					.while byte ptr[edx]
						push	edx
						.while byte ptr[edx]
							inc	edx
						.endw
						inc	edx
						xor	ecx,ecx
						.while byte ptr[edx+ecx]
							mov	al,[edx+ecx]
							.break .if al!=byte ptr[esi+ecx]
							inc	ecx
						.endw
						.if (byte ptr[edx+ecx])||(byte ptr[esi+ecx]!=';')
							lea	edx,[edx+ecx]
							.while byte ptr[edx]
								inc	edx
							.endw
							inc	edx
							inc	edx
							pop	eax
						.else
							lea	esi,[esi+ecx+1]
							pop	edx
							call	copyedx
							.break
						.endif
					.endw
					.if dword ptr[edx]==0
						mov	al,'&'
						stosb
					.endif
				.endif
			.elseif (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
					inc	esi
				.endw
				mov	al,32
				stosb
			.else
				movsb
			.endif
	.endif
	ret
savechar:.if savetype==2
		stosb
	.elseif savetype==3
		push	eax
		saveline
		pop	eax
		stosb
	.endif
	ret

;ebx=foruminfo
;edi=href
assume	ebx:ptr foruminfo
make_fname:
	push	edi
	lea	edi,[ebx]._save
	lea	edx,defdir
	mov	ecx,edi
	.while byte ptr[edx]!=0
		mov	al,[edx]
		.if al=='\'
			mov	ecx,edi
		.endif
		stosb
		inc	edx
	.endw
	mov	edi,ecx
	mov	al,'\'
	stosb
	mov	eax,diridx
	push	ebx
	call	w5
	pop	ebx
	mov	al,32
	stosb
	lea	edx,[ebx]._addr
	mov	ecx,edx
	.while byte ptr[edx]
		.if (byte ptr[edx]=='/')&&(byte ptr[edx+1]!=0)
			lea	ecx,[edx+1]
		.endif
		inc	edx
	.endw
	mov	esi,ecx
	.if byte ptr[ebx]._file
		lea	esi,[ebx]._file
	.endif
	mov	ecx,maxfile
	push	ebx
	call	escfile1
	pop	ebx
	mov	al,0
	stosb
	xor	eax,eax
	pop	edi
	mov	eax,diridx
	lea	edx,[ebx]._save
	mov	ecx,edx
	.while byte ptr[edx]
		.if byte ptr[edx]=='\'
			lea	ecx,[edx+1]
		.endif
		inc	edx
	.endw
	mov	edx,ecx
	call	copyedx
	lea	edx,[ebx]._save
	push	esi
	push	edi
	mov	edi,edx
	mov	esi,edx
	.while byte ptr[esi]
		.if byte ptr[esi]=='%'
			.if word ptr[esi+1]=='02'
				lea	esi,[esi+3]
				mov	al,32
				stosb
			.elseif word ptr[esi+1]=='52'
				lea	esi,[esi+3]
				mov	al,'%'
				stosb
			.elseif word ptr[esi+1]=='32'
				lea	esi,[esi+3]
				mov	al,'#'
				stosb
			.elseif word ptr[esi+1]=='42'
				lea	esi,[esi+3]
				mov	al,'$'
				stosb
			.elseif word ptr[esi+1]=='12'
				lea	esi,[esi+3]
				mov	al,'!'
				stosb
			.elseif (word ptr[esi+1]=='e5')||(word ptr[esi+1]=='E5')
				lea	esi,[esi+3]
				mov	al,'^'
				stosb
			.else
				movsb
			.endif
		.else
			movsb
		.endif
	.endw
	movsb
	pop	edi
	pop	esi
	call	u_fn
	ret
endm

save_init	macro
	invoke	SendDlgItemMessage,hDlg,6300,CB_ADDSTRING,0,addr savetype1
	invoke	SendDlgItemMessage,hDlg,6300,CB_SETITEMDATA,eax,0
	invoke	SendDlgItemMessage,hDlg,6300,CB_ADDSTRING,0,addr savetype2
	invoke	SendDlgItemMessage,hDlg,6300,CB_SETITEMDATA,eax,1
	invoke	SendDlgItemMessage,hDlg,6300,CB_ADDSTRING,0,addr savetype3
	invoke	SendDlgItemMessage,hDlg,6300,CB_SETITEMDATA,eax,2
	invoke	SendDlgItemMessage,hDlg,6300,CB_ADDSTRING,0,addr savetype4
	invoke	SendDlgItemMessage,hDlg,6300,CB_SETITEMDATA,eax,3
	movzx	eax,savetype
	invoke	SendDlgItemMessage,hDlg,6300,CB_SETCURSEL,eax,0
endm

save_dlg	macro
	.elseif (ax==6300)&&(bx==CBN_SELCHANGE)
		invoke	SendDlgItemMessage,hDlg,6300,CB_GETCURSEL,0,0
		.if eax!=CB_ERR
			invoke	SendDlgItemMessage,hDlg,6300,CB_GETITEMDATA,eax,0
			.if eax!=CB_ERR
				mov	savetype,al
			.endif
		.endif
endm

save_page	macro
	.if savetype<2
		push	edi
		lea	edi,defdir
		mov	edx,edi
		mov	ecx,edi
		.while byte ptr[edi]
			.if (byte ptr[edi]=='.')
				mov	ecx,edx
				mov	edx,edi
			.elseif (byte ptr[edi]=='/')||(byte ptr[edi]=='\')
				mov	ecx,edi
				mov	edx,edi
			.endif
			inc	edi
		.endw
		.if (spage==1)||(byte ptr[ecx]!='.')
			mov	edi,edx
		.else
			mov	edi,ecx
		.endif
		inc	edi
		mov	eax,spage
		.if eax>999
			call	itoa
		.else
			call	w3
		.endif
		mov	eax,'mth.'
		stosd
		mov	ax,'l'
		stosw
		pop	edi
	.elseif savetype==3
		push	edi
		lea	edi,defdir
		mov	edx,edi
		mov	ecx,edi
		.while byte ptr[edi]
			.if (byte ptr[edi]=='.')
				mov	edx,edi
				.if byte ptr[ecx]!='.'
					mov	ecx,edi
				.endif
			.elseif (byte ptr[edi]=='/')||(byte ptr[edi]=='\')
				mov	ecx,edi
				mov	edx,edi
			.endif
			inc	edi
		.endw
		mov	edi,edx
		.if byte ptr[edi]=='.'
			inc	edi
		.endif
		mov	eax,'txt'
		stosd
		pop	edi
	.endif
endm

save_fmt	macro
	.if savetype==2
		.while (byte ptr[esi]!='<')&&(byte ptr[esi]!=0)
			movsb
		.endw
	.elseif savetype==3
		saveline
		.while (byte ptr[esi]!='<')&&(byte ptr[esi]!=0)
			.if byte ptr[esi]=='&'
				inc	esi
				.if byte ptr[esi]=='#'
					push	esi
					inc	esi
					call	atoi
					.if byte ptr[esi]==';'
						.if eax<80h
							stosb
						.elseif eax<800h
							shl	ax,2
							shr	al,2
							or	ax,1100000010000000b
							xchg	al,ah
							stosw
						.elseif eax<10000h
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+2],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	ax,0e080h
							xchg	al,ah
							stosw
							inc	edi
						.elseif eax<200000h
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+3],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+2],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	ax,0f080h
							xchg	al,ah
							stosw
							inc	edi
							inc	edi
						.elseif eax<4000000h
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+4],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+3],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+2],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	ax,0f880h
							xchg	al,ah
							stosw
							add	edi,3
						.else
							push	eax
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+5],al
							pop	eax
							shr	eax,6
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+4],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+3],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	al,80h
							mov	[edi+2],al
							shr	eax,8
							shl	eax,2
							shr	al,2
							or	ax,0f880h
							xchg	al,ah
							stosw
							add	edi,4
						.endif
						inc	esi
						pop	eax
					.else
						pop	esi
						mov	al,'&'
						stosb
					.endif
				.else
					lea	edx,webtbl
					.while byte ptr[edx]
						push	edx
						.while byte ptr[edx]
							inc	edx
						.endw
						inc	edx
						xor	ecx,ecx
						.while byte ptr[edx+ecx]
							mov	al,[edx+ecx]
							.break .if al!=byte ptr[esi+ecx]
							inc	ecx
						.endw
						.if (byte ptr[edx+ecx])||(byte ptr[esi+ecx]!=';')
							lea	edx,[edx+ecx]
							.while byte ptr[edx]
								inc	edx
							.endw
							inc	edx
							inc	edx
							pop	eax
						.else
							lea	esi,[esi+ecx+1]
							pop	edx
							call	copyedx
							.break
						.endif
					.endw
					.if dword ptr[edx]==0
						mov	al,'&'
						stosb
					.endif
				.endif
			.elseif (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
					inc	esi
				.endw
				mov	al,32
				stosb
			.else
				movsb
			.endif
		.endw
	.endif
endm



save_href	macro
	mov	dword ptr buftmp0,edi
	.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
		mov	eax,[esi]
		or	eax,20202020h
		.if (eax=='erh ')&&((byte ptr[esi+4]=='f')||(byte ptr[esi+4]=='F'))
			movsd
			movsb
			.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]=='=')||(byte ptr[esi]==34)||(byte ptr[esi]==39)
				movsb
			.endw
			mov	eax,[esi]
			or	eax,20202020h
			.if (eax=='avaj')
				mov	eax,[esi+4]
				or	eax,20202020h
				.if eax=='ircs'
					mov	al,'#'
					stosb
					.while (byte ptr[esi-1]!='f')&&(byte ptr[esi-1]!='F')
						.break .if (byte ptr[esi-1]==34)||(byte ptr[esi-1]==39)
						dec	esi
					.endw
					.if byte ptr[esi-1]==39
						.while (byte ptr[esi]!=39)&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
							inc	esi
						.endw
					.elseif byte ptr[esi-1]==34
						.while (byte ptr[esi]!=34)&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
							inc	esi
						.endw
					.else
						.while (byte ptr[esi]!=39)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
							inc	esi
						.endw
					.endif
					.break
				.endif
			.else	;if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+6]=='/')
				isalreadylinked
		;		call	isbanneddns
		;		.if eax==0
				mov	eax,[esi+7]
				or	eax,20202020h
				push	edi
				mov	edi,dword ptr buftmp0
				dec	edi
				call	is_img
				pop	edx
				.if eax
					addlinkwithpath
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
					.break
				.else
					mov	edi,edx
					xor	ecx,ecx
					.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='>')
						inc	ecx
					.endw
					.if byte ptr[esi+ecx]=='>'
						inc	ecx
						.while 1
							.break .if byte ptr[esi+ecx]==0
							.break .if byte ptr[esi+ecx]=='<'
							.if (byte ptr[esi+ecx]==32)||(byte ptr[esi+ecx]==9)||(byte ptr[esi+ecx]==13)||(byte ptr[esi+ecx]==10)
								inc	ecx
							.elseif byte ptr[esi+ecx]=='&'
								inc	ecx
								mov	eax,[esi+ecx]
								or	eax,20202020h
								.if (eax=='psbn')&&(byte ptr[esi+ecx+4]==';')
									lea	ecx,[ecx+10]
								.endif
							.else
								.break
							.endif
						.endw
						.if byte ptr[esi+ecx]=='<'
							mov	eax,[esi+ecx+1]
							or	eax,20202020h
							.if eax==' gmi'
							;	call	isbanneddns
							;	.if eax==0
									addlinkwithoutpath
							;	.endif
							.endif
						.endif
					.endif
		;		.endif
				.endif
			.endif
			call	is_internal
			.break .if eax==0
			xor	ecx,ecx
			xor	eax,eax
			push	esi
			push	edi
			.while (byte ptr[esi+ecx]!=39)&&(byte ptr[esi+ecx]!=34)&&(byte ptr[esi+ecx]>32)&&(byte ptr[esi+ecx]!='<')
				mov	eax,[esi+ecx]
				or	eax,20202020h
				mov	dx,[esi+ecx+4]
				or	dx,2020h
				.if ((eax=='atta')&&(dx=='hc'))||((eax=='elif')&&(dx=='/s'))||(eax=='nwod')
					invoke	get_att,2
					.break
				.endif
				inc	ecx
			.endw
			pop	edx
			pop	esi
			.if (edi!=edx)
				.if edi!=edx
					.while (byte ptr[esi]!=39)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
						inc	esi
					.endw
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					movsb
				.endw
				.if byte ptr[esi]=='>'
					movsb
				.endif
			.else
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					movsb
				.endw
				.if byte ptr[esi]=='>'
					movsb
				.endif
			.endif
			xor	ecx,ecx
			.break
		.else
			movsb
		.endif
	.endw
endm


save_fn	macro
save_img:
	mov	dword ptr buftmp0,edi
	.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
		mov	eax,[esi]
		or	eax,20202020h
		.if (eax=='crs ')
_s_href:		movsd
			.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]=='=')||(byte ptr[esi]==34)||(byte ptr[esi]==39)
				movsb
			.endw
sv_img:			push	esi
			push	edi
			invoke	save_lnk,0
			pop	edx
			pop	esi
			.if (edi!=edx)||(pflag&64)
				.if edi!=edx
					.while (byte ptr[esi]!=39)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
						inc	esi
					.endw
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					movsb
				.endw
				.if byte ptr[esi]=='>'
					movsb
				.endif
			.else
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
				mov	edi,dword ptr buftmp0
				dec	edi
			.endif
			.break
		.elseif (eax=='erh ')&&((byte ptr[esi+4]=='f')||(byte ptr[esi+4]=='F'))
			movsb
			jmp	_s_href
		.else
			movsb
		.endif
	.endw
	ret

save_css:
	mov	dword ptr buftmp0,edi
	.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
		mov	eax,[esi]
		or	eax,20202020h
		.if (eax=='crs ')
_css_href:		movsd
			.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]=='=')||(byte ptr[esi]==34)||(byte ptr[esi]==39)
				movsb
			.endw
sv_css:			push	esi
			push	edi
			invoke	save_lnk,1
			pop	edx
			pop	esi
			.if (edi!=edx)||(pflag&64)
				.if edi!=edx
					.while (byte ptr[esi]!=39)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
						inc	esi
					.endw
				.endif
			.else
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
				mov	edi,dword ptr buftmp0
				dec	edi
			.endif
			.break
		.elseif (eax=='erh ')&&((byte ptr[esi+4]=='f')||(byte ptr[esi+4]=='F'))
			movsb
			jmp	_css_href
		.else
			movsb
		.endif
	.endw
	ret

save_css1:
	mov	dword ptr buftmp0,edi
	.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
		mov	eax,[esi]
		or	eax,20202020h
		.if (eax=='crs ')
_css_href1:		movsd
			.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]=='=')||(byte ptr[esi]==34)||(byte ptr[esi]==39)
				movsb
			.endw
sv_css1:		push	esi
			push	edi
			invoke	save_lnk,2
			pop	edx
			pop	esi
			.if (edi!=edx)||(pflag&64)
				.if edi!=edx
					.while (byte ptr[esi]!=39)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
						inc	esi
					.endw
				.endif
			.else
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
				mov	edi,dword ptr buftmp0
				dec	edi
			.endif
			.break
sv_css2:		push	esi
			push	edi
			invoke	save_lnk,3
			pop	edx
			pop	esi
			.if (edi!=edx)||(pflag&64)
				.if edi!=edx
					.while (byte ptr[esi]!=39)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
						inc	esi
					.endw
				.endif
			.else
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
				mov	edi,dword ptr buftmp0
				dec	edi
			.endif
			.break
		.elseif (eax=='erh ')&&((byte ptr[esi+4]=='f')||(byte ptr[esi+4]=='F'))
			movsb
			jmp	_css_href1
		.else
			movsb
		.endif
	.endw
	ret

save_lnk	PROC uses esi ebx isCss:DWORD
	local	lParam:DWORD,r_buf:DWORD,_edi:DWORD
	mov	_edi,edi
	invoke	GlobalAlloc,GPTR,sizeof foruminfo
	mov	lParam,eax
	invoke	GlobalAlloc,GPTR,8192
	mov	r_buf,eax
	mov	ebx,lParam
	assume	ebx:ptr foruminfo
	lea	edi,[ebx]._addr
	mov	eax,[esi]
	or	eax,20202020h
	.if eax!='ptth'
		.if byte ptr[esi]=='/'
			push	ebx
			mov	ebx,f_info
			lea	edx,[ebx]._addr
			mov	eax,[edx]
			or	eax,20202020h
			.if eax=='ptth'
				stosd
				lea	edx,[edx+4]
				.if byte ptr[edx]==':'
					mov	al,[edx]
					stosb
					inc	edx
				.endif
				.if byte ptr[edx]=='/'
					mov	al,[edx]
					stosb
					inc	edx
				.endif
				.if byte ptr[edx]=='/'
					mov	al,[edx]
					stosb
					inc	edx
				.endif
			.endif
			.while byte ptr[edx]
				mov	al,[edx]
				.break .if al=='/'
				stosb
				inc	edx
			.endw
			pop	ebx
		.else
			push	ebx
			.if isCss>1
				mov	edx,lastcss
			.else
				mov	ebx,f_info
				lea	edx,[ebx]._addr
			.endif
			mov	eax,[edx]
			or	eax,20202020h
			.if (eax=='ptth')&&(byte ptr[edx+4]==':')
				mov	eax,[edx]
				stosd
				lea	edx,[edx+4]
				.while (byte ptr[edx]==':')||(byte ptr[edx]=='/')
					mov	al,[edx]
					stosb
					inc	edx
				.endw
			.endif
			push	edi
			mov	ecx,edi
			.while byte ptr[edx]
				mov	al,[edx]
				.if al=='/'
					mov	ecx,edi
				.endif
				stosb
				inc	edx
			.endw
			pop	eax
			.if ecx==eax
				.if byte ptr[edi]!='/'
					mov	al,'/'
					stosb
				.endif
			.else
				mov	edi,ecx
				mov	al,'/'
				stosb
			.endif
			pop	ebx
		.endif
	.endif
	.if word ptr[esi]=='/.'
		lodsw
	.endif
	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
		lodsb
		.if al=='&'
			mov	eax,[esi]
			or	eax,202020h
			.if eax==';pma'
				lodsd
			.endif
			mov	al,'&'
		.else
			mov	eax,[esi-1]
			or	eax,20202020h
			.if eax=='=dis'
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
					inc	esi
				.endw
				.continue
			.elseif eax=='sphp'
				mov	eax,[esi+3]
				or	eax,20202020h
				.if eax=='isse'
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
						inc	esi
					.endw
					.continue
				.endif
			.elseif ax=='=s'
				mov	eax,2
				.while ((byte ptr[esi+eax]>='0')&&(byte ptr[esi+eax]<='9'))||((byte ptr[esi+eax]>='a')&&(byte ptr[esi+eax]<='f'))||((byte ptr[esi+eax]>='A')&&(byte ptr[esi+eax]<='F'))
					inc	eax
				.endw
				.if eax>8
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
						inc	esi
					.endw
					.continue
				.endif
			.endif
			mov	al,[esi-1]
		.endif
		stosb
	.endw
	.if byte ptr[edi-1]=='&'
		dec	edi
	.endif
	mov	al,0
	stosb

	gethistptr
	.if edx
		push	esi
		mov	esi,edx
		mov	edi,_edi
		xor	ecx,ecx
		.while byte ptr defdir[ecx]
			mov	al,defdir[ecx]
			mov	ah,byte ptr[esi+ecx]
			or	ax,2020h
			.break .if al!=ah
			inc	ecx
		.endw
		.if isCss<2
			push	ecx
			mov	ecx,dirs
			.while ecx
				mov	ax,'..'
				stosw
				mov	al,'/'
				stosb
				dec	ecx
			.endw
			.if dirs
				dec	edi
			.endif
			pop	ecx
			.while (ecx!=0)&&(byte ptr [esi+ecx]!='\')
				dec	ecx
			.endw
			.if byte ptr[esi+ecx]!='\'
				mov	al,'/'
				stosb
			.endif
		.else
			.while (ecx!=0)&&(byte ptr [esi+ecx]!='\')
				dec	ecx
			.endw
			.if byte ptr[esi+ecx]=='\'
				inc	esi
			.endif
		.endif
		.while byte ptr[esi+ecx]
			mov	al,[esi+ecx]
			.if al=='\'
				mov	al,'/'
			.endif
			stosb
			inc	ecx
		.endw
		pop	esi
		invoke	GlobalFree,lParam
		invoke	GlobalFree,r_buf
		ret
	.endif

	invoke	GlobalAlloc,GPTR,8192
	push	eax
	push	esi
	lea	esi,defdir
	mov	edi,eax
	.while byte ptr[esi]
		movsb
	.endw
	movsb
	lea	edi,defdir
	lea	edx,defimg
	call	copyedx
	invoke	CreateDirectory,addr defimg,0
	mov	ax,'\'
	stosw
	pop	esi
	mov	edi,_edi
	.if isCss<2
		mov	ecx,dirs
		.while ecx
			mov	ax,'..'
			stosw
			mov	al,'/'
			stosb
			dec	ecx
		.endw
		mov	eax,'/gmI'
		stosd
	.endif
	mov	ebx,edi
	mov	edi,lParam
	mov	[edi]._loc,0
	invoke	get_afile,addr r_buf,ebx,2,0,8190
	.if (isCss==1)||(isCss==2)
		mov	edx,lParam
		assume	edx:ptr foruminfo
		lea	eax,[edx]._addr
		push	lastcss
		mov	lastcss,eax
		invoke	CreateFile,addr [edx]._save,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0
		assume	edx:nothing
		.if eax!=INVALID_HANDLE_VALUE
			push	fsize
			push	esi
			push	edi
			push	eax
			invoke	GetFileSize,eax,0
			mov	bread,eax
			lea	ecx,[eax+1024]
			invoke	GlobalAlloc,GPTR,ecx
			mov	edi,eax
			mov	eax,[esp]
			invoke	ReadFile,eax,edi,bread,addr bread,0
			mov	eax,bread
			.if eax<7fffffffh
				mov	byte ptr[edi+eax],0
			.endif
			call	CloseHandle
			mov	esi,edi
			call	parse_css
			mov	esi,edi
			mov	edi,lParam
			invoke	CreateFile,addr [edi]._save,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0
			push	eax
			invoke	WriteFile,eax,esi,bread,addr bread,0
			call	CloseHandle
			invoke	GlobalFree,esi
			pop	edi
			pop	esi
			pop	fsize
		.endif
		pop	lastcss
	.endif

	mov	edx,[esp]
	push	edi
	lea	edi,defdir
	call	copyedx
	mov	al,0
	stosb
	.if fsize
		addlocation
	.else
		mov	edi,_edi
		mov	[esp],edi
	.endif
	pop	edi

	call	GlobalFree
	mov	hfile,0
	invoke	GlobalFree,lParam
	invoke	GlobalFree,r_buf
	ret
save_lnk	ENDP

is_internal:
	mov	edx,f_info
	assume	edx:ptr foruminfo
	lea	edx,[edx]._addr
	assume	edx:nothing

	mov	eax,[esi]
	or	eax,20202020h
	.if eax=='ptth'
		xor	eax,eax
		mov	al,4
		.while 1
			.if (byte ptr[esi+eax]==':')||(byte ptr[esi+eax]=='/')
				inc	eax
			.elseif (dword ptr[esi+eax]=='85#&')
				lea	eax,[eax+4]
				.if byte ptr[esi+eax]==';'
					inc	eax
				.endif
			.else
				.break
			.endif
		.endw
	.else
		xor	eax,eax
		inc	eax
		ret
	.endif
	push	esi
	lea	esi,[esi+eax]
	mov	eax,[esi]
	or	eax,202020h
	.if eax=='.www'
		lodsd
	.endif
	mov	eax,[edx]
	or	eax,20202020h
	.if eax=='ptth'
		lea	edx,[edx+4]
		.while (byte ptr[edx]==':')||(byte ptr[edx]=='/')
			inc	edx
		.endw
		mov	eax,[edx]
		or	eax,202020h
		.if eax=='.www'
			lea	edx,[edx+4]
		.endif
	.endif
	xor	ecx,ecx
	.while (byte ptr[edx+ecx]!=0)&&(byte ptr[edx+ecx]!='/')
		mov	al,[edx+ecx]
		mov	ah,[esi+ecx]
		or	ax,2020h
		.break .if al!=ah
		inc	ecx
	.endw
	pop	esi
	xor	eax,eax
	.if (byte ptr[edx+ecx]=='/')||(byte ptr[edx+ecx]==0)
		inc	eax
	.endif
	ret

rm_script:
	mov	edi,esi
	push	eax
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			push	esi
			inc	esi
			mov	eax,[esi]
			or	eax,20202020h
			.if eax==dword ptr[esp+4]
				mov	dl,0
				.while byte ptr[esi]
					.if word ptr[esi]=='/<'
						inc	esi
						inc	esi
						mov	eax,[esi]
						or	eax,20202020h
						.if eax==dword ptr[esp+4]
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								inc	esi
							.endw
							.if byte ptr[esi]=='>'
								inc	esi
							.endif
							mov	[esp],esi
							mov	dl,1
							.break
						.endif
					.elseif byte ptr[esi]=='<'
						inc	esi
						mov	eax,[esi]
						or	eax,20202020h
						.if eax==dword ptr[esp+4]
							dec	esi
							push	esi
							mov	esi,[esp+4]
							.while esi<[esp]
								movsb
							.endw
							mov	dl,1
							pop	esi
							pop	eax
							push	esi
							inc	esi
						.endif
					.else
						inc	esi
					.endif
				.endw
				pop	esi
				.if dl==0
					movsb
				.endif
			.else
				pop	esi
				movsb
			.endif
		.else
			movsb
		.endif
	.endw
	pop	eax
	mov	eax,edi
	movsb
	ret

prel_file	PROC
	local	r_buf:DWORD
	mov	r_buf,esi
	mov	edi,esi
	xor	ecx,ecx
	.while ecx<fsize
		.if byte ptr[esi+ecx]==0
			mov	byte ptr[esi+ecx],32
		.endif
		inc	ecx
	.endw
	mov	byte ptr[esi+ecx],0

	mov	eax,'ircs'
	call	rm_script
	sub	eax,r_buf
	mov	fsize,eax

	mov	eax,'arfi'
	mov	esi,r_buf
	call	rm_script
	sub	eax,r_buf
	mov	fsize,eax

	mov	eax,'lppa'
	mov	esi,r_buf
	call	rm_script
	sub	eax,r_buf
	mov	fsize,eax

	mov	eax,'ejbo'
	mov	esi,r_buf
	call	rm_script
	sub	eax,r_buf
	mov	fsize,eax

	mov	esi,r_buf
	mov	edi,esi
	.while byte ptr[esi]
		.if (dword ptr[esi]=='--!<')
			.while (byte ptr[esi]!=0)&&((word ptr[esi]!='--')||(byte ptr[esi+2]!='>'))
				movsb
			.endw
		.elseif byte ptr[esi]=='<'
			push	esi
			inc	esi
			mov	eax,[esi]
			or	eax,20202020h
			.if (eax=='ircs')||(eax=='arfi')||(eax=='cson')||(eax=='lppa')||(eax=='ejbo')||(eax=='son/')||(eax=='esab')||(eax=='lmth')	;||(eax=='knil')
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
				pop	eax
			.else
				pop	esi
				.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
					.if (byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)
						.while (byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)
							inc	esi
						.endw
						mov	ax,[esi]
						or	ax,2020h
						.if ax=='no'
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								.if byte ptr[esi]==34
									inc	esi
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!='>')
										inc	esi
									.endw
									.if byte ptr[esi]==34
										inc	esi
									.endif
									.break
								.elseif byte ptr[esi]==39
									inc	esi
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!='>')
										inc	esi
									.endw
									.if byte ptr[esi]==39
										inc	esi
									.endif
									.break
								.else
									inc	esi
								.endif
							.endw
						.else
							mov	al,32
							stosb
						.endif
					.else
						movsb
					.endif
				.endw
				.if byte ptr[esi]=='>'
					movsb
				.endif
			.endif
		.else
			movsb
		.endif
	.endw
	mov	eax,edi
	movsb
	sub	eax,r_buf
	mov	fsize,eax
	.if (pflag&32)||(pflag&16)
		lea	eax,[eax*2+10240]
		invoke	GlobalAlloc,GPTR,eax
		push	eax
		mov	edi,eax
		mov	esi,r_buf
		.while byte ptr[esi]
			.if byte ptr[esi]=='<'
				movsb
				mov	eax,[esi]
				or	eax,20202020h
				.if ((eax==' gmi')||(eax=='upni'))&&(pflag&32)
					call	save_img
				.elseif (ax==' a')&&(pflag&16)
					save_href
				.elseif (eax=='knil')
					.if (pflag&32)
						xor	ecx,ecx
						.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='>')
							mov	eax,[esi+ecx]
							mov	edx,[esi+ecx+4]
							or	eax,20202020h
							or	edx,20202020h
							.if ((eax=='lyts')&&(edx=='ehse'))||((eax=='txet')&&(edx=='ssc/'))
								mov	dword ptr buftmp0,edi
								.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
									mov	eax,[esi]
									or	eax,20202020h
									.if (eax=='crs ')
										movsd
										.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]=='=')||(byte ptr[esi]==34)||(byte ptr[esi]==39)
											movsb
										.endw
										call	sv_css
									.elseif (eax=='erh ')&&((byte ptr[esi+4]=='f')||(byte ptr[esi+4]=='F'))
										movsd
										movsb
										.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]=='=')||(byte ptr[esi]==34)||(byte ptr[esi]==39)
											movsb
										.endw
										call	sv_css
									.else
										movsb
									.endif
								.endw
								mov	al,1
								.break
							.endif
							inc	ecx
							mov	al,0
						.endw
					.else
						xor	eax,eax
					.endif
					.if al==0
						dec	edi
						.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
							inc	esi
						.endw
						.if byte ptr[esi]=='>'
							inc	esi
						.endif
					.endif
				.elseif (eax=='lyts')&&(pflag&32)
					xor	ecx,ecx
					xor	eax,eax
					.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='>')
						mov	eax,[esi+ecx]
						or	eax,20202020h
						.break .if (eax=='crs ')||(eax=='ferh')
						inc	ecx
					.endw
					.if (eax=='crs ')||(eax=='ferh')
						call	save_css
					.elseif byte ptr[esi+ecx]=='>'
						.while (byte ptr[esi+ecx]!=0)
							.if word ptr[esi+ecx]=='/<'
								mov	eax,[esi+ecx+2]
								or	eax,20202020h
								.break .if eax=='lyts'
							.endif
							mov	eax,[esi+ecx+1]
							mov	edx,[esi+ecx+4+1]
							or	eax,20202020h
							or	edx,20202020h
							.if (byte ptr[esi+ecx]=='@')&&(eax=='opmi')&&(dx=='tr')
								rep	movsb
								movsb
								movsd
								movsw
								css_spaces
								mov	ax,[esi+1]
								or	ax,2020h
								.if (byte ptr[esi]=='u')||(byte ptr[esi]=='U')&&(ax=='lr')
									movsw
									movsb
								.endif
								.while 1
									css_spaces
									.if (byte ptr[esi]==32)||(byte ptr[esi]=='=')||(byte ptr[esi]==9)||(byte ptr[esi]=='(')||(byte ptr[esi]==39)||(byte ptr[esi]==34)
										movsb
									.else
										.break
									.endif
								.endw
								.if (byte ptr[esi]>32)&&(word ptr[esi]!='/<')
									mov	edx,esi
									.while (byte ptr[esi]>32)&&(byte ptr[esi]!=')')&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=34)&&(word ptr[esi]!='/<')
										inc	esi
									.endw
									push	dword ptr[esi]
									push	esi
									mov	byte ptr[esi],0
									mov	esi,edx
									mov	dword ptr buftmp0,edi
									call	sv_css
									pop	esi
									pop	dword ptr[esi]
									xor	ecx,ecx
									dec	ecx
								.else
									movsb
								.endif
							.elseif ((byte ptr[esi+ecx]=='h')||(byte ptr[esi+ecx]=='H'))&&(eax==':ptt')
								jmp	css_url
							.elseif ((byte ptr[esi+ecx]=='u')||(byte ptr[esi+ecx]=='U'))&&(ax=='lr')&&(byte ptr[esi+ecx+3]<'A')
								lea	ecx,[ecx+3]
								.while (byte ptr[esi+ecx]==32)||(byte ptr[esi+ecx]=='=')||(byte ptr[esi+ecx]==9)||(byte ptr[esi+ecx]=='(')||(byte ptr[esi+ecx]==39)||(byte ptr[esi+ecx]==34)
									inc	ecx
								.endw
								.if (byte ptr[esi+ecx]>32)&&(word ptr[esi+ecx]!='/<')
css_url:								rep	movsb
									xor	ecx,ecx
									.while (byte ptr[esi+ecx]>32)&&(byte ptr[esi+ecx]!=')')&&(byte ptr[esi+ecx]!=39)&&(byte ptr[esi+ecx]!=34)&&(word ptr[esi+ecx]!='/<')
										inc	ecx
									.endw
									push	dword ptr[esi+ecx]
									push	esi
									push	ecx
									mov	byte ptr[esi+ecx],0
									mov	dword ptr buftmp0,edi
									call	sv_img
									pop	ecx
									pop	esi
									pop	dword ptr[esi+ecx]
									lea	esi,[esi+ecx]
									xor	ecx,ecx
									dec	ecx
								.endif
							.elseif word ptr[esi+ecx]=='//'
								.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!=13)&&(byte ptr[esi+ecx]!=10)
									inc	ecx
								.endw
								dec	ecx
							.endif
							inc	ecx
						.endw
						rep	movsb
					.endif
				.else
					movsb
				.endif
			.else
				movsb
			.endif
		.endw
		mov	eax,edi
		movsb
		sub	eax,dword ptr[esp]
		mov	fsize,eax
		mov	eax,[esp]
		xchg	eax,r_buf
		xchg	eax,[esp]
		call	GlobalFree
	.endif
	mov	esi,r_buf
	ret
prel_file	ENDP

parse_css	PROC
	push	dword ptr buftmp0
	mov	ecx,bread
	lea	ecx,[ecx*2+10240]
	invoke	GlobalAlloc,GPTR,ecx
	push	eax
	push	esi
	mov	edi,eax
	xor	ecx,ecx
	.while byte ptr[esi]
		mov	eax,[esi+1]
		mov	edx,[esi+4+1]
		or	eax,20202020h
		or	edx,20202020h
		.if (byte ptr[esi]=='@')&&(eax=='opmi')&&(dx=='tr')
			movsb
			movsd
			movsw
			css_spaces
			mov	ax,[esi+1]
			or	ax,2020h
			.if (byte ptr[esi]=='u')||(byte ptr[esi]=='U')&&(ax=='lr')
				movsw
				movsb
			.endif
			.while 1
				css_spaces
				.if (byte ptr[esi]==32)||(byte ptr[esi]=='=')||(byte ptr[esi]==9)||(byte ptr[esi]=='(')||(byte ptr[esi]==39)||(byte ptr[esi]==34)
					movsb
				.else
					.break
				.endif
			.endw
			.if (byte ptr[esi]>32)&&(word ptr[esi]!='/<')
				mov	edx,esi
				.while (byte ptr[esi]>32)&&(byte ptr[esi]!=')')&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=34)&&(word ptr[esi]!='/<')
					inc	esi
				.endw
				push	dword ptr[esi]
				push	esi
				mov	byte ptr[esi],0
				mov	esi,edx
				mov	dword ptr buftmp0,edi
				call	sv_css1
				pop	esi
				pop	dword ptr[esi]
			.else
				movsb
			.endif
		.elseif ((byte ptr[esi]=='h')||(byte ptr[esi]=='H'))&&(eax==':ptt')
			jmp	ss_url
		.elseif ((byte ptr[esi]=='u')||(byte ptr[esi]=='U'))&&(ax=='lr')&&(byte ptr[esi+3]<'A')
			movsw
			movsb
			.while (byte ptr[esi]==32)||(byte ptr[esi]=='=')||(byte ptr[esi]==9)||(byte ptr[esi]=='(')||(byte ptr[esi]==39)||(byte ptr[esi]==34)
				movsb
			.endw
			.if (byte ptr[esi]>32)&&(word ptr[esi]!='/<')
ss_url:				mov	edx,esi
				.while (byte ptr[esi]>32)&&(byte ptr[esi]!=')')&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=34)&&(word ptr[esi]!='/<')
					inc	esi
				.endw
				push	dword ptr[esi]
				push	esi
				mov	byte ptr[esi],0
				mov	esi,edx
				mov	dword ptr buftmp0,edi
				call	sv_css2
				pop	esi
				pop	dword ptr[esi]
				lea	esi,[esi]
			.endif
		.elseif word ptr[esi]=='//'
			.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=13)&&(byte ptr[esi]!=10)
				movsb
			.endw
		.else
			movsb
		.endif
	.endw
	call	GlobalFree
	mov	ecx,edi
	mov	al,0
	stosb
	pop	edi
	sub	ecx,edi
	mov	bread,ecx
	pop	dword ptr buftmp0
	ret
parse_css	ENDP
endm
