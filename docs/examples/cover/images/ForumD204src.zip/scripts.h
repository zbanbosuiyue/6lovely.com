maxrec=100
maxredirects=100

get_url		PROTO	:DWORD
check_url	PROTO	:DWORD,:DWORD
link_scan	PROTO	:DWORD,:DWORD,:DWORD,:DWORD
savelinked	PROTO	:DWORD

bufstruc	struct
	_ptr	dd	?		;pointer to data
	_size	dd	?		;allocated size
	_data	dd	?		;size of data in allocated buffer
	_pos	dd	?		;position in data buffer
bufstruc	ends

_stosb	macro
	stosb
	mov	edx,[ebx]._pos
	.if edx==[ebx]._data
		inc	[ebx]._data
		mov	edx,[ebx]._data
		add	edx,1024
		.if edx>=[ebx]._size
			add	[ebx]._size,8192
			push	ebx
			invoke	GlobalAlloc,GPTR,[ebx]._size
			pop	ebx
			push	esi
			mov	esi,[ebx]._ptr
			mov	edi,eax
			mov	[ebx]._ptr,edi
			mov	ecx,[ebx]._data
			cld
			push	esi
			rep	movsb
			pop	edx
			push	ebx
			invoke	GlobalFree,edx
			pop	ebx
			pop	esi
			mov	edi,[ebx]._ptr
			add	edi,[ebx]._pos
			inc	edi
		.endif
	.endif
	inc	[ebx]._pos
endm

script_init	macro
	ext_save1	db	'Do nothing',0
	ext_save2	db	'Just add them to download queue',0
	ext_save3	db	'Save them as Forumdir\links.txt',0
	ext_save4	db	'Save the file that is linked',0
	ext_save5	db	'Process the link with associated script',0
	editclass	db	'Edit',0
	msgnodns	db	'The address you have entered doesn',39,'t look like a domain name or a template.',13,10
			db	'To save a script, enter a valid domain name or append ',39,'.template',39,' to save a template.',0
	msgscr		db	'Script',0
initscr	PROC
	local	wfdata:WIN32_FIND_DATA
	lea	edi,scrfile
	lea	edx,logfile
	.while byte ptr[edx]
		mov	al,[edx]
		stosb
		inc	edx
	.endw
	.while (edi!=offset logfile)&&(byte ptr[edi-1]!='/')&&(byte ptr[edi-1]!='\')
		dec	edi
	.endw
	mov	eax,'ircS'
	stosd
	mov	eax,'\stp'
	stosd
	mov	eax,'xt.*'
	stosd
	mov	ax,'t'
	stosw
	invoke	FindFirstFile,addr scrfile,addr wfdata
	.if eax!=INVALID_HANDLE_VALUE
		push	eax
		.while 1
			lea	edx,wfdata.cFileName
			.while (byte ptr[edx]!=0)
				mov	eax,[edx]
				or	eax,20202000h
				.if (eax=='txt.')&&(byte ptr[edx+4]==0)
					mov	byte ptr[edx],0
					.break
				.endif
				inc	edx
			.endw
			invoke	SendDlgItemMessage,hDialog,4300,CB_ADDSTRING,0,addr wfdata.cFileName
			mov	edx,[esp]
			invoke	FindNextFile,edx,addr wfdata
			.break .if eax==0
		.endw
		call	CloseHandle
	.endif
	invoke	SendDlgItemMessage,hDialog,4100,EM_SETMODIFY,0,0
	invoke	GetDlgItem,hDialog,4300
	invoke	FindWindowEx,eax,0,addr editclass,0
	mov	hEdit,eax
	invoke	SendDlgItemMessage,hDialog,2100,EM_SETLIMITTEXT,65535,0
	invoke	SendDlgItemMessage,hDialog,2101,EM_SETLIMITTEXT,65535,0
	invoke	SendDlgItemMessage,hDialog,6302,CB_ADDSTRING,0,addr ext_save1
	invoke	SendDlgItemMessage,hDialog,6302,CB_SETITEMDATA,eax,1
	invoke	SendDlgItemMessage,hDialog,6302,CB_ADDSTRING,0,addr ext_save2
	invoke	SendDlgItemMessage,hDialog,6302,CB_SETITEMDATA,eax,2
	invoke	SendDlgItemMessage,hDialog,6302,CB_ADDSTRING,0,addr ext_save3
	invoke	SendDlgItemMessage,hDialog,6302,CB_SETITEMDATA,eax,3
	invoke	SendDlgItemMessage,hDialog,6302,CB_ADDSTRING,0,addr ext_save4
	invoke	SendDlgItemMessage,hDialog,6302,CB_SETITEMDATA,eax,4
	invoke	SendDlgItemMessage,hDialog,6302,CB_ADDSTRING,0,addr ext_save5
	invoke	SendDlgItemMessage,hDialog,6302,CB_SETITEMDATA,eax,5
	movzx	eax,extsave
	dec	eax
	invoke	SendDlgItemMessage,hDialog,6302,CB_SETCURSEL,eax,0
	mov	desturls,0
	ret
initscr	ENDP
endm

script_dlg	macro
	.elseif (ax==6302)&&(bx==CBN_SELCHANGE)
		invoke	SendDlgItemMessage,hDlg,6302,CB_GETCURSEL,0,0
		.if eax!=CB_ERR
			invoke	SendDlgItemMessage,hDlg,6302,CB_GETITEMDATA,eax,0
			.if (eax!=0)&&(eax!=CB_ERR)
				mov	extsave,al
			.endif
		.endif
	.elseif (ax==4300)
		.if (bx==CBN_SELCHANGE)||(bx==CBN_EDITCHANGE)
			invoke	SendDlgItemMessage,hDlg,4100,EM_GETMODIFY,0,0
			.if eax==0
				invoke	GlobalAlloc,GPTR,8192
				push	eax
				invoke	SendDlgItemMessage,hDlg,4300,CB_GETCURSEL,0,0
				.if eax==CB_ERR
					mov	edx,[esp]
					invoke	SendMessage,hEdit,WM_GETTEXT,256,edx
					mov	edx,[esp]
					invoke	SendDlgItemMessage,hDlg,4300,CB_FINDSTRINGEXACT,0,edx
					.if eax!=CB_ERR
						mov	edx,[esp]
						invoke	SendDlgItemMessage,hDlg,4300,CB_SELECTSTRING,0,edx
					.endif
				.endif
				.if eax!=CB_ERR
_cb_setscr:				mov	edi,[esp]
					push	eax
					lea	edx,scrfile
					call	copyedx
					sub	edi,5
					pop	edx
					mov	word ptr[edi],4096
					invoke	SendDlgItemMessage,hDlg,4300,CB_GETLBTEXT,edx,edi
					.while byte ptr[edi]
						inc	edi
					.endw
					mov	eax,'txt.'
					stosd
					mov	al,0
					stosb
					mov	edx,[esp]
					invoke	CreateFile,edx,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0
					.if eax!=INVALID_HANDLE_VALUE
						push	eax
						invoke	GetFileSize,eax,0
						push	eax
						lea	eax,[eax+1024]
						invoke	GlobalAlloc,GPTR,eax
						pop	ecx
						push	eax
						mov	edx,[esp+4]
						push	0
						mov	esi,esp
						invoke	ReadFile,edx,eax,ecx,esi,0
						pop	eax
						add	eax,[esp]
						mov	byte ptr[eax],0
						mov	edx,[esp]
						invoke	SetDlgItemText,hDlg,4100,edx
						call	GlobalFree
						call	CloseHandle
					.else
						invoke	SetDlgItemText,hDlg,4100,addr nptr
					.endif
					invoke	SendDlgItemMessage,hDlg,4100,EM_SETMODIFY,0,0
				.endif
				call	GlobalFree
			.else
				invoke	GlobalAlloc,GPTR,8192
				push	eax
				invoke	SendDlgItemMessage,hDlg,4300,CB_GETCURSEL,0,0
				.if eax==CB_ERR
					mov	edx,[esp]
					invoke	SendMessage,hEdit,WM_GETTEXT,256,edx
					mov	edx,[esp]
					invoke	SendDlgItemMessage,hDlg,4300,CB_FINDSTRINGEXACT,0,edx
					.if eax!=CB_ERR
						mov	edx,[esp]
						invoke	SendDlgItemMessage,hDlg,4300,CB_SELECTSTRING,0,edx
					.endif
				.endif
				.if eax!=CB_ERR
					jmp	_cb_setscr
				.endif
				call	GlobalFree
			.endif
		.endif
	.elseif ax==4001
		invoke	GlobalAlloc,GPTR,8192
		push	eax
		mov	edi,eax
		lea	edx,scrfile
		call	copyedx
		sub	edi,5
		invoke	SendDlgItemMessage,hDlg,4300,CB_GETCURSEL,0,0
		.if eax==CB_ERR
			mov	edx,[esp]
			invoke	SendMessage,hEdit,WM_GETTEXT,256,edi
		.else
			invoke	SendDlgItemMessage,hDlg,4300,CB_GETLBTEXT,eax,edi
		.endif
		push	edi
		.while byte ptr[edi]
			.if (byte ptr[edi]=='/')||(byte ptr[edi]==':')||(byte ptr[edi]=='\')||(byte ptr[edi]=='*')||(byte ptr[edi]=='?')||(byte ptr[edi]=='|')||(byte ptr[edi]==34)||(byte ptr[edi]<32)
				mov	byte ptr[edi],'_'
			.endif
			inc	edi
		.endw
		push	edi
		mov	eax,'txt.'
		stosd
		mov	al,0
		stosb
		mov	edi,[esp+4+4]
		invoke	GetFileAttributes,edi
		push	eax
		invoke	CreateFile,edi,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0
		.if eax!=INVALID_HANDLE_VALUE
			push	eax
			invoke	SendDlgItemMessage,hDlg,4100,WM_GETTEXTLENGTH,0,0
			inc	eax
			push	eax
			lea	eax,[eax+1024]
			invoke	GlobalAlloc,GPTR,eax
			pop	ecx
			push	eax
			invoke	GetDlgItemText,hDlg,4100,eax,ecx
			mov	edx,[esp]
			push	0
			mov	esi,esp
			mov	ebx,[esp+4+4]
			invoke	WriteFile,ebx,edx,eax,esi,0
			pop	eax
			call	GlobalFree
			call	CloseHandle
		.else
			invoke	MessageBox,hDialog,addr errsave_,edi,0
			mov	dword ptr[esp],-2
		.endif
		pop	eax
		pop	edx
		mov	byte ptr[edx],0
		pop	edi
		.if eax==-2
		.elseif (eax&FILE_ATTRIBUTE_DIRECTORY)
			invoke	SendDlgItemMessage,hDlg,4300,CB_ADDSTRING,0,edi
			invoke	SendDlgItemMessage,hDlg,4300,CB_SETCURSEL,eax,0
		.endif
s_nodns:	call	GlobalFree
endm

script_data	macro
	desturls	dd	?
	bwrite		dd	?
	scrsaddr	sockaddr_in <>
	scrfds		fd_set	<>
	scrtimewait	timeval	<>
stsave=$
	lasterror	dd	?
	lastidx		dd	?
	_0		bufstruc <>
	_1		bufstruc <>
	_2		bufstruc <>
	_3		bufstruc <>
	_4		bufstruc <>
	_5		bufstruc <>
	_6		bufstruc <>
lsave1=$-stsave
endm

script_exec	macro
getrs	PROC	lParam:DWORD
	push	ebp
	mov	edi,lParam
	mov	diridx,1
	invoke	GlobalAlloc,GPTR,65536
	mov	desturls,eax
	mov	byte ptr[eax],0
	invoke	SendDlgItemMessage,hDialog,2100,WM_GETTEXTLENGTH,0,0
	push	eax
	lea	eax,[eax+1024]
	invoke	GlobalAlloc,GPTR,eax
	pop	ecx
	inc	ecx
	mov	esi,eax
	push	eax
	invoke	GetDlgItemText,hDialog,2100,esi,ecx

	.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
		inc	esi
	.endw
	.while byte ptr[esi]
		mov	lasterror,0
		invoke	get_url,0
		.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
			inc	esi
		.endw
		.while (byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==32)||(byte ptr[esi]==9)
			inc	esi
		.endw
	.endw
	mov	al,0
	stosb

	call	GlobalFree
	mov	started,0
	invoke	SetDlgItemText,hDialog,1,addr start3
	invoke	GetDlgItem,hDialog,3
	invoke	EnableWindow,eax,1
	invoke	GetDlgItem,hDialog,5
	invoke	EnableWindow,eax,1
	invoke	GetDlgItem,hDialog,6101
	invoke	EnableWindow,eax,1
	invoke	GetDlgItem,hDialog,6003
	invoke	EnableWindow,eax,1
	invoke	SendDlgItemMessage,hDialog,2100,EM_SETREADONLY,0,0
	lea	edi,forums
	xor	eax,eax
	dec	eax
	mov	ecx,256
	cld
	rep	stosd
	invoke	GlobalFree,desturls
	mov	desturls,0
	invoke	CloseHandle,[edi].hThread
	pop	ebp
	invoke	ExitThread,0
getrs	ENDP

msgscr1	db	'--> Testing link: ',0
msgscr2	db	'<X> Nothing found.',13,10,0
msgscr3	db	'--> No extra action was taken.',13,10,0
msg4s	db	'--> Delaying for ',0
msg4ds	db	' days, ',0
msg4hs	db	' hours, ',0
msg4ms	db	' minutes, ',0
msg4ss	db	' seconds, ',0
msg4mss	db	' milliseconds.',0
msg_ds	db	'--> Saving buffer as ',0
msg_as	db	'--> Appending to file: ',0
msg_des	db	'--> Deleting file: ',0
msg_errf db	'--> Error creating file ',0
err_redir db	'<X> Maximum number of HTTP redirects exceeded',13,10,0
err_sredir db	'<X> Parse error in HTTP redirect address',13,10,0
nptr		db	0
_open	db	'open',0
get_url	PROC	uses esi recnr:DWORD
	.if (byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==0)
		ret
	.endif
	.if dltype<10
		lea	edi,buftmp
		lea	edx,msgscr1
		call	copyedx
		xor	ecx,ecx
		.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!=13)&&(byte ptr[esi+ecx]!=10)
			mov	al,[esi+ecx]
			stosb
			inc	ecx
		.endw
		mov	eax,'... '
		stosd
		mov	ax,0a0dh
		stosw
		mov	al,0
		stosb
		lea	edx,buftmp
		call	showmsg
	.endif
	mov	eax,[esi]
	or	eax,20202020h
	.if ((eax=='ptth')||(eax=='pxxh')||(eax=='p**h')||(eax=='pttx'))&&(byte ptr[esi+4]==':')
		lea	esi,[esi+5]
		.while (byte ptr[esi]==':')||(byte ptr[esi]=='/')||(byte ptr[esi]=='\')||(byte ptr[esi]==' ')||(byte ptr[esi]==9)
			inc	esi
		.endw
	.endif
	xor	ecx,ecx
	.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!=13)&&(byte ptr[esi+ecx]!=10)
		inc	ecx
	.endw
	lea	ecx,[ecx+1024]
	invoke	GlobalAlloc,GPTR,ecx
	push	eax
	cld
	mov	edi,eax
	.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
		inc	esi
	.endw
	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=13)&&(byte ptr[esi]!=10)
		movsb
	.endw
	mov	al,0
	stosb

	mov	esi,[esp]
	invoke	GlobalAlloc,GPTR,8192
	push	eax
	mov	edi,eax

	lea	edx,scrfile
	call	copyedx
	sub	edi,5
	mov	ecx,edi
	sub	ecx,[esp]
	mov	edx,esi
	.while (byte ptr[edx]!='/')&&(byte ptr[edx]!='\')&&(byte ptr[edx]!=0)&&(ecx<1024)
		mov	al,[edx]
		stosb
		inc	ecx
		inc	edx
	.endw
	mov	eax,'txt.'
	stosd
	mov	al,0
	stosb
	mov	edx,[esp]
	invoke	GetFileAttributes,edx
	.while eax&FILE_ATTRIBUTE_DIRECTORY
		mov	edx,[esp]
		.while byte ptr[edx]!=0
			inc	edx
		.endw
		.while (edx!=dword ptr[esp])&&(byte ptr[edx-1]!='\')
			dec	edx
		.endw
		xor	ecx,ecx
		push	edx
		.while byte ptr[edx]!=0
			.if byte ptr[edx]=='.'
				inc	ecx
			.endif
			inc	edx
		.endw
		pop	edx
		.break .if ecx<=2
		push	edi
		mov	edi,edx
		.while byte ptr[edx]!='.'
			inc	edx
		.endw
		inc	edx
		call	copyedx
		mov	al,0
		stosb
		pop	edi
		mov	edx,[esp]
		invoke	GetFileAttributes,edx
	.endw
	.if eax&FILE_ATTRIBUTE_DIRECTORY
		mov	edi,[esp]
		lea	edx,scrfile
		call	copyedx
		sub	edi,5
		mov	eax,'afed'
		stosd
		mov	eax,'.tlu'
		stosd
		mov	eax,'txt'
		stosd
		mov	edx,[esp]
		invoke	GetFileAttributes,edx
	.endif
	.if (!(eax&FILE_ATTRIBUTE_DIRECTORY))
s_testscr:	.if desturls==0
			invoke	GlobalAlloc,GPTR,8192
			mov	desturls,eax
		.endif
		mov	edi,desturls
		mov	byte ptr[edi],0
		mov	edx,[esp]
		invoke	CreateFile,edx,GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,0,0
		.if eax!=INVALID_HANDLE_VALUE
			push	eax
			invoke	GetFileSize,eax,0
			push	eax
			lea	eax,[eax+1024]
			invoke	GlobalAlloc,GPTR,eax
			pop	ecx
			mov	ebx,eax
			pop	eax
			push	eax
			push	ebx
			invoke	ReadFile,eax,ebx,ecx,addr bread,0
			pop	ebx
			mov	eax,bread
			mov	byte ptr[ebx+eax],0
			push	ebx
			invoke	check_url,esi,ebx
			call	GlobalFree
			call	CloseHandle
			.if (recnr<maxrec)&&(lasterror==0)
				inc	recnr
				mov	esi,desturls
				.if (byte ptr[esi]!=1)&&(byte ptr[esi]!=0)
					invoke	get_url,recnr
				.endif
				dec	recnr
			.endif
		.endif
		.if recnr==0
			call	addurl
		.endif
	.else
		mov	edx,esi
		xor	ecx,ecx
		xor	eax,eax
		.while (byte ptr[esi+eax]!=0)&&(byte ptr[esi+eax]!='/')&&(byte ptr[esi+eax]!='\')
			.if byte ptr[esi+eax]=='.'
				.if ecx
					lea	edx,[ecx+1]
					lea	ecx,[esi+eax]
				.else
					lea	ecx,[esi+eax]
				.endif
			.endif
			inc	eax
		.endw
		.if ecx
			mov	edi,[esp]
			push	edx
			lea	edx,scrfile
			call	copyedx
			sub	edi,5
			pop	edx
			.while (byte ptr[edx]!='/')&&(byte ptr[edx]!='\')&&(byte ptr[edx]!=0)
				mov	al,[edx]
				stosb
				inc	edx
			.endw
			mov	eax,'txt.'
			stosd
			mov	al,0
			stosb
			mov	edx,[esp]
			invoke	GetFileAttributes,edx
			.if (!(eax&FILE_ATTRIBUTE_DIRECTORY))
				jmp	s_testscr
			.elseif dltype<10
				lea	edx,msgscr3
				call	showmsg
			.endif
		.elseif dltype<10
			lea	edx,msgscr2
			call	showmsg
		.endif
	.endif
	call	GlobalFree
	call	GlobalFree
	ret
get_url	ENDP

addurl:	mov	eax,desturls
	.if (byte ptr[eax]>1)
		invoke	SendDlgItemMessage,hDialog,2101,WM_GETTEXTLENGTH,0,0
		xor	ecx,ecx
		mov	edx,desturls
		.while byte ptr [edx+ecx]
			inc	ecx
		.endw
		lea	ecx,[ecx+eax]
		.if ecx>65535
			sub	ecx,32768
		;	push	ecx
		;	invoke	SendDlgItemMessage,hDialog,2101,WM_SETREDRAW,0,0
		;	pop	ecx
			invoke	SendDlgItemMessage,hDialog,2101,EM_SETSEL,0,ecx
			invoke	SendDlgItemMessage,hDialog,2101,EM_REPLACESEL,0,addr nptr
			invoke	SendDlgItemMessage,hDialog,2101,WM_GETTEXTLENGTH,0,0
		.endif
	;	push	eax
	;	invoke	SendDlgItemMessage,hDialog,2101,WM_SETREDRAW,0,0
	;	pop	eax
		invoke	SendDlgItemMessage,hDialog,2101,EM_SETSEL,eax,eax
		mov	edx,desturls
		.while byte ptr[edx]
			inc	edx
		.endw
		push	edx
		mov	dword ptr[edx],0a0dh
		invoke	SendDlgItemMessage,hDialog,2101,EM_REPLACESEL,0,desturls
		pop	edx
		mov	byte ptr[edx],0
	;	invoke	SendDlgItemMessage,hDialog,2101,WM_SETREDRAW,1,0
		invoke	SendDlgItemMessage,hDialog,2101,EM_SCROLLCARET,0,0
		mov	edx,desturls
		mov	word ptr[edx],1
	.endif
	ret

idxsrc1	db	'forumindexdownloadcomplete',0
idxsrc2	db	'forumindexdownload',0
idxsrc3	db	'indexdownloadcomplete',0
idxsrc4	db	'indexdownload',0
idxsrc5	db	'topicdownloadcomplete',0
idxsrc6	db	'topicdownload',0
idxsrc7	db	'indexnextpagesearch',0
idxsrc8	db	'topicnextpagesearch',0
idxsrc9	db	'forumsearch',0
idxsrc10 db	'topicsearch',0
check_url	PROC	uses esi url:DWORD,rules:DWORD
	local	parsed:DWORD,inurl:DWORD,redirects:DWORD
	mov	eax,url
	mov	parsed,eax
	mov	inurl,0
	mov	lasterror,0
	mov	lastidx,0
	mov	_0._ptr,0
	mov	_0._size,0
	mov	_0._pos,0
	mov	_0._data,0
	mov	_1._ptr,0
	mov	_1._size,0
	mov	_1._pos,0
	mov	_1._data,0
	mov	_2._ptr,0
	mov	_2._size,0
	mov	_2._pos,0
	mov	_2._data,0
	mov	_3._ptr,0
	mov	_3._size,0
	mov	_3._pos,0
	mov	_3._data,0
	mov	_4._ptr,0
	mov	_4._size,0
	mov	_4._pos,0
	mov	_4._data,0
	mov	_5._ptr,0
	mov	_5._size,0
	mov	_5._data,0
	mov	_5._pos,0
	mov	_6._ptr,0
	mov	_6._size,0
	mov	_6._pos,0
	mov	_6._data,0
	invoke	GlobalAlloc,GPTR,8192
	mov	_0._ptr,eax
	mov	_0._size,8192
	mov	edi,eax
	mov	esi,url
	xor	ecx,ecx
	.while (ecx<8191)&&(byte ptr[esi]!=0)
		movsb
		inc	ecx
	.endw
	mov	_0._data,ecx
	mov	al,0
	stosb
	invoke	GlobalAlloc,GPTR,8192
	mov	_5._ptr,eax
	mov	_5._size,8192
	mov	edi,eax
	mov	esi,url
	xor	ecx,ecx
	.while (ecx<8191)&&(byte ptr[esi]!=0)
		movsb
		inc	ecx
	.endw
	mov	_5._data,ecx
	mov	al,0
	stosb

	call	mk_headers
	mov	esi,rules
	.if dltype>9
		xor	edx,edx
		.if dltype==10
			lea	esi,idxsrc2
			mov	edx,esi
			mov	eax,tmpbuf
			mov	_6._ptr,eax
			mov	eax,fsize
			mov	_6._size,8192
			mov	_6._data,eax
		.elseif dltype==11
			mov	eax,tmpbuf
			mov	_6._ptr,eax
			mov	eax,fsize
			mov	_6._size,eax
			mov	_6._data,eax
			lea	esi,idxsrc1
			mov	edx,esi
		.elseif dltype==12
			lea	esi,idxsrc4
			mov	edx,esi
			mov	eax,tmpbuf
			mov	_6._ptr,eax
			mov	eax,fsize
			mov	_6._size,8192
			mov	_6._data,eax
		.elseif dltype==13
			mov	eax,tmpbuf
			mov	_6._ptr,eax
			mov	eax,fsize
			mov	_6._size,eax
			mov	_6._data,eax
			lea	esi,idxsrc3
			mov	edx,esi
		.elseif dltype==14
			lea	esi,idxsrc6
			mov	edx,esi
			mov	eax,tmpbuf
			mov	_6._ptr,eax
			mov	eax,fsize
			mov	_6._size,8192
			mov	_6._data,eax
		.elseif dltype==15
			mov	eax,tmpbuf
			mov	_6._ptr,eax
			mov	eax,fsize
			mov	_6._size,eax
			mov	_6._data,eax
			lea	esi,idxsrc5
			mov	edx,esi
		.elseif (dltype==16)||(dltype==17)
			mov	eax,tmppos
			mov	_6._pos,eax
			mov	eax,tmpbuf
			mov	_6._ptr,eax
			sub	_6._pos,eax
			xor	ecx,ecx
			.while byte ptr[eax+ecx]
				inc	ecx
			.endw
			mov	_6._size,ecx
			mov	_6._data,ecx
			.if dltype==16
				lea	esi,idxsrc7
			.else
				lea	esi,idxsrc8
			.endif
			mov	edx,esi
		.elseif (dltype==18)||(dltype==19)
			mov	eax,tmppos
			mov	_6._pos,eax
			mov	eax,tmpbuf
			mov	_6._ptr,eax
			sub	_6._pos,eax
			xor	ecx,ecx
			.while byte ptr[eax+ecx]
				inc	ecx
			.endw
			mov	_6._size,ecx
			mov	_6._data,ecx
			.if dltype==18
				lea	esi,idxsrc9
			.else
				lea	esi,idxsrc10
			.endif
			mov	edx,esi
		.endif
		.if edx
			mov	edx,rules
			.while byte ptr[edx]
				.while (byte ptr[edx]==32)||(byte ptr[edx]==9)||(byte ptr[edx]==13)||(byte ptr[edx]==10)
					inc	edx
				.endw
				.if byte ptr[edx]==':'
					inc	edx
					xor	ecx,ecx
					.while (byte ptr[esi+ecx]!=13)&&(byte ptr[esi+ecx]!=10)&&(byte ptr[esi+ecx]!=0)
						mov	al,[esi+ecx]
						mov	ah,[edx+ecx]
						or	ax,2020h
						.break .if al!=ah
						inc	ecx
					.endw
					.if (byte ptr[esi+ecx]==13)||(byte ptr[esi+ecx]==10)||(byte ptr[esi+ecx]==0)
						.if (byte ptr[edx+ecx]==13)||(byte ptr[edx+ecx]==10)||(byte ptr[edx+ecx]==0)||(byte ptr[edx]==32)||(byte ptr[edx]==9)
							lea	esi,[edx+ecx]
							mov	labelex,1
							jmp	_foundlbl
						.endif
					.endif
				.endif
				.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
					inc	edx
				.endw
			.endw
		.endif
		mov	_5._data,0
		mov	edx,_5._ptr
		mov	byte ptr[edx],0
		lea	esi,idxsrc6-1
	.endif
_foundlbl:.while byte ptr[esi]
		.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
			inc	esi
		.endw
		.if byte ptr[esi]
			mov	eax,[esi]
			or	eax,20202020h
			.if (eax=='runi')
				.break .if inurl
				inc	inurl
				.while (byte ptr[esi]>='A')
					inc	esi
				.endw
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endw
				mov	eax,[esi]
				or	eax,20202020h
				.if (eax=='ptth')&&(byte ptr[esi+4]==':')
					mov	ebx,url
					lea	esi,[esi+5]
					.while (byte ptr[esi]==':')||(byte ptr[esi]=='/')||(byte ptr[esi]=='\')||(byte ptr[esi]==32)||(byte ptr[esi]==9)
						inc	esi
					.endw
					call	esccmp
					.if eax==0
						dec	inurl
						.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
							inc	esi
						.endw
						.while byte ptr[esi]
							.while (byte ptr[esi]==13)||(byte ptr[esi]==10)
								inc	esi
							.endw
							mov	eax,[esi]
							or	eax,20202020h
							.break .if eax=='runi'
							.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
								inc	esi
							.endw
						.endw
						.if byte ptr[esi]==0
							mov	lasterror,1
						.endif
					.else
						mov	lasterror,0
					.endif
				.else
					mov	ebx,url
					xor	eax,eax
					.while byte ptr[ebx]
						push	ebx
						push	esi
						call	esccmp
						pop	esi
						pop	ebx
						.break .if eax
						inc	ebx
					.endw
					.if eax==0
						dec	inurl
						.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
							inc	esi
						.endw
						.while byte ptr[esi]
							.while (byte ptr[esi]==13)||(byte ptr[esi]==10)
								inc	esi
							.endw
							mov	eax,[esi]
							or	eax,20202020h
							.break .if eax=='runi'
							.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
								inc	esi
							.endw
						.endw
						.if byte ptr[esi]==0
							mov	lasterror,1
						.endif
					.else
						mov	lasterror,0
					.endif
				.endif
			.elseif eax=='ohce'
				.while (byte ptr[esi]>='A')
					inc	esi
				.endw
				lea	edi,buftmp
				mov	eax,' >--'
				stosd
				.while 1
					.if byte ptr[esi]=='.'
						mov	edx,_6._ptr
						.if edx
							call	copyedx
						.endif
						inc	esi
					.elseif word ptr[esi]=='$$'
						push	esi
						call	getbptr
						mov	edx,ebx
						mov	eax,lastidx
						shl	eax,4
						lea	eax,_0[eax]
						assume	eax:ptr bufstruc
						mov	edx,[eax]._ptr
						call	copyedx
						pop	esi
						inc	esi
						inc	esi
					.elseif byte ptr[esi]=='$'
						push	esi
						call	getbptr
						mov	esi,ebx
						call	seeklnk
						lea	esi,[esi+edx]
						mov	eax,lastidx
						shl	eax,4
						lea	eax,_0[eax]
						assume	eax:ptr bufstruc
						mov	edx,esi
						sub	edx,[eax]._ptr
						.if edx&80000000h
							int 3
						.endif
						push	[eax]._pos
						push	eax
						mov	[eax]._pos,edx
						call	showlnk
						pop	eax
						pop	[eax]._pos
						pop	esi
						inc	esi
					.else
						.break
					.endif
				.endw
				.if (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endif
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					movsb
				.endw
				mov	eax,0a0dh
				stosd
				lea	edx,buftmp
				call	showmsg
			.elseif eax=='kees'
				lodsd
				.if (byte ptr[esi]=='-')&&(byte ptr[esi+1]>='0')&&(byte ptr[esi+1]<='9')
					lodsb
					call	atoi
					mov	edx,lastidx
					shl	edx,4
					lea	edx,_0[edx]
					assume	edx:ptr bufstruc
					.if eax<[edx]._pos
						sub	[edx]._pos,eax
					.else
						mov	[edx]._pos,0
					.endif
					assume	edx:nothing
				.else
					.while byte ptr[esi]=='-'
						inc	esi
						mov	eax,lastidx
						shl	eax,4
						lea	eax,_0[eax]
						assume	eax:ptr bufstruc
						mov	[eax]._pos,0
						assume	eax:nothing
					.endw
				.endif
				push	esi
				.while (byte ptr[esi]>32)
					inc	esi
				.endw
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endw
				.while 1
					.if word ptr[esi]=='0$'
						mov	lastidx,0
						lodsw
						call	getbptr
					.elseif word ptr[esi]=='1$'
						mov	lastidx,1
						lodsw
						call	getbptr
					.elseif word ptr[esi]=='2$'
						mov	lastidx,2
						lodsw
						call	getbptr
					.elseif word ptr[esi]=='3$'
						mov	lastidx,3
						lodsw
						call	getbptr
					.elseif word ptr[esi]=='4$'
						mov	lastidx,4
						lodsw
						call	getbptr
					.elseif word ptr[esi]=='5$'
						mov	lastidx,5
						lodsw
						call	getbptr
					.elseif word ptr[esi]=='6$'
						mov	lastidx,6
						lodsw
						call	getbptr
					.elseif byte ptr[esi]==32
						lodsb
					.elseif byte ptr[esi]==9
						inc	esi
					.else
						.break
					.endif
				.endw
				.if (byte ptr[esi]!=0)&&(byte ptr[esi]!=13)&&(byte ptr[esi]!=10)
					call	getbptr
					.while byte ptr[ebx]
						xor	ecx,ecx
						.while (byte ptr[esi+ecx]!=13)&&(byte ptr[esi+ecx]!=10)&&(byte ptr[esi+ecx]!=0)
							mov	al,[esi+ecx]
							mov	ah,[ebx+ecx]
							.break .if ah==0
							or	ax,2020h
							.break .if al!=ah
							inc	ecx
						.endw
						.if (byte ptr[esi+ecx]==13)||(byte ptr[esi+ecx]==10)||(byte ptr[esi+ecx]==0)
							mov	eax,lastidx
							shl	eax,4
							lea	eax,_0[eax]
							mov	ecx,ebx
							assume	eax:ptr bufstruc
							sub	ecx,[eax]._pos
							sub	ecx,[eax]._ptr
							assume	eax:nothing
							mov	eax,lastidx
							call	addbptr
							.break
						.endif
						inc	ebx
					.endw
					.if byte ptr[ebx]==0
						inc	lasterror
					.else
						mov	lasterror,0
					.endif
				.else
					mov	lasterror,0
				.endif
				pop	esi
				.while byte ptr[esi]>32
					.if byte ptr[esi]=='$'
						inc	esi
						push	esi
						call	getbptr
						mov	esi,ebx
						call	seeklnk
						lea	esi,[esi+edx]
						mov	edx,esi
						mov	eax,lastidx
						shl	eax,4
						lea	eax,_0[eax]
						assume	eax:ptr bufstruc
						sub	edx,[eax]._ptr
						.if edx&80000000h
							int 3
						.endif
						mov	[eax]._pos,edx
						assume	eax:nothing
						pop	esi
					.elseif byte ptr[esi]=='|'
						inc	esi
						mov	eax,lastidx
						shl	eax,4
						lea	eax,_0[eax]
						assume	eax:ptr bufstruc
						mov	edx,[eax]._data
						mov	[eax]._pos,edx
						assume	eax:nothing
					.elseif byte ptr[esi]=='+'
						inc	esi
						mov	eax,lastidx
						shl	eax,4
						lea	eax,_0[eax]
						assume	eax:ptr bufstruc
						.if (byte ptr[esi]>='0')&&(byte ptr[esi]<='9')
							push	eax
							call	atoi
							mov	edx,eax
							pop	eax
							add	edx,[eax]._pos
							.if edx>[eax]._data
								mov	edx,[eax]._data
								inc	lasterror
							.endif
							mov	[eax]._pos,edx
						.else
							inc	[eax]._pos
						.endif
						assume	eax:nothing
					.elseif byte ptr[esi]=='-'
						inc	esi
						mov	eax,lastidx
						shl	eax,4
						lea	eax,_0[eax]
						assume	eax:ptr bufstruc
						mov	[eax]._pos,0
						assume	eax:nothing
					.else
						inc	esi
					.endif
				.endw
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.elseif eax=='otog'
				lodsd
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endw
				mov	edx,rules
				.while byte ptr[edx]
					.while (byte ptr[edx]==32)||(byte ptr[edx]==9)||(byte ptr[edx]==13)||(byte ptr[edx]==10)
						inc	edx
					.endw
					.if byte ptr[edx]==':'
						inc	edx
						xor	ecx,ecx
						.while (byte ptr[esi+ecx]!=13)&&(byte ptr[esi+ecx]!=10)&&(byte ptr[esi+ecx]!=0)
							mov	al,[esi+ecx]
							mov	ah,[edx+ecx]
							or	ax,2020h
							.break .if al!=ah
							inc	ecx
						.endw
						.if (byte ptr[esi+ecx]==13)||(byte ptr[esi+ecx]==10)||(byte ptr[esi+ecx]==0)
							.if (byte ptr[edx+ecx]==13)||(byte ptr[edx+ecx]==10)||(byte ptr[edx+ecx]==0)||(byte ptr[edx]==32)||(byte ptr[edx]==9)
								lea	esi,[edx+ecx]
								.break
							.endif
						.endif
					.endif
					.while (byte ptr[edx]!=13)&&(byte ptr[edx]!=10)&&(byte ptr[edx]!=0)
						inc	edx
					.endw
				.endw
				.break .if byte ptr[edx]==0
			.elseif eax=='tirw'
				mov	lasterror,0
				lodsd
				.if (byte ptr[esi]=='e')||(byte ptr[esi]=='E')
					inc	esi
				.endif
				push	esi
				.while byte ptr[esi]=='.'
					inc	esi
				.endw
				.if (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endif
				mov	ebx,lastidx
			;	.if ebx<3
			;		mov	bl,6
			;	.endif
				push	ebx
				mov	eax,ebx
				call	gbptr
				pop	ebx
				shl	ebx,4
				lea	ebx,_0[ebx]
				assume	ebx:ptr bufstruc
				mov	edi,[ebx]._ptr
				add	edi,[ebx]._pos
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=13)&&(byte ptr[esi]!=10)
					lodsb
					.if al=='%'
						.if ((byte ptr[esi]>='0')&&(byte ptr[esi]<='9'))||((byte ptr[esi]>='A')&&(byte ptr[esi]<='Z'))||((byte ptr[esi]>='a')&&(byte ptr[esi]<='z'))
							lodsb
							.if al>='a'
								sub	al,20h
							.endif
							.if al>='A'
								sub	al,7
							.endif
							sub	al,30h
							.if al>15
								int 3
							.endif
							.if ((byte ptr[esi]>='0')&&(byte ptr[esi]<='9'))||((byte ptr[esi]>='A')&&(byte ptr[esi]<='Z'))||((byte ptr[esi]>='a')&&(byte ptr[esi]<='z'))
								mov	ah,al
								shl	ah,4
								lodsb
								.if al>='a'
									sub	al,20h
								.endif
								.if al>='A'
									sub	al,7
								.endif
								sub	al,30h
								.if al>15
									int 3
								.endif
								or	al,ah
								_stosb
							.else
								_stosb
							.endif
						.else
							_stosb
						.endif
					.elseif (al=='$')&&(byte ptr[esi]>='0')&&(byte ptr[esi]<='6')
						lodsb
						.if al=='0'
							mov	edx,_0._ptr
							.while byte ptr[edx]
								mov	al,[edx]
								push	edx
								_stosb
								pop	edx
								inc	edx
							.endw
						.else
							push	ebx
							mov	edx,[ebx]._data
							add	edx,8192
							push	eax
							.if edx>=[ebx]._size
								add	[ebx]._size,8192*2
								push	ebx
								invoke	GlobalAlloc,GPTR,[ebx]._size
								pop	ebx
								push	esi
								mov	esi,[ebx]._ptr
								mov	edi,eax
								mov	[ebx]._ptr,edi
								mov	ecx,[ebx]._data
								cld
								push	esi
								rep	movsb
								call	GlobalFree
								pop	esi
								mov	edi,[ebx]._ptr
								add	edi,[ebx]._pos
							.endif
							pop	eax
							push	esi
							sub	al,'0'
							movzx	eax,al
							call	gbptr
							mov	esi,ebx
							push	edi
							call	showlnk
							pop	edx
							mov	eax,edi
							sub	eax,edx
							pop	esi
							pop	ebx
							add	[ebx]._pos,eax
							mov	edx,[ebx]._pos
							.if edx>[ebx]._data
								mov	[ebx]._data,edx
							.endif
						.endif
					.elseif (al=='$')&&((byte ptr[esi]=='u')||(byte ptr[esi]=='U'))
						lodsb
						invoke	GlobalAlloc,GPTR,8192
						push	eax
						mov	edx,eax
						invoke	GetDlgItemText,hDialog,102,edx,8190
						pop	edx
						push	edx
						.while byte ptr[edx]
							push	edx
							mov	al,[edx]
							_stosb
							pop	edx
							inc	edx
						.endw
						call	GlobalFree
					.elseif (al=='$')&&((byte ptr[esi]=='p')||(byte ptr[esi]=='P'))
						lodsb
						invoke	GlobalAlloc,GPTR,8192
						push	eax
						mov	edx,eax
						invoke	GetDlgItemText,hDialog,103,edx,8190
						pop	edx
						push	edx
						.while byte ptr[edx]
							push	edx
							mov	al,[edx]
							_stosb
							pop	edx
							inc	edx
						.endw
						call	GlobalFree
					.elseif (al=='|')&&(byte ptr[esi]=='+')
						push	ebx
						inc	esi
						call	atoi
						push	eax
						call	getbptr
						.if (byte ptr[esi]=='$')&&(byte ptr[esi+1]>='0')&&(byte ptr[esi+1]<='6')
							lodsb
							lodsb
							sub	al,'0'
							movzx	eax,al
							shl	eax,4
							lea	eax,_0[eax]
							assume	eax:ptr bufstruc
							mov	edx,[eax]._data
							sub	edx,[eax]._pos
							.if edx<[esp]
								mov	[esp],edx
							.endif
							mov	edx,[eax]._ptr
							add	edx,[eax]._pos
							assume	eax:nothing
						.else
							mov	dword ptr[esp],0
						.endif
						pop	ecx
						pop	ebx
						.if ecx
						;	push	ecx
						;	push	edx
						;	add	[ebx]._size,ecx
						;	push	ebx
						;	invoke	GlobalAlloc,GPTR,[ebx]._size
						;	pop	ebx
						;	push	esi
						;	mov	esi,[ebx]._ptr
						;	mov	edi,eax
						;	mov	[ebx]._ptr,edi
						;	mov	ecx,[ebx]._data
						;	cld
						;	push	esi
						;	rep	movsb
						;	pop	eax
						;	pop	esi
							mov	edi,[ebx]._ptr
							add	edi,[ebx]._pos
						;	pop	edx
						;	pop	ecx
						;	push	eax
							.while ecx
								mov	al,[edx]
								push	edx
								push	ecx
								_stosb
								pop	ecx
								pop	edx
								inc	edx
								dec	ecx
							.endw
						;	call	GlobalFree
						.endif
					.elseif (al=='|')&&(byte ptr[esi]=='$')&&(byte ptr[esi+1]>='0')&&(byte ptr[esi+1]<='9')
						lodsb
						lodsb
						sub	al,'0'
						movzx	eax,al
						push	eax
						push	ebx
						call	gbptr
						pop	ebx
						pop	eax
						shl	eax,4
						lea	eax,_0[eax]
						assume	eax:ptr bufstruc
						mov	edx,[eax]._ptr
						add	edx,[eax]._pos
						assume	eax:nothing
						xor	ecx,ecx
						push	ebx
						push	esi
						.while byte ptr[edx+ecx]
							lea	ebx,[edx+ecx]
							push	ecx
							mov	esi,[esp+4]
							xor	ecx,ecx
							.while byte ptr[ebx+ecx]
								mov	al,[ebx+ecx]
								mov	ah,[esi]
								.if ah=='%'
									inc	esi
									mov	ax,[esi]
									inc	esi
									.if al>'F'
										sub	al,32
									.endif
									.if ah>'F'
										sub	ah,32
									.endif
									.if al>'9'
										sub	al,7
									.endif
									.if ah>'9'
										sub	ah,7
									.endif
									shl	al,4
									and	ax,0ff0h
									or	ah,al
									mov	al,[ebx+ecx]
									.if al!=ah
										or	al,20h
									.endif
								.else
									or	ax,2020h
								.endif
								.break .if (al!=ah)||(byte ptr[esi]==0)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
								inc	ecx
								inc	esi
							.endw
							.if (byte ptr[esi]==0)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
								pop	ecx
								.break
							.endif
							pop	ecx
							inc	ecx
						.endw
						pop	esi
						pop	ebx
						.if byte ptr[edx+ecx]
						;	push	ecx
						;	push	edx
						;	add	[ebx]._size,ecx
						;	add	[ebx]._size,1024
						;	push	ebx
						;	invoke	GlobalAlloc,GPTR,[ebx]._size
						;	pop	ebx
						;	push	esi
						;	mov	esi,[ebx]._ptr
						;	mov	edi,eax
						;	mov	[ebx]._ptr,edi
						;	mov	ecx,[ebx]._data
						;	cld
						;	push	esi
						;	.if ecx
						;		rep	movsb
						;	.endif
						;	pop	eax
						;	pop	esi
							mov	edi,[ebx]._ptr
							add	edi,[ebx]._pos
						;	pop	edx
						;	pop	ecx
						;	push	eax
							.while ecx
								mov	al,[edx]
								push	edx
								push	ecx
								_stosb
								pop	ecx
								pop	edx
								inc	edx
								dec	ecx
							.endw
						;	call	GlobalFree
						.endif
						.break
					.else
						_stosb
					.endif
				.endw
				mov	eax,lastidx
				shl	eax,4
				lea	eax,_0[eax]
				assume	eax:ptr bufstruc
				mov	edx,[eax]._ptr
				add	edx,[eax]._data
				mov	byte ptr[edx],0
				assume	eax:nothing
				assume	ebx:nothing
				pop	esi
				.if byte ptr[esi]=='.'
					mov	eax,lastidx
					shl	eax,4
					lea	eax,_0[eax]
					assume	eax:ptr bufstruc
					mov	edx,[eax]._pos
					mov	[eax]._data,edx
					add	edx,[eax]._ptr
					mov	byte ptr[edx],0
					assume	eax:nothing
				.endif
				.if (lastidx==5)||(lastidx==4)
					call	mk_headers
				.endif
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.elseif eax=='orre'
				lodsd
				.if (byte ptr[esi]=='r')||(byte ptr[esi]=='R')
					inc	esi
				.endif
				.if lasterror==0
					.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
						inc	esi
					.endw
				.endif
			.elseif eax=='daeh'
				.if (autoupd&1)&&(_5._ptr!=0)
					invoke	auto_upd,_5._ptr
				.endif
				mov	lasterror,0
				mov	eax,3
				call	gbptr
				mov	ebx,_3._ptr
				mov	dword ptr[ebx],'DAEH'
				.if _3._data<4
					mov	_3._data,4
				.endif
				call	hostchk
				.if dword ptr scrsaddr.sin_addr!=0
					invoke	socket,PF_INET,SOCK_STREAM,IPPROTO_TCP
					.if eax!=INVALID_SOCKET
						push	eax
						invoke	connect,eax,addr scrsaddr,sizeof scrsaddr
						.if eax==0
							pop	edx
							push	edx
							mov	dword ptr buftmp,0
							invoke	ioctlsocket,edx,FIONBIO,addr buftmp
							pop	edx
							push	edx
							.if autoupd&1
								push	edx
								invoke	send_upd,_3._ptr,_3._data
								pop	edx
							.endif
							invoke	send,edx,_3._ptr,_3._data,0
							.if eax!=SOCKET_ERROR
								pop	eax
								push	eax
								call	get_head
							.else
							invoke	WSAGetLastError
								inc	lasterror
								lea	edx,err_send
								call	showmsg
							.endif
						.else
							inc	lasterror
							lea	edi,buftmp
							lea	edx,err_con
							call	copyedx
							mov	edx,_5._ptr
							mov	eax,[edx]
							or	eax,20202020h
							.if (eax=='ptth')&&(byte ptr[edx+1]==':')||(byte ptr[edx+1]=='/')||(byte ptr[edx+1]=='\')
								lea	edx,[edx+5]
								.while (byte ptr[edx]==':')||(byte ptr[edx]=='/')||(byte ptr[edx]=='\')
									inc	edx
								.endw
							.endif
							.while (byte ptr[edx]>32)&&(byte ptr[edx]!='/')&&(byte ptr[edx]!='\')
								mov	al,[edx]
								stosb
								inc	edx
							.endw
							mov	eax,0a0dh
							stosd
							lea	edx,buftmp
							call	showmsg
						.endif
						call	closesocket
					.else
						inc	lasterror
					.endif
				.endif
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.elseif (ax=='eg')&&((byte ptr[esi+2]=='t')||(byte ptr[esi+2]=='T'))&&(byte ptr[esi+3]<33)
				.if (autoupd&1)&&(_5._ptr!=0)
					invoke	auto_upd,_5._ptr
				.endif
				lodsw
				inc	esi
				mov	redirects,0
_followredirect:		mov	lasterror,0
				mov	eax,3
				call	gbptr
				mov	ebx,_3._ptr
				mov	dword ptr[ebx],'TEG '
				.if _3._data<4
					mov	_3._data,4
					mov	eax,_3._ptr
					mov	byte ptr[eax+4],0
				.endif
				call	hostchk
				.if dword ptr scrsaddr.sin_addr!=0
					invoke	socket,PF_INET,SOCK_STREAM,IPPROTO_TCP
					.if eax!=INVALID_SOCKET
						push	eax
						invoke	connect,eax,addr scrsaddr,sizeof scrsaddr
						.if eax==0
							pop	edx
							push	edx
							mov	dword ptr buftmp,0
							invoke	ioctlsocket,edx,FIONBIO,addr buftmp
							pop	edx
							push	edx
							mov	eax,_3._ptr
							mov	ecx,_3._data
							inc	eax
							.if ecx
								dec	ecx
							.endif
							.if autoupd&1
								push	edx
								push	eax
								invoke	send_upd,eax,ecx
								pop	eax
								pop	edx
							.endif
							invoke	send,edx,eax,ecx,0
_get_:							.if eax!=SOCKET_ERROR
								pop	eax
								push	eax
								call	get_head
								.if (_1._ptr!=0)&&(lasterror==0)
									mov	ebx,_1._ptr
									mov	eax,[ebx]
									or	eax,20202020h
									.if eax=='ptth'
										lea	ebx,[ebx+4]
										.while (byte ptr[ebx]=='/')||(byte ptr[ebx]=='.')||((byte ptr[ebx]>='0')&&(byte ptr[ebx]<='9'))
											inc	ebx
										.endw
										.if byte ptr[ebx]==32
											.while (byte ptr[ebx]==32)
												inc	ebx
											.endw
											.if byte ptr[ebx]=='2'
												pop	eax
												push	eax
												call	get_data
											.elseif byte ptr[ebx]=='3'
												inc	redirects
												.if redirects<maxredirects
													call	setredirect
													.if lasterror==0
														call	closesocket
														jmp	_followredirect
													.else
														lea	edx,err_sredir
														call	showmsg
													.endif
												.else
													lea	edx,err_redir
													call	showmsg
													inc	lasterror
												.endif
											.else
												inc	lasterror
											.endif
										.else
											inc	lasterror
										.endif
									.else
										inc	lasterror
									.endif
								.endif
							.else
								inc	lasterror
								lea	edx,err_send
								call	showmsg
							.endif
						.else
							inc	lasterror
							lea	edi,buftmp
							lea	edx,err_con
							call	copyedx
							mov	edx,_5._ptr
							mov	eax,[edx]
							or	eax,20202020h
							.if (eax=='ptth')&&(byte ptr[edx+1]==':')||(byte ptr[edx+1]=='/')||(byte ptr[edx+1]=='\')
								lea	edx,[edx+5]
								.while (byte ptr[edx]==':')||(byte ptr[edx]=='/')||(byte ptr[edx]=='\')
									inc	edx
								.endw
							.endif
							.while (byte ptr[edx]>32)&&(byte ptr[edx]!='/')&&(byte ptr[edx]!='\')
								mov	al,[edx]
								stosb
								inc	edx
							.endw
							mov	eax,0a0dh
							stosd
							lea	edx,buftmp
						.endif
						call	closesocket
					.else
						inc	lasterror
					.endif
				.endif
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.elseif eax=='tsop'
				.if (autoupd&1)&&(_5._ptr!=0)
					invoke	auto_upd,_5._ptr
				.endif
				lodsd
				mov	redirects,0
_followredirectp:		mov	lasterror,0
				mov	eax,3
				call	gbptr
				mov	ebx,_3._ptr
				mov	dword ptr[ebx],'TSOP'
				.if _3._data<4
					mov	_3._data,4
					mov	eax,_3._ptr
					mov	byte ptr[eax+4],0
				.endif
				call	hostchk
				.if dword ptr scrsaddr.sin_addr!=0
					invoke	socket,PF_INET,SOCK_STREAM,IPPROTO_TCP
					.if eax!=INVALID_SOCKET
						push	eax
						invoke	connect,eax,addr scrsaddr,sizeof scrsaddr
						.if eax==0
							pop	edx
							push	edx
							mov	dword ptr buftmp,0
							invoke	ioctlsocket,edx,FIONBIO,addr buftmp
							pop	edx
							push	edx
							mov	eax,_3._ptr
							mov	ecx,_3._data
						;	inc	eax
						;	.if ecx
						;		dec	ecx
						;	.endif
							.if (autoupd&1)&&(_4._data==0)
								push	edx
								push	eax
								invoke	send_upd,eax,ecx
								pop	eax
								pop	edx
							.endif
							invoke	send,edx,eax,ecx,0
							.if _4._data
								pop	edx
								push	edx
								.if autoupd&1
									push	edx
									call	send_upd1
									pop	edx
								.endif
								invoke	send,edx,_4._ptr,_4._data,0
							.endif
							.if eax!=SOCKET_ERROR
								pop	eax
								push	eax
								call	get_head
								.if (_1._ptr!=0)&&(lasterror==0)
									mov	ebx,_1._ptr
									mov	eax,[ebx]
									or	eax,20202020h
									.if eax=='ptth'
										lea	ebx,[ebx+4]
										.while (byte ptr[ebx]=='/')||(byte ptr[ebx]=='.')||((byte ptr[ebx]>='0')&&(byte ptr[ebx]<='9'))
											inc	ebx
										.endw
										.if byte ptr[ebx]==32
											.while (byte ptr[ebx]==32)
												inc	ebx
											.endw
											.if byte ptr[ebx]=='2'
												pop	eax
												push	eax
												call	get_data
											.elseif byte ptr[ebx]=='3'
												inc	redirects
												.if redirects<maxredirects
													call	setredirect
													.if lasterror==0
														call	closesocket
														jmp	_followredirectp
													.else
														lea	edx,err_sredir
														call	showmsg
													.endif
												.else
													lea	edx,err_redir
													call	showmsg
													inc	lasterror
												.endif
											.else
												inc	lasterror
											.endif
										.else
											inc	lasterror
										.endif
									.else
										inc	lasterror
									.endif
								.endif
							.else
								inc	lasterror
								lea	edx,err_send
								call	showmsg
							.endif
						.else
							inc	lasterror
							lea	edi,buftmp
							lea	edx,err_con
							call	copyedx
							mov	edx,_5._ptr
							mov	eax,[edx]
							or	eax,20202020h
							.if (eax=='ptth')&&(byte ptr[edx+1]==':')||(byte ptr[edx+1]=='/')||(byte ptr[edx+1]=='\')
								lea	edx,[edx+5]
								.while (byte ptr[edx]==':')||(byte ptr[edx]=='/')||(byte ptr[edx]=='\')
									inc	edx
								.endw
							.endif
							.while (byte ptr[edx]>32)&&(byte ptr[edx]!='/')&&(byte ptr[edx]!='\')
								mov	al,[edx]
								stosb
								inc	edx
							.endw
							mov	eax,0a0dh
							stosd
							lea	edx,buftmp
							call	showmsg
						.endif
						call	closesocket
					.else
						inc	lasterror
					.endif
				.endif
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.elseif eax=='dnes'
				.if (autoupd&1)&&(_5._ptr!=0)
					invoke	auto_upd,_5._ptr
				.endif
				lodsd
				mov	redirects,0
				mov	lasterror,0
				mov	eax,4
				call	gbptr
				call	hostchk
				.if dword ptr scrsaddr.sin_addr!=0
					invoke	socket,PF_INET,SOCK_STREAM,IPPROTO_TCP
					.if eax!=INVALID_SOCKET
						push	eax
						invoke	connect,eax,addr scrsaddr,sizeof scrsaddr
						.if eax==0
							pop	edx
							push	edx
							mov	dword ptr buftmp,0
							invoke	ioctlsocket,edx,FIONBIO,addr buftmp
							.if _4._data
								pop	edx
								push	edx
								.if (autoupd&1)
									push	edx
									push	eax
									invoke	send_upd,_3._ptr,_3._data
									pop	eax
									pop	edx
								.endif
								invoke	send,edx,_3._ptr,_3._data,0
							.endif
							jmp	_get_
						.else
							inc	lasterror
							lea	edi,buftmp
							lea	edx,err_con
							call	copyedx
							mov	edx,_5._ptr
							mov	eax,[edx]
							or	eax,20202020h
							.if (eax=='ptth')&&(byte ptr[edx+1]==':')||(byte ptr[edx+1]=='/')||(byte ptr[edx+1]=='\')
								lea	edx,[edx+5]
								.while (byte ptr[edx]==':')||(byte ptr[edx]=='/')||(byte ptr[edx]=='\')
									inc	edx
								.endw
							.endif
							.while (byte ptr[edx]>32)&&(byte ptr[edx]!='/')&&(byte ptr[edx]!='\')
								mov	al,[edx]
								stosb
								inc	edx
							.endw
							mov	eax,0a0dh
							stosd
							lea	edx,buftmp
							call	showmsg
						.endif
						call	closesocket
					.else
						inc	lasterror
					.endif
				.endif
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.elseif eax=='evas'
				lodsd
				xor	eax,eax
				.if byte ptr[esi]=='+'
					inc	esi
					inc	eax
				.endif
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endw
				mov	redirects,0
				mov	lasterror,0
				push	eax
				mov	eax,3
				call	gbptr
				mov	ebx,_3._ptr
				mov	al,[esi]
				or	al,20h
				.if al=='p'
					mov	dword ptr[ebx],'TSOP'
				.elseif al=='h'
					mov	dword ptr[ebx],'DAEH'
				.elseif al=='s'
					mov	byte ptr[ebx],0
				.else
					mov	dword ptr[ebx],'TEG '
				.endif
				.if _3._data<4
					mov	_3._data,4
					mov	eax,_3._ptr
					mov	byte ptr[eax+4],0
				.endif
				pop	eax
				call	scrsave_file

				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.elseif eax=='llac'
				lodsd
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endw
				lea	edi,buftmp
				.if (byte ptr[esi]=='$')&&(byte ptr[esi+1]>='0')&&(byte ptr[esi+1]<='6')
					lodsb
					lodsb
					sub	al,'0'
					movzx	eax,al
					shl	eax,4
					lea	eax,_0[eax]
					assume	eax:ptr bufstruc
					mov	edx,[eax]._ptr
					mov	ecx,[eax]._data
					sub	ecx,[eax]._pos
					.if ecx
						add	edx,[eax]._pos
					.else
						xor	edx,edx
					.endif
					assume	eax:nothing
				.else
					mov	edx,esi
				.endif
				.if edx
					.while (byte ptr[edx]!=0)&&(byte ptr[edx]!=13)&&(byte ptr[edx]!=10)
						mov	al,[edx]
						stosb
						inc	edx
					.endw
					mov	al,0
					stosb
				;	invoke	WinExec,addr buftmp,SW_SHOW
					lea	edx,buftmp
					.while (byte ptr[edx]==32)||(byte ptr[edx]==9)
						inc	edx
					.endw
					.if byte ptr[edx]==34
						inc	edx
						push	edx
						.while (byte ptr[edx]!=34)&&(byte ptr[edx]!=0)
							inc	edx
						.endw
						.if byte ptr[edx]==34
							mov	byte ptr[edx],0
							inc	edx
							.if (byte ptr[edx]==32)||(byte ptr[edx]==9)
								inc	edx
							.endif
							push	edx
						.else
							inc	edx
							mov	byte ptr[edx],0
							push	edx
						.endif
					.elseif byte ptr[edx]==39
						inc	edx
						push	edx
						.while (byte ptr[edx]!=39)&&(byte ptr[edx]!=0)
							inc	edx
						.endw
						.if byte ptr[edx]==39
							mov	byte ptr[edx],0
							inc	edx
							.if (byte ptr[edx]==32)||(byte ptr[edx]==9)
								inc	edx
							.endif
							push	edx
						.else
							inc	edx
							mov	byte ptr[edx],0
							push	edx
						.endif
					.else
						inc	edx
						push	edx
						.while (byte ptr[edx]!=32)&&(byte ptr[edx]!=0)
							inc	edx
						.endw
						.if byte ptr[edx]==32
							mov	byte ptr[edx],0
							inc	edx
							push	edx
						.else
							inc	edx
							mov	byte ptr[edx],0
							push	edx
						.endif
					.endif
					pop	ecx
					pop	edx
					invoke	ShellExecute,hDialog,addr _open,edx,ecx,addr nptr,SW_SHOW
				.endif
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.elseif eax=='aled'
				lodsd
				.if (byte ptr[esi]=='y')||(byte ptr[esi]=='Y')
					inc	esi
				.endif
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endw
				.if byte ptr[esi]=='$'
					lodsb
					call	getbptr
					push	esi
					mov	esi,ebx
					call	atoi
					pop	esi
				.else
					call	atoi
				.endif
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endw
				xor	edx,edx
				.if (byte ptr[esi]=='m')||(byte ptr[esi]=='M')
					inc	esi
					.if (byte ptr[esi]=='s')||(byte ptr[esi]=='S')
						inc	esi
					.else
						mov	ebx,1000*60
						mul	ebx
					.endif
				.elseif (byte ptr[esi]=='s')||(byte ptr[esi]=='S')
					inc	esi
					mov	ebx,1000
					mul	ebx
				.elseif (byte ptr[esi]=='h')||(byte ptr[esi]=='H')
					inc	esi
					mov	ebx,1000*60*60
					mul	ebx
				.elseif (byte ptr[esi]=='d')||(byte ptr[esi]=='D')
					inc	esi
					mov	ebx,1000*60*60*24
					mul	ebx
				.else
					mov	ebx,1000
					mul	ebx
				.endif
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endw
				.if (byte ptr[esi]>='0')&&(byte ptr[esi]<='9')
					push	eax
					call	atoi
					mov	ebx,eax
					pop	eax
					xor	edx,edx
					mul	ebx
				.endif
				push	eax
				lea	edi,buftmp
				lea	edx,msg4s
				call	copyedx
				pop	eax
				push	eax
				.if eax>(24*60*60*1000)
					mov	ebx,24*60*60*1000
					xor	edx,edx
					div	ebx
					push	edx
					call	itoa
					lea	edx,msg4ds
					call	copyedx
					pop	eax
					jmp	_delay1
				.elseif eax>(60*60*1000)
_delay1:				mov	ebx,60*60*1000
					xor	edx,edx
					div	ebx
					push	edx
					call	itoa
					lea	edx,msg4hs
					call	copyedx
					pop	eax
					jmp	_delay2
				.elseif eax>(60*1000)
_delay2:				mov	ebx,60*1000
					xor	edx,edx
					div	ebx
					push	edx
					call	itoa
					lea	edx,msg4ms
					call	copyedx
					pop	eax
					jmp	_delay3
				.elseif eax>(1000)
_delay3:				mov	ebx,1000
					xor	edx,edx
					div	ebx
					push	edx
					call	itoa
					lea	edx,msg4ss
					call	copyedx
					pop	eax
					jmp	_delay4
				.else
_delay4:				call	itoa
					lea	edx,msg4mss
					call	copyedx
				.endif
				mov	eax,0a0dh
				stosd
				lea	edx,buftmp
				call	showmsg
				pop	eax
				invoke	Sleep,eax
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.elseif eax=='pmud'
				lodsd
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endw
				lea	edi,buftmp
				lea	edx,msg_ds
				call	copyedx
				push	edi
				.if (byte ptr[esi]=='$')&&(byte ptr[esi+1]>='0')&&(byte ptr[esi+1]<='6')
					lodsb
					lodsb
					sub	al,'0'
					movzx	eax,al
					shl	eax,4
					lea	eax,_0[eax]
					assume	eax:ptr bufstruc
					mov	edx,[eax]._ptr
					assume	eax:nothing
					.if edx
						call	copyedx
					.endif
				.else
					.if byte ptr[esi]==34
						inc	esi
						.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=0)
							movsb
						.endw
					.elseif byte ptr[esi]==39
						inc	esi
						.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)
							movsb
						.endw
					.else
						.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
							inc	esi
						.endw
						.if (byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==0)
							mov	eax,'pmud'
							stosd
							mov	eax,'txt.'
							stosd
						.else
							.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
								movsb
							.endw
						.endif
					.endif
				.endif
				mov	al,0
				stosb
				mov	edi,desturls
				.if dltype==2
					lea	edx,savedir
					call	copyedx
					.if (edi!=desturls)&&(byte ptr[edi-1]!='\')
						mov	al,'\'
						stosb
					.endif
				.else
					lea	edx,defdir
					mov	ecx,edi
					.while byte ptr[edx]!=0
						mov	al,[edx]
						.if al=='\'
							mov	ecx,edi
						.endif
						stosb
						inc	edx
					.endw
					mov	edi,ecx
					mov	al,'\'
					stosb
					mov	eax,diridx
					call	w5
					mov	al,32
					stosb
				.endif
				pop	edx
				push	edx
				.if byte ptr[edx]=='\'
					inc	edx
				.endif
				xor	ecx,ecx
				.while byte ptr[edx+ecx]
					mov	al,[edx+ecx]
					.if al<32
						.break
					.endif
					stosb
					inc	ecx
				.endw
				mov	al,0
				stosb
				mov	edx,desturls
				call	u_fn
				mov	edi,desturls
				call	copyedx
				mov	al,0
				stosb
				pop	edi
				push	edi
				mov	edx,desturls
				call	copyedx
				mov	eax,0a0dh
				stosd
				lea	edx,buftmp
				call	showmsg
				mov	edx,desturls
				call	mkdirs
				invoke	CreateFile,desturls,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0
				.if eax==INVALID_HANDLE_VALUE
					lea	edi,buftmp
					lea	edx,msg_errf
					call	copyedx
					mov	edx,desturls
					call	copyedx
					mov	eax,0a0dh
					stosd
					lea	edx,buftmp
					call	showmsg
				.else
					push	eax
					mov	edx,lastidx
					.if edx>6
						int 3
					.endif
					shl	edx,4
					lea	edx,_0[edx]
					assume	edx:ptr bufstruc
					mov	ecx,[edx]._data
					mov	ebx,[edx]._ptr
					assume	edx:nothing
					invoke	WriteFile,eax,ebx,ecx,addr bread,0
					call	CloseHandle
					call	addurl
				.endif
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.elseif eax=='eppa'
				lodsd
				.if (byte ptr[esi]=='n')||(byte ptr[esi]=='N')
					inc	esi
				.endif
				.if (byte ptr[esi]=='d')||(byte ptr[esi]=='D')
					inc	esi
				.endif
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endw
				lea	edi,buftmp
				push	edi
				.if (byte ptr[esi]=='$')&&(byte ptr[esi+1]>='0')&&(byte ptr[esi+1]<='6')
					lodsb
					lodsb
					sub	al,'0'
					movzx	eax,al
					shl	eax,4
					lea	eax,_0[eax]
					assume	eax:ptr bufstruc
					mov	edx,[eax]._ptr
					assume	eax:nothing
					.if edx
						call	copyedx
					.endif
				.else
					.if byte ptr[esi]==34
						inc	esi
						.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=0)
							movsb
						.endw
					.elseif byte ptr[esi]==39
						inc	esi
						.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)
							movsb
						.endw
					.else
						.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
							movsb
						.endw
					.endif
				.endif
				mov	al,0
				stosb
				mov	edi,desturls
				.if dltype==2
					lea	edx,savedir
					call	copyedx
					.if (edi!=desturls)&&(byte ptr[edi-1]!='\')
						mov	al,'\'
						stosb
					.endif
				.else
					lea	edx,defdir
					mov	ecx,edi
					.while byte ptr[edx]!=0
						mov	al,[edx]
						.if al=='\'
							mov	ecx,edi
						.endif
						stosb
						inc	edx
					.endw
					mov	edi,ecx
					mov	al,'\'
					stosb
					mov	eax,diridx
					call	w5
					mov	al,32
					stosb
				.endif
				pop	edx
				push	edx
				.if (byte ptr[edx]=='\')||(byte ptr[edx]=='/')
					inc	edx
				.endif
				call	copyedx
				mov	al,0
				stosb
				pop	edi
				mov	edx,desturls
				call	u_fn
				mov	edi,desturls
				call	copyedx
				mov	al,0
				stosb
				lea	edi,buftmp
				lea	edx,msg_as
				call	copyedx
				mov	edx,desturls
				call	copyedx
				mov	eax,0a0dh
				stosd
				lea	edx,buftmp
				call	showmsg
				invoke	CreateFile,desturls,GENERIC_READ or GENERIC_WRITE,FILE_SHARE_READ,0,OPEN_EXISTING,0,0
				.if eax==INVALID_HANDLE_VALUE
					invoke	CreateFile,edi,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0
				.else
					push	eax
					invoke	SetFilePointer,eax,0,0,FILE_END
					pop	eax
				.endif
				.if eax==INVALID_HANDLE_VALUE
					lea	edi,buftmp
					lea	edx,msg_errf
					call	copyedx
					mov	edx,desturls
					call	copyedx
					mov	eax,0a0dh
					stosd
					lea	edx,buftmp
					call	showmsg
				.else
					push	eax
					mov	edx,lastidx
					.if edx>6
						int 3
					.endif
					shl	edx,4
					lea	edx,_0[edx]
					assume	edx:ptr bufstruc
					mov	ecx,[edx]._data
					mov	ebx,[edx]._ptr
					assume	edx:nothing
					invoke	WriteFile,eax,ebx,ecx,addr bread,0
					call	CloseHandle
					call	addurl
				.endif
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.elseif eax=='eled'
				lodsd
				.if (byte ptr[esi]=='t')||(byte ptr[esi]=='T')
					inc	esi
				.endif
				.if (byte ptr[esi]=='e')||(byte ptr[esi]=='E')
					inc	esi
				.endif
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endw
				lea	edi,buftmp
				lea	edx,msg_des
				call	copyedx
				push	edi
				.if (byte ptr[esi]=='$')&&(byte ptr[esi+1]>='0')&&(byte ptr[esi+1]<='6')
					lodsb
					lodsb
					sub	al,'0'
					movzx	eax,al
					shl	eax,4
					lea	eax,_0[eax]
					assume	eax:ptr bufstruc
					mov	edx,[eax]._ptr
					assume	eax:nothing
					.if edx
						call	copyedx
					.endif
				.else
					.if byte ptr[esi]==34
						inc	esi
						.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=0)
							movsb
						.endw
					.elseif byte ptr[esi]==39
						inc	esi
						.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)
							movsb
						.endw
					.else
						.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
							movsb
						.endw
					.endif
				.endif
				mov	eax,0a0dh
				stosd
				lea	edx,buftmp
				call	showmsg
				pop	edi
				invoke	SetFileAttributes,edi,0
				invoke	DeleteFile,edi
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.elseif eax=='nacs'
				lodsd
				mov	eax,lsave1
				invoke	GlobalAlloc,GPTR,eax
				push	esi
				push	eax
				mov	edi,eax
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endw
				.if (byte ptr[esi]==0)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
					call	getbptr
					mov	esi,ebx
				.endif
				push	esi
				mov	esi,stsave
				mov	ecx,lsave1
				cld
				rep	movsb
				xor	eax,eax
				mov	edi,stsave
				mov	ecx,lsave1
				rep	stosb
				pop	esi
				mov	lasterror,0
				invoke	get_url,0

				pop	esi
				push	esi
				mov	edi,stsave
				cld
				mov	ecx,lsave1
				rep	movsb
				call	GlobalFree
				pop	esi
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.elseif eax=='lper'
				.while (byte ptr[esi]>32)
					inc	esi
				.endw
				.if (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
					call	getbptr
					mov	edi,ebx
					mov	ebx,eax
					assume	ebx:ptr bufstruc
					mov	ecx,[ebx]._data
					.if ecx>[ebx]._pos
						sub	ecx,[ebx]._pos
						push	ecx
						lea	ecx,[ecx+1024]
						push	ebx
						invoke	GlobalAlloc,GPTR,ecx
						pop	ebx
						mov	edi,eax
						push	edi
						push	esi
						mov	esi,[ebx]._ptr
						add	esi,[ebx]._pos
						mov	ecx,[esp+4+4+4]
						rep	movsb
						mov	al,0
						stosb
						pop	esi
						pop	edi
						mov	ecx,[esp]
						call	scr_replace		;esi,edi,ecx, returns edi+ecx, uses esi ebx
						push	edi
						mov	edx,edi
						mov	edi,[ebx]._ptr
						add	edi,[ebx]._pos
						.while ecx
							push	ecx
							push	edx
							mov	al,[edx]
							_stosb
							pop	edx
							pop	ecx
							inc	edx
							dec	ecx
						.endw
						call	GlobalFree
						pop	ecx
					.endif
					assume	ebx:nothing
				.endif
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.else
				.while (byte ptr[esi]!=13)&&(byte ptr[esi]!=10)&&(byte ptr[esi]!=0)
					inc	esi
				.endw
			.endif
		.endif
	.endw

	.if _0._ptr
		invoke	GlobalFree,_0._ptr
	.endif
	.if _1._ptr
		invoke	GlobalFree,_1._ptr
	.endif
	.if _2._ptr
		invoke	GlobalFree,_2._ptr
	.endif
	.if _3._ptr
		invoke	GlobalFree,_3._ptr
	.endif
	.if _4._ptr
		invoke	GlobalFree,_4._ptr
	.endif
	mov	edi,desturls
	.if _5._ptr
		mov	esi,_5._ptr
		.while byte ptr[esi]
			movsb
		.endw
		invoke	GlobalFree,_5._ptr
	.endif
	mov	al,0
	stosb
	.if (dltype==11)||(dltype==13)||(dltype==15)
		mov	edx,_6._ptr
		mov	tmpbuf,edx
		mov	_6._ptr,0
		mov	ecx,_6._data
		mov	fsize,ecx
		mov	dword ptr[edx+ecx],0
	.elseif (dltype==16)||(dltype==17)||(dltype==18)||(dltype==19)
		mov	edx,_6._ptr
		mov	tmpbuf,edx
		mov	ecx,_6._data
		mov	dword ptr[edx+ecx],0
		mov	eax,_6._pos
		lea	eax,[eax+edx]
		mov	tmppos,eax
		mov	_6._ptr,0
	.elseif dltype>9
		mov	edx,_6._ptr
		mov	tmpbuf,edx
		mov	_6._ptr,0
		mov	ecx,_6._data
		mov	fsize,ecx
		mov	dword ptr[edx+ecx],0
	.elseif 0
		mov	ecx,_6._data
		mov	fsize,ecx
		push	edi
		push	esi
		lea	ecx,[ecx+8192]
		invoke	GlobalAlloc,GPTR,ecx
		mov	edi,eax
		mov	edx,tmpbuf
		invoke	GlobalFree,edx
		mov	tmpbuf,edi
		mov	esi,_6._ptr
		mov	ecx,_6._data
		cld
		push	esi
		rep	movsb
		call	GlobalFree
		pop	esi
		pop	edi
	.endif
	.if _6._ptr
		invoke	GlobalFree,_6._ptr
	.endif
	mov	_0._ptr,0
	mov	_0._size,0
	mov	_0._pos,0
	mov	_1._ptr,0
	mov	_1._size,0
	mov	_1._pos,0
	mov	_2._ptr,0
	mov	_2._size,0
	mov	_2._pos,0
	mov	_3._ptr,0
	mov	_3._size,0
	mov	_3._pos,0
	mov	_4._ptr,0
	mov	_4._size,0
	mov	_4._pos,0
	mov	_5._ptr,0
	mov	_5._size,0
	mov	_5._pos,0
	mov	_6._ptr,0
	mov	_6._size,0
	mov	_6._pos,0
	ret
check_url	ENDP

savelinked	PROC	uses esi edi ebx lParam:DWORD
		.while ecx
			mov	ax,[edx]
			or	ah,20h
			.if (ax=='a<')&&(byte ptr[edx+2]<33)
				.while ecx
					mov	eax,[edx]
					.break .if al=='>'
					or	eax,20202020h
					.if (eax=='ferh')&&(ecx>4)
						sub	ecx,4
						lea	edx,[edx+4]
						.while ecx
							.break .if byte ptr[edx]>32
							inc	edx
							dec	ecx
						.endw
						.if (byte ptr[edx]=='=')&&(ecx>1)
							inc	edx
							dec	ecx
							.while ecx
								.break .if byte ptr[edx]>32
								inc	edx
								dec	ecx
							.endw
							.if ecx
								.if (byte ptr[edx]==34)||(byte ptr[edx]==39)
									inc	edx
									dec	ecx
									mov	eax,[edx]
									or	eax,20202020h
									.if (eax=='ptth')&&(byte ptr[edx+4]==':')||(byte ptr[edx+3]==':')||(byte ptr[edx+4]==':')||(byte ptr[edx+5]==':')
										invoke	link_scan,edx,ecx,1,lParam
										.while (byte ptr[edx]!='>')&&(ecx!=0)
											inc	edx
											dec	ecx
										.endw
									.endif
								.endif
							.endif
						.endif
						.break
					.endif
					inc	edx
					dec	ecx
				.endw
				.while ecx
					.break .if (dword ptr[edx]=='>A/<')||(dword ptr[edx]=='>a/<')
					inc	edx
					dec	ecx
				.endw
			.elseif al=='<'
				.while ecx
					.break .if byte ptr[edx]=='>'
					inc	edx
					dec	ecx
				.endw
				.if ecx
					.if byte ptr[edx]=='>'
						inc	edx
						dec	ecx
					.endif
				.endif
			.elseif ((al>='A')&&(al<='Z'))||((al>='a')&&(al<='z'))||((al>='0')&&(al<='9'))
				mov	eax,[edx]
				or	eax,20202020h
				.if ((eax=='ptth')||(eax=='pxxh')||(eax=='p**h')||(eax=='pttx'))&&(word ptr[edx+4]=='/:')
					invoke	link_scan,edx,ecx,0,lParam
					.while ecx
						.break .if (byte ptr[edx]=='>')||(byte ptr[edx]=='<')||(byte ptr[edx]<33)
						inc	edx
						dec	ecx
					.endw
				.elseif eax==':ptf'
					invoke	link_scan,edx,ecx,0,lParam
					.while ecx
						.break .if (byte ptr[edx]=='>')||(byte ptr[edx]=='<')||(byte ptr[edx]<33)
						inc	edx
						dec	ecx
					.endw
				.elseif (eax=='ptth')&&((byte ptr[edx+1]=='s')||(byte ptr[edx+1]=='S'))&&(word ptr[edx+5]=='/:')
					invoke	link_scan,edx,ecx,0,lParam
					.while ecx
						.break .if (byte ptr[edx]=='>')||(byte ptr[edx]=='<')||(byte ptr[edx]<33)
						inc	edx
						dec	ecx
					.endw
				.elseif (eax=='uhcd')&&((byte ptr[edx+1]=='b')||(byte ptr[edx+1]=='B'))&&(word ptr[edx+5]=='/:')
					invoke	link_scan,edx,ecx,0,lParam
					.while ecx
						.break .if (byte ptr[edx]=='>')||(byte ptr[edx]=='<')||(byte ptr[edx]<33)
						inc	edx
						dec	ecx
					.endw
				.elseif eax==':dca'
					invoke	link_scan,edx,ecx,0,lParam
					.while ecx
						.break .if (byte ptr[edx]=='>')||(byte ptr[edx]=='<')||(byte ptr[edx]<33)
						inc	edx
						dec	ecx
					.endw
				.elseif ((word ptr[edx]=='/:')&&(byte ptr[edx+2]=='/'))||((word ptr[edx+1]=='/:')&&(byte ptr[edx+3]=='/'))
					invoke	link_scan,edx,ecx,0,lParam
					.while ecx
						.break .if (byte ptr[edx]=='>')||(byte ptr[edx]=='<')||(byte ptr[edx]<33)
						inc	edx
						dec	ecx
					.endw
				.elseif ((word ptr[edx+2]=='/:')&&(byte ptr[edx+4]=='/'))||((word ptr[edx+3]=='/:')&&(byte ptr[edx+5]=='/'))||((word ptr[edx+4]=='/:')&&(byte ptr[edx+6]=='/'))
					invoke	link_scan,edx,ecx,0,lParam
					.while ecx
						.break .if (byte ptr[edx]=='>')||(byte ptr[edx]=='<')||(byte ptr[edx]<33)
						inc	edx
						dec	ecx
					.endw
				.else
					push	0
					xor	eax,eax
					.while (byte ptr[edx+eax]>='0')||(byte ptr[edx+eax]=='.')||(byte ptr[edx+eax]=='/')||(byte ptr[edx+eax]=='&')||(byte ptr[edx+eax]==';')||(byte ptr[edx+eax]=='#')||(byte ptr[edx+eax]=='-')
						.if byte ptr[edx+eax]>'z'
							mov	dword ptr[esp],0
							.break
						.elseif (byte ptr[edx+eax]=='<')||(byte ptr[edx+eax]=='>')||(byte ptr[edx+eax]=='=')
							mov	dword ptr[esp],0
							.break
						.elseif (byte ptr[edx+eax]=='[')||(byte ptr[edx+eax]==']')||(byte ptr[edx+eax]=='|')
							mov	dword ptr[esp],0
							.break
						.elseif (byte ptr[edx+eax]=='(')||(byte ptr[edx+eax]==')')||(byte ptr[edx+eax]=='*')
							mov	dword ptr[esp],0
							.break
						.elseif (byte ptr[edx+eax]==34)||(byte ptr[edx+eax]==39)||(byte ptr[edx+eax]=='\')
							mov	dword ptr[esp],0
							.break
						.elseif word ptr[edx+eax]=='..'
							mov	dword ptr[esp],0
							.break
						.elseif byte ptr[edx+eax]=='.'
							inc	dword ptr[esp]
							.break .if dword ptr[esp]>3
						.elseif (byte ptr[edx+eax]=='/')||((byte ptr[edx+eax]<33)&&(lParam!=0))
							.break .if dword ptr[esp]==0
							invoke	link_scan,edx,ecx,0,lParam
							.while ecx
								.break .if (byte ptr[edx]=='>')||(byte ptr[edx]=='<')||(byte ptr[edx]<33)
								inc	edx
								dec	ecx
							.endw
							mov	dword ptr[esp],0
							.break
						.elseif byte ptr[edx+eax]<33
							mov	dword ptr[esp],0
							.break
						.endif
						inc	eax
					.endw
					.if dword ptr[esp]
						invoke	link_scan,edx,ecx,0,lParam
						.while ecx
							.break .if (byte ptr[edx]=='>')||(byte ptr[edx]=='<')||(byte ptr[edx]<33)
							inc	edx
							dec	ecx
						.endw
					.endif
					pop	eax
					.while ecx
						.break .if (byte ptr[edx]=='>')||(byte ptr[edx]=='<')||(byte ptr[edx]<'0')||(byte ptr[edx]==':')||(byte ptr[edx]=='/')||(byte ptr[edx]=='\')
						inc	edx
						dec	ecx
					.endw
				.endif
			.else
				dec	ecx
				inc	edx
			.endif
		.endw
	ret
savelinked	ENDP

nline	db	13,10,0
link_scan	PROC	uses esi edi ecx edx ebx src_:DWORD,size_:DWORD,ishref:DWORD,lParam:DWORD
	invoke	GlobalAlloc,GPTR,8192
	push	eax
	mov	edi,eax
	mov	ecx,size_
	mov	edx,src_
	mov	eax,[edx]
	or	eax,20202020h
	.if (eax=='uhcd')&&((byte ptr[edx+4]=='b')||(byte ptr[edx+4]=='B'))&&(ecx>5)&&(byte ptr[edx+6]==':')
		lea	edx,[edx+5]
		sub	ecx,5
		mov	eax,'uhcd'
		stosd
		mov	al,'b'
		stosb
		mov	al,':'
		stosb
		inc	edx
		.while (byte ptr[edx]=='/')||(byte ptr[edx]=='\')
			inc	edx
		.endw
		mov	ax,'//'
		stosw
	.elseif (eax=='ptth')&&((byte ptr[edx+4]=='s')||(byte ptr[edx+4]=='S'))&&(ecx>5)&&(byte ptr[edx+5]==':')
		lea	edx,[edx+5]
		sub	ecx,5
		mov	eax,'ptth'
		stosd
		mov	al,'s'
		stosb
		mov	al,':'
		stosb
		inc	edx
		.while (byte ptr[edx]=='/')||(byte ptr[edx]=='\')
			inc	edx
		.endw
		mov	ax,'//'
		stosw
	.elseif ((eax==':ptf')||(eax==':cda'))&&(ecx>4)
		mov	eax,[edx]
		lea	edx,[edx+4]
		sub	ecx,4
		stosd
		.while (byte ptr[edx]=='/')||(byte ptr[edx]=='\')
			inc	edx
		.endw
		mov	ax,'//'
		stosw
	.elseif ((word ptr[edx]=='/:')&&(byte ptr[edx+2]=='/'))
		mov	eax,'ptth'
		stosd
		mov	al,':'
		stosb
		inc	edx
		.while (byte ptr[edx]=='/')||(byte ptr[edx]=='\')
			inc	edx
		.endw
		mov	ax,'//'
		stosw
	.elseif ((word ptr[edx+1]=='/:')&&(byte ptr[edx+3]=='/'))&&(ecx>3)
		mov	eax,'ptth'
		stosd
		inc	edx
		mov	al,':'
		stosb
		inc	edx
		.while (byte ptr[edx]=='/')||(byte ptr[edx]=='\')
			inc	edx
		.endw
		mov	ax,'//'
		stosw
	.elseif ((word ptr[edx+2]=='/:')&&(byte ptr[edx+4]=='/'))&&(ecx>3)
		mov	eax,'ptth'
		stosd
		inc	edx
		inc	edx
		mov	al,':'
		stosb
		inc	edx
		.while (byte ptr[edx]=='/')||(byte ptr[edx]=='\')
			inc	edx
		.endw
		mov	ax,'//'
		stosw
	.elseif ((word ptr[edx+3]=='/:')&&(byte ptr[edx+5]=='/'))&&(ecx>4)
		mov	eax,'ptth'
		stosd
		lea	edx,[edx+3]
		mov	al,':'
		stosb
		inc	edx
		.while (byte ptr[edx]=='/')||(byte ptr[edx]=='\')
			inc	edx
		.endw
		mov	ax,'//'
		stosw
	.elseif ((word ptr[edx+4]=='/:')&&(byte ptr[edx+6]=='/'))&&(ecx>5)
		mov	eax,'ptth'
		stosd
		lea	edx,[edx+4]
		mov	al,':'
		stosb
		inc	edx
		.while (byte ptr[edx]=='/')||(byte ptr[edx]=='\')
			inc	edx
		.endw
		mov	ax,'//'
		stosw
	.elseif (eax=='ptth')&&(dword ptr[edx+4]=='85#&')&&(byte ptr[edx+8]==';')&&(ecx>9)
		lea	edx,[edx+9]
		sub	ecx,9
		mov	eax,'ptth'
		stosd
		mov	al,':'
		stosb
		.while (byte ptr[edx]=='/')||(byte ptr[edx]=='\')
			inc	edx
		.endw
		mov	ax,'//'
		stosw
	.else
		mov	eax,'ptth'
		stosd
		mov	eax,'//:'
		stosd
		dec	edi
	.endif

	.if ishref
		mov	ebx,8000
		.while ecx
			.break .if (byte ptr[edx]==39)||(byte ptr[edx]==34)||(byte ptr[edx]=='<')||(byte ptr[edx]=='>')
			mov	al,[edx]
			.if (al=='&')&&(ecx>4)
				mov	eax,[edx+1]
				or	eax,20202020h
				.if eax==';pma'
_s_amp:					lea	edx,[edx+4]
					sub	ecx,4
					mov	al,'&'
					.if (dword ptr[edx+1]!=';pma')||(ecx<5)
						stosb
						dec	ebx
						.break .if ebx==0
					.else
						jmp	_s_amp
					.endif
				.elseif (eax=='psbn')&&(byte ptr[edx+1+4]==';')&&(ecx>5)
					mov	al,32
					stosb
					dec	ebx
					.break .if ebx==0
					lea	edx,[edx+5]
					sub	ecx,5
				.elseif (((ax=='tl')||(ax=='tg'))&&(byte ptr[edx+1+2]==';'))||(((eax=='touq')||(eax=='sopa'))&&(byte ptr[edx+1+4]==';'))
					call	GlobalFree
					ret
				.else
					mov	al,'&'
					stosb
					dec	ebx
					.break .if ebx==0
				.endif
			.elseif (al!='*')
				stosb
				dec	ebx
				.break .if ebx==0
			.endif
			inc	edx
			dec	ecx
		.endw
		.if ebx<4000
			call	GlobalFree
			ret
		.endif
	.else
		mov	ebx,8000
		push	edi
		.while ecx
			.break .if (byte ptr[edx]<33)||(byte ptr[edx]=='<')||(byte ptr[edx]=='>')
			.break .if (byte ptr[edx]==34)||(byte ptr[edx]==39)
			.if (byte ptr[edx]=='(')||(byte ptr[edx]==')')||(byte ptr[edx]=='[')||(byte ptr[edx]==']')||(byte ptr[edx]=='{')||(byte ptr[edx]=='}')||(byte ptr[edx]>'z')
				pop	edi
				call	GlobalFree
				ret
			.endif
			mov	al,[edx]
			.if (al=='&')&&(ecx>4)
				mov	eax,[edx+1]
				or	eax,20202020h
				.if eax==';pma'
_s_amp1:				lea	edx,[edx+4]
					sub	ecx,4
					mov	al,'&'
					.if (dword ptr[edx+1]!=';pma')||(ecx<5)
						stosb
						dec	ebx
						.break .if ebx==0
					.else
						jmp	_s_amp1
					.endif
				.elseif (eax=='psbn')&&(byte ptr[edx+1+4]==';')&&(ecx>5)
					mov	al,32
					stosb
					dec	ebx
					.break .if ebx==0
					lea	edx,[edx+5]
					sub	ecx,5
				.elseif (((ax=='tl')||(ax=='tg'))&&(byte ptr[edx+1+2]==';'))||(((eax=='touq')||(eax=='sopa'))&&(byte ptr[edx+1+4]==';'))
					pop	edi
					call	GlobalFree
					ret
				.else
					mov	al,'&'
					stosb
					dec	ebx
					.break .if ebx==0
				.endif
			.elseif (al!='*')
				stosb
				dec	ebx
				.break .if ebx==0
			.endif
			inc	edx
			dec	ecx
		.endw
		mov	byte ptr[edi],0
		pop	ecx
		xor	eax,eax
		push	ecx
		push	ecx
		.while (byte ptr[ecx]!=0)&&(byte ptr[ecx]!='/')&&(byte ptr[ecx]!='\')
			.if byte ptr[ecx]=='.'
				inc	eax
				mov	[esp],ecx
			.elseif (byte ptr[ecx]>='0')&&(byte ptr[ecx]<='9')
			.elseif (byte ptr[ecx]>='A')&&(byte ptr[ecx]<='Z')
			.elseif (byte ptr[ecx]>='a')&&(byte ptr[ecx]<='z')
			.elseif byte ptr[ecx]=='-'
			.else
				xor	ebx,ebx
				.break
			.endif
			inc	ecx
		.endw
		pop	ecx
		.if eax==0
			xor	ebx,ebx
		.elseif byte ptr[ecx]=='.'
			inc	ecx
			.if (byte ptr[ecx]>='0')&&(byte ptr[ecx]<='9')
				.while (byte ptr[ecx]>='0')&&(byte ptr[ecx]<='9')
					inc	ecx
				.endw
				.if (byte ptr[ecx]!=0)&&(byte ptr[ecx]!='/')&&(byte ptr[ecx]!='\')
					xor	ebx,ebx
				.elseif ebx
					mov	eax,[esp]
					push	esi
					push	ebx
					push	edx
					mov	ebx,eax
					call	is_ip
					pop	edx
					pop	ebx
					pop	esi
					.if eax==0
						xor	ebx,ebx
					.endif
				.endif
			.elseif ((byte ptr[ecx]>='A')&&(byte ptr[ecx]<='Z'))||((byte ptr[ecx]>='a')&&(byte ptr[ecx]<='z'))
				.while ((byte ptr[ecx]>='A')&&(byte ptr[ecx]<='Z'))||((byte ptr[ecx]>='a')&&(byte ptr[ecx]<='z'))
					inc	ecx
				.endw
				.if (byte ptr[ecx]!=0)&&(byte ptr[ecx]!='/')&&(byte ptr[ecx]!='\')
					xor	ebx,ebx
				.endif
			.else
				xor	ebx,ebx
			.endif
		.endif
		pop	ecx
		.if ebx<4000
			call	GlobalFree
			ret
		.endif
	.endif
	.while (edi>dword ptr[esp])&&((byte ptr[edi-1]<33)||(byte ptr[edi-1]==',')||(byte ptr[edi-1]=='.')||(byte ptr[edi-1]=='&')||(byte ptr[edi-1]=='?')||(byte ptr[edi-1]==';'))
		dec	edi
	.endw
	.if (edi>dword ptr[esp])
		.if byte ptr[edi-1]==')'
			lea	edx,[edi-1]
			.while edx>dword ptr[esp]
				.if byte ptr[edx-1]=='('
					jmp	_link_1
				.endif
				dec	edx
			.endw
			dec	edi
		.elseif (byte ptr[edi-1]==']')
			lea	edx,[edi-1]
			.while edx>dword ptr[esp]
				.if byte ptr[edx-1]=='['
					jmp	_link_1
				.endif
				dec	edx
			.endw
			dec	edi
		.elseif (byte ptr[edi-1]=='}')
			lea	edx,[edi-1]
			.while edx>dword ptr[esp]
				.if byte ptr[edx-1]=='{'
					jmp	_link_1
				.endif
				dec	edx
			.endw
			dec	edi
		.elseif (byte ptr[edi-1]=='�')
			lea	edx,[edi-1]
			.while edx>dword ptr[esp]
				.if byte ptr[edx-1]=='�'
					jmp	_link_1
				.endif
				dec	edx
			.endw
			dec	edi
		.endif
	.endif
_link_1:mov	al,0
	stosb
	mov	edi,[esp]
	mov	edx,edi
	mov	eax,[edx]
	or	eax,20202020h
	.if (eax=='ptth')&&(word ptr[edx+4]=='/:')&&(byte ptr[edx+6]=='/')
		.if (word ptr[edx+7]=='/:')||(word ptr[edx+8]=='/:')||(word ptr[edx+9]=='/:')||(word ptr[edx+10]=='/:')||(word ptr[edx+11]=='/:')||(word ptr[edx+12]=='/:')
			lea	edx,[edx+7]
		.endif
	.endif
	.while (word ptr[edx]!='/:')&&(byte ptr[edx]!=0)
		mov	al,[edx]
		stosb
		inc	edx
	.endw
	.if byte ptr[edx]
		mov	ax,[edx]
		stosw
		inc	edx
		inc	edx
		.while (byte ptr[edx]!='/')&&(byte ptr[edx]!='\')&&(byte ptr[edx]!=0)
			mov	al,[edx]
_link_2:		.if (al=='(')||(al==')')||(al=='[')||(al==']')||(al=='{')||(al=='}')
				mov	edi,[esp]
				mov	byte ptr[edi],0
				mov	edx,edi
				.break
			.elseif (al=='!')
			.elseif (al=='?')||(al=='#')||(al==',')||(al==';')
				.break
			.elseif (al=='%')
				inc	edx
				.if ((byte ptr[edx]<='9')&&(byte ptr[edx]>='0'))||((byte ptr[edx]<='F')&&(byte ptr[edx]>='A'))||((byte ptr[edx]<='f')&&(byte ptr[edx]>='a'))
					inc	edx
					.if ((byte ptr[edx]<='9')&&(byte ptr[edx]>='0'))||((byte ptr[edx]<='F')&&(byte ptr[edx]>='A'))||((byte ptr[edx]<='f')&&(byte ptr[edx]>='a'))
						mov	ax,[edx-1]
						.if al>'F'
							sub	al,32
						.endif
						.if ah>'F'
							sub	ah,32
						.endif
						.if al>'9'
							sub	al,7
						.endif
						.if ah>'9'
							sub	ah,7
						.endif
						shl	al,4
						and	ax,0ff0h
						or	al,ah
						.if al>32
							jmp	_link_2
						.else
							mov	edi,[esp]
							mov	byte ptr[edi],0
							mov	edx,edi
							.break
						.endif
					.else
						mov	edi,[esp]
						mov	byte ptr[edi],0
						mov	edx,edi
						.break
					.endif
				.else
					mov	edi,[esp]
					mov	byte ptr[edi],0
					mov	edx,edi
					.break
				.endif
			.elseif (al=='$')||(al=='*')||(al=='=')||(al=='|')||(word ptr[edx]=='..')
				mov	edi,[esp]
				mov	byte ptr[edi],0
				mov	edx,edi
				.break
			.else
				stosb
			.endif
			inc	edx
		.endw
	.endif
	.while (byte ptr[edx]!=0)&&(byte ptr[edx]!='#')
		mov	al,[edx]
		stosb
		inc	edx
	.endw
	mov	al,0
	stosb
	inc	eax
	mov	esi,[esp]
	.if lParam
		mov	edi,lParam
		.while byte ptr[edi]
			inc	edi
		.endw
		mov	ax,0a0dh
		stosw
		mov	edx,[esp]
		call	copyedx
		mov	al,0
		stosb
	.else
	.if byte ptr[esi]
		call	is_internal
	.endif
	.if eax==0
		call	isbanneddns
		.if eax
			call	GlobalFree
			ret
		.endif
		.if extsave!=4
			mov	edx,esi
			call	is_saved2
			.if eax
				call	GlobalFree
				ret
			.endif
		.endif
		idx_addlink
		idx_savelinkstart
		.if extsave<=4
			.if extsave==4
				invoke	get_att,3
				.if eax==0
					call	GlobalFree
					idx_savelinkend
					ret
				.endif
			.endif
			xor	ecx,ecx
			.while byte ptr[esi+ecx]
				inc	ecx
			.endw
			mov	dword ptr[esi+ecx],0a0dh
			invoke	SendDlgItemMessage,hDialog,2100,WM_GETTEXTLENGTH,0,0
			push	eax
			invoke	SendDlgItemMessage,hDialog,2100,EM_GETLIMITTEXT,0,0
			mov	edx,[esp]
			sub	eax,edx
			.if (eax&80000000h)||(eax<8192)
				lea	edx,[edx+32768]
				invoke	SendDlgItemMessage,hDialog,2100,EM_SETLIMITTEXT,edx,0
			.endif
			pop	eax
			push	eax
			invoke	SendDlgItemMessage,hDialog,2100,EM_LINEFROMCHAR,eax,0
			invoke	SendDlgItemMessage,hDialog,2100,EM_LINEINDEX,eax,0
			pop	edx
			.if eax!=edx
				invoke	SendDlgItemMessage,hDialog,2100,EM_SETSEL,edx,edx
				invoke	SendDlgItemMessage,hDialog,2100,EM_REPLACESEL,0,addr nline
				invoke	SendDlgItemMessage,hDialog,2100,WM_GETTEXTLENGTH,0,0
				mov	edx,eax
			.endif
			invoke	SendDlgItemMessage,hDialog,2100,EM_SETSEL,edx,edx
			invoke	SendDlgItemMessage,hDialog,2100,EM_REPLACESEL,0,esi
			.if extsave>2
				lea	edi,buftmp
				lea	edx,fsavedir
				call	copyedx
				.if byte ptr[edi-1]!='\'
					mov	al,'\'
					stosb
				.endif
				mov	eax,'knil'
				stosd
				mov	eax,'xt.s'
				stosd
				mov	ax,'t'
				stosw
				invoke	CreateFile,addr buftmp,GENERIC_READ or GENERIC_WRITE,FILE_SHARE_READ,0,OPEN_EXISTING,0,0
				.if eax==INVALID_HANDLE_VALUE
					invoke	CreateFile,addr buftmp,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0
				.else
					push	eax
					invoke	SetFilePointer,eax,0,0,FILE_END
					pop	eax
				.endif
				push	eax
				xor	ecx,ecx
				.while byte ptr[esi+ecx]
					inc	ecx
				.endw
				invoke	WriteFile,eax,esi,ecx,addr bread,0
				call	CloseHandle
			.endif
			call	GlobalFree
			idx_savelinkend
			ret
		.else
			invoke	GlobalAlloc,GPTR,65536
			mov	desturls,eax
			mov	byte ptr[eax],0
			mov	lasterror,0
			invoke	get_url,0
			invoke	GlobalFree,desturls
			mov	desturls,0
		.endif
		pop	esi
		push	esi
		xor	ecx,ecx
		.while byte ptr[esi+ecx]
			inc	ecx
		.endw
		mov	dword ptr[esi+ecx],0a0dh
		lea	edi,buftmp
		lea	edx,fsavedir
		call	copyedx
		.if byte ptr[edi-1]!='\'
			mov	al,'\'
			stosb
		.endif
		mov	eax,'knil'
		stosd
		mov	eax,'xt.s'
		stosd
		mov	ax,'t'
		stosw
		invoke	CreateFile,addr buftmp,GENERIC_READ or GENERIC_WRITE,FILE_SHARE_READ,0,OPEN_EXISTING,0,0
		.if eax==INVALID_HANDLE_VALUE
			invoke	CreateFile,addr buftmp,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0
		.else
			push	eax
			invoke	SetFilePointer,eax,0,0,FILE_END
			pop	eax
		.endif
		push	eax
		xor	ecx,ecx
		.while byte ptr[esi+ecx]
			inc	ecx
		.endw
		invoke	WriteFile,eax,esi,ecx,addr bread,0
		call	CloseHandle
		idx_savelinkend
	.endif
	.endif
	call	GlobalFree
	ret
link_scan	ENDP

include	scrparse.h
endm

forumindexdownload	macro
	push	edi
	push	esi
	mov	desturls,0
	mov	lasterror,0
	lea	esi,[edi]._addr
	mov	dltype,10
	mov	edx,recvbuf
	mov	tmpbuf,edx
	invoke	get_url,0
	mov	edx,tmpbuf
	mov	recvbuf,edx
	mov	dltype,1
	pop	esi
	pop	edi
	.if desturls
		invoke	GlobalFree,desturls
		mov	desturls,0
	.endif
endm

forumindexdownloadcomplete	macro
	push	esi
	push	edi
	mov	desturls,0
	mov	lasterror,0
	lea	esi,[edi]._addr
	mov	dltype,11
	mov	edx,recvbuf
	mov	tmpbuf,edx
	invoke	get_url,0
	mov	edx,tmpbuf
	mov	recvbuf,edx
	mov	dltype,1
	pop	edi
	pop	esi
	.if desturls
		invoke	GlobalFree,desturls
		mov	desturls,0
	.endif
endm

indexdownload	macro
	assume	edi:ptr foruminfo
	push	edi
	push	esi
	mov	tmppos,0
	mov	desturls,0
	mov	lasterror,0
	lea	esi,[edi]._addr
	mov	dltype,12
	mov	edx,r_buf
	mov	tmpbuf,edx
	invoke	get_url,0
	mov	edx,tmpbuf
	mov	r_buf,edx
	mov	dltype,1
	pop	esi
	pop	edi
	.if desturls
		invoke	GlobalFree,desturls
		mov	desturls,0
	.endif
endm

indexdownloadcomplete	macro
	assume	edi:ptr foruminfo
	push	esi
	push	edi
	mov	desturls,0
	mov	lasterror,0
	mov	edi,lParam
	lea	esi,[edi]._addr
	mov	dltype,13
	mov	edx,r_buf
	mov	tmpbuf,edx
	invoke	get_url,0
	mov	edx,tmpbuf
	mov	r_buf,edx
	mov	dltype,1
	pop	edi
	pop	esi
	.if desturls
		invoke	GlobalFree,desturls
		mov	desturls,0
	.endif
endm

topicdownload	macro
	assume	edi:ptr foruminfo
	push	edi
	push	esi
	mov	desturls,0
	mov	lasterror,0
	lea	esi,[edi]._addr
	mov	dltype,14
	mov	edx,r_buf
	mov	tmpbuf,edx
	invoke	get_url,0
	mov	edx,tmpbuf
	mov	r_buf,edx
	mov	dltype,1
	pop	esi
	pop	edi
	.if desturls
		invoke	GlobalFree,desturls
		mov	desturls,0
	.endif
endm

topicdownloadcomplete	macro
	assume	edi:ptr foruminfo
	push	esi
	push	edi
	mov	desturls,0
	mov	lasterror,0
	lea	esi,[edi]._addr
	mov	dltype,15
	mov	edx,r_buf
	mov	tmpbuf,edx
	invoke	get_url,0
	mov	edx,tmpbuf
	mov	r_buf,edx
	mov	dltype,1
	pop	edi
	pop	esi
	.if desturls
		invoke	GlobalFree,desturls
		mov	desturls,0
	.endif
endm

indexnextpagesearch	macro
	assume	edi:ptr foruminfo
	push	edi
	mov	desturls,0
	mov	lasterror,0
	mov	tmppos,esi
	lea	esi,[edi]._addr
	mov	dltype,16
	mov	edx,r_buf
	mov	tmpbuf,edx
	mov	labelex,0
	invoke	get_url,0
	mov	edx,tmpbuf
	mov	r_buf,edx
	mov	dltype,1
	pop	edi
	mov	esi,tmppos
	.if desturls
		invoke	GlobalFree,desturls
		mov	desturls,0
	.endif
endm

topicnextpagesearch	macro
	assume	edi:ptr foruminfo
	push	edi
	mov	desturls,0
	mov	lasterror,0
	mov	tmppos,esi
	lea	esi,[edi]._addr
	mov	dltype,17
	mov	edx,r_buf
	mov	tmpbuf,edx
	mov	labelex,0
	invoke	get_url,0
	mov	edx,tmpbuf
	mov	r_buf,edx
	mov	dltype,1
	pop	edi
	mov	esi,tmppos
	.if desturls
		invoke	GlobalFree,desturls
		mov	desturls,0
	.endif
endm

forumsearch	macro
	assume	edi:ptr foruminfo
	push	esi
	push	edi
	mov	desturls,0
	mov	lasterror,0
	mov	tmppos,esi
	lea	esi,[edi]._addr
	mov	dltype,18
	mov	edx,initbuf
	mov	edx,[edx]
	mov	tmpbuf,edx
	mov	labelex,0
	mov	labelex,0
	invoke	get_url,0
	mov	edx,tmpbuf
	mov	eax,initbuf
	mov	[eax],edx
	mov	dltype,1
	pop	edi
	pop	esi
	.if labelex
		mov	esi,tmppos
	.endif
	.if desturls
		invoke	GlobalFree,desturls
		mov	desturls,0
	.endif
endm

topicsearch	macro
	assume	edi:ptr foruminfo
	push	esi
	push	edi
	mov	desturls,0
	mov	lasterror,0
	mov	tmppos,esi
	lea	esi,[edi]._addr
	mov	dltype,19
	mov	edx,initbuf
	mov	edx,[edx]
	mov	tmpbuf,edx
	mov	labelex,0
	invoke	get_url,0
	mov	edx,tmpbuf
	mov	eax,initbuf
	mov	[eax],edx
	mov	dltype,1
	pop	edi
	pop	esi
	.if labelex
		mov	esi,tmppos
	.endif
	.if desturls
		invoke	GlobalFree,desturls
		mov	desturls,0
	.endif
endm
