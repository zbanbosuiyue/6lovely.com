maxerrs=10
SehHandler	PROTO	:DWORD

SEHdata	macro
	hKernel		dd	?
	CreateToolhelp32Snapshot_ dd	?
	Module32First_	dd	?
	Module32Next_	dd	?
	extimer		dd	?
	exceptions	db	?
endm

SEHinit	macro
	mov	exceptions,0
	mov	hKernel,0
	mov	CreateToolhelp32Snapshot_,0
	invoke	SetUnhandledExceptionFilter,addr SehHandler
endm

seh_procs	macro
_kernel	db	'kernel32.dll',0
_CreateToolhelp32Snapshot db	'CreateToolhelp32Snapshot',0
_Module32First	db	'Module32First',0
_Module32Next	db	'Module32Next',0
bfe	db	'BIG FUCKING ERROR ',0
excode	db	13,10,9,'ExceptionCode: ',0
exaddr	db	13,10,9,'Address: ',0
excaus	db	13,10,9,'Cause: ',0
exread	db	'Read from address: ',0
exwrit	db	'Write to address: ',0
expara	db	13,10,9,'Parameters: ',0
exmod	db	13,10,9,'Module: ',0
exres1	db	13,10,9,'Attempting to recover from error...',0
exres2	db	13,10,9,'Cannot recover from this error, the hub must be restarted',0
exres3	db	13,10,9,'Attempting to terminate the thread that caused this error...',0
eroare1	db	'EXCEPTION_ACCESS_VIOLATION',0
eroare2	db	'EXCEPTION_ARRAY_BOUNDS_EXCEEDED',0
eroare3	db	'EXCEPTION_BREAKPOINT',0
eroare4	db	'EXCEPTION_DATATYPE_MISALIGNMENT',0
eroare5	db	'EXCEPTION_FLT_DENORMAL_OPERAND',0
eroare6	db	'EXCEPTION_FLT_DIVIDE_BY_ZERO',0
eroare7	db	'EXCEPTION_FLT_INEXACT_RESULT',0
eroare8	db	'EXCEPTION_FLT_INVALID_OPERATION',0
eroare9	db	'EXCEPTION_FLT_OVERFLOW',0
eroare10 db	'EXCEPTION_FLT_STACK_CHECK',0
eroare11 db	'EXCEPTION_FLT_UNDERFLOW',0
eroare12 db	'EXCEPTION_ILLEGAL_INSTRUCTION',0
eroare13 db	'EXCEPTION_IN_PAGE_ERROR',0
eroare14 db	'EXCEPTION_INT_DIVIDE_BY_ZERO',0
eroare15 db	'EXCEPTION_INT_OVERFLOW',0
eroare16 db	'EXCEPTION_INVALID_DISPOSITION',0
eroare17 db	'EXCEPTION_NONCONTINUABLE',0
eroare18 db	'EXCEPTION_PRIV_INSTRUCTION',0
eroare19 db	'EXCEPTION_SINGLE_STEP',0
eroare20 db	'EXCEPTION_STACK_OVERFLOW',0

opc_table:
	db	-1	;00
	db	-1	;01
	db	-1	;02
	db	-1	;03
	db	-1	;04
	db	5	;05
	db	1	;06
	db	1	;07
	db	-1	;08
	db	-1	;09
	db	-1	;0a
	db	-1	;0b
	db	-1	;0c
	db	5	;0d
	db	1	;0e
	db	-2	;0f
	db	-1	;10
	db	-1	;11
	db	-1	;12
	db	-1	;13
	db	-1	;14
	db	5	;15
	db	1	;16
	db	1	;17
	db	-1	;18
	db	-1	;19
	db	-1	;1a
	db	-1	;1b
	db	-1	;1c
	db	5	;1d
	db	1	;1e
	db	1	;1f
	db	-1	;20
	db	-1	;21
	db	-1	;22
	db	-1	;23
	db	-1	;24
	db	5	;25
	db	1	;26
	db	1	;27
	db	-1	;28
	db	-1	;29
	db	-1	;2a
	db	-1	;2b
	db	-1	;2c
	db	5	;2d
	db	1	;2e
	db	1	;2f
	db	-1	;30
	db	-1	;31
	db	-1	;32
	db	-1	;33
	db	-1	;34
	db	5	;35
	db	1	;36
	db	1	;37
	db	-1	;38
	db	-1	;39
	db	-1	;3a
	db	-1	;3b
	db	-1	;3c
	db	5	;3d
	db	1	;3e
	db	1	;3f
	db	1	;40
	db	1	;41
	db	1	;42
	db	1	;43
	db	1	;44
	db	1	;45
	db	1	;46
	db	1	;47
	db	1	;48
	db	1	;49
	db	1	;4a
	db	1	;4b
	db	1	;4c
	db	1	;4d
	db	1	;4e
	db	1	;4f
	db	1	;50
	db	1	;51
	db	1	;52
	db	1	;53
	db	1	;54
	db	1	;55
	db	1	;56
	db	1	;57
	db	1	;58
	db	1	;59
	db	1	;5a
	db	1	;5b
	db	1	;5c
	db	1	;5d
	db	1	;5e
	db	1	;5f
	db	1	;60
	db	1	;61
	db	-1	;62
	db	-1	;63
	db	1	;64
	db	1	;65
	db	1	;66
	db	1	;67
	db	5	;68
	db	-3	;69 imm32+modrm
	db	2	;6a
	db	-4	;6b imm8+modrm
	db	1	;6c
	db	1	;6d
	db	1	;6e
	db	1	;6f
	db	2	;70
	db	2	;71
	db	2	;72
	db	2	;73
	db	2	;74
	db	2	;75
	db	2	;76
	db	2	;77
	db	2	;78
	db	2	;79
	db	2	;7a
	db	2	;7b
	db	2	;7c
	db	2	;7d
	db	2	;7e
	db	2	;7f
	db	-4	;80
	db	-3	;81
	db	-4	;82
	db	-4	;83
	db	-1	;84
	db	-1	;85
	db	-1	;86
	db	-1	;87
	db	-1	;88
	db	-1	;89
	db	-1	;8a
	db	-1	;8b
	db	-1	;8c
	db	-1	;8d
	db	-1	;8e
	db	-1	;8f
	db	1	;90
	db	1	;91
	db	1	;92
	db	1	;93
	db	1	;94
	db	1	;95
	db	1	;96
	db	1	;97
	db	1	;98
	db	1	;99
	db	7	;9a
	db	1	;9b
	db	1	;9c
	db	1	;9d
	db	1	;9e
	db	1	;9f
	db	5	;a0
	db	5	;a1
	db	5	;a2
	db	5	;a3
	db	1	;a4
	db	1	;a5
	db	1	;a6
	db	1	;a7
	db	2	;a8
	db	5	;a9
	db	1	;aa
	db	1	;ab
	db	1	;ac
	db	1	;ad
	db	1	;ae
	db	1	;af
	db	2	;b0
	db	2	;b1
	db	2	;b2
	db	2	;b3
	db	2	;b4
	db	2	;b5
	db	2	;b6
	db	2	;b7
	db	5	;b8
	db	5	;b9
	db	5	;ba
	db	5	;bb
	db	5	;bc
	db	5	;bd
	db	5	;be
	db	5	;bf
	db	-4	;c0
	db	-4	;c1
	db	3	;c2
	db	1	;c3
	db	-1	;c4
	db	-1	;c5
	db	-4	;c6
	db	-3	;c7
	db	4	;c8
	db	1	;c9
	db	3	;ca
	db	1	;cb
	db	1	;cc
	db	2	;cd
	db	1	;ce
	db	1	;cf
	db	2	;d0
	db	-1	;d1
	db	-1	;d2
	db	-1	;d3
	db	2	;d4
	db	2	;d5
	db	1	;d6
	db	1	;d7
	db	-1	;d8
	db	-1	;d9
	db	-1	;da
	db	-1	;db
	db	-1	;dc
	db	-1	;dd
	db	-1	;de
	db	-1	;df
	db	2	;e0
	db	2	;e1
	db	2	;e2
	db	2	;e3
	db	2	;e4
	db	2	;e5
	db	2	;e6
	db	2	;e7
	db	5	;e8
	db	5	;e9
	db	7	;ea
	db	2	;eb
	db	1	;ec
	db	1	;ed
	db	1	;ee
	db	1	;ef
	db	1	;f0
	db	1	;f1
	db	1	;f2
	db	1	;f3
	db	1	;f4
	db	1	;f5
	db	-4	;f6
	db	-1	;f7
	db	1	;f8
	db	1	;f9
	db	1	;fa
	db	1	;fb
	db	1	;fc
	db	1	;fd
	db	-1	;fe
	db	-1	;ff

opc_0f	db	-1	;00
	db	-1	;01
	db	-1	;02
	db	-1	;03
	db	2	;04 n/a
	db	2	;05
	db	2	;06
	db	2	;07
	db	2	;08
	db	2	;09
	db	2	;0a
	db	2	;0b
	db	2	;0c
	db	2	;0d
	db	2	;0e
	db	2	;0f
	db	2	;10 n/a
	db	2	;11 n/a
	db	2	;12 n/a
	db	2	;13 n/a
	db	2	;14 n/a
	db	2	;15 n/a
	db	2	;16 n/a
	db	2	;17 n/a
	db	2	;18 n/a
	db	2	;19 n/a
	db	2	;1a n/a
	db	2	;1b n/a
	db	2	;1c n/a
	db	2	;1d n/a
	db	2	;1e n/a
	db	2	;1f n/a
	db	3	;20
	db	3	;21
	db	3	;22
	db	3	;23
	db	3	;24
	db	2	;25 n/a
	db	3	;26
	db	2	;27 n/a
	db	2	;28 n/a
	db	2	;29 n/a
	db	2	;2a n/a
	db	2	;2b n/a
	db	2	;2c n/a
	db	2	;2d n/a
	db	2	;2e n/a
	db	2	;2f n/a
	db	2	;30
	db	2	;31
	db	2	;32
	db	2	;33
	db	2	;34 n/a
	db	2	;35 n/a
	db	2	;36 n/a
	db	2	;37 n/a
	db	2	;38 n/a
	db	2	;39 n/a
	db	2	;3a n/a
	db	2	;3b n/a
	db	2	;3c n/a
	db	2	;3d n/a
	db	2	;3e n/a
	db	2	;3f n/a
	db	-1	;40
	db	-1	;41
	db	-1	;42
	db	-1	;43
	db	-1	;44
	db	-1	;45
	db	-1	;46
	db	-1	;47
	db	-1	;48
	db	-1	;49
	db	-1	;4a
	db	-1	;4b
	db	-1	;4c
	db	-1	;4d
	db	-1	;4e
	db	-1	;4f
	db	2	;50 n/a
	db	2	;51 n/a
	db	2	;52 n/a
	db	2	;53 n/a
	db	2	;54 n/a
	db	2	;55 n/a
	db	2	;56 n/a
	db	2	;57 n/a
	db	2	;58 n/a
	db	2	;59 n/a
	db	2	;5a n/a
	db	2	;5b n/a
	db	2	;5c n/a
	db	2	;5d n/a
	db	2	;5e n/a
	db	2	;5f n/a
	db	-1	;60
	db	-1	;61
	db	-1	;62
	db	-1	;63
	db	-1	;64
	db	-1	;65
	db	-1	;66
	db	-1	;67
	db	-1	;68
	db	-1	;69
	db	-1	;6a
	db	-1	;6b
	db	-1	;6c n/a
	db	-1	;6d n/a
	db	-1	;6e
	db	-1	;6f
	db	-1	;70 n/a
	db	-1	;71 n/a
	db	-1	;72 n/a
	db	-1	;73 n/a
	db	-1	;74
	db	-1	;75
	db	-1	;76
	db	2	;77
	db	2	;78 n/a
	db	2	;79 n/a
	db	2	;7a n/a
	db	2	;7b n/a
	db	2	;7c n/a
	db	2	;7d n/a
	db	-1	;7e
	db	-1	;7f
	db	6	;80
	db	6	;81
	db	6	;82
	db	6	;83
	db	6	;84
	db	6	;85
	db	6	;86
	db	6	;87
	db	6	;88
	db	6	;89
	db	6	;8a
	db	6	;8b
	db	6	;8c
	db	6	;8d
	db	6	;8e
	db	6	;8f
	db	-1	;90
	db	-1	;91
	db	-1	;92
	db	-1	;93
	db	-1	;94
	db	-1	;95
	db	-1	;96
	db	-1	;97
	db	-1	;98
	db	-1	;99
	db	-1	;9a
	db	-1	;9b
	db	-1	;9c
	db	-1	;9d
	db	-1	;9e
	db	-1	;9f
	db	2	;a0
	db	2	;a1
	db	2	;a2
	db	-1	;a3
	db	-4	;a4
	db	-1	;a5
	db	2	;a6 n/a
	db	2	;a7 n/a
	db	2	;a8
	db	2	;a9
	db	2	;aa
	db	-1	;ab
	db	-4	;ac
	db	-1	;ad
	db	2	;ae n/a
	db	-1	;af
	db	-1	;b0
	db	-1	;b1
	db	-1	;b2
	db	-1	;b3
	db	-1	;b4
	db	-1	;b5
	db	-1	;b6
	db	-1	;b7
	db	-1	;b8 n/a
	db	-1	;b9 n/a
	db	-1	;ba n/a
	db	-1	;bb
	db	-1	;bc
	db	-1	;bd
	db	-1	;be
	db	-1	;bf
	db	-1	;c0
	db	-1	;c1
	db	2	;c2 n/a
	db	2	;c3 n/a
	db	2	;c4 n/a
	db	2	;c5 n/a
	db	2	;c6 n/a
	db	2	;c7 n/a
	db	2	;c8
	db	2	;c9
	db	2	;ca
	db	2	;cb
	db	2	;cc
	db	2	;cd
	db	2	;ce
	db	2	;cf
	db	-1	;d0 n/a
	db	-1	;d1
	db	-1	;d2
	db	-1	;d3
	db	-1	;d4 n/a
	db	-1	;d5
	db	-1	;d6 n/a
	db	-1	;d7 n/a
	db	-1	;d8
	db	-1	;d9
	db	-1	;da n/a
	db	-1	;db
	db	-1	;dc
	db	-1	;dd
	db	-1	;de n/a
	db	-1	;df
	db	2	;e0 n/a
	db	-1	;e1
	db	-1	;e2
	db	2	;e3 n/a
	db	2	;e4 n/a
	db	-1	;e5
	db	2	;e6 n/a
	db	2	;e7 n/a
	db	-1	;e8
	db	-1	;e9
	db	2	;ea n/a
	db	-1	;eb
	db	-1	;ec
	db	-1	;ed
	db	2	;ee n/a
	db	-1	;ef
	db	2	;f0 n/a
	db	-1	;f1
	db	-1	;f2
	db	-1	;f3
	db	2	;f4 n/a
	db	-1	;f5
	db	2	;f6 n/a
	db	2	;f7 n/a
	db	-1	;f8
	db	-1	;f9
	db	-1	;fa
	db	2	;fb n/a
	db	-1	;fc
	db	-1	;fd
	db	-1	;fe
	db	2	;ff n/a

erori	dd	EXCEPTION_ACCESS_VIOLATION
	dd	offset eroare1
	dd	EXCEPTION_ARRAY_BOUNDS_EXCEEDED
	dd	offset eroare2
	dd	EXCEPTION_BREAKPOINT
	dd	offset eroare3
	dd	EXCEPTION_DATATYPE_MISALIGNMENT
	dd	offset eroare4
	dd	EXCEPTION_FLT_DENORMAL_OPERAND
	dd	offset eroare5
	dd	EXCEPTION_FLT_DIVIDE_BY_ZERO
	dd	offset eroare6
	dd	EXCEPTION_FLT_INEXACT_RESULT
	dd	offset eroare7
	dd	EXCEPTION_FLT_INVALID_OPERATION
	dd	offset eroare8
	dd	EXCEPTION_FLT_OVERFLOW
	dd	offset eroare9
	dd	EXCEPTION_FLT_STACK_CHECK
	dd	offset eroare10
	dd	EXCEPTION_FLT_UNDERFLOW
	dd	offset eroare11
	dd	EXCEPTION_ILLEGAL_INSTRUCTION
	dd	offset eroare12
	dd	EXCEPTION_IN_PAGE_ERROR
	dd	offset eroare13
	dd	EXCEPTION_INT_DIVIDE_BY_ZERO
	dd	offset eroare14
	dd	EXCEPTION_INT_OVERFLOW
	dd	offset eroare15
	dd	0c0000026h
	dd	offset eroare16
	dd	EXCEPTION_NONCONTINUABLE
	dd	offset eroare17
	dd	EXCEPTION_PRIV_INSTRUCTION
	dd	offset eroare18
	dd	EXCEPTION_SINGLE_STEP
	dd	offset eroare19
	dd	0c00000fdh
	dd	offset eroare20
	dd	-1

ex_dump:push	ecx
	push	edx
	xor	ecx,ecx
	.while ecx<32
		push	ecx
		invoke	IsBadReadPtr,edx,1
		pop	ecx
		pop	edx
		.if eax
			mov	eax,' A/N'
			stosd
		.else
			mov	al,32
			stosb
			mov	al,[edx]
			mov	ah,al
			and	ax,0ff0h
			shr	al,4
			or	ax,3030h
			.if al>'9'
				add	al,7
			.endif
			.if ah>'9'
				add	ah,7
			.endif
			stosw
			mov	al,32
			stosb
		.endif
		inc	edx
		push	edx
		inc	ecx
	.endw
	pop	edx
	pop	ecx
	ret

modrm:	assume	esi:ptr EXCEPTION_RECORD
	mov	al,[eax]
	inc	[esi].ExceptionAddress
	mov	ah,al
	and	ax,0c00fh
	.if al==4
		inc	[esi].ExceptionAddress
	.elseif ax==5
		.if dl&2
			add	[esi].ExceptionAddress,2
		.else
			add	[esi].ExceptionAddress,4
		.endif
	.endif
	.if ah==40h
		inc	[esi].ExceptionAddress
	.elseif ah==80h
		.if dl&2
			add	[esi].ExceptionAddress,2
		.else
			add	[esi].ExceptionAddress,4
		.endif
	.endif
	assume	esi:nothing
	ret

assume	edx:nothing
SehHandler	PROC	uses esi edi ebx lParam:DWORD
	local	hSeh:DWORD,_prefix:DWORD
	local	_m:MODULEENTRY32
	invoke	GlobalAlloc,GPTR,8192
	mov	hSeh,eax
	mov	edi,eax
	lea	edx,bfe
	call	copyedx
	mov	esi,lParam
	assume	esi:ptr EXCEPTION_POINTERS
	mov	esi,[esi].pExceptionRecord
	assume	esi:ptr EXCEPTION_RECORD
	mov	eax,[esi].ExceptionCode
	push	eax
	call	whex
	pop	eax
	lea	edx,erori
	.while dword ptr[edx]!=-1
		.break .if eax==dword ptr[edx]
		lea	edx,[edx+8]
	.endw
	.if eax==[edx]
		push	edx
		lea	edx,excode
		call	copyedx
		pop	edx
		mov	edx,dword ptr[edx+4]
		call	copyedx
	.endif
	inc	exceptions
	lea	edx,exaddr
	call	copyedx
	mov	eax,[esi].ExceptionAddress
	call	whex
	mov	eax,[esi].ExceptionCode
	.if eax==EXCEPTION_ACCESS_VIOLATION
		lea	edx,excaus
		call	copyedx
		mov	eax,[esi].ExceptionInformation
		.if eax
			lea	edx,exwrit
		.else
			lea	edx,exread
		.endif
		call	copyedx
		mov	eax,dword ptr[esi+4].ExceptionInformation
		call	whex
	.else
		lea	edx,expara
		call	copyedx
		xor	ecx,ecx
		.while ecx<[esi].NumberParameters
			.if ecx
				mov	ax,' ,'
				stosw
			.endif
			mov	eax,[esi+ecx*4].ExceptionInformation
			push	ecx
			call	whex
			pop	ecx
			inc	ecx
		.endw
	.endif
	mov	esi,lParam
	assume	esi:ptr EXCEPTION_POINTERS
	mov	esi,[esi].ContextRecord
	assume	esi:ptr CONTEXT
	mov	eax,09090a0dh
	stosd
	mov	eax,'=XAE'
	stosd
	mov	eax,[esi].regEax
	call	whex
	mov	al,9
	stosb
	mov	eax,'=XBE'
	stosd
	mov	eax,[esi].regEbx
	call	whex
	mov	al,9
	stosb
	mov	eax,'=XCE'
	stosd
	mov	eax,[esi].regEcx
	call	whex
	mov	al,9
	stosb
	mov	eax,'=XDE'
	stosd
	mov	eax,[esi].regEdx
	call	whex
	mov	eax,09090a0dh
	stosd
	mov	eax,'=ISE'
	stosd
	mov	eax,[esi].regEsi
	call	whex
	mov	al,9
	stosb
	mov	eax,'=IDE'
	stosd
	mov	eax,[esi].regEdi
	call	whex
	mov	al,9
	stosb
	mov	eax,'=PBE'
	stosd
	mov	eax,[esi].regEbp
	call	whex
	mov	al,9
	stosb
	mov	eax,'=PSE'
	stosd
	mov	eax,[esi].regEsp
	call	whex
	mov	eax,09090a0dh
	stosd
	mov	eax,'=0RD'
	stosd
	mov	eax,[esi].iDr0
	call	whex
	mov	al,9
	stosb
	mov	eax,'=1RD'
	stosd
	mov	eax,[esi].iDr1
	call	whex
	mov	al,9
	stosb
	mov	eax,'=2RD'
	stosd
	mov	eax,[esi].iDr2
	call	whex
	mov	al,9
	stosb
	mov	eax,'=3RD'
	stosd
	mov	eax,[esi].iDr3
	call	whex
	mov	eax,09090a0dh
	stosd
	mov	eax,'=6RD'
	stosd
	mov	eax,[esi].iDr6
	call	whex
	mov	al,9
	stosb
	mov	eax,'=7RD'
	stosd
	mov	eax,[esi].iDr7
	call	whex
	mov	al,9
	stosb
	mov	eax,'=SF'
	stosd
	dec	edi
	mov	eax,[esi].regFs
	call	whex
	mov	al,9
	stosb
	mov	eax,'=SG'
	stosd
	dec	edi
	mov	eax,[esi].regGs
	call	whex
	mov	eax,09090a0dh
	stosd
	mov	eax,'=SC'
	stosd
	dec	edi
	mov	eax,[esi].regCs
	call	whex
	mov	al,9
	stosb
	mov	eax,'=SD'
	stosd
	dec	edi
	mov	eax,[esi].regDs
	call	whex
	mov	al,9
	stosb
	mov	eax,'=SE'
	stosd
	dec	edi
	mov	eax,[esi].regEs
	call	whex
	mov	al,9
	stosb
	mov	eax,'=SS'
	stosd
	dec	edi
	mov	eax,[esi].regSs
	call	whex
	mov	eax,09090a0dh
	stosd
	mov	eax,'=PIE'
	stosd
	mov	eax,[esi].regEip
	call	whex
	mov	al,9
	stosb
	mov	eax,'alFE'
	stosd
	mov	eax,'=sg'
	stosd
	dec	edi
	mov	eax,[esi].regFlag
	call	whex
	mov	eax,0a0d0a0dh
	stosd
	mov	al,9
	stosb
	mov	eax,'XAE['
	stosd
	mov	eax,' :]'
	stosd
	dec	edi
	mov	edx,[esi].regEax
	call	ex_dump
	mov	ax,0a0dh
	stosw
	mov	al,9
	stosb
	mov	eax,'XBE['
	stosd
	mov	eax,' :]'
	stosd
	dec	edi
	mov	edx,[esi].regEbx
	call	ex_dump
	mov	ax,0a0dh
	stosw
	mov	al,9
	stosb
	mov	eax,'XCE['
	stosd
	mov	eax,' :]'
	stosd
	dec	edi
	mov	edx,[esi].regEcx
	call	ex_dump
	mov	ax,0a0dh
	stosw
	mov	al,9
	stosb
	mov	eax,'XDE['
	stosd
	mov	eax,' :]'
	stosd
	dec	edi
	mov	edx,[esi].regEdx
	call	ex_dump
	mov	ax,0a0dh
	stosw
	mov	al,9
	stosb
	mov	eax,'ISE['
	stosd
	mov	eax,' :]'
	stosd
	dec	edi
	mov	edx,[esi].regEsi
	call	ex_dump
	mov	ax,0a0dh
	stosw
	mov	al,9
	stosb
	mov	eax,'IDE['
	stosd
	mov	eax,' :]'
	stosd
	dec	edi
	mov	edx,[esi].regEdi
	call	ex_dump
	mov	ax,0a0dh
	stosw
	mov	al,9
	stosb
	mov	eax,'PBE['
	stosd
	mov	eax,' :]'
	stosd
	dec	edi
	mov	edx,[esi].regEbp
	call	ex_dump
	mov	ax,0a0dh
	stosw
	mov	al,9
	stosb
	mov	eax,'PSE['
	stosd
	mov	eax,' :]'
	stosd
	dec	edi
	mov	edx,[esi].regEsp
	call	ex_dump
	mov	ax,0a0dh
	stosw
	mov	al,9
	stosb
	mov	eax,'PIE['
	stosd
	mov	eax,' :]'
	stosd
	dec	edi
	mov	edx,[esi].regEip
	call	ex_dump
	mov	ax,0a0dh
	stosw
	lea	edx,exmod
	call	copyedx
	.if hKernel==0
		invoke	LoadLibrary,addr _kernel
		mov	hKernel,eax
		.if eax
			invoke	GetProcAddress,hKernel,addr _CreateToolhelp32Snapshot
			mov	CreateToolhelp32Snapshot_,eax
			invoke	GetProcAddress,hKernel,addr _Module32First
			mov	Module32First_,eax
			invoke	GetProcAddress,hKernel,addr _Module32Next
			mov	Module32Next_,eax
		.endif
	.endif
	.if CreateToolhelp32Snapshot_
		push	0
		push	TH32CS_SNAPMODULE
		call	CreateToolhelp32Snapshot_
		.if eax==INVALID_HANDLE_VALUE
			invoke	GetModuleFileName,0,edi,4096
		.else
			mov	_prefix,eax
			mov	_m.modBaseAddr,0
			mov	_m.modBaseSize,0
			mov	_m.szExePath,0
			mov	_m.dwSize,sizeof MODULEENTRY32
			lea	eax,_m
			push	eax
			push	_prefix
			call	Module32First_
			push	edi
			.while eax
				mov	eax,[esi].regEip
				sub	eax,_m.modBaseAddr
				.if eax<_m.modBaseSize
					lea	edx,_m.szExePath
					call	copyedx
					mov	al,0
					stosb
					.break
				.endif
				mov	_m.modBaseAddr,0
				mov	_m.modBaseSize,0
				mov	_m.szExePath,0
				mov	_m.dwSize,sizeof MODULEENTRY32
				lea	eax,_m
				push	eax
				push	_prefix
				call	Module32Next_
				.if eax==0
					mov	eax,'nknu'
					stosd
					mov	eax,'nwo'
					stosd
					.break
				.endif
			.endw
			pop	edi
			invoke	CloseHandle,_prefix
		.endif
	.else
		invoke	GetModuleFileName,0,edi,4096
	.endif
	assume	esi:ptr EXCEPTION_RECORD
	xor	ecx,ecx
	mov	edx,edi
	.while byte ptr[edi+ecx]
		.if (byte ptr[edi+ecx]=='\')||(byte ptr[edi+ecx]=='/')
			lea	edx,[edi+ecx+1]
		.endif
		inc	ecx
	.endw
	call	copyedx
	mov	al,exceptions
	.if al>=maxerrs
		lea	edx,exres3
	.elseif [esi].ExceptionFlags&EXCEPTION_NONCONTINUABLE
		lea	edx,exres2
	.else
		lea	edx,exres1
	.endif
	call	copyedx
	mov	ax,0a0dh
	stosw
	mov	al,0
	stosb
	mov	edx,hSeh
	call	showmsg
	invoke	GlobalFree,hSeh
	mov	esi,lParam
	assume	esi:ptr EXCEPTION_POINTERS
	mov	esi,[esi].pExceptionRecord
	mov	al,exceptions
	.if al>=maxerrs
		lea	edx,thr_ex
		assume	esi:ptr EXCEPTION_RECORD
		mov	[esi].ExceptionAddress,edx
		mov	esi,lParam
		assume	esi:ptr EXCEPTION_POINTERS
		mov	esi,[esi].ContextRecord
		assume	esi:ptr CONTEXT
		mov	[esi].regEip,edx
		mov	eax,[esi].regEsp
		.if eax>4
			sub	eax,4
			invoke	IsBadReadPtr,eax,4
			.if eax
				mov	eax,[esi].regEsp
				invoke	IsBadReadPtr,eax,4
				.if eax
					mov	[esi].regEsp,esp
				.else
					add	[esi].regEsp,4
				.endif
			.endif
		.else
			mov	[esi].regEsp,esp
		.endif
		mov	eax,EXCEPTION_CONTINUE_EXECUTION
		ret
	.endif
	assume	esi:ptr EXCEPTION_RECORD
	mov	_prefix,0
	.if (!([esi].ExceptionFlags&EXCEPTION_NONCONTINUABLE))
		.while 1
			mov	eax,[esi].ExceptionAddress
			invoke	IsBadReadPtr,eax,5
			.if eax
				inc	[esi].ExceptionAddress
				.break
			.else
				mov	eax,[esi].ExceptionAddress
				inc	[esi].ExceptionAddress
				.continue .if (byte ptr[eax]==0f0h)||(byte ptr[eax]==0f2h)||(byte ptr[eax]==0f3h)
				.continue .if (byte ptr[eax]==064h)||(byte ptr[eax]==065h)
				.if (byte ptr[eax]==066h)
					or	_prefix,1
					.continue
				.elseif (byte ptr[eax]==067h)
					or	_prefix,2
					.continue
				.endif
				mov	al,[eax]
				lea	ebx,opc_table
				xlat
				mov	edx,_prefix
				.if al<80h
					movzx	eax,al
					dec	eax
					.if eax>=3
						.if _prefix&2
							dec	eax
							dec	eax
						.endif
					.endif
					add	[esi].ExceptionAddress,eax
					.break
				.elseif al==-1
					mov	eax,[esi].ExceptionAddress
					call	modrm
				.elseif al==-3
					mov	eax,[esi].ExceptionAddress
					.if _prefix&1
						add	[esi].ExceptionAddress,2
					.else
						add	[esi].ExceptionAddress,4
					.endif
					call	modrm
				.elseif al==-4
					mov	eax,[esi].ExceptionAddress
					inc	[esi].ExceptionAddress
					call	modrm
				.elseif al==-2
					mov	eax,[esi].ExceptionAddress
					inc	[esi].ExceptionAddress
					mov	al,[eax]
					lea	ebx,opc_0f
					xlat
					.if al<80h
						movzx	eax,al
						dec	eax
						dec	eax
						.if eax>=3
							.if _prefix&2
								dec	eax
								dec	eax
							.endif
						.endif
						add	[esi].ExceptionAddress,eax
						.break
					.elseif al==-1
						mov	eax,[esi].ExceptionAddress
						call	modrm
					.elseif al==-3
						mov	eax,[esi].ExceptionAddress
						.if _prefix&1
							add	[esi].ExceptionAddress,2
						.else
							add	[esi].ExceptionAddress,4
						.endif
						call	modrm
					.elseif al==-4
						mov	eax,[esi].ExceptionAddress
						inc	[esi].ExceptionAddress
						call	modrm
					.endif
				.endif
				.break
			.endif
		.endw
		mov	eax,[esi].ExceptionAddress
		mov	esi,lParam
		assume	esi:ptr EXCEPTION_POINTERS
		mov	esi,[esi].ContextRecord
		assume	esi:ptr CONTEXT
		mov	[esi].regEip,eax
		mov	eax,EXCEPTION_CONTINUE_EXECUTION
	.else
		mov	eax,EXCEPTION_CONTINUE_SEARCH
	.endif
	assume	esi:nothing
	ret
thr_ex:	push	0
	jmp	ExitThread
SehHandler	ENDP
endm