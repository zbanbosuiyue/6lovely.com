scan1	db	'forum',0,2
scan2	db	'board',0,2
scan3	db	'post',0,3
scan4	db	'topic',0,3
scan5	db	'profile',0,4
scan6	db	'user',0,4
scan7	db	'unread',0,4
scan8	db	'sort=',0,4
scan9	db	'member',0,4
scan10	db	'thread',0,3
scan11	db	'viewtopic',0,3
scan12	db	'showtopic',0,3

savedump	macro
	.if savefile
		mov	ecx,edi
		sub	ecx,offset savetmp
		push	edx
		mov	eax,esp
		invoke	WriteFile,savefile,addr savetmp,ecx,eax,0
		pop	edx
	.endif
	lea	edi,savetmp
endm

savedump1	macro
	mov	ecx,edi
	sub	ecx,offset savetmp
	.if ecx>savebufsize/2
		.if savefile
			push	eax
			mov	eax,esp
			invoke	WriteFile,savefile,addr savetmp,ecx,eax,0
			pop	eax
		.endif
		lea	edi,savetmp
	.endif
endm

var_init:mov	proxyflag,2
	mov	flink1,0
	mov	flink2,0
	mov	flink3,0
	mov	flink4,0
	mov	flink5,0
	mov	tlink1,0
	mov	tlink2,0
	mov	tlink3,0
	mov	tlink4,0
	mov	plink1,0
	mov	plink2,0
	mov	plink4,0
	mov	fflag,0
	mov	pflag,0
	mov	tflag,0

	mov	fflag,64+128	;+16
	mov	pflag,30h	;0b0h
	mov	delayd,10000
	mov	maxretries,2
	mov	maxctimeout,2
	mov	rdelay,100
	mov	rdelay1,100
	mov	maxfile,50
	mov	_cookies,0
	ret

get_format:
	push	ebp
	assume	edi:ptr foruminfo
	lea	edi,[edi].tables
	assume	edi:nothing
	push	edi
	mov	ecx,4096
	xor	eax,eax
	rep	stosd
	pop	edi
	xor	ebp,ebp
	push	esi
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			mov	eax,[esi+1]
			or	eax,20202020h
			.if eax=='ircs'
				mov	byte ptr[esi],32
				inc	esi
				.while byte ptr[esi]
					.if word ptr[esi]=='/<'
						mov	eax,[esi+2]
						or	eax,20202020h
						.if eax=='ircs'
							.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
								mov	byte ptr[esi],32
								inc	esi
							.endw
							.if byte ptr[esi]=='>'
								mov	byte ptr[esi],32
								inc	esi
							.endif
							.break
						.else
							mov	byte ptr[esi],32
							inc	esi
						.endif
					.else
						mov	byte ptr[esi],32
						inc	esi
					.endif
				.endw
			.else
				inc	esi
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	esi
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			inc	esi
			mov	eax,[esi]
			or	eax,20202020h
			.if (eax=='lbat')
				xor	ebx,ebx
				dec	esi
				inc	ebp
				call	s_dirs
				dec	ebp
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	ebp
	ret

s_dirs:	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			inc	esi
			mov	eax,[esi]
			or	eax,20202020h
			.if (eax=='lbat')
				.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
					mov	eax,[esi]
					or	eax,20202020h
					.if (eax=='diw ')
						mov	ax,[esi+4]
						or	ax,2020h
						.if (ax=='ht')&&(byte ptr[esi+6]=='=')
							lea	esi,[esi+7]
							call	atoi
							mov	[edi+12],eax
						;	.if (ax>80)
								mov	bh,1
						;	.else
						;		mov	bh,0
						;	.endif
							.break
						.endif
					.endif
					inc	esi
				.endw
				.if bh==1
					mov	dword ptr[edi],0
					mov	dword ptr[edi+4],0
					mov	[edi+8],ebp
					push	edi
					lea	edi,[edi+16]
					.while 1
						.if byte ptr[esi]=='<'
							inc	esi
							mov	eax,[esi]
							or	eax,20202020h
							.if (eax=='lbat')
								push	ebx
								xor	ebx,ebx
								dec	esi
								inc	ebp
								call	s_dirs
								dec	ebp
								pop	ebx
							.elseif byte ptr[esi]=='/'
								mov	eax,[esi+1]
								or	eax,20202020h
								.if (eax=='lbat')
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
										inc	esi
									.endw
									.if byte ptr[esi]=='>'
										inc	esi
									.endif
									.break
								.elseif ax=='rt'
									pop	edx
									.if ebx>[edx+4]
										mov	[edx+4],ebx
									.endif
									push	edx
									xor	ebx,ebx
								.endif
							.elseif ax=='rt'
								xor	ebx,ebx
								pop	edx
								inc	dword ptr[edx]
								push	edx
							.elseif ax=='dt'
								inc	ebx
							.endif
						.elseif byte ptr[esi]==0
							.break
						.else
							inc	esi
						.endif
					.endw
					pop	edx
					ret
				.else
				.endif
			.elseif byte ptr[esi]=='/'
				inc	esi
				mov	eax,[esi]
				or	eax,20202020h
				.if (eax=='lbat')
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
					ret
				.endif
			.else
				inc	esi
			.endif
		.else
			inc	esi
		.endif
	.endw
	ret

get_max:
	xor	edx,edx
	assume	edi:ptr foruminfo
	lea	esi,[edi].tables
	assume	edi:nothing
	.while dword ptr[esi]
		.if (ecx==[esi+4])&&(ebp==[esi+8])
			add	edx,[esi]
		.endif
		lea	esi,[esi+16]
	.endw
	ret

getformat:
	push	ebp
	push	edi
	call	get_format
	pop	edi
	push	edi

	push	0
	push	0
	mov	ecx,3
	xor	ebx,ebx
	.while ecx<20
		xor	ebp,ebp
		.while ebp<5
			call	get_max
			.if edx>ebx
				mov	dword ptr[esp],ebp
				mov	dword ptr[esp+4],ecx
				mov	ebx,edx
			.endif
			inc	ebp
		.endw
		inc	ecx
	.endw
	pop	eax
	pop	edx
	mov	tblforum,edx
	mov	tblforum[4],eax
	pop	edi
	push	edi
	assume	edi:ptr foruminfo
	lea	esi,[edi].tables
	assume	edi:nothing
	.while dword ptr[esi]
		.if (eax==[esi+8])&&(edx==[esi+4])
		.else
			mov	dword ptr[esi+4],0
		.endif
		lea	esi,[esi+16]
	.endw

	pop	edi
	pop	ebp
	ret


s_dirs1:.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			inc	esi
			mov	eax,[esi]
			or	eax,20202020h
			.if (eax=='lbat')
				.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
					mov	eax,[esi]
					or	eax,20202020h
					.if (eax=='diw ')
						mov	ax,[esi+4]
						or	ax,2020h
						.if (ax=='ht')&&(byte ptr[esi+6]=='=')
							lea	esi,[esi+7]
							call	atoi
							mov	[edi+12],eax
						;	.if (ax>80)
								mov	bh,1
						;	.else
						;		mov	bh,0
						;	.endif
							.break
						.endif
					.endif
					inc	esi
				.endw
				.if bh==1
					push	edi
					lea	edi,[edi+16]
					.while 1
						.if byte ptr[esi]=='<'
							inc	esi
							mov	eax,[esi]
							or	eax,20202020h
							.if (eax=='lbat')
								push	ebx
								xor	ebx,ebx
								dec	esi
								call	s_dirs1
								pop	ebx
							.elseif byte ptr[esi]=='/'
								mov	eax,[esi+1]
								or	eax,20202020h
								.if (eax=='lbat')
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
										inc	esi
									.endw
									.if byte ptr[esi]=='>'
										inc	esi
									.endif
									.break
								.elseif ax=='rt'
									xor	ebx,ebx
								.endif
							.elseif ax=='rt'
								xor	ebx,ebx
								pop	edx
								push	edx
								.if dword ptr[edx+4]
									push	stbl
									push	edi
									call	ebp
									pop	edi
									pop	stbl
								.endif
							.elseif ax=='dt'
								inc	ebx
							.endif
						.elseif byte ptr[esi]==0
							.break
						.else
							inc	esi
						.endif
					.endw
					pop	edx
					ret
				.else
				.endif
			.elseif byte ptr[esi]=='/'
				inc	esi
				mov	eax,[esi]
				or	eax,20202020h
				.if (eax=='lbat')
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
					ret
				.endif
			.else
				inc	esi
			.endif
		.else
			inc	esi
		.endif
	.endw
	ret

checkdirs:
	assume	edi:ptr foruminfo
	lea	edx,[edi].tables
	lea	edi,[edi].tdtbl
	mov	stbl,edi
	mov	ecx,100
	xor	eax,eax
	rep	stosd
	mov	edi,edx
	assume	edi:nothing
	push	esi
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			mov	eax,[esi+1]
			or	eax,20202020h
			.if eax=='ircs'
				mov	byte ptr[esi],32
				inc	esi
				.while byte ptr[esi]
					.if word ptr[esi]=='/<'
						mov	eax,[esi+2]
						or	eax,20202020h
						.if eax=='ircs'
							.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
								mov	byte ptr[esi],32
								inc	esi
							.endw
							.if byte ptr[esi]=='>'
								mov	byte ptr[esi],32
								inc	esi
							.endif
							.break
						.else
							mov	byte ptr[esi],32
							inc	esi
						.endif
					.else
						mov	byte ptr[esi],32
						inc	esi
					.endif
				.endw
			.else
				inc	esi
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	esi
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			inc	esi
			mov	eax,[esi]
			or	eax,20202020h
			.if (eax=='lbat')
				xor	ebx,ebx
				dec	esi
				push	stbl
				call	s_dirs1
				pop	stbl
			.endif
		.else
			inc	esi
		.endif
	.endw
	ret

chkdirs:
	push	esi
	push	edi
	push	ebx
	mov	edi,stbl
	.while (byte ptr[esi]!=0)
		.if byte ptr[esi]=='<'
			inc	esi
			.if byte ptr[esi]=='/'
				mov	ax,[esi+1]
				or	ax,2020h
				.break .if (ax=='rt')
				.if (ax=='dt')||(ax=='ht')
					lea	edi,[edi+4]
				.endif
			.else
				mov	ax,[esi]
				or	ax,2020h
				.if (ax=='dt')&&(byte ptr[edi]<2)
					.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
						mov	eax,[esi]
						or	eax,20202020h
						.if eax=='loc '
							mov	eax,[esi+4]
							or	eax,20202020h
							.break .if eax=='naps'
						.endif
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.else
						.break
				;		mov	eax,stbl
				;		mov	dword ptr[eax],-1
						.while (byte ptr[esi]!=0)
							.if byte ptr[esi]=='<'
								inc	esi
								.if byte ptr[esi]=='/'
									inc	esi
									mov	ax,[esi]
									or	ax,2020h
									.break .if (ax=='rt')
								.endif
							.else
								inc	esi
							.endif
						.endw
						mov	edi,stbl
						xor	ecx,ecx
						xor	eax,eax
				;		mov	ecx,100
				;		rep	stosd
						.break
					.endif
					.while byte ptr[esi]
						.if (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
							inc	esi
						.elseif byte ptr[esi]=='<'
							mov	ax,[esi+1]
							.if al=='/'
								mov	ax,[esi+2]
								or	ax,2020h
								.break .if (ax=='rt')||(ax=='dt')
							.else
								or	al,20h
								.break .if al=='a'
							.endif
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								inc	esi
							.endw
							.if byte ptr[esi]
								inc	esi
							.endif
						.elseif byte ptr[esi]=='&'
							.while (byte ptr[esi]!=';')&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='<')
								inc	esi
							.endw
							.if byte ptr[esi]==';'
								inc	esi
							.endif
						.else
							.break
						.endif
					.endw
					.if (byte ptr[esi]=='<')&&((byte ptr[esi+1]=='a')||(byte ptr[esi+1]=='A'))
						mov	ecx,esi
						.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
							mov	eax,[esi]
							or	eax,20202020h
							.if eax=='erh '
								lea	esi,[esi+4]
								mov	al,[esi]
								or	al,20h
								.if al=='f'
									inc	esi
								.endif
								.while (byte ptr[esi]=='=')||(byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==39)||(byte ptr[esi]==34)
									inc	esi
								.endw
								lea	edx,scan6
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan7
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan8
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan9
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan10
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan1
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan2
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan3
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan4
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan5
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								.if forum_sim
									push	esi
									push	edi
									lea	edi,forum_sim
									mov	edx,esi
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
										.if (byte ptr[esi]=='/')&&((byte ptr[esi+1]>='a')&&(byte ptr[esi+1]<='z'))||((byte ptr[esi+1]>='A')&&(byte ptr[esi+1]<='Z'))
											mov	edx,esi
										.endif
										inc	esi
									.endw
									mov	esi,edx
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
										.if (byte ptr[esi]<='9')&&(byte ptr[esi]>='0')
										.else
											mov	al,[esi]
											mov	ah,[edi]
											.break .if al!=ah
											inc	edi
										.endif
										inc	esi
									.endw
									mov	al,0
									.if byte ptr[edi]==0
										mov	al,2
									.endif
									pop	edi
									pop	esi
									.if al
										mov	[edi],al
									.endif
								.endif
								.break
							.endif
							inc	esi
						.endw
						.if byte ptr[edi]==0
							mov	byte ptr[edi],1
					;	.elseif byte ptr[edi]==5
					;		.break
						.endif
					.endif
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	ebx
	pop	edi
	pop	esi
	ret


chktopics:
	push	esi
	push	edi
	push	ebx
	mov	edi,stbl
	.while (byte ptr[esi]!=0)
		.if byte ptr[esi]=='<'
			inc	esi
			.if byte ptr[esi]=='/'
				mov	ax,[esi+1]
				or	ax,2020h
				.break .if (ax=='rt')||(ax=='ht')
				.if ax=='dt'
					lea	edi,[edi+4]
				.endif
			.else
				mov	ax,[esi]
				or	ax,2020h
				.if (ax=='dt')&&(byte ptr[edi]<2)
					.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
						mov	eax,[esi]
						or	eax,20202020h
						.if eax=='loc '
							mov	eax,[esi+4]
							or	eax,20202020h
							.break .if eax=='naps'
						.endif
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.else
						push	esi
						.while 1
							dec	esi
							.if byte ptr[esi]=='<'
								mov	ax,[esi+1]
								or	ax,2020h
								.if ax=='rt'
									mov	word ptr[esi],'__'
									.break
								.endif
							.endif
						.endw
						pop	esi
						mov	eax,stbl
						mov	dword ptr[eax],-1
						.while (byte ptr[esi]!=0)
							.if byte ptr[esi]=='<'
								inc	esi
								.if byte ptr[esi]=='/'
									inc	esi
									mov	ax,[esi]
									or	ax,2020h
									.break .if (ax=='rt')
								.endif
							.else
								inc	esi
							.endif
						.endw
						mov	edi,stbl
						xor	ecx,ecx
						xor	eax,eax
					;	mov	ecx,100
					;	rep	stosd
						.break
					.endif
					.while byte ptr[esi]
						.if (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
							inc	esi
						.elseif byte ptr[esi]=='<'
							mov	ax,[esi+1]
							.if al=='/'
								mov	ax,[esi+2]
								or	ax,2020h
								.break .if (ax=='rt')||(ax=='dt')
							.else
								or	al,20h
								.break .if al=='a'
							.endif
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								inc	esi
							.endw
							.if byte ptr[esi]
								inc	esi
							.endif
						.elseif byte ptr[esi]=='&'
							.while (byte ptr[esi]!=';')&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='<')
								inc	esi
							.endw
							.if byte ptr[esi]==';'
								inc	esi
							.endif
						.else
							.break
						.endif
					.endw
					.if (byte ptr[esi]=='<')&&((byte ptr[esi+1]=='a')||(byte ptr[esi+1]=='A'))
						mov	ecx,esi
						.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
							mov	eax,[esi]
							or	eax,20202020h
							.if eax=='erh '
								lea	esi,[esi+4]
								mov	al,[esi]
								or	al,20h
								.if al=='f'
									inc	esi
								.endif
								.while (byte ptr[esi]=='=')||(byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==39)||(byte ptr[esi]==34)
									inc	esi
								.endw
								lea	edx,scan6
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan7
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan8
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan9
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan10
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan11
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan12
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan1
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan2
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan3
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan4
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								lea	edx,scan5
								call	_scan
								.if eax
									mov	byte ptr[edi],al
									.break
								.endif
								.if forum_sim
									push	esi
									push	edi
									lea	edi,forum_sim
									mov	edx,esi
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
										.if (byte ptr[esi]=='/')&&((byte ptr[esi+1]>='a')&&(byte ptr[esi+1]<='z'))||((byte ptr[esi+1]>='A')&&(byte ptr[esi+1]<='Z'))
											mov	edx,esi
										.endif
										inc	esi
									.endw
									mov	esi,edx
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
										.if (byte ptr[esi]<='9')&&(byte ptr[esi]>='0')
										.else
											mov	al,[esi]
											mov	ah,[edi]
											.break .if al!=ah
											inc	edi
										.endif
										inc	esi
									.endw
									mov	al,0
									.if byte ptr[edi]==0
										mov	al,5
									.endif
									pop	edi
									pop	esi
									.if al
										mov	[edi],al
									.endif
								.endif
								.if topic_sim
									push	esi
									push	edi
									lea	edi,topic_sim
									mov	edx,esi
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
										.if (byte ptr[esi]=='/')&&((byte ptr[esi+1]>='a')&&(byte ptr[esi+1]<='z'))||((byte ptr[esi+1]>='A')&&(byte ptr[esi+1]<='Z'))
											mov	edx,esi
										.endif
										inc	esi
									.endw
									mov	esi,edx
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
										.if (byte ptr[esi]<='9')&&(byte ptr[esi]>='0')
										.else
											mov	al,[esi]
											mov	ah,[edi]
											.break .if al!=ah
											inc	edi
										.endif
										inc	esi
									.endw
									mov	al,0
									.if byte ptr[edi]==0
										mov	al,3
									.endif
									pop	edi
									pop	esi
									.if al
										mov	[edi],al
									.endif
								.endif
								.break
							.endif
							inc	esi
						.endw
						.if byte ptr[edi]==0
							mov	byte ptr[edi],1
					;	.elseif (byte ptr[edi]==5)||(byte ptr[edi]==4)
					;		.break
						.endif
					.endif
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	ebx
	pop	edi
	pop	esi
	ret


savedirs:
	assume	edi:ptr foruminfo
	lea	edi,[edi].tables
	assume	edi:nothing
	push	esi
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			mov	eax,[esi+1]
			or	eax,20202020h
			.if eax=='ircs'
				mov	byte ptr[esi],32
				inc	esi
				.while byte ptr[esi]
					.if word ptr[esi]=='/<'
						mov	eax,[esi+2]
						or	eax,20202020h
						.if eax=='ircs'
							.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
								mov	byte ptr[esi],32
								inc	esi
							.endw
							.if byte ptr[esi]=='>'
								mov	byte ptr[esi],32
								inc	esi
							.endif
							.break
						.else
							mov	byte ptr[esi],32
							inc	esi
						.endif
					.else
						mov	byte ptr[esi],32
						inc	esi
					.endif
				.endw
			.else
				inc	esi
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	esi
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			inc	esi
			mov	eax,[esi]
			or	eax,20202020h
			.if (eax=='lbat')
				xor	ebx,ebx
				dec	esi
				push	stbl
				call	s_dirs1
				pop	stbl
			.endif
		.else
			inc	esi
		.endif
	.endw
	ret





createtopics:
	push	esi
	push	edi
	push	ebx
	mov	edi,stbl
	.while (byte ptr[esi]!=0)
		.if byte ptr[esi]=='<'
			inc	esi
			.if byte ptr[esi]=='/'
				mov	ax,[esi+1]
				or	ax,2020h
				.break .if ax=='rt'
				.if (ax=='dt')||(ax=='ht')
					lea	edi,[edi+4]
				.endif
			.else
				mov	ax,[esi]
				or	ax,2020h
				.if (ax=='dt')&&(word ptr[edi]>0)&&(word ptr[edi]<4)
					.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
						mov	eax,[esi]
						or	eax,20202020h
						.if eax=='loc '
							mov	eax,[esi+4]
							or	eax,20202020h
							.break .if eax=='naps'
						.endif
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.else
						.while (byte ptr[esi]!=0)
							.if byte ptr[esi]=='<'
								inc	esi
								.if byte ptr[esi]=='/'
									inc	esi
									mov	ax,[esi]
									or	ax,2020h
									.break .if (ax=='rt')
								.endif
							.else
								inc	esi
							.endif
						.endw
						.continue
					.endif
					.while byte ptr[esi]
						.if (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
							inc	esi
						.elseif byte ptr[esi]=='<'
							mov	ax,[esi+1]
							.if al=='/'
								mov	ax,[esi+2]
								or	ax,2020h
								.break .if (ax=='rt')||(ax=='dt')
							.else
								or	al,20h
								.break .if al=='a'
							.endif
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								inc	esi
							.endw
							.if byte ptr[esi]
								inc	esi
							.endif
						.elseif byte ptr[esi]=='&'
							.while (byte ptr[esi]!=';')&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='<')
								inc	esi
							.endw
							.if byte ptr[esi]==';'
								inc	esi
							.endif
						.else
							.break
						.endif
					.endw
					.if (byte ptr[esi]=='<')&&((byte ptr[esi+1]=='a')||(byte ptr[esi+1]=='A'))
						.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
							mov	eax,[esi]
							or	eax,20202020h
							.if eax=='erh '
								push	edi
								lea	esi,[esi+4]
								mov	al,[esi]
								or	al,20h
								.if al=='f'
									inc	esi
								.endif
								.while (byte ptr[esi]=='=')||(byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==39)||(byte ptr[esi]==34)
									inc	esi
								.endw
								.if topic_sim==0
									push	esi
									push	edi
									lea	edi,topic_sim
									mov	edx,esi
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
										.if (byte ptr[esi]=='/')&&((byte ptr[esi+1]>='a')&&(byte ptr[esi+1]<='z'))||((byte ptr[esi+1]>='A')&&(byte ptr[esi+1]<='Z'))
											mov	edx,esi
										.endif
										inc	esi
									.endw
									mov	esi,edx
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
										.if (byte ptr[esi]<='9')&&(byte ptr[esi]>='0')
											inc	esi
										.else
											movsb
										.endif
									.endw
									mov	al,0
									stosb

									pop	edi
									pop	esi
								.endif
								invoke	GlobalAlloc,GPTR,sizeof foruminfo
								push	eax
								mov	ebx,eax
								assume	ebx:ptr foruminfo
								mov	[ebx]._next,0
								mov	[ebx].histptr,0
								mov	edx,f_info
								assume	edx:ptr foruminfo
								lea	edx,[edx]._addr
								assume	edx:nothing
								lea	edi,[ebx]._addr
								call	copyedx
								mov	al,0
								stosb
								mov	edx,f_info
								assume	edx:ptr foruminfo
								lea	edx,[edx]._dns
								assume	edx:nothing
								lea	edi,[ebx]._dns
								call	copyedx
								mov	al,0
								stosb
								lea	edi,[ebx]._addr
								mov	eax,[edi]
								or	eax,20202020h
								.if (eax=='ptth')&&(word ptr[edi+4]=='/:')&&(byte ptr[edi+6]=='/')
									lea	edi,[edi+7]
								.endif
								mov	eax,[esi]
								or	eax,20202020h
								.if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+6]=='/')
									lea	esi,[esi+7]
								.elseif byte ptr[esi]=='/'
									.while (byte ptr[edi]!='/')&&(byte ptr[edi]!=0)
										inc	edi
									.endw
								.else
									mov	edx,edi
									push	edi
									.while byte ptr[edi]
										.if byte ptr[edi]=='/'
											mov	edx,edi
										.endif
										inc	edi
									.endw
									pop	eax
									.if edx==eax
										.if byte ptr[edi]!='/'
											mov	al,'/'
											stosb
										.endif
									.else
										mov	edi,edx
										mov	al,'/'
										stosb
									.endif
								.endif
								.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
									lodsb
									.if al=='&'
										mov	eax,[esi]
										or	eax,202020h
										.if eax==';pma'
											lodsd
										.endif
										mov	al,'&'
									.else
										mov	eax,[esi-1]
										or	eax,20202020h
										.if eax=='=dis'
											.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
												inc	esi
											.endw
											.continue
										.elseif eax=='sphp'
											mov	eax,[esi+3]
											or	eax,20202020h
											.if eax=='isse'
												.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
													inc	esi
												.endw
												.continue
											.endif
										.elseif ax=='=s'
											mov	eax,2
											.while ((byte ptr[esi+eax]>='0')&&(byte ptr[esi+eax]<='9'))||((byte ptr[esi+eax]>='a')&&(byte ptr[esi+eax]<='f'))||((byte ptr[esi+eax]>='A')&&(byte ptr[esi+eax]<='F'))
												inc	eax
											.endw
											.if eax>8
												.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
													inc	esi
												.endw
												.continue
											.endif
										.endif
										mov	al,[esi-1]
									.endif
									stosb
								.endw
								.if byte ptr[edi-1]=='&'
									dec	edi
								.endif
								mov	al,0
								stosb
								lea	edx,[ebx]._addr
								istopicsaved
								mov	[ebx].histptr,eax
								.if edx==0
									lea	edi,defdir
									.while byte ptr[edi]
										inc	edi
									.endw
									push	dword ptr[edi]
									push	edi
									push	ebx
									.if byte ptr[edi-1]!='\'
										mov	al,'\'
										stosb
									.endif
									mov	eax,diridx
									call	w5
									mov	al,32
									stosb
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
										inc	esi
									.endw
									.if byte ptr[esi]=='>'
										inc	esi
									.endif
									mov	ecx,maxfile
									.if ecx>6
										sub	ecx,6
									.else
										xor	ecx,ecx
									.endif
									push	edi
									call	escfile
									pop	edx
									pop	ebx
									.if edi!=edx
										mov	eax,'mth.'
										stosd
										mov	ax,'l'
										stosw
										push	stbl
										invoke	save_topics,ebx
										pop	stbl
										inc	diridx
									.endif
									pop	edi
									pop	dword ptr[edi]
								.endif
								assume	ebx:nothing
								call	GlobalFree
								pop	edi
								.break
							.endif
							inc	esi
						.endw
					.endif
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	ebx
	pop	edi
	pop	esi
	ret

scanpage:.while byte ptr[esi]
		mov	eax,[esi]
		or	eax,20202020h
		
		.if (eax=='otog')&&(byte ptr[esi+4]==32)
			mov	eax,[esi+5]
			or	eax,20202020h
			.if eax=='egap'
				lea	esi,[esi+9]
				jmp	_pg
			.endif
			inc	esi
		.elseif 0 ;(eax=='verp')
			mov	eax,[esi+4]
			or	eax,20202020h
			.if eax=='suoi'
				lea	esi,[esi+8]
				.while (byte ptr[esi]==32)||(dword ptr[esi]=='sbn&')
					.if (dword ptr[esi]=='sbn&')&&(word ptr[esi+4]==';p')
						lea	esi,[esi+6]
					.else
						inc	esi
					.endif
				.endw
				.if dword ptr[esi]=='>A/<'
					jmp	_pg
				.endif
				dec	esi
			.else
				lea	esi,[esi+4]
				.while (byte ptr[esi]==32)||(dword ptr[esi]=='sbn&')
					.if (dword ptr[esi]=='sbn&')&&(word ptr[esi+4]==';p')
						lea	esi,[esi+6]
					.else
						inc	esi
					.endif
				.endw
				.if dword ptr[esi]=='>A/<'
					jmp	_pg
				.endif
				dec	esi
			.endif
			inc	esi
		.elseif (eax=='egap')&&((byte ptr[esi+4]=='s')||(byte ptr[esi+4]=='S'))
			.if byte ptr[esi+5]==':'
				lea	esi,[esi+5]
				jmp	_pg
			.endif
			xor	edx,edx
			lea	edx,[edx+5]
			.while (byte ptr[esi+edx]=='(')||(byte ptr[esi+edx]==')')||((byte ptr[esi+edx]<='9')&&(byte ptr[esi+edx]>='0'))||(byte ptr[esi+edx]==' ')
				inc	edx
			.endw
			.if byte ptr[esi+edx]==':'
				lea	esi,[esi+edx+5]
				jmp	_pg
			.endif
			inc	esi
		.elseif (eax=='egap')&&((byte ptr[esi+4]==':')||(((byte ptr[esi+4]=='s')||(byte ptr[esi+4]=='S'))&&(byte ptr[esi+5]==':')))
			lea	esi,[esi+5]
_pg:			xor	edx,edx
			.while 1
				.if (byte ptr[esi]==':')||(byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]=='[')||(byte ptr[esi]==']')
					inc	esi
				.elseif (byte ptr[esi]=='.')||(byte ptr[esi]==',')||(byte ptr[esi]=='(')||(byte ptr[esi]==')')
					inc	esi
				.elseif dword ptr[esi]=='--!<'
					.while (byte ptr[esi]!=0)&&(word ptr[esi]!='>-')
						inc	esi
					.endw
					.if word ptr[esi]=='>-'
						inc	esi
						inc	esi
					.endif
				.elseif (word ptr[esi]=='b<')||(word ptr[esi]=='B<')||(word ptr[esi]=='f<')||(word ptr[esi]=='F<')
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (word ptr[esi]=='/<')&&((byte ptr[esi+2]=='b')||(byte ptr[esi+2]=='B')||(byte ptr[esi+2]=='f')||(byte ptr[esi+2]=='F')||(byte ptr[esi+2]=='a')||(byte ptr[esi+2]=='A'))
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (word ptr[esi]=='a<')||(word ptr[esi]=='A<')
					.if edx==0
						.while (byte ptr[esi]!=0)
							.if (word ptr[esi]=='/<')&&((byte ptr[esi+2]=='a')||(byte ptr[esi+2]=='A'))
								.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
									inc	esi
								.endw
								.if byte ptr[esi]=='>'
									inc	esi
								.endif
								.break
							.else
								inc	esi
							.endif
						.endw
					.else
						.break
					.endif
				.elseif (byte ptr[esi]>='0')&&(byte ptr[esi]<='9')
					inc	edx
					inc	esi
				.else
					mov	eax,[esi]
					or	eax,20202020h
					.if eax=='txen'
						.while (byte ptr[esi]>='A')||(byte ptr[esi]==32)
							inc	esi
						.endw
					.elseif eax=='verp'
						.while (byte ptr[esi]>='A')||(byte ptr[esi]==32)
							inc	esi
						.endw
					.elseif byte ptr[esi]=='&'
						mov	eax,[esi+1]
						or	eax,20202020h
						.if (eax=='psbn')&&(byte ptr[esi+5]==';')
							lea	esi,[esi+6]
						.else
							inc	esi
						.endif
					.else
						.break
					.endif
				.endif
			.endw
			.if (word ptr[esi]=='a<')||(word ptr[esi]=='A<')
				ret
			.endif
		.elseif eax=='egap'
			mov	eax,[esi+4]
			or	eax,20202020h
			.if eax=='knil'
				push	ecx
				xor	ecx,ecx
				.while (byte ptr[esi+ecx]!=34)&&(byte ptr[esi+ecx]!='<')&&(byte ptr[esi+ecx]!=0)
					inc	ecx
				.endw
				.if byte ptr[esi+ecx]==34
					.while (byte ptr[esi+ecx]!=':')&&(byte ptr[esi+ecx]!='<')&&(byte ptr[esi+ecx]!=0)
						inc	ecx
					.endw
					.if byte ptr[esi+ecx]==':'
						lea	esi,[esi+ecx+1]
						pop	ecx
						jmp	_pg
					.endif
				.endif
				pop	ecx
			.endif
			inc	esi
		.elseif (byte ptr[esi]=='<')&&(ah=='a')&&(byte ptr[esi+2]==' ')
			push	ecx
			xor	ecx,ecx
			.while (byte ptr[esi+ecx]!='>')&&(byte ptr[esi+ecx]!=0)
				mov	eax,[esi+ecx]
				or	eax,20202020h
				.if eax=='tit '
					mov	ax,[esi+ecx+4]
					or	ax,2020h
					.if (ax=='el')
						lea	ecx,[ecx+6]
						.while (byte ptr[esi+ecx]==32)||(byte ptr[esi+ecx]==9)||(byte ptr[esi+ecx]==13)||(byte ptr[esi+ecx]==10)
							inc	ecx
						.endw
						.if byte ptr[esi+ecx]=='='
							inc	ecx
							.while (byte ptr[esi+ecx]==32)||(byte ptr[esi+ecx]==9)||(byte ptr[esi+ecx]==13)||(byte ptr[esi+ecx]==10)
								inc	ecx
							.endw
							.if (byte ptr[esi+ecx]==39)||(byte ptr[esi+ecx]==34)
								inc	ecx
								.while (byte ptr[esi+ecx]==32)||(byte ptr[esi+ecx]==9)||(byte ptr[esi+ecx]==13)||(byte ptr[esi+ecx]==10)
									inc	ecx
								.endw
								mov	eax,[esi+ecx]
								or	eax,20202020h
								.if (eax=='txen')
									lea	ecx,[ecx+4]
									.while (byte ptr[esi+ecx]==32)||(byte ptr[esi+ecx]==9)||(byte ptr[esi+ecx]==13)||(byte ptr[esi+ecx]==10)
										inc	ecx
									.endw
									mov	eax,[esi+ecx]
									or	eax,20202020h
									.if eax=='egap'
										lea	ecx,[ecx+4]
										.while (byte ptr[esi+ecx]==32)||(byte ptr[esi+ecx]==9)||(byte ptr[esi+ecx]==13)||(byte ptr[esi+ecx]==10)
											inc	ecx
										.endw
										.if (byte ptr[esi+ecx]==34)||(byte ptr[esi+ecx]==39)
											pop	ecx
											ret
										.endif
									.endif
								.endif
							.endif
						.endif
						dec	ecx
					.endif
				.endif
				inc	ecx
			.endw
			pop	ecx
			inc	esi
		.else
			inc	esi
		.endif
	.endw
	ret



skiptbl:
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			inc	esi
			mov	eax,[esi]
			or	eax,20202020h
			.if (eax=='lbat')
				call	skiptbl
			.elseif byte ptr[esi]=='/'
				inc	esi
				mov	eax,[esi]
				or	eax,20202020h
				.if (eax=='lbat')
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
					ret
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	ret

get_matrix:
	push	esi
	.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
		mov	eax,[esi]
		or	eax,20202020h
		.if eax=='diw '
			mov	ax,[esi+2]
			or	ax,2020h
			.if ax=='ht'
				lea	esi,[esi+6]
				.while (byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]=='=')||(byte ptr[esi]==34)||(byte ptr[esi]==39)
					inc	esi
				.endw
				call	atoi
				.if eax<70
					pop	esi
					xor	ecx,ecx
					mov	dl,-1
					ret
				.endif
				.break
			.else
				inc	esi
			.endif
		.else
			inc	esi
		.endif
	.endw
	xor	ecx,ecx
	xor	edx,edx
	xor	ebx,ebx
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			inc	esi
			mov	eax,[esi]
			or	eax,20202020h
			.if (eax=='lbat')
				call	skiptbl
			.elseif ax=='rt'
				mov	dh,0
				inc	ecx
			;	.if (ecx>2)&&(dl==-1)
			;		mov	dl,2
			;	.endif
			.elseif ax=='dt'
				inc	dh
			.elseif (eax=='mrof')||(eax=='eles')||(eax=='upni')
				mov	bl,1
			.elseif byte ptr[esi]=='/'
				mov	eax,[esi+1]
				or	eax,20202020h
				.if (eax=='lbat')
					pop	esi
					ret
				.elseif ax=='rt'
					mov	dl,dh
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	esi
	ret

_tbl	db	'<TABLE border="1">',0
_tbl1	db	'</TABLE>',0
wtbl:	.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
	;	inc	esi
		movsb
	.endw
	.if byte ptr[esi]=='>'
	;	inc	esi
		movsb
	.endif
	.while (byte ptr[esi]!=0)
		.if byte ptr[esi]=='<'
			mov	eax,[esi+1]
			or	eax,20202020h
			.if (eax=='lbat')
			;	lea	edx,_tbl
			;	call	copyedx
				call	wtbl
			;	lea	edx,_tbl1
			;	call	copyedx
			.elseif ax==' a'
				.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
					mov	eax,[esi]
					or	eax,20202020h
					.if eax=='erh '
						mov	ax,'A<'
						stosw
						movsd
						.while (byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
							movsb
						.endw
						.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
							movsb
							.while (byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								movsb
							.endw
							.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
								movsb
							.endif
							mov	al,'>'
							stosb
						.endif
						.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
							inc	esi
						.endw
						.if byte ptr[esi]=='>'
							inc	esi
						.endif
						.break
					.endif
					inc	esi
				.endw
			.elseif eax==' gmi'
				.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
					mov	eax,[esi]
					or	eax,20202020h
					.if eax=='crs '
						mov	eax,'GMI<'
						stosd
						movsd
						.while (byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
							movsb
						.endw
						.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
							movsb
							.while (byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								movsb
							.endw
							.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
								movsb
							.endif
							mov	al,'>'
							stosb
						.endif
						.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
							inc	esi
						.endw
						.if byte ptr[esi]=='>'
							inc	esi
						.endif
						.break
					.endif
					inc	esi
				.endw
			.elseif eax=='ircs'
				.while byte ptr[esi]
					.if word ptr[esi]=='/<'
						mov	eax,[esi+2]
						or	eax,20202020h
						.if eax=='ircs'
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								inc	esi
							.endw
							.if byte ptr[esi]=='>'
								inc	esi
							.endif
							.break
						.endif
						inc	esi
					.else
						inc	esi
					.endif
				.endw
			.elseif eax=='naps'
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif ax=='rt'
				mov	eax,'>RT<'
				stosd
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif ax=='dt'
				mov	eax,'>DT<'
				stosd
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif ax=='ht'
				mov	eax,'>HT<'
				stosd
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif eax==' vid'
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif ax=='rb'
				mov	eax,'>RB<'
				stosd
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif ax=='rh'
				mov	eax,'>RH<'
				stosd
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (ax==' b')||(ax=='>b')
				mov	eax,'>B<'
				stosd
				dec	edi
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (ax==' i')||(ax=='>i')
				mov	eax,'>I<'
				stosd
				dec	edi
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif byte ptr[esi+1]=='/'
				mov	eax,[esi+2]
				or	eax,20202020h
				.if (eax=='lbat')
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					;	inc	esi
						movsb
					.endw
					.if byte ptr[esi]=='>'
					;	inc	esi
						movsb
					.endif
					ret
				.elseif (eax=='ircs')||(eax=='naps')||(ax=='id')||(eax=='ydob')||(eax=='lmth')
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (ax=='>a')||(al=='a')||(al=='b')||(al=='i')||(ax=='rt')||(ax=='dt')||(ax=='ht')
					.while (byte ptr[esi]!=32)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
						mov	al,[esi]
						stosb
						inc	esi
					.endw
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						movsb
					.endif
				.elseif (ax=='dt')||(ax=='rt')||(ax=='ht')
					.while (byte ptr[esi]!=32)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
						mov	al,[esi]
						stosb
						inc	esi
					.endw
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.else
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.endif
			.else
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.endif
		.else
			movsb
		.endif
	.endw
	ret

wtr:	.while (byte ptr[esi]!=0)
		.if byte ptr[esi]=='<'
			mov	eax,[esi+1]
			or	eax,20202020h
			.if (eax=='lbat')
			;	lea	edx,_tbl
			;	call	copyedx
				call	wtbl
			;	lea	edx,_tbl1
			;	call	copyedx
			.elseif ax==' a'
				.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
					mov	eax,[esi]
					or	eax,20202020h
					.if eax=='erh '
						mov	ax,'A<'
						stosw
						movsd
						.while (byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
							movsb
						.endw
						.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
							movsb
							.while (byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								movsb
							.endw
							.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
								movsb
							.endif
							mov	al,'>'
							stosb
						.endif
						.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
							inc	esi
						.endw
						.if byte ptr[esi]=='>'
							inc	esi
						.endif
						.break
					.endif
					inc	esi
				.endw
			.elseif eax==' gmi'
				.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
					mov	eax,[esi]
					or	eax,20202020h
					.if eax=='crs '
						mov	eax,'GMI<'
						stosd
						movsd
						.while (byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
							movsb
						.endw
						.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
							movsb
							.while (byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								movsb
							.endw
							.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
								movsb
							.endif
							mov	al,'>'
							stosb
						.endif
						.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
							inc	esi
						.endw
						.if byte ptr[esi]=='>'
							inc	esi
						.endif
						.break
					.endif
					inc	esi
				.endw
			.elseif eax=='ircs'
				.while byte ptr[esi]
					.if word ptr[esi]=='/<'
						mov	eax,[esi+2]
						or	eax,20202020h
						.if eax=='ircs'
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								inc	esi
							.endw
							.if byte ptr[esi]=='>'
								inc	esi
							.endif
							.break
						.endif
						inc	esi
					.else
						inc	esi
					.endif
				.endw
			.elseif eax=='naps'
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif ax=='rt'
				ret
			.elseif ax=='dt'
				mov	eax,'>DT<'
				stosd
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif ax=='ht'
				mov	eax,'>HT<'
				stosd
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif eax==' vid'
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif ax=='rb'
				mov	eax,'>RB<'
				stosd
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif ax=='rh'
				mov	eax,'>RH<'
				stosd
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (ax==' b')||(ax=='>b')
				mov	eax,'>B<'
				stosd
				dec	edi
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (ax==' i')||(ax=='>i')
				mov	eax,'>I<'
				stosd
				dec	edi
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif byte ptr[esi+1]=='/'
				mov	eax,[esi+2]
				or	eax,20202020h
				.if (eax=='lbat')||(ax=='rt')
					ret
				.elseif (eax=='ircs')||(eax=='naps')||(ax=='id')||(eax=='ydob')||(eax=='lmth')
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (ax=='>a')||(al=='a')||(al=='b')||(al=='i')||(ax=='rt')||(ax=='dt')||(ax=='ht')
					.while (byte ptr[esi]!=32)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
						mov	al,[esi]
						stosb
						inc	esi
					.endw
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						movsb
					.endif
				.elseif (ax=='dt')||(ax=='rt')||(ax=='ht')
					.while (byte ptr[esi]!=32)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
						mov	al,[esi]
						stosb
						inc	esi
					.endw
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.else
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.endif
			.else
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.endif
		.else
			movsb
		.endif
	.endw
	ret

skipscr:.while byte ptr[esi]
		.if word ptr[esi]=='/<'
			mov	eax,[esi+2]
			or	eax,20202020h
			.if eax=='ircs'
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
				.break
			.endif
			inc	esi
		.else
			inc	esi
		.endif
	.endw
	ret

tbl2txt:
	.while byte ptr[esi]!=0
		.if (byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)
			inc	esi
		.elseif byte ptr[esi]=='<'
			mov	eax,[esi+1]
			or	eax,20202020h
			.if (eax=='lbat')
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
				inc	_indent
				call	tbl2txt
			.elseif ax=='ircs'
				call	skipscr
			.elseif ax=='rb'
				.if savetype==2
					.if dword ptr[edi-4]!='>RB<'
						mov	eax,'>RB<'
						stosd
					.endif
				.else
					mov	_nline,1
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (al=='b')&&((byte ptr[esi+2]=='>')||(byte ptr[esi+2]<33))
				.if savetype==2
					mov	eax,'>B<'
					stosd
					dec	edi
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (al=='i')&&((byte ptr[esi+2]=='>')||(byte ptr[esi+2]<33))
				.if savetype==2
					mov	eax,'>I<'
					stosd
					dec	edi
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (al=='u')&&((byte ptr[esi+2]=='>')||(byte ptr[esi+2]<33))
				.if savetype==2
					mov	eax,'>U<'
					stosd
					dec	edi
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif ax=='rt'
				mov	_nline,1
				.if savetype==2
					.if (dword ptr[edi-4]!='>RB<')&&(dword ptr[edi-4]!='>DT<')
						mov	eax,'>RB<'
						stosd
					.endif
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif byte ptr[esi+1]=='/'
				mov	eax,[esi+2]
				or	eax,20202020h
				.if (al=='b')&&((byte ptr[esi+3]=='>')||(byte ptr[esi+3]<33))
					.if savetype==2
						mov	eax,'>B/<'
						stosd
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (al=='i')&&((byte ptr[esi+3]=='>')||(byte ptr[esi+3]<33))
					.if savetype==2
						mov	eax,'>I/<'
						stosd
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (al=='u')&&((byte ptr[esi+3]=='>')||(byte ptr[esi+3]<33))
					.if savetype==2
						mov	eax,'>U/<'
						stosd
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (al=='a')&&(byte ptr[esi+3]=='>')
				;	.if dword ptr[edi-4]!='>RB<'
				;		mov	eax,'>RB<'
				;		stosd
				;	.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (eax=='lbat')
					mov	_nline,1
					dec	_indent
					.if savetype==2
						.if (dword ptr[edi-4]!='>RB<')||(dword ptr[edi-8]!='>RB<')
							mov	eax,'>RB<'
							stosd
						.endif
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
					ret
				.else
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.endif
			.else
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.endif
		.else
			call	savechr
		.endif
		savedump1
	.endw
	ret

esc_tbl:.if savetype!=2
		.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
			inc	esi
		.endw
		.if byte ptr[esi]=='>'
			inc	esi
		.endif
		ret
	.endif
	.if byte ptr[esi]=='<'
		movsb
	.endif
	.while (byte ptr[esi]>32)&&(byte ptr[esi]!='>')
		movsb
	.endw
	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
		mov	eax,[esi]
		or	eax,20202020h
		.if eax=='alc '
			lea	esi,[esi+4]
			mov	al,[esi]
			or	al,20h
			.if al=='s'
				inc	esi
			.endif
			mov	al,[esi]
			or	al,20h
			.if al=='s'
				inc	esi
			.endif
			.while (byte ptr[esi]=='=')||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==32)
				inc	esi
			.endw
			.if (byte ptr[esi]==34)
				inc	esi
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]==34
					inc	esi
				.endif
			.elseif byte ptr[esi]==39
				inc	esi
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]==39
					inc	esi
				.endif
			.else
				.while (byte ptr[esi]>32)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
			.endif
		.elseif eax=='yts '
			lea	esi,[esi+4]
			mov	al,[esi]
			or	al,20h
			.if al=='l'
				inc	esi
			.endif
			mov	al,[esi]
			or	al,20h
			.if al=='e'
				inc	esi
			.endif
			.while (byte ptr[esi]=='=')||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==32)
				inc	esi
			.endw
			.if (byte ptr[esi]==34)
				inc	esi
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]==34
					inc	esi
				.endif
			.elseif byte ptr[esi]==39
				inc	esi
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]==39
					inc	esi
				.endif
			.else
				.while (byte ptr[esi]>32)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
			.endif
		.elseif ax=='o '
			inc	esi
			.while byte ptr[esi]>='A'
				inc	esi
			.endw
			.while (byte ptr[esi]=='=')||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==32)
				inc	esi
			.endw
			.if (byte ptr[esi]==34)
				inc	esi
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]==34
					inc	esi
				.endif
			.elseif byte ptr[esi]==39
				inc	esi
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]==39
					inc	esi
				.endif
			.else
				.while (byte ptr[esi]>32)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
			.endif
		.else
			movsb
		.endif
	.endw
	.if byte ptr[esi]=='>'
		inc	esi
	.endif
	mov	al,'>'
	stosb
	ret


tbl2txt2:
	call	esc_tbl
	.while byte ptr[esi]!=0
		.if (byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)
			inc	esi
		.elseif byte ptr[esi]=='<'
			mov	eax,[esi+1]
			or	eax,20202020h
			.if (eax=='lbat')
				inc	_indent
				push	ecx
				call	tbl2txt2
				pop	ecx
			.elseif ax=='ircs'
				push	ecx
				call	skipscr
				pop	ecx
			.elseif ax=='rb'
				call	esc_br
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (al=='b')&&((byte ptr[esi+2]=='>')||(byte ptr[esi+2]<33))
				.if savetype==2
					mov	eax,'>B<'
					stosd
					dec	edi
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif ax==' a'
				call	w_a
			.elseif (eax==' gmi')&&(savetype>=2)
				push	ecx
				call	w_img
				pop	ecx
			.elseif (al=='i')&&((byte ptr[esi+2]=='>')||(byte ptr[esi+2]<33))
				.if savetype==2
					mov	eax,'>I<'
					stosd
					dec	edi
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (al=='u')&&((byte ptr[esi+2]=='>')||(byte ptr[esi+2]<33))
				.if savetype==2
					mov	eax,'>U<'
					stosd
					dec	edi
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif ax=='rt'
				mov	_nline,1
				call	esc_tbl
			.elseif ax=='dt'
				.if savetype!=2
					mov	al,9
					call	savechar
				.endif
				call	esc_tbl
			.elseif ax=='ht'
				mov	_nline,1
				call	esc_tbl
			.elseif byte ptr[esi+1]=='/'
				mov	eax,[esi+2]
				or	eax,20202020h
				.if (al=='b')&&((byte ptr[esi+3]=='>')||(byte ptr[esi+3]<33))
					.if savetype==2
						mov	eax,'>B/<'
						stosd
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (al=='i')&&((byte ptr[esi+3]=='>')||(byte ptr[esi+3]<33))
					.if savetype==2
						mov	eax,'>I/<'
						stosd
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (al=='u')&&((byte ptr[esi+3]=='>')||(byte ptr[esi+3]<33))
					.if savetype==2
						mov	eax,'>U/<'
						stosd
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif ax=='dt'
					.if savetype==2
						mov	eax,'DT/<'
						stosd
						mov	al,'>'
						stosb
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif ax=='ht'
					mov	_nline,1
					.if savetype==2
						mov	eax,'HT/<'
						stosd
						mov	al,'>'
						stosb
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif ax=='rt'
					mov	_nline,1
					.if savetype==2
						mov	eax,'RT/<'
						stosd
						mov	al,'>'
						stosb
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (al=='a')&&((byte ptr[esi+3]=='>')||(byte ptr[esi+3]<33))
					.if ecx
						xor	ecx,ecx
						.if savetype==2
							mov	eax,'>A/<'
							stosd
						.endif
					.elseif (byte ptr[esi+3]=='>')
						call	esc_br
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (eax=='lbat')
					.if _indent
						dec	_indent
					.endif
					mov	_nline,1
					.if savetype==2
						mov	eax,'AT/<'
						stosd
						mov	eax,'>ELB'
						stosd
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
					ret
				.else
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.endif
			.else
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.endif
		.else
			call	savechr
		.endif
		savedump1
	.endw
	ret

skiptd:	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
		inc	esi
	.endw
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			.if byte ptr[esi+1]=='/'
				mov	eax,[esi+2]
				or	eax,20202020h
				.if (ax=='dt')
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
					ret
				.else
					inc	esi
				.endif
			.else
				mov	eax,[esi+1]
				or	eax,20202020h
				.if ax=='dt'
					ret
				.else
					inc	esi
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	ret

w_td1:	.while byte ptr[esi]!=0
		.if byte ptr[esi]=='<'
			mov	ax,[esi+1]
			or	ax,2020h
			.if ax=='dt'
				.while 0 ;(byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					mov	eax,[esi]
					or	eax,20202020h
					.if eax=='diw '
						lea	esi,[esi+4]
						mov	ax,[esi]
						or	ax,2020h
						.if ax=='ht'
							inc	esi
							inc	esi
						.endif
						.while (byte ptr[esi]=='=')||(byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==39)||(byte ptr[esi]==34)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
							inc	esi
						.endw
						push	edx
						call	atoi
						pop	edx
						.if byte ptr[esi]=='%'
							.if eax<=5
								call	skiptd
								jmp	w_td1
							.endif
						.else
							.if eax<=5
								call	skiptd
								jmp	w_td1
							.endif
						.endif
					.else
						inc	esi
					.endif
				.endw

				.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
				.break
			.else
				inc	esi
			.endif
		.else
			inc	esi
		.endif
	.endw
w_td1a:	.while byte ptr[esi]!=0
		.if (byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)
			inc	esi
		.elseif byte ptr[esi]=='<'
			mov	eax,[esi+1]
			or	eax,20202020h
			.if (eax=='lbat')
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
				inc	_indent
				call	tbl2txt
			.elseif ax=='ircs'
				call	skipscr
			.elseif ax=='rb'
				call	esc_br
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (al=='b')&&((byte ptr[esi+2]=='>')||(byte ptr[esi+2]<33))
				.if savetype==2
					mov	eax,'>B<'
					stosd
					dec	edi
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (al=='i')&&((byte ptr[esi+2]=='>')||(byte ptr[esi+2]<33))
				.if savetype==2
					mov	eax,'>I<'
					stosd
					dec	edi
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (al=='u')&&((byte ptr[esi+2]=='>')||(byte ptr[esi+2]<33))
				.if savetype==2
					mov	eax,'>U<'
					stosd
					dec	edi
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif byte ptr[esi+1]=='/'
				mov	eax,[esi+2]
				or	eax,20202020h
				.if (al=='b')&&((byte ptr[esi+3]=='>')||(byte ptr[esi+3]<33))
					.if savetype==2
						mov	eax,'>B/<'
						stosd
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (al=='i')&&((byte ptr[esi+3]=='>')||(byte ptr[esi+3]<33))
					.if savetype==2
						mov	eax,'>I/<'
						stosd
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (al=='u')&&((byte ptr[esi+3]=='>')||(byte ptr[esi+3]<33))
					.if savetype==2
						mov	eax,'>U/<'
						stosd
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (al=='a')&&(byte ptr[esi+3]=='>')
				;	call	esc_br
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (ax=='dt')||(ax=='rt')
					mov	_nline,1
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
					ret
				.else
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.endif
			.else
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.endif
		.else
			call	savechr
		.endif
		savedump1
	.endw
	ret

w_td2:	.while byte ptr[esi]!=0
		.if byte ptr[esi]=='<'
			mov	ax,[esi+1]
			or	ax,2020h
			.if ax=='dt'
				.while 0 ;(byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					mov	eax,[esi]
					or	eax,20202020h
					.if eax=='diw '
						lea	esi,[esi+4]
						mov	ax,[esi]
						or	ax,2020h
						.if ax=='ht'
							inc	esi
							inc	esi
						.endif
						.while (byte ptr[esi]=='=')||(byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==39)||(byte ptr[esi]==34)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
							inc	esi
						.endw
						push	edx
						call	atoi
						pop	edx
						.if byte ptr[esi]=='%'
							.if eax<=5
								call	skiptd
								jmp	w_td2
							.endif
						.else
							.if eax<=5
								call	skiptd
								jmp	w_td2
							.endif
						.endif
					.else
						inc	esi
					.endif
				.endw

				.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
				.break
			.else
				inc	esi
			.endif
		.else
			inc	esi
		.endif
	.endw
w_td2a:	.while byte ptr[esi]!=0
		.if (byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)
			inc	esi
		.elseif byte ptr[esi]=='<'
			mov	eax,[esi+1]
			or	eax,20202020h
			.if (eax=='lbat')
				inc	_indent
				call	tbl2txt2
			.elseif ax=='ircs'
				call	skipscr
			.elseif ax=='rb'
				call	esc_br
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (al=='b')&&((byte ptr[esi+2]=='>')||(byte ptr[esi+2]<33))
				.if savetype==2
					mov	eax,'>B<'
					stosd
					dec	edi
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (al=='i')&&((byte ptr[esi+2]=='>')||(byte ptr[esi+2]<33))
				.if savetype==2
					mov	eax,'>I<'
					stosd
					dec	edi
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (al=='u')&&((byte ptr[esi+2]=='>')||(byte ptr[esi+2]<33))
				.if savetype==2
					mov	eax,'>U<'
					stosd
					dec	edi
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.elseif (eax==' gmi')&&(savetype>=2)
				call	w_img
			.elseif ax==' a'
				call	w_a
			.elseif byte ptr[esi+1]=='/'
				mov	eax,[esi+2]
				or	eax,20202020h
				.if (al=='b')&&((byte ptr[esi+3]=='>')||(byte ptr[esi+3]<33))
					.if savetype==2
						mov	eax,'>B/<'
						stosd
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (al=='i')&&((byte ptr[esi+3]=='>')||(byte ptr[esi+3]<33))
					.if savetype==2
						mov	eax,'>I/<'
						stosd
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (al=='u')&&((byte ptr[esi+3]=='>')||(byte ptr[esi+3]<33))
					.if savetype==2
						mov	eax,'>U/<'
						stosd
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (al=='a')&&((byte ptr[esi+3]=='>')||(byte ptr[esi+3]<33))
					.if ecx
						xor	ecx,ecx
						.if savetype==2
							mov	eax,'>A/<'
							stosd
						.endif
					.elseif (byte ptr[esi+3]=='>')
						call	esc_br
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.elseif (ax=='dt')||(ax=='rt')
					mov	_nline,1
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
					ret
				.else
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
				.endif
			.else
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.endif
		.else
			call	savechr
		.endif
		savedump1
	.endw
	ret

esc_br:	.if savetype==2
		.while (byte ptr[edi-1]==32)||(byte ptr[edi-1]==9)||(byte ptr[edi-1]==13)||(byte ptr[edi-1]==10)
			dec	edi
		.endw
		.if (dword ptr[edi-4]!='>RB<')&&(dword ptr[edi-4]!='>DT<')
			mov	eax,'>RB<'
			stosd
		.endif
	.else
		mov	_nline,1
	.endif
	ret

u_fn:	push	edx
	invoke	GetFileAttributes,edx
	pop	edx
	.if eax==-1
		ret
	.endif
	push	edx
	mov	ecx,edx
	.while byte ptr[edx]
		.if (byte ptr[edx]=='.')||(byte ptr[edx]=='/')||(byte ptr[edx]=='\')
			mov	ecx,edx
		.endif
		inc	edx
	.endw
	.if byte ptr[ecx]!='.'
		mov	ecx,edx
		mov	byte ptr[ecx+1000],0
	.else
		push	edi
		push	ecx
		push	edx
		mov	edx,ecx
		xor	ecx,ecx
		lea	edi,[edx+1000]
		.while (ecx<999)&&(byte ptr[edx]!=0)
			mov	al,[edx]
			stosb
			inc	edx
			inc	ecx
		.endw
		mov	al,0
		stosb
		pop	edx
		pop	ecx
		pop	edi
	.endif
	mov	edx,ecx
	lea	ecx,[ecx+1000]
	.while (byte ptr[edx-1]=='9')
		dec	edx
	.endw
	.if (byte ptr[edx-1]<='9')&&(byte ptr[edx-1]>='0')
		dec	edx
	.endif
	.if (byte ptr[edx]<'0')||(byte ptr[edx]>'9')
		mov	word ptr[edx],'1_'
		push	edi
		lea	edi,[edx+2]
		mov	edx,ecx
		call	copyedx
		mov	al,0
		stosb
		pop	edi
		pop	edx
		jmp	u_fn
	.endif
	.if byte ptr[edx]=='9'
		mov	byte ptr[edx],'1'
		inc	edx
		.while byte ptr[edx]=='9'
			mov	byte ptr[edx],'0'
			inc	edx
		.endw
		mov	byte ptr[edx],'0'
		push	edi
		lea	edi,[edx+1]
		mov	edx,ecx
		call	copyedx
		mov	al,0
		stosb
		pop	edi
		pop	edx
		jmp	u_fn
	.else
		inc	byte ptr[edx]
		.while byte ptr[edx+1]=='9'
			inc	edx
			mov	byte ptr[edx],'0'
		.endw
		push	edi
		lea	edi,[edx+1]
		mov	edx,ecx
		call	copyedx
		mov	al,0
		stosb
		pop	edi
		pop	edx
		jmp	u_fn
	.endif
	pop	edx
	ret


assume	ebx:ptr foruminfo
get_lnk	PROC uses esi ebx
	local	lParam:DWORD,r_buf:DWORD,_edi:DWORD
	mov	_edi,edi
	invoke	GlobalAlloc,GPTR,sizeof foruminfo
	mov	lParam,eax
	invoke	GlobalAlloc,GPTR,8192
	mov	r_buf,eax
	mov	ebx,lParam
	assume	ebx:ptr foruminfo
	mov	[ebx]._loc,0
	mov	[ebx].histptr,0
	lea	edi,[ebx]._addr
	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
		lodsb
		.if al=='&'
			mov	eax,[esi]
			or	eax,202020h
			.if eax==';pma'
				lodsd
			.endif
			mov	al,'&'
		.else
			mov	eax,[esi-1]
			or	eax,20202020h
			.if eax=='=dis'
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
					inc	esi
				.endw
				.continue
			.elseif eax=='sphp'
				mov	eax,[esi+3]
				or	eax,20202020h
				.if eax=='isse'
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
						inc	esi
					.endw
					.continue
				.endif
			.elseif ax=='=s'
				mov	eax,2
				.while ((byte ptr[esi+eax]>='0')&&(byte ptr[esi+eax]<='9'))||((byte ptr[esi+eax]>='a')&&(byte ptr[esi+eax]<='f'))||((byte ptr[esi+eax]>='A')&&(byte ptr[esi+eax]<='F'))
					inc	eax
				.endw
				.if eax>8
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
						inc	esi
					.endw
					.continue
				.endif
			.endif
			mov	al,[esi-1]
		.endif
		stosb
	.endw
	.if byte ptr[edi-1]=='&'
		dec	edi
	.endif
	mov	al,0
	stosb
	check_hist

	mov	edi,lParam
	invoke	get_afile,addr r_buf,_edi,1,0,8192
	mov	hfile,0
	invoke	GlobalFree,lParam
	invoke	GlobalFree,r_buf
	ret
get_lnk	ENDP

get_att	PROC uses esi ebx atype:DWORD
	local	lParam:DWORD,r_buf:DWORD,_edi:DWORD
	mov	_edi,edi
	invoke	GlobalAlloc,GPTR,sizeof foruminfo
	mov	lParam,eax
	invoke	GlobalAlloc,GPTR,8192
	mov	r_buf,eax
	mov	ebx,lParam
	assume	ebx:ptr foruminfo
	lea	edi,[ebx]._addr
	mov	[ebx]._loc,0
	mov	[ebx].histptr,0
	call	copylink

	check_hist
	mov	edi,lParam
	invoke	get_afile,addr r_buf,_edi,0,0,8192
	.if fsize
		mov	ebx,lParam
		idx_savefile
		assume	edi:ptr foruminfo
		mov	edi,lParam
		lea	edx,[edi]._save
		mov	edi,_edi
		.if atype==1
			.if savetype==2
				mov	eax,'GMI<'
				stosd
				mov	eax,'crs '
				stosd
				mov	ax,'"='
				stosw
			.else
				mov	al,'('
				push	edx
				call	savechar
				pop	edx
			.endif
			call	copyedx
			.if savetype==2
				mov	ax,'>"'
				stosw
			.else
				mov	al,')'
				stosb
			.endif
		.elseif atype==2
			xor	ecx,ecx
			.while byte ptr[edx+ecx]
				.if (byte ptr[edx+ecx]=='\')||(byte ptr[edx+ecx]=='/')
					lea	edx,[edx+ecx]
					xor	ecx,ecx
				.endif
				inc	ecx
			.endw
			.if (byte ptr[edx]=='/')||(byte ptr[edx]=='\')
				inc	edx
			.endif
			call	copyedx
		.elseif atype==3
			push	desturls
			mov	edi,lParam
			lea	eax,[edi]._save
			mov	desturls,eax
			call	addurl
			pop	desturls
		.endif
		assume	edi:nothing
	.endif
	mov	hfile,0
	invoke	GlobalFree,lParam
	invoke	GlobalFree,r_buf
	xor	eax,eax
	inc	eax
	ret
get_att	ENDP
assume	ebx:nothing


sm1	db	'/tongue',0,1
sm2	db	'/biggrin',0,2
sm3	db	'/smile.',0,3
sm4	db	'/sad',0,4
sm5	db	'/smiley.',0,3
w_img:	.while (byte ptr[esi]!='>')
		mov	eax,[esi]
		or	eax,20202020h
		.if eax=='crs '
			lea	esi,[esi+4]
			.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]=='=')||(byte ptr[esi]==34)||(byte ptr[esi]==39)
				inc	esi
			.endw

			mov	edx,f_info
			assume	edx:ptr foruminfo
			lea	edx,[edx]._addr
			assume	edx:nothing
			mov	eax,[esi]
			or	eax,20202020h
			.if eax=='ptth'
				lea	esi,[esi+4]
				.while 1
					.if (byte ptr[esi]==':')||(byte ptr[esi]=='/')
						inc	esi
					.elseif (dword ptr[esi]=='85#&')
						lea	esi,[esi+4]
						.if byte ptr[esi]==';'
							inc	esi
						.endif
					.else
						.break
					.endif
				.endw
			.else
				jmp	_int_img
			.endif
			mov	eax,[edx]
			or	eax,20202020h
			.if eax=='ptth'
				lea	edx,[edx+4]
				.while (byte ptr[edx]==':')||(byte ptr[edx]=='/')
					inc	edx
				.endw
			.endif
			xor	ecx,ecx
			.while (byte ptr[edx+ecx]!=0)&&(byte ptr[edx+ecx]!='/')
				mov	al,[edx+ecx]
				mov	ah,[esi+ecx]
				or	ax,2020h
				.break .if al!=ah
				inc	ecx
			.endw
			.if (byte ptr[edx+ecx]=='/')||(byte ptr[edx+ecx]==0)
_int_img:			push	esi
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)
					mov	eax,[esi]
					or	eax,20202020h
					.if (eax=='lims')&&((byte ptr[esi+4]=='e')||(byte ptr[esi+1]=='E'))
						lea	edx,sm1
						call	_scan
						.if eax
							mov	ax,'P:'
							stosw
							jmp	_sm
						.endif
						lea	edx,sm2
						call	_scan
						.if eax
							mov	ax,'D:'
							stosw
							jmp	_sm
						.endif
						lea	edx,sm3
						call	_scan
						.if eax
							mov	ax,'):'
							stosw
							jmp	_sm
						.endif
						lea	edx,sm4
						call	_scan
						.if eax
							mov	ax,'(:'
							stosw
							jmp	_sm
						.endif
						lea	edx,sm5
						call	_scan
						.if eax
							mov	ax,'):'
							stosw
							jmp	_sm
						.endif
						.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!='/')
							inc	esi
						.endw
						.if (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)
							mov	al,'['
							stosb
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)
								movsb
							.endw
							mov	al,']'
							stosb
						.endif
_sm:						.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)
							inc	esi
						.endw
						.if byte ptr[esi]=='>'
							inc	esi
						.endif
						.break
					.elseif eax=='atta'
						pop	esi
						jmp	_imgatt
						pop	esi
						push	esi
						invoke	get_att,1
						.break
					.endif
					inc	esi
				.endw
				pop	eax
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
				ret
			.endif
			mov	eax,[edx]
			or	eax,20202020h
			.if eax=='ptth'
				lea	edx,[edx+4]
				.while (byte ptr[edx]==':')||(byte ptr[edx]=='/')
					inc	edx
				.endw
			.endif
			xor	ecx,ecx
			.while (byte ptr[edx+ecx]!=0)&&(byte ptr[edx+ecx]!='/')
				mov	al,[esi+ecx]
				mov	ah,[edx+ecx]
				or	ax,2020h
				.break .if al!=ah
				inc	ecx
			.endw
			.if (byte ptr[edx+ecx]==0)||(byte ptr[edx+ecx]=='/')
				.continue
			.else
_imgatt:			.if savetype==2
					mov	eax,'GMI<'
					stosd
					mov	eax,'crs '
					stosd
					mov	ax,'"='
					stosw
				.else
					mov	al,'('
					call	savechar
				.endif
				xor	ecx,ecx
				push	esi
				push	edi
				.if pflag&32
					call	get_lnk
				.endif
				pop	edx
				pop	esi
				.if edi!=edx
					.if savetype==2
						mov	ax,'>"'
						stosw
					.else
						mov	al,')'
						call	savechar
					.endif
				.elseif pflag&64
					.while (byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						movsb
					.endw
					.if savetype==2
						mov	ax,'>"'
						stosw
					.else
						mov	al,')'
						call	savechar
					.endif
				.else
					sub	edi,4+4+2
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
			.endif
			xor	ecx,ecx
			ret
		.endif
		inc	esi
	.endw
	ret

_imgth	db	'*** Image is linked using a thumbnail, downloading full image...',13,10,0
get_img	PROC uses esi ebx
	local	lParam:DWORD,r_buf:DWORD,_edi:DWORD
	mov	_edi,edi
	invoke	GlobalAlloc,GPTR,sizeof foruminfo
	mov	lParam,eax
	invoke	GlobalAlloc,GPTR,8192
	mov	r_buf,eax
	mov	ebx,lParam
	assume	ebx:ptr foruminfo
	lea	edi,[ebx]._addr
	mov	[ebx].histptr,0
	mov	eax,[esi]
	or	eax,20202020h
	.if byte ptr[esi]=='/'
		mov	edx,f_info
		assume	edx:ptr foruminfo
		lea	edx,[edx]._addr
		assume	edx:nothing
		mov	eax,[edx]
		or	eax,20202020h
		.if eax=='ptth'
			lea	edx,[edx+4]
			.while (byte ptr[edx]==':')||(byte ptr[edx]=='/')
				inc	edx
			.endw
		.endif
		.while (byte ptr[edx]!=0)&&(byte ptr[edx]!='/')
			mov	al,[edx]
			stosb
			inc	edx
		.endw
	.elseif (eax!='ptth')||(word ptr[esi+4]!='/:')||(byte ptr[esi+6]!='/')
		mov	edx,f_info
		assume	edx:ptr foruminfo
		lea	edx,[edx]._addr
		assume	edx:nothing
		mov	eax,[edx]
		or	eax,20202020h
		.if eax=='ptth'
			lea	edx,[edx+4]
			.while (byte ptr[edx]==':')||(byte ptr[edx]=='/')
				inc	edx
			.endw
		.endif
		.while (byte ptr[edx]!=0)&&(byte ptr[edx]!='/')
			mov	al,[edx]
			stosb
			inc	edx
		.endw
		mov	al,'/'
		stosb
	.endif
	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
		lodsb
		.if al=='&'
			mov	eax,[esi]
			or	eax,202020h
			.if eax==';pma'
				lodsd
			.endif
			mov	al,'&'
		.else
			mov	eax,[esi-1]
			or	eax,20202020h
			.if eax=='=dis'
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
					inc	esi
				.endw
				.continue
			.elseif eax=='sphp'
				mov	eax,[esi+3]
				or	eax,20202020h
				.if eax=='isse'
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
						inc	esi
					.endw
					.continue
				.endif
			.elseif ax=='=s'
				mov	eax,2
				.while ((byte ptr[esi+eax]>='0')&&(byte ptr[esi+eax]<='9'))||((byte ptr[esi+eax]>='a')&&(byte ptr[esi+eax]<='f'))||((byte ptr[esi+eax]>='A')&&(byte ptr[esi+eax]<='F'))
					inc	eax
				.endw
				.if eax>8
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
						inc	esi
					.endw
					.continue
				.endif
			.endif
			mov	al,[esi-1]
		.endif
		stosb
	.endw
	.if byte ptr[edi-1]=='&'
		dec	edi
	.endif
	mov	al,0
	stosb
	check_hist1

	mov	edi,lParam
	mov	fsize,0
	.if pflag&32
		assume	edi:ptr foruminfo
		mov	[edi]._loc,0
		lea	esi,[edi]._addr
		call	isbanneddns
		assume	edi:nothing
		.if eax==0
			invoke	getfile,addr r_buf,0,0,8192
		.endif
		mov	hfile,0
	.endif
	.if fsize
		mov	esi,r_buf
		xor	ecx,ecx
		.while byte ptr[esi+ecx]
			mov	eax,[esi+ecx]
			or	eax,20202000h
			.break .if eax=='gmi['
			inc	ecx
		.endw
		.if (eax!='gmi[')
			mov	esi,r_buf
			.if (word ptr[esi]==0d8ffh)||(word ptr[esi]=='MB')||(word ptr[esi]=='MM')||(word ptr[esi]=='II')||(dword ptr[esi]=='8FIG')||(dword ptr[esi]==474e5089h)
				mov	edi,_edi
				.if (savetype==2)
					lea	edx,imgsrc
					call	copyedx
				.elseif (savetype==1)
					lea	edx,ahref
					call	copyedx
				.else
					mov	al,'('
					call	savechar
				.endif
				mov	ebx,lParam
				call	make_fname
				invoke	CreateFile,edx,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0
				.if eax!=INVALID_HANDLE_VALUE
					push	eax
					mov	edx,eax
					invoke	WriteFile,edx,r_buf,fsize,addr bread,0
					call	CloseHandle
					.if (savetype==2)||(savetype==1)
						mov	ax,'>"'
						stosw
					.else
						mov	al,')'
						stosb
					.endif
					.if [ebx]._loc
						lea	edx,[ebx]._loc
					.else
						lea	edx,[ebx]._addr
					.endif
					add_hist
					invoke	GlobalFree,lParam
					invoke	GlobalFree,r_buf
					xor	eax,eax
					inc	eax
				.else
					mov	edi,_edi
					invoke	GlobalFree,lParam
					invoke	GlobalFree,r_buf
					xor	eax,eax
				.endif
				ret
			.else
				push	esi
				.while byte ptr[esi]
					.if byte ptr[esi]=='<'
						mov	eax,[esi+1]
						or	eax,20202020h
						.if (eax=='ydob')
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								inc	esi
							.endw
							.if byte ptr[esi]=='>'
								inc	esi
								.while 1
									.if (byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==32)||(byte ptr[esi]==9)
										inc	esi
									.elseif (byte ptr[esi]=='<')&&((byte ptr[esi+1]=='p')||(byte ptr[esi+1]=='P'))&&(byte ptr[esi+2]=='>')
										lea	esi,[esi+3]
										.while (byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==32)||(byte ptr[esi]==9)
											inc	esi
										.endw
										mov	eax,[esi]
										or	eax,20202000h
										.if eax=='gmi<'
											pop	esi
											jmp	_bspot
										.endif
									.else
										.break
									.endif
								.endw
								mov	eax,[esi]
								or	eax,20202000h
								.if eax=='gmi<'
									.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
										inc	esi
									.endw
									.if byte ptr[esi]=='>'
										inc	esi
									.endif
									.while (byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==32)||(byte ptr[esi]==9)
										inc	esi
									.endw
									mov	eax,[esi]
									or	eax,202000h
									.if eax=='ob/<'
										pop	esi
										jmp	_bspot
									.endif
								.endif
							.endif
						.elseif eax=='ltit'
							xor	ecx,ecx
							inc	ecx
							.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='<')
								mov	eax,[esi+ecx]
								or	eax,20202020h
								.if eax=='gami'
									mov	eax,[esi+ecx+4]
									or	eax,20h
									.if ax==':e'
										pop	esi
										jmp	_bspot
									.endif
								.endif
								inc	ecx
							.endw
							inc	esi
						.else
							inc	esi
						.endif
					.else
						inc	esi
					.endif
				.endw
				pop	esi
				invoke	GlobalFree,lParam
				invoke	GlobalFree,r_buf
				mov	edi,_edi
				xor	eax,eax
				ret
			.endif
		.endif
_bspot:		xor	edx,edx
		.while byte ptr[esi]
			.if byte ptr[esi]=='<'
				mov	eax,[esi+1]
				or	eax,20202020h
				.if (eax==' gmi')&&(edx!=0)
					mov	ebx,esi
					lea	esi,[esi+4]
					xor	ecx,ecx
					.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='>')
						mov	ax,[esi+ecx]
						or	ax,2020h
						.if ax=='a '
							mov	eax,[esi+ecx+2]
							or	eax,2020h
							.if (eax=='"=tl')
								.if (byte ptr[esi+ecx+2+4]=='[')
									jmp	testth
								.else
									mov	eax,[esi+ecx+2+4]
									or	eax,20202020h
									.if eax=='gami'
										mov	ax,[esi+ecx+2+4+4]
										or	al,20h
										.if ax==':e'
											jmp	testth
										.else
											inc	ecx
										.endif
									.else
										inc	ecx
									.endif
								.endif
							.else
								inc	ecx
							.endif
						.elseif ax=='t '
							mov	eax,[esi+ecx+2]
							or	eax,20202020h
							.if eax=='elti'
testth:								mov	esi,ebx
								.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
									mov	eax,[esi]
									or	eax,20202020h
									.break .if eax=='=crs'
									inc	esi
								.endw
								.if eax=='=crs'
									lea	esi,[esi+4]
foundth:								lea	edx,_imgth
									call	showmsg
									.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]=='=')||(byte ptr[esi]==34)||(byte ptr[esi]==39)
										inc	esi
									.endw
									mov	edi,_edi
									push	edi
									push	f_info
									mov	eax,lParam
									mov	f_info,eax
									.if (savetype==2)
										lea	edx,ahref
										call	copyedx
									.elseif (savetype==1)
										lea	edx,ahref
										call	copyedx
									.else
										mov	al,'('
										call	savechar
									.endif
									push	edi
									invoke	get_att,2
									pop	edx
									.if edi==edx
										mov	edi,[esp+4]
									.else
										.if (savetype==2)||(savetype==1)
											mov	ax,'>"'
											stosw
										.else
											mov	al,')'
											stosb
										.endif
									.endif
									pop	f_info
									invoke	GlobalFree,lParam
									invoke	GlobalFree,r_buf
									pop	edx
									xor	eax,eax
									.if edi!=edx
										inc	eax
									.endif
									ret
								.endif
								.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
									inc	esi
								.endw
								.break
							.else
								inc	ecx
							.endif
						.else
							inc	ecx
						.endif
					.endw
				.elseif eax=='ydob'
					inc	edx
					inc	esi
				.else
					inc	esi
				.endif
			.elseif (dword ptr[esi]=='GMI[')
				lodsd
				.if byte ptr[esi]==']'
					lodsb
					xor	ecx,ecx
					push	0
					.while (byte ptr[esi+ecx]!='[')&&(byte ptr[esi+ecx]!=0)
						mov	eax,[esi+ecx]
						or	eax,20202020h
						.if (eax=='gami')
							mov	eax,[esi+ecx+4]
							or	eax,20202020h
							.if eax=='ahse'
								mov	eax,[esi+ecx+8]
								or	eax,20002020h
								.if eax=='u.kc'
									mov	byte ptr[esp],1
								.endif
							.endif
						.endif
						.break .if dword ptr[esi+ecx]=='.ht.'
						inc	ecx
					.endw
					pop	eax
					.if (dword ptr[esi+ecx]=='.ht.')&&(eax!=0)
						push	ecx
						lea	ecx,[ecx+4]
						.while (byte ptr[esi+ecx]!='[')&&(byte ptr[esi+ecx]!=0)
							.break .if (byte ptr[esi+ecx]<'A')||(byte ptr[esi+ecx]>'z')
							inc	ecx
						.endw
						pop	eax
						.if byte ptr[esi+ecx]=='['
							mov	ecx,eax
							.while (byte ptr[esi+ecx]!='[')
								mov	al,[esi+ecx+4]
								mov	[esi+ecx],al
								inc	ecx
							.endw
							mov	byte ptr[esi+ecx],34
							jmp	foundth
						.endif
					.endif
				.endif
			.else
				inc	esi
			.endif
		.endw
	.endif
	invoke	GlobalFree,lParam
	invoke	GlobalFree,r_buf
	mov	edi,_edi
	xor	eax,eax
	ret
get_img	ENDP

is_img:
	xor	ecx,ecx
	.while (byte ptr[esi+ecx]!=0)&&(byte ptr[esi+ecx]!='>')
		inc	ecx
	.endw
	.if byte ptr[esi+ecx]=='>'
		inc	ecx
		.while 1
			.break .if byte ptr[esi+ecx]==0
			.break .if byte ptr[esi+ecx]=='<'
			.if (byte ptr[esi+ecx]==32)||(byte ptr[esi+ecx]==9)||(byte ptr[esi+ecx]==13)||(byte ptr[esi+ecx]==10)
				inc	ecx
			.elseif byte ptr[esi+ecx]=='&'
				inc	ecx
				mov	eax,[esi+ecx]
				or	eax,20202020h
				.if (eax=='psbn')&&(byte ptr[esi+ecx+4]==';')
					lea	ecx,[ecx+10]
				.endif
			.else
				.break
			.endif
		.endw
		.if byte ptr[esi+ecx]=='<'
			mov	eax,[esi+ecx+1]
			or	eax,20202020h
			.if eax==' gmi'
				call	get_img
				ret
			.endif
		.endif
	.endif
	xor	eax,eax
	ret

__a	db	'<A HREF="http://',0
ahref	db	'<A HREF="',0
imgsrc	db	'<IMG src="',0
w_a:	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
		mov	eax,[esi]
		or	eax,20202020h
		.if (eax=='erh ')&&((byte ptr[esi+4]=='f')||(byte ptr[esi+4]=='F'))
			lea	esi,[esi+5]
			.while (byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]=='=')||(byte ptr[esi]==34)||(byte ptr[esi]==39)
				inc	esi
			.endw
			mov	eax,[esi]
			or	eax,20202020h
			.if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+6]=='/')&&(savetype>=2)
				mov	eax,[esi+7]
				or	eax,20202020h
				call	is_img
				.if eax
					xor	ecx,ecx
					inc	ecx
					jmp	_rlink
				.endif
				mov	edx,f_info
				assume	edx:ptr foruminfo
				lea	edx,[edx]._addr
				assume	edx:nothing
				lea	esi,[esi+7]
				mov	eax,[edx]
				or	eax,20202020h
				.if eax=='ptth'
					lea	edx,[edx+4]
					.while (byte ptr[edx]==':')||(byte ptr[edx]=='/')
						inc	edx
					.endw
				.endif
				xor	ecx,ecx
				.while (byte ptr[edx+ecx]!=0)&&(byte ptr[edx+ecx]!='/')
					mov	al,[esi+ecx]
					mov	ah,[edx+ecx]
					or	ax,2020h
					.break .if al!=ah
					inc	ecx
				.endw
				.if (byte ptr[edx+ecx]==0)||(byte ptr[edx+ecx]=='/')
					xor	ecx,ecx
_xlink:				.else
					.if savetype==2
						lea	edx,__a
						call	copyedx
					.else
						mov	al,'('
						call	savechar
					.endif
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='"')&&(byte ptr[esi]!='>')&&(byte ptr[esi]!=39)
						mov	al,[esi]
						stosb
						inc	esi
					.endw
					.if savetype==2
						mov	ax,'>"'
						stosw
					.else
						mov	al,')'
						call	savechar
					.endif
					xor	ecx,ecx
					inc	ecx
				.endif
_rlink:				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
				ret
			.else
				jmp	_xlink
			.endif
		.else
			inc	esi
		.endif
	.endw
	.if byte ptr[esi]=='>'
		inc	esi
	.endif
	xor	ecx,ecx
	ret

skiptr:	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
		inc	esi
	.endw
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			.if byte ptr[esi+1]=='/'
				mov	eax,[esi+2]
				or	eax,20202020h
				.if (ax=='rt')
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
					ret
				.else
					inc	esi
				.endif
			.else
				mov	eax,[esi+1]
				or	eax,20202020h
				.if ax=='rt'
					ret
				.else
					inc	esi
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	ret

skiptrtbl:.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
		inc	esi
	.endw
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			.if byte ptr[esi+1]=='/'
				mov	eax,[esi+2]
				or	eax,20202020h
				.if (ax=='rt')||(eax=='lbat')
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.endif
					ret
				.else
					inc	esi
				.endif
			.else
				mov	eax,[esi+1]
				or	eax,20202020h
				.if ax=='rt'
					ret
				.elseif (eax=='lbat')
					inc	esi
					call	skiptbl
				.else
					inc	esi
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	ret

get_info:
	push	esi
	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
		inc	esi
	.endw
	xor	edx,edx
	xor	ecx,ecx
	dec	ecx
	.while byte ptr[esi]!=0
		.if byte ptr[esi]=='<'
			.if byte ptr[esi+1]=='/'
				mov	ax,[esi+2]
				or	ax,2020h
				.if ax=='rt'
					pop	esi
					ret
				.endif
				inc	esi
			.else
				mov	eax,[esi+1]
				or	eax,20202020h
				.if ax=='dt'
					inc	edx
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
						mov	eax,[esi]
						or	eax,20202020h
						.if eax=='diw '
							lea	esi,[esi+4]
							mov	ax,[esi]
							or	ax,2020h
							.if ax=='ht'
								inc	esi
								inc	esi
							.endif
							.while (byte ptr[esi]=='=')||(byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==39)||(byte ptr[esi]==34)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
								inc	esi
							.endw
							.if dl==1
								push	edx
								call	atoi
								pop	edx
								.if byte ptr[esi]=='%'
									.if (eax<=20) ;&&(eax>5)
										xor	ecx,ecx
									.elseif 0 ;eax<=5
										xor	ecx,ecx
										inc	ecx
										dec	edx
									.endif
								.else
									.if (eax<=200) ;&&(eax>5)
										xor	ecx,ecx
									.elseif 0 ;eax<=5
										xor	ecx,ecx
										inc	ecx
										dec	edx
									.endif
								.endif
							.elseif 0
								push	edx
								call	atoi
								pop	edx
								.if byte ptr[esi]=='%'
									.if eax<=5
								;		dec	edx
									.endif
								.else
									.if eax<=5
								;		dec	edx
									.endif
								.endif
							.endif
						.else
							inc	esi
						.endif
					.endw
				.elseif eax=='lbat'
					inc	esi
					call	skiptbl
				.elseif ax=='rt'
					pop	esi
					ret
				.elseif eax=='arfi'
					xor	ecx,ecx
					dec	ecx
					inc	esi
				.else
					inc	esi
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	esi
	ret

dlattach:
	.if (!(pflag&16))
		ret
	.endif
	push	esi
	push	edi
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			inc	esi
			mov	eax,[esi]
			or	eax,20202020h
			.if ax==' a'
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					mov	eax,[esi]
					or	eax,20202020h
					.if (eax=='erh ')&&((byte ptr[esi+4]=='f')||(byte ptr[esi+4]=='F'))
						lea	esi,[esi+5]
_test_att:					.while (byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]=='=')||(byte ptr[esi]==34)||(byte ptr[esi]==39)
							inc	esi
						.endw
						call	forbid_anchor
						.continue .if eax
						call	is_internal
						.continue .if eax==0
						xor	ecx,ecx
						.while (byte ptr[esi+ecx]>32)&&(byte ptr[esi+ecx]!=34)&&(byte ptr[esi+ecx]!=39)&&(byte ptr[esi+ecx]!='>')
							mov	eax,[esi+ecx]
							or	eax,20202020h
							.if eax=='atta'
								mov	ax,[esi+ecx+4]
								or	ax,2020h
								.if ax=='hc'
									invoke	get_att,0
									.break
								.endif
							.elseif (eax=='elif')
								mov	ax,[esi+ecx+4]
								or	ax,2020h
								.if ax=='/s'
									invoke	get_att,0
									.break
								.endif
							.elseif (eax=='nwod')
								invoke	get_att,0
								.break
							.endif
							inc	ecx
						.endw
						xor	ecx,ecx
						.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
							inc	esi
						.endw
						.if byte ptr[esi]=='>'
							inc	esi
						.endif
						.break
					.else
						inc	esi
					.endif
				.endw
			.elseif eax==' gmi'
				lea	esi,[esi+3]
				mov	eax,[esi]
				or	eax,20202020h
				.if (eax=='crs ')
					lea	esi,[esi+4]
					jmp	_test_att
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	edi
	pop	esi
	ret

saved1	db	'*** Saved: ',0
save1	db	'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'
	db	'<HTML><HEAD><META http-equiv="Content-Type" content="text/html; charset=UTF-8"><META name=',34,'GENERATOR',34,' content=',34,'Forum Downloader 1.02 Copyright (c) 2007 by Albu Cristian Laurentiu',34,'><TITLE>',0
save2	db	'</TITLE></HEAD><BODY><TABLE width="100%" border="1"><TR><TH width="20%">Author</TH><TH>Message</TH></TR>',0
save3	db	'</TABLE></BODY></HTML>',0
_td	db	'<TD valign="top" align="left">',0
f_err	db	'[ X ] Forum error ',0
save_topics	PROC	uses esi edi ebx ecx edx lParam:DWORD
	local	r_buf:DWORD,b_read:DWORD,spage:DWORD
	push	ebp
	invoke	GlobalAlloc,GPTR,8192
	mov	r_buf,eax
	mov	edi,lParam
	call	phpset
	mov	fsize,0
	topicdownload
	.if fsize==0
		assume	edi:ptr foruminfo
		mov	[edi]._loc,0
		invoke	getfile,addr r_buf,1,0,8192
		.if (hfile==-1)||(fsize==0)
			mov	hfile,0
		.endif
		mov	edi,lParam
		topicdownloadcomplete
	.endif
	mov	spage,1
	call	escdir
	save_page
	mov	ebx,lParam
	idx_newtopic
	hist_addfile
	invoke	CreateFile,addr defdir,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0
	mov	savefile,eax
	.if savetype<2
		.if savetype==1
			mov	esi,r_buf
			call	prel_file
			mov	r_buf,esi
		.endif
		invoke	WriteFile,savefile,r_buf,fsize,addr b_read,0
		invoke	CloseHandle,savefile
		mov	savefile,0
		lea	edi,buftmp
		push	edi
		lea	edx,saved1
		call	copyedx
		lea	edx,defdir
		call	copyedx
		mov	ax,0a0dh
		stosw
		mov	al,0
		stosb
		pop	edx
		call	showmsg
	.endif
	.if savetype==2
		lea	edi,savetmp
		lea	edx,save1
		call	copyedx
	.endif
	mov	esi,r_buf
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			inc	esi
			mov	eax,[esi]
			or	eax,20202020h
			.if eax=='ltit'
				lea	esi,[esi+4]
				mov	al,[esi]
				or	al,20h
				.if al=='e'
					inc	esi
					.if byte ptr[esi]=='>'
						inc	esi
						save_fmt
						.break
					.endif
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	.if savetype==2
		lea	edx,save2
		call	copyedx
	.endif
	savedump
t_page:
	mov	esi,r_buf
	mov	_indent,0
	mov	_nline,1
	.if (pflag&1)&&(plink1!=0)
		.while byte ptr[esi]
		lea	edx,plink1
		call	_seek
		.if byte ptr[esi]
			.if savetype==2
				mov	eax,'>RT<'
				stosd
				lea	edx,_td
				call	copyedx
			.endif
			mov	ecx,esi
			xor	ebx,ebx
			.if pflag&2
				lea	edx,plink2
				call	_seek
				.if pflag&1
_retry0p:				push	esi
					lea	esi,[ecx+1]
					lea	edx,plink1
					call	_seek
					pop	edx
					.if (byte ptr[esi]!=0)&&(esi<edx)
						mov	ecx,esi
						mov	esi,edx
						jmp	_retry0p
					.else
						mov	esi,edx
					.endif
				.endif
				.if byte ptr[esi]
					push	dword ptr[esi]
					push	esi
					mov	byte ptr[esi],0
					mov	esi,ecx
					call	w_td1a
					pop	esi
					pop	dword ptr[esi]
				.endif
			.else
				call	w_td1a
			.endif
			.if savetype==2
				mov	eax,'DT/<'
				stosd
				mov	al,'>'
				stosb
				lea	edx,_td
				call	copyedx
			.else
				mov	ax,0a0dh
				stosw
				stosw
				mov	_nline,1
				mov	_indent,0
			.endif
			push	esi
			.if pflag&4
				lea	edx,plink3
				call	_seek
				.if byte ptr[esi]
					mov	ecx,esi
					xor	ebx,ebx
					.if (pflag&8)&&(plink4!=0)
						lea	edx,plink4
						call	_seek
						.if pflag&4
_retry1p:						push	esi
							lea	esi,[ecx+1]
							lea	edx,plink3
							call	_seek
							pop	edx
							.if (byte ptr[esi]!=0)&&(esi<edx)
								mov	ecx,esi
								mov	esi,edx
								jmp	_retry1p
							.else
								mov	esi,edx
							.endif
						.endif
						.if byte ptr[esi]
							push	dword ptr[esi]
							push	esi
							mov	byte ptr[esi],0
							mov	esi,ecx
							xor	ecx,ecx
							call	w_td2a
							pop	esi
							pop	dword ptr[esi]
						.endif
					.else
						xor	ecx,ecx
						call	w_td2a
					.endif
				.else
					xor	ecx,ecx
					call	w_td2a
				.endif
			.else
				xor	ecx,ecx
				call	w_td2
			.endif
			pop	edx
			.if extsave>1
				mov	ecx,esi
				sub	ecx,edx
				invoke	savelinked,0
			.endif
			.if savetype==2
				mov	eax,'DT/<'
				stosd
				mov	eax,'T/<>'
				stosd
				mov	ax,'>R'
				stosw
			.else
				mov	eax,0a0d0a0dh
				stosd
				stosw
				mov	_nline,1
				mov	_indent,0
			.endif
			savedump
		.endif
		.endw
	.else
		.while byte ptr[esi]
			.if byte ptr[esi]=='<'
				inc	esi
				mov	eax,[esi]
				or	eax,20202020h
				.if ax=='rt'
					call	get_info
					dec	esi
					.if (ecx!=-1)&&(dl==2)
						push	esi
						.if savetype==2
							mov	eax,'>RT<'
							stosd
							lea	edx,_td
							call	copyedx
						.endif
						call	w_td1
						.if savetype==2
							mov	eax,'DT/<'
							stosd
							mov	al,'>'
							stosb
							lea	edx,_td
							call	copyedx
						.else
							mov	ax,0a0dh
							stosw
							stosw
							mov	_nline,1
							mov	_indent,0
						.endif
						push	esi
						xor	ecx,ecx
						call	w_td2
						pop	edx
						.if extsave>1
							mov	ecx,esi
							sub	ecx,edx
							invoke	savelinked,0
						.endif
						.if savetype==2
							mov	eax,'DT/<'
							stosd
							mov	eax,'T/<>'
							stosd
							mov	ax,'>R'
							stosw
						.else
							mov	eax,0a0d0a0dh
							stosd
							stosw
							mov	_nline,1
							mov	_indent,0
						.endif
						pop	esi
						call	skiptrtbl
						savedump
					.else
						call	skiptr
					.endif
				.endif
			.else
				inc	esi
			.endif
		.endw
	.endif
	mov	esi,r_buf
	mov	ebx,lParam
	idx_savelinkstart
	call	dlattach
	mov	ebx,lParam
	idx_savelinkend
	idx_endpage

	mov	esi,r_buf
	push	edi
	push	esi
	mov	edi,lParam
	topicnextpagesearch
	pop	edx
	.if (labelex!=0)
		.if (esi!=edx)&&(byte ptr[esi]!=0)
			jmp	_tnext1
		.else
			pop	edi
			jmp	tnopage
		.endif
	.endif
	pop	edi
	push	edi
	
	.if (tflag&8)&&(tlink4!=0)
_nnpage:	lea	edx,tlink4
		call	_seek
		.if (byte ptr[esi]!=0)
			.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
				dec	esi
			.endif
			.while (byte ptr[esi-1]>='0')&&(byte ptr[esi-1]<='9')
				dec	esi
			.endw
			.if (byte ptr[esi]=='0')||((byte ptr[esi]=='1')&&((byte ptr[esi+1]>'9')||(byte ptr[esi+1]<'0')))
				inc	esi
				jmp	_nnpage
			.endif
			.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)
				inc	esi
			.endw
			.if byte ptr[esi]==34
				dec	esi
				.while (byte ptr[esi]!=34)&&(esi!=r_buf)
					dec	esi
				.endw
				.if byte ptr[esi]==34
					inc	esi
					mov	edx,esi
					istopicsaved
					.if edx
						.while byte ptr[esi]!=34
							inc	esi
						.endw
						jmp	_nnpage
					.endif
					pop	edi
					push	edi
					jmp	_tnext1
				.endif
			.elseif byte ptr[esi]==39
				dec	esi
				.while (byte ptr[esi]!=39)&&(esi!=r_buf)
					dec	esi
				.endw
				.if byte ptr[esi]==39
					inc	esi
					mov	edx,esi
					istopicsaved
					.if edx
						.while byte ptr[esi]!=39
							inc	esi
						.endw
						jmp	_nnpage
					.endif
					pop	edi
					push	edi
					jmp	_tnext1
				.endif
			.endif
		.endif
	.else
		call	scanpage
	.endif
	pop	edi
	.if (word ptr[esi]=='a<')||(word ptr[esi]=='A<')
		.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
			call	forbid_anchor
			.continue .if eax
			mov	eax,[esi]
			or	eax,20202020h
			.if eax=='erh '
				push	edi
				lea	esi,[esi+4]
				mov	al,[esi]
				or	al,20h
				.if al=='f'
					inc	esi
				.endif
				.while (byte ptr[esi]=='=')||(byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==39)||(byte ptr[esi]==34)
					inc	esi
				.endw
_tnext1:			mov	ebx,lParam
				assume	ebx:ptr foruminfo
				mov	edx,f_info
				assume	edx:ptr foruminfo
				lea	edx,[edx]._addr
				assume	edx:nothing
				lea	edi,[ebx]._addr
				call	copyedx
				mov	al,0
				stosb
				mov	edx,f_info
				assume	edx:ptr foruminfo
				lea	edx,[edx]._dns
				assume	edx:nothing
				lea	edi,[ebx]._dns
				call	copyedx
				mov	al,0
				stosb
				lea	edi,[ebx]._addr
				mov	eax,dword ptr[edi]
				or	eax,20202020h
				.if (eax=='ptth')&&(word ptr[edi+4]=='/:')&&(byte ptr[edi+6]=='/')
					lea	edi,[edi+7]
				.endif
				mov	eax,[esi]
				or	eax,20202020h
				.if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+6]=='/')
					lea	esi,[esi+7]
				.elseif byte ptr[esi]=='/'
					.while (byte ptr[edi]!='/')&&(byte ptr[edi]!=0)
						inc	edi
					.endw
				.else
					mov	edx,edi
					push	edi
					.while byte ptr[edi]
						.if byte ptr[edi]=='/'
							mov	edx,edi
						.endif
						inc	edi
					.endw
					pop	eax
					.if edx==eax
						.if byte ptr[edi]!='/'
							mov	al,'/'
							stosb
						.endif
					.else
						mov	edi,edx
						mov	al,'/'
						stosb
					.endif
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
					lodsb
					.if al=='&'
						mov	eax,[esi]
						or	eax,202020h
						.if eax==';pma'
							lodsd
						.endif
						mov	al,'&'
					.else
						mov	eax,[esi-1]
						or	eax,20202020h
						.if eax=='=dis'
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
								inc	esi
							.endw
							.continue
						.elseif eax=='sphp'
							mov	eax,[esi+3]
							or	eax,20202020h
							.if eax=='isse'
								.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
									inc	esi
								.endw
								.continue
							.endif
						.elseif ax=='=s'
							mov	eax,2
							.while ((byte ptr[esi+eax]>='0')&&(byte ptr[esi+eax]<='9'))||((byte ptr[esi+eax]>='a')&&(byte ptr[esi+eax]<='f'))||((byte ptr[esi+eax]>='A')&&(byte ptr[esi+eax]<='F'))
								inc	eax
							.endw
							.if eax>8
								.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
									inc	esi
								.endw
								.continue
							.endif
						.endif
						mov	al,[esi-1]
					.endif
					stosb
				.endw
				.if byte ptr[edi-1]=='&'
					dec	edi
				.endif
				mov	al,0
				stosb
				mov	edi,lParam
				call	phpset
				mov	fsize,0
				topicdownload
				.if fsize==0
					mov	[edi]._loc,0
					invoke	getfile,addr r_buf,1,0,8192
					.if (hfile==-1)||(fsize==0)
						mov	hfile,0
					.endif
					mov	edi,lParam
					topicdownloadcomplete
				.endif
				inc	spage
				.if savetype<2
					call	escdir
					save_page
					mov	ebx,lParam
					lea	edx,[ebx]._addr
					istopicsaved
					push	[ebx].histptr
					mov	[ebx].histptr,eax
					idx_newtopicpage
					hist_addfile
					pop	[ebx].histptr
					invoke	CreateFile,addr defdir,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0
					mov	savefile,eax
					.if savetype==1
						mov	esi,r_buf
						call	prel_file
						mov	r_buf,esi
					.endif
					invoke	WriteFile,savefile,r_buf,fsize,addr b_read,0
					invoke	CloseHandle,savefile
					mov	ebx,lParam
					idx_endpage
					mov	savefile,0
					lea	edi,buftmp
					push	edi
					lea	edx,saved1
					call	copyedx
					lea	edx,defdir
					call	copyedx
					mov	ax,0a0dh
					stosw
					mov	al,0
					stosb
					pop	edx
					call	showmsg
				.endif
				pop	edi
				jmp	t_page
				assume	ebx:nothing
			.endif
			inc	esi
		.endw
	.endif
tnopage:.if savetype==2
		lea	edx,save3
		call	copyedx
	.endif

	.if savefile
		mov	ecx,edi
		sub	ecx,offset savetmp
		invoke	WriteFile,savefile,addr savetmp,ecx,addr b_read,0
		invoke	CloseHandle,savefile
	.endif

	.if savetype>=2
		mov	edi,r_buf
		push	edi
		lea	edx,saved1
		call	copyedx
		lea	edx,defdir
		call	copyedx
		mov	ax,0a0dh
		stosw
		mov	al,0
		stosb
		pop	edx
		call	showmsg
	.endif
	mov	ebx,lParam
	idx_endtopic

	invoke	GlobalFree,r_buf
	pop	ebp
	ret
save_topics	ENDP
assume	edi:nothing
