;	fontcolor	dd	?
;	backcolor	dd	?
;	idxsave		db	?

idxgendata	macro
	chcol		CHOOSECOLOR	<>
	custcol		dd	16 dup(?)
	hIndex		dd	?
	last_esc	dd	?
	idxfiles	dd	?
	idxdirs		dd	?
	idxpages	dd	?
	idxattachmem	dd	?
	idxattachsize	dd	?
	idxattachpos	dd	?
	idxlink		db	?
	idxsavefile	db	?
	idxtotal1	dd	?
	idxtotal2	dd	?
	idxtotal1a	dd	?
	idxtotal2a	dd	?
	htmltmp		db	8192 dup(?)
	htmltmp1	dd	?
endm

idx_data	macro
html1	db	'<HTML><HEAD>',13,10,9,'<META http-equiv="Content-Type" content="text/html; charset=UTF-8">',13,10
	db	9,'<META name="GENERATOR" content="Forum Downloader 2.02 Copyright (c) 2007-2009 by Albu Cristian">',13,10
	db	9,'<META name="robots" content="INDEX, FOLLOW">',13,10,9,'<TITLE>',0
html2	db	'</TITLE>',13,10,'</HEAD>',13,10,'<BODY text="#',0
html3	db	'" bgcolor="#',0
html4	db	'" link="#',0
html5	db	'" vlink="#',0
html6	db	'" alink="#',0
html7	db	'">',13,10,'<HR><P><CENTER><H1>',0
html8	db	'</H1></CENTER><HR><P>',13,10,0
html9	db	'<CENTER><TABLE width=100%>',13,10,9,'<TR>',13,10,9,9,'<TH bgcolor=#',0
html10	db	'><FONT color=#',0
html11	db	'><B>Index</B></FONT></TH>',13,10,9,9,'<TH width=5% bgcolor=#',0
html12	db	'><B>Type</B></FONT></TH>',13,10,9,9,'<TH width=40% style="min-width:200px" bgcolor=#',0
html13	db	'><B>Name</B></FONT></TH>',13,10,9,9,'<TH width=50% bgcolor=#',0
html14	db	'><B>External links / Attachments</B></FONT></TH>',13,10,9,'</TR>',0
html15	db	13,10,'</TABLE></CENTER>',13,10,'<P ALIGN=RIGHT><SMALL>There are ',0
html16	db	' topics and ',0
html17	db	' lists</SMALL>',13,10,'</BODY>',13,10,'</HTML>',0
html20	db	13,10,9,'<TR valign=top><TD>',0
html21	db	'</TD><TD>&lt;List&gt;</TD><TD><A href="',0
html21a	db	'</TD><TD>Topic</TD><TD><A href="',0
html22	db	'</A>'
html22a	db	'</TD><TD>'
html22b	db	0
html23	db	'</TD></TR>'
html23a	db	0
html24	db	'Untitled'
html25	db	'<BR>Pages: <A href="'
endm

fwrite	macro	m,n
	.if 0
	push	m
	push	n
	push	ecx
	lea	edx,[n+5]
	invoke	GlobalAlloc,GPTR,edx
	mov	ebx,[esp+4+4+4]
	push	esi
	push	edi
	mov	edi,eax
	mov	edx,[ebx].histptr
	lea	edx,[edx+4+1+4]
	.while dword ptr[edx]
		mov	edx,[edx]
	.endw
	mov	[edx],edi
	xor	eax,eax
	stosd
	mov	esi,dword ptr[esp+4+4+4+4]
	mov	ecx,[esp+4+4+4]
	rep	movsb
	mov	al,0
	stosb
	pop	edi
	pop	esi
	pop	ecx
	pop	eax
	pop	eax
	.endif
endm

idxgen_init	macro
	.if idxsave&1
		invoke	CheckDlgButton,hDlg,6417,BST_CHECKED
	.else
		invoke	GetDlgItem,hDlg,6421
		invoke	EnableWindow,eax,0
		invoke	GetDlgItem,hDlg,6422
		invoke	EnableWindow,eax,0
	.endif
	mov	hIndex,0
endm

idxgen_dlg	macro
	.elseif ax==6417
		invoke	IsDlgButtonChecked,hDlg,6417
		.if eax==BST_CHECKED
			or	idxsave,1
			invoke	GetDlgItem,hDlg,6421
			invoke	EnableWindow,eax,1
			invoke	GetDlgItem,hDlg,6422
			invoke	EnableWindow,eax,1
		.else
			and	idxsave,1 xor -1
			invoke	GetDlgItem,hDlg,6421
			invoke	EnableWindow,eax,0
			invoke	GetDlgItem,hDlg,6422
			invoke	EnableWindow,eax,0
		.endif
	.elseif ax==6421
		mov	chcol.lStructSize,sizeof CHOOSECOLOR
		mov	eax,hDlg
		mov	chcol.hwndOwner,eax
		mov	eax,hInstance
		mov	chcol.hInstance,eax
		mov	eax,fontcolor
		mov	chcol.rgbResult,eax
		mov	chcol.lpCustColors,offset custcol
		mov	chcol.Flags,CC_RGBINIT or CC_FULLOPEN
		mov	chcol.lpfnHook,0
		mov	chcol.lpTemplateName,0
		invoke	ChooseColor,addr chcol
		.if eax
			mov	eax,chcol.rgbResult
			mov	fontcolor,eax
		.endif
	.elseif ax==6422
		mov	chcol.lStructSize,sizeof CHOOSECOLOR
		mov	eax,hDlg
		mov	chcol.hwndOwner,eax
		mov	eax,hInstance
		mov	chcol.hInstance,eax
		mov	eax,backcolor
		mov	chcol.rgbResult,eax
		mov	chcol.lpCustColors,offset custcol
		mov	chcol.Flags,CC_RGBINIT or CC_FULLOPEN
		mov	chcol.lpfnHook,0
		mov	chcol.lpTemplateName,0
		invoke	ChooseColor,addr chcol
		.if eax
			mov	eax,chcol.rgbResult
			mov	backcolor,eax
		.endif
endm

idx_init	macro
	mov	idxtotal1,0
	mov	idxtotal2,0
endm

idx_start	macro
	inc	idxdirs
	push	idxfiles
	push	idxdirs
	push	idxtotal1
	push	idxtotal2
	mov	idxtotal1,0
	mov	idxtotal2,0
	push	hIndex
	push	edi
	push	ebx
	push	esi
	.if hIndex
		lea	edi,htmltmp
		lea	edx,html20
		call	copyedx
		mov	eax,idxdirs
		add	eax,idxfiles
		call	itoa
		lea	edx,html21
		call	copyedx
		lea	edx,defdir
		.while byte ptr[edx]!=0
			inc	edx
		.endw
		.if (edx!=offset defdir)&&((byte ptr[edx-1]=='/')||(byte ptr[edx-1]=='\'))
			dec	edx
		.endif
		.while (edx!=offset defdir)&&(byte ptr[edx-1]!='\')&&(byte ptr[edx-1]!='/')
			dec	edx
		.endw
		esc_utf8
		mov	al,'/'
		stosb
		xor	eax,eax
		call	w5
		mov	al,32
		stosb
		mov	eax,'edni'
		stosd
		mov	eax,'th.x'
		stosd
		mov	eax,'lm'
		stosw
		mov	ax,'>"'
		stosw
		mov	edx,last_esc
		.if edx
			xor	ecx,ecx
			.while (word ptr[edx]!='/<')&&(byte ptr[edx]!=0)&&(ecx<1024)
				mov	al,[edx]
				.if al=='<'
					.while (byte ptr[edx]!=0)&&(byte ptr[edx]!='>')
						inc	edx
					.endw
					.if byte ptr[edx]=='>'
						inc	edx
					.endif
					.continue
				.endif
				.break .if al=='>'
				inc	edx
				esc_utf8b
				inc	ecx
			.endw
		.endif
		lea	edx,html22
		call	copyedx
		mov	ecx,edi
		sub	ecx,offset htmltmp
		push	ecx
		lea	edx,[ecx+4+1]
		invoke	GlobalAlloc,GPTR,edx
		mov	ebx,[esp+4+4]
		push	esi
		push	edi
		mov	edi,eax
		mov	edx,[ebx].histptr
		lea	edx,[edx+4+1+4]
		.while dword ptr[edx]
			mov	edx,[edx]
		.endw
		mov	[edx],edi
		xor	eax,eax
		stosd
		lea	esi,htmltmp
		mov	ecx,[esp+4+4]
		rep	movsb
		mov	al,0
		stosb
		pop	edi
		pop	esi
		pop	ecx
		invoke	WriteFile,hIndex,addr htmltmp,ecx,addr htmltmp1,0
	.endif
	.if idxsave&1
		lea	edx,defdir
		lea	edi,htmltmp
		call	copyedx
		.if al!='\'
			mov	al,'\'
			stosb
		.endif
		xor	eax,eax
		call	w5
		mov	al,32
		stosb
		mov	eax,'edni'
		stosd
		mov	eax,'th.x'
		stosd
		mov	eax,'lm'
		stosd
		mov	ebx,[esp+4]
		hist_adddir
		invoke	CreateFile,addr htmltmp,GENERIC_WRITE,FILE_SHARE_READ,0,CREATE_ALWAYS,0,0
		mov	hIndex,eax
		lea	edi,htmltmp
		lea	edx,html1
		call	copyedx
		mov	edx,last_esc
		.if edx
			xor	ecx,ecx
			.while (word ptr[edx]!='/<')&&(byte ptr[edx]!=0)&&(ecx<1024)
				mov	al,[edx]
				.if al=='<'
					.while (byte ptr[edx]!=0)&&(byte ptr[edx]!='>')
						inc	edx
					.endw
					.if byte ptr[edx]=='>'
						inc	edx
					.endif
					.continue
				.endif
				.break .if al=='>'
				inc	edx
				stosb
				inc	ecx
			.endw
		.endif
		lea	edx,html2
		call	copyedx
		mov	eax,fontcolor
		call	wcolor
		lea	edx,html3
		call	copyedx
		mov	eax,backcolor
		call	wcolor
		lea	edx,html4
		call	copyedx
		mov	eax,fontcolor
		xor	eax,0f0f0fh
		call	wcolor
		lea	edx,html5
		call	copyedx
		mov	eax,fontcolor
		xor	eax,0f0f0fh
		ror	eax,8
		.if al>30h
			sub	al,30h
		.else
			mov	al,0
		.endif
		ror	eax,8
		.if al>30h
			sub	al,30h
		.else
			mov	al,0
		.endif
		ror	eax,8
		.if al>30h
			sub	al,30h
		.else
			mov	al,0
		.endif
		ror	eax,8
		push	eax
		call	wcolor
		lea	edx,html6
		call	copyedx
		pop	eax
		xor	eax,171717h
		call	wcolor
		lea	edx,html7
		call	copyedx
		mov	edx,last_esc
		.if edx
			xor	ecx,ecx
			.while (word ptr[edx]!='/<')&&(byte ptr[edx]!=0)&&(ecx<1024)
				mov	al,[edx]
				.if al=='<'
					.while (byte ptr[edx]!=0)&&(byte ptr[edx]!='>')
						inc	edx
					.endw
					.if byte ptr[edx]=='>'
						inc	edx
					.endif
					.continue
				.endif
				.break .if al=='>'
				inc	edx
				stosb
				inc	ecx
			.endw
		.endif
		lea	edx,html8
		call	copyedx
		lea	edx,html9
		call	copyedx
		mov	eax,fontcolor
		xor	eax,0f0f0fh
		push	eax
		call	wcolor
		lea	edx,html10
		call	copyedx
		mov	eax,fontcolor
		xor	eax,0f0f0f0h
		call	wcolor
		lea	edx,html11
		call	copyedx
		pop	eax
		call	sub20
		push	eax
		lea	edx,html10
		call	copyedx
		mov	eax,fontcolor
		xor	eax,0f0f0f0h
		call	wcolor
		lea	edx,html12
		call	copyedx
		pop	eax
		call	sub20
		push	eax
		lea	edx,html10
		call	copyedx
		mov	eax,fontcolor
		xor	eax,0f0f0f0h
		call	wcolor
		lea	edx,html13
		call	copyedx
		pop	eax
		call	sub20
		lea	edx,html10
		call	copyedx
		mov	eax,fontcolor
		xor	eax,0f0f0f0h
		call	wcolor
		lea	edx,html14
		call	copyedx
		mov	ecx,edi
		sub	ecx,offset htmltmp
		invoke	WriteFile,hIndex,addr htmltmp,ecx,addr htmltmp1,0
	.else
		mov	hIndex,0
		mov	ebx,[esp+4]
		hist_adddir1
	.endif
	pop	esi
	pop	ebx
	pop	edi
	mov	idxfiles,0
	mov	idxdirs,0
	push	ebp
endm

idx_end		macro
	pop	ebp
	.if hIndex
		push	edi
		push	ebx
		lea	edi,htmltmp
		lea	edx,html15
		call	copyedx
		mov	eax,idxfiles
		call	itoa
		lea	edx,html16
		call	copyedx
		mov	eax,idxdirs
		call	itoa
		lea	edx,html17
		call	copyedx
		mov	ecx,edi
		sub	ecx,offset htmltmp
		invoke	WriteFile,hIndex,addr htmltmp,ecx,addr htmltmp1,0
		invoke	CloseHandle,hIndex
		pop	ebx
		pop	edi
	.endif
	pop	hIndex
	.if hIndex
		push	edi
		push	ebx
		lea	edi,htmltmp
		.if idxtotal1
			mov	eax,idxtotal1
			call	itoa
			mov	al,32
			stosb
			mov	eax,'knil'
			stosd
			mov	al,'s'
			stosb
			.if idxtotal2
				mov	ax,' ,'
				stosw
			.endif
		.endif
		.if idxtotal2
			mov	eax,idxtotal2
			call	itoa
			mov	eax,'tta '
			stosd
			mov	eax,'mhca'
			stosd
			mov	eax,'stne'
			stosd
		.endif
		lea	edx,html23
		call	copyedx
		mov	ecx,edi
		sub	ecx,offset htmltmp

		fwrite	offset htmltmp,ecx
		invoke	WriteFile,hIndex,addr htmltmp,ecx,addr htmltmp1,0
		mov	ebx,[esp]
		.if [ebx].histptr
			mov	ebx,[ebx].histptr
			mov	eax,idxtotal1
			mov	dword ptr [ebx+4+1+4+4],eax
			mov	eax,idxtotal2
			mov	dword ptr [ebx+4+1+4+4+4],eax
		.endif
		pop	ebx
		pop	edi
	.endif
	pop	eax
	add	idxtotal2,eax
	pop	eax
	add	idxtotal1,eax
	pop	idxdirs
	pop	idxfiles
endm

idx_newtopic	macro
	mov	idxtotal1a,0
	mov	idxtotal2a,0
	inc	idxfiles
	mov	idxpages,1
	.if hIndex
		push	edi
		push	ebx
		lea	edi,htmltmp
		lea	edx,html20
		call	copyedx
		mov	eax,idxdirs
		add	eax,idxfiles
		call	itoa
		lea	edx,html21a
		call	copyedx
		lea	edx,defdir
		.while byte ptr[edx]!=0
			inc	edx
		.endw
		.if (edx!=offset defdir)&&((byte ptr[edx-1]=='/')||(byte ptr[edx-1]=='\'))
			dec	edx
		.endif
		.while (edx!=offset defdir)&&(byte ptr[edx-1]!='\')&&(byte ptr[edx-1]!='/')
			dec	edx
		.endw
		esc_utf8
		mov	ax,'>"'
		stosw
		mov	edx,last_esc
		.if edx
			xor	ecx,ecx
			.while (word ptr[edx]!='/<')&&(byte ptr[edx]!=0)&&(ecx<1024)
				mov	al,[edx]
				.if al=='<'
					.while (byte ptr[edx]!=0)&&(byte ptr[edx]!='>')
						inc	edx
					.endw
					.if byte ptr[edx]=='>'
						inc	edx
					.endif
					.continue
				.endif
				.break .if al=='>'
				inc	edx
				.if al>7fh
					mov	word ptr[edi],'#&'
					inc	edi
					inc	edi
					movzx	eax,al
					push	edx
					push	ebx
					call	itoa
					pop	ebx
					pop	edx
					mov	al,';'
				.endif
				stosb
				inc	ecx
			.endw
		.endif
		mov	eax,'>A/<'
		stosd
		mov	ecx,edi
		sub	ecx,offset htmltmp

		fwrite	offset htmltmp,ecx
		invoke	WriteFile,hIndex,addr htmltmp,ecx,addr htmltmp1,0
		invoke	GlobalAlloc,GPTR,8192
		mov	idxattachmem,eax
		mov	idxattachpos,0
		mov	idxattachsize,8192
		mov	idxlink,0
		mov	idxsavefile,0
		pop	ebx
		pop	edi
	.endif
endm

idx_newtopicpage macro
	inc	idxpages
	.if hIndex
		push	edi
		push	ebx
		lea	edi,htmltmp
		.if idxpages==2
			mov	eax,sizeof html25
			fwrite	offset html25,eax
			invoke	WriteFile,hIndex,addr html25,sizeof html25,addr htmltmp1,0
			lea	edx,defdir
			.while byte ptr[edx]!=0
				inc	edx
			.endw
			.if (edx!=offset defdir)&&((byte ptr[edx-1]=='/')||(byte ptr[edx-1]=='\'))
				dec	edx
			.endif
			.while (edx!=offset defdir)&&(byte ptr[edx-1]!='\')&&(byte ptr[edx-1]!='/')
				dec	edx
			.endw
			esc_utf8
			dec	byte ptr[edi-1-5]
			mov	ax,'>"'
			stosw
			mov	eax,'A/<1'
			stosd
			mov	al,'>'
			stosb
		.endif
		mov	ax,' ,'
		stosw
		lea	edx,ahref
		call	copyedx
		lea	edx,defdir
		.while byte ptr[edx]!=0
			inc	edx
		.endw
		.if (edx!=offset defdir)&&((byte ptr[edx-1]=='/')||(byte ptr[edx-1]=='\'))
			dec	edx
		.endif
		.while (edx!=offset defdir)&&(byte ptr[edx-1]!='\')&&(byte ptr[edx-1]!='/')
			dec	edx
		.endw
		esc_utf8
		mov	ax,'>"'
		stosw
		mov	eax,idxpages
		call	itoa
		mov	eax,'>A/<'
		stosd
		mov	ecx,edi
		sub	ecx,offset htmltmp

		fwrite	offset htmltmp,ecx
		invoke	WriteFile,hIndex,addr htmltmp,ecx,addr htmltmp1,0
		pop	ebx
		pop	edi
	.endif
endm

idx_endpage	macro
endm

idx_endtopic	macro
	.if hIndex
		push	ebx
		assume	ebx:ptr foruminfo
		mov	eax,sizeof html22a
		fwrite	offset html22a,eax
		invoke	WriteFile,hIndex,addr html22a,sizeof html22a,addr htmltmp1,0
		.if idxattachpos
			.if idxlink==2
				mov	edi,idxattachmem
				mov	ecx,idxattachpos
				lea	edi,[edi+ecx]
				mov	eax,'LU/<'
				stosd
				mov	al,'>'
				stosb
				add	idxattachpos,5
			.endif
			mov	eax,idxattachpos
			mov	edx,idxattachmem
			fwrite	edx,eax
			invoke	WriteFile,hIndex,idxattachmem,idxattachpos,addr htmltmp1,0
		.endif
		mov	eax,sizeof html23
		fwrite	offset html23,eax
		invoke	WriteFile,hIndex,addr html23,sizeof html23,addr htmltmp1,0
		invoke	GlobalFree,idxattachmem
		assume	ebx:nothing
		mov	idxattachmem,0
		mov	ebx,[esp]
		assume	ebx:ptr foruminfo
		.if [ebx].histptr
			mov	ebx,[ebx].histptr
			mov	eax,idxtotal1a
			mov	dword ptr [ebx+4+1+4+4],eax
			mov	eax,idxtotal2a
			mov	dword ptr [ebx+4+1+4+4+4],eax
		.endif
		assume	ebx:nothing
		pop	ebx
	.endif
endm

idx_title	macro
	mov	last_esc,esi
endm

idx_title1	macro
	mov	last_esc,edi
endm

idx_addlink	macro
	.if hIndex
		push	edi
		mov	eax,idxattachsize
		sub	eax,idxattachpos
		.if eax<1024
			add	idxattachsize,8192
			invoke	GlobalAlloc,GPTR,idxattachsize
			push	esi
			push	edi
			mov	esi,idxattachmem
			mov	edi,eax
			mov	idxattachmem,eax
			push	esi
			mov	ecx,idxattachpos
			rep	movsb
			call	GlobalFree
			pop	edi
			pop	esi
		.endif
		mov	edi,idxattachmem
		mov	ecx,idxattachpos
		lea	edi,[edi+ecx]
		.if idxlink==2
			mov	eax,'LU/<'
			stosd
			mov	al,'>'
			stosb
		.elseif idxlink!=0
			mov	eax,'>RB<'
			stosd
		.endif
		lea	edx,ahref
		call	copyedx
		mov	edx,esi
		esc_utf8a
		mov	ax,'>"'
		stosw
		mov	edx,esi
		call	copyedx
		mov	eax,'>A/<'
		stosd
		sub	edi,idxattachmem
		mov	idxattachpos,edi
		mov	idxlink,1
		pop	edi
		inc	idxtotal1
		inc	idxtotal1a
	.endif
endm

idx_savefile	macro
	.if (hIndex!=0)&&(idxsavefile!=0)
		push	edi
		mov	eax,idxattachsize
		sub	eax,idxattachpos
		.if eax<1024
			add	idxattachsize,8192
			invoke	GlobalAlloc,GPTR,idxattachsize
			push	esi
			push	edi
			mov	esi,idxattachmem
			mov	edi,eax
			mov	idxattachmem,eax
			push	esi
			mov	ecx,idxattachpos
			rep	movsb
			call	GlobalFree
			pop	edi
			pop	esi
		.endif
		mov	edi,idxattachmem
		mov	ecx,idxattachpos
		lea	edi,[edi+ecx]
		.if idxlink!=2
			mov	eax,'>LU<'
			stosd
		.endif
		mov	eax,'>IL<'
		stosd
		lea	edx,ahref
		call	copyedx
		mov	edx,lParam
		assume	edx:ptr foruminfo
		lea	edx,[edx]._save
		assume	edx:nothing
		.while byte ptr[edx]!=0
			inc	edx
		.endw
		.while (byte ptr[edx-1]!='\')&&(byte ptr[edx-1]!='/')
			dec	edx
		.endw
		push	edx
		esc_utf8
		mov	ax,'>"'
		stosw
		pop	edx
		.while (byte ptr[edx]!=32)&&(byte ptr[edx]!=0)
			inc	edx
		.endw
		.if byte ptr[edx]==32
			inc	edx
		.endif
		call	copyedx
		mov	eax,'>A/<'
		stosd
		sub	edi,idxattachmem
		mov	idxattachpos,edi
		pop	edi
		mov	idxlink,2
		inc	idxtotal2
		inc	idxtotal2a
	.endif
endm

idx_savelinkstart	macro
	mov	idxsavefile,1
endm

idx_savelinkend	macro
	mov	idxsavefile,0
endm

esc_utf8	macro
	.while (byte ptr[edx]!=0)&&(byte ptr[edx]!='/')&&(byte ptr[edx]!='\')
		mov	al,[edx]
		esc_utf8b
		inc	edx
	.endw
endm

esc_utf8a	macro
	.while (byte ptr[edx]!=0)
		mov	al,[edx]
		esc_utf8b
		inc	edx
	.endw
endm

esc_utf8b	macro
	.if al>7fh
		mov	ah,[edx+1]
		.if (ah&80h)&&(!(ah&40h))&&(((al&0c0h)&&(!(al&20h)))||((al&0e0h)&&(!(al&10h))))
			and	ax,3f1fh
			shl	al,3
			shr	ax,3
			movzx	eax,ax
			mov	word ptr[edi],'#&'
			inc	edi
			inc	edi
			push	edx
			push	ebx
			call	itoa
			pop	ebx
			pop	edx
			mov	al,';'
		.else
			mov	word ptr[edi],'#&'
			inc	edi
			inc	edi
			movzx	eax,al
			push	edx
			push	ebx
			call	itoa
			pop	ebx
			pop	edx
			mov	al,';'
		.endif
	.endif
	stosb
endm
