
scantbl:xor	ecx,ecx
	push	edx
	.while ecx<100
		.if (dword ptr[edx]==4)||(dword ptr[edx]==3)||(dword ptr[edx]==5)
			mov	byte ptr[edx],0
		.elseif dword ptr[edx]==2
			pop	edx
			xor	ecx,ecx
			xor	eax,eax
			.while ecx<100
				.if dword ptr[edx]!=2
					mov	[edx],eax
				.endif
				lea	edx,[edx+4]
				inc	ecx
			.endw
			ret
		.endif
		lea	edx,[edx+4]
		inc	ecx
	.endw
	pop	edx
	ret

saveforum:
	.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
		mov	eax,[esi]
		or	eax,20202020h
		.if eax=='erh '
			push	edi
			lea	esi,[esi+4]
			mov	al,[esi]
			or	al,20h
			.if al=='f'
				inc	esi
			.endif
			.while (byte ptr[esi]=='=')||(byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==39)||(byte ptr[esi]==34)
				inc	esi
			.endw
			.if forum_sim==0
				push	esi
				push	edi
				lea	edi,forum_sim
				mov	edx,esi
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
					.if (byte ptr[esi]=='/')&&((byte ptr[esi+1]>='a')&&(byte ptr[esi+1]<='z'))||((byte ptr[esi+1]>='A')&&(byte ptr[esi+1]<='Z'))
						mov	edx,esi
					.endif
					inc	esi
				.endw
				mov	esi,edx
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
					.if (byte ptr[esi]<='9')&&(byte ptr[esi]>='0')
						inc	esi
					.else
						movsb
					.endif
				.endw
				mov	al,0
				stosb

				pop	edi
				pop	esi
			.endif
			invoke	GlobalAlloc,GPTR,sizeof foruminfo
			push	eax
			mov	ebx,eax
			assume	ebx:ptr foruminfo
			mov	[ebx]._next,0
			mov	[ebx].histptr,0
			mov	edx,f_info
			assume	edx:ptr foruminfo
			lea	edx,[edx]._addr
			assume	edx:nothing
			lea	edi,[ebx]._addr
			call	copyedx
			mov	al,0
			stosb
			mov	edx,f_info
			assume	edx:ptr foruminfo
			lea	edx,[edx]._dns
			assume	edx:nothing
			lea	edi,[ebx]._dns
			call	copyedx
			mov	al,0
			stosb
			lea	edi,[ebx]._addr
			mov	eax,[edi]
			or	eax,20202020h
			.if (eax=='ptth')&&(word ptr[edi+4]=='/:')&&(byte ptr[edi+6]=='/')
				lea	edi,[edi+7]
			.endif
			mov	eax,[esi]
			or	eax,20202020h
			.if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+6]=='/')
				lea	esi,[esi+7]
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
					.break .if byte ptr[esi]=='/'
					inc	esi
				.endw
			.endif
			.if byte ptr[esi]=='/'
				.while (byte ptr[edi]!='/')&&(byte ptr[edi]!=0)
					inc	edi
				.endw
			.else
				mov	edx,edi
				.while byte ptr[edi]
					.if byte ptr[edi]=='/'
						mov	edx,edi
					.endif
					inc	edi
				.endw
				mov	edi,edx
				mov	al,'/'
				stosb
			.endif
			.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
				lodsb
				.if al=='&'
					mov	eax,[esi]
					or	eax,202020h
					.if eax==';pma'
						lodsd
					.endif
					mov	al,'&'
				.else
					mov	eax,[esi-1]
					or	eax,20202020h
					.if eax=='=dis'
						.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
							inc	esi
						.endw
						.continue
					.elseif eax=='sphp'
						mov	eax,[esi+3]
						or	eax,20202020h
						.if eax=='isse'
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
								inc	esi
							.endw
							.continue
						.endif
					.endif
					mov	al,[esi-1]
				.endif
				stosb
			.endw
			.if byte ptr[edi-1]=='&'
				dec	edi
			.endif
			mov	al,0
			stosb
			lea	edx,[ebx]._addr
			isforumsaved
			mov	[ebx].histptr,eax
			.if (edx==0)
				lea	edi,defdir
				.while byte ptr[edi]
					inc	edi
				.endw
				push	dword ptr[edi]
				push	edi
				push	ebx
				.if byte ptr[edi-1]!='\'
					mov	al,'\'
					stosb
				.endif
				mov	eax,diridx
				call	w2
				mov	al,32
				stosb
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
					inc	esi
				.endw
				.if byte ptr[esi]=='>'
					inc	esi
				.endif
				mov	ecx,maxfile
				.if ecx>3
					sub	ecx,3
				.else
					xor	ecx,ecx
				.endif
				push	edi
				call	escfile
				pop	edx
				pop	ebx
				.if edi!=edx
					mov	eax,diridx
					dec	eax
					movzx	eax,byte ptr forums[eax]
					.if eax
						.while byte ptr[edi-1]<=32
							dec	edi
						.endw
						mov	al,0
						stosb
						push	ebx
						call	escdir
						invoke	CreateDirectory,addr defdir,0
						pop	ebx
						inc	dirs
						.if eax==0
							invoke	GetLastError
							.if eax!=ERROR_ALREADY_EXISTS
								lea	edi,buftmp
								push	edi
								lea	edx,errdir
								call	copyedx
								lea	edx,defdir
								call	copyedx
								mov	ax,0a0dh
								stosw
								mov	al,0
								stosb
								pop	edx
								call	showmsg
							.else
								idx_start
								push	stbl
								invoke	get_topics,ebx
								pop	stbl
								idx_end
							.endif
						.else
							idx_start
							push	stbl
							invoke	get_topics,ebx
							pop	stbl
							idx_end
						.endif
						dec	dirs
					.endif
					inc	diridx
				.endif
				pop	edi
				pop	dword ptr[edi]
			.endif
			assume	ebx:nothing
			call	GlobalFree
			pop	edi
			.break
		.endif
		inc	esi
	.endw
	ret

createdirs:
	push	esi
	push	edi
	push	ebx
	mov	edi,stbl
	.while (byte ptr[esi]!=0)
		.if byte ptr[esi]=='<'
			inc	esi
			.if byte ptr[esi]=='/'
				mov	ax,[esi+1]
				or	ax,2020h
				.break .if ax=='rt'
				.if ax=='dt'
					lea	edi,[edi+4]
				.endif
			.else
				mov	ax,[esi]
				or	ax,2020h
				.if (ax=='dt')&&(word ptr[edi]>0)
					.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
						mov	eax,[esi]
						or	eax,20202020h
						.if eax=='loc '
							mov	eax,[esi+4]
							or	eax,20202020h
							.break .if eax=='naps'
						.endif
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.else
						.while (byte ptr[esi]!=0)
							.if byte ptr[esi]=='<'
								inc	esi
								.if byte ptr[esi]=='/'
									inc	esi
									mov	ax,[esi]
									or	ax,2020h
									.break .if (ax=='rt')
								.endif
							.else
								inc	esi
							.endif
						.endw
						.continue
					.endif
					.while byte ptr[esi]
						.if (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
							inc	esi
						.elseif byte ptr[esi]=='<'
							mov	ax,[esi+1]
							.if al=='/'
								mov	ax,[esi+2]
								or	ax,2020h
								.break .if (ax=='rt')||(ax=='dt')
							.else
								or	al,20h
								.break .if al=='a'
							.endif
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								inc	esi
							.endw
							.if byte ptr[esi]
								inc	esi
							.endif
						.elseif byte ptr[esi]=='&'
							.while (byte ptr[esi]!=';')&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='<')
								inc	esi
							.endw
							.if byte ptr[esi]==';'
								inc	esi
							.endif
						.else
							.break
						.endif
					.endw
					.if (byte ptr[esi]=='<')&&((byte ptr[esi+1]=='a')||(byte ptr[esi+1]=='A'))
						call	saveforum
					.endif
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	ebx
	pop	edi
	pop	esi
	ret

showdirs:
	push	esi
	push	edi
	push	ebx
	mov	edi,stbl
	.while (byte ptr[esi]!=0)
		.if byte ptr[esi]=='<'
			inc	esi
			.if byte ptr[esi]=='/'
				mov	ax,[esi+1]
				or	ax,2020h
				.break .if ax=='rt'
				.if ax=='dt'
					lea	edi,[edi+4]
				.endif
			.else
				mov	ax,[esi]
				or	ax,2020h
				.if (ax=='dt')&&(word ptr[edi]>0)
					.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
						mov	eax,[esi]
						or	eax,20202020h
						.if eax=='loc '
							mov	eax,[esi+4]
							or	eax,20202020h
							.break .if eax=='naps'
						.endif
						inc	esi
					.endw
					.if byte ptr[esi]=='>'
						inc	esi
					.else
						.while (byte ptr[esi]!=0)
							.if byte ptr[esi]=='<'
								inc	esi
								.if byte ptr[esi]=='/'
									inc	esi
									mov	ax,[esi]
									or	ax,2020h
									.break .if (ax=='rt')
								.endif
							.else
								inc	esi
							.endif
						.endw
						.continue
					.endif
					.while byte ptr[esi]
						.if (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]==13)||(byte ptr[esi]==10)
							inc	esi
						.elseif byte ptr[esi]=='<'
							mov	ax,[esi+1]
							.if al=='/'
								mov	ax,[esi+2]
								or	ax,2020h
								.break .if (ax=='rt')||(ax=='dt')
							.else
								or	al,20h
								.break .if al=='a'
							.endif
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
								inc	esi
							.endw
							.if byte ptr[esi]
								inc	esi
							.endif
						.elseif byte ptr[esi]=='&'
							.while (byte ptr[esi]!=';')&&(byte ptr[esi]!=0)&&(byte ptr[esi]!='<')
								inc	esi
							.endw
							.if byte ptr[esi]==';'
								inc	esi
							.endif
						.else
							.break
						.endif
					.endw
					.if (byte ptr[esi]=='<')&&((byte ptr[esi+1]=='a')||(byte ptr[esi+1]=='A'))
						call	forbid_anchor
						.if eax
							inc	esi
							.continue
						.endif
						.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
							mov	eax,[esi]
							or	eax,20202020h
							.if eax=='erh '
								push	edi
								lea	esi,[esi+4]
								mov	al,[esi]
								or	al,20h
								.if al=='f'
									inc	esi
								.endif
								.while (byte ptr[esi]=='=')||(byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==39)||(byte ptr[esi]==34)
									inc	esi
								.endw
								.if forum_sim==0
									push	esi
									push	edi
									lea	edi,forum_sim
									mov	edx,esi
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
										.if (byte ptr[esi]=='/')&&((byte ptr[esi+1]>='a')&&(byte ptr[esi+1]<='z'))||((byte ptr[esi+1]>='A')&&(byte ptr[esi+1]<='Z'))
											mov	edx,esi
										.endif
										inc	esi
									.endw
									mov	esi,edx
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
										.if (byte ptr[esi]<='9')&&(byte ptr[esi]>='0')
											inc	esi
										.else
											movsb
										.endif
									.endw
									mov	al,0
									stosb

									pop	edi
									pop	esi
								.endif
								invoke	GlobalAlloc,GPTR,sizeof foruminfo
								push	eax
								mov	ebx,eax
								assume	ebx:ptr foruminfo
								mov	[ebx]._next,0
								mov	[ebx].histptr,0
								mov	edx,f_info
								assume	edx:ptr foruminfo
								lea	edx,[edx]._addr
								assume	edx:nothing
								lea	edi,[ebx]._addr
								call	copyedx
								mov	al,0
								stosb
								mov	edx,f_info
								assume	edx:ptr foruminfo
								lea	edx,[edx]._dns
								assume	edx:nothing
								lea	edi,[ebx]._dns
								call	copyedx
								mov	al,0
								stosb
								lea	edi,[ebx]._addr
								mov	eax,[edi]
								or	eax,20202020h
								.if (eax=='ptth')&&(word ptr[edi+4]=='/:')&&(byte ptr[edi+6]=='/')
									lea	edi,[edi+7]
								.endif
								mov	eax,[esi]
								or	eax,20202020h
								.if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+6]=='/')
									lea	esi,[esi+7]
								.elseif byte ptr[esi]=='/'
									.while (byte ptr[edi]!='/')&&(byte ptr[edi]!=0)
										inc	edi
									.endw
								.else
									mov	edx,edi
									push	edi
									.while byte ptr[edi]
										.if byte ptr[edi]=='/'
											mov	edx,edi
										.endif
										inc	edi
									.endw
									pop	eax
									.if edx==eax
										.if byte ptr[edi]!='/'
											mov	al,'/'
											stosb
										.endif
									.else
										mov	edi,edx
										mov	al,'/'
										stosb
									.endif
								.endif
								.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
									lodsb
									.if al=='&'
										mov	eax,[esi]
										or	eax,202020h
										.if eax==';pma'
											lodsd
										.endif
										mov	al,'&'
									.else
										mov	eax,[esi-1]
										or	eax,20202020h
										.if eax=='=dis'
											.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
												inc	esi
											.endw
											.continue
										.elseif eax=='sphp'
											mov	eax,[esi+3]
											or	eax,20202020h
											.if eax=='isse'
												.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
													inc	esi
												.endw
												.continue
											.endif
										.endif
										mov	al,[esi-1]
									.endif
									stosb
								.endw
								.if byte ptr[edi-1]=='&'
									dec	edi
								.endif
								mov	al,0
								stosb
								lea	edx,[ebx]._addr
								isforumsaved1
								mov	[ebx].histptr,eax
								.if edx==0
									lea	edi,defdir
									.while byte ptr[edi]
										inc	edi
									.endw
									push	dword ptr[edi]
									push	edi
									push	ebx
									mov	eax,diridx
									call	w2
									mov	al,32
									stosb
									.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
										inc	esi
									.endw
									.if byte ptr[esi]=='>'
										inc	esi
									.endif
									mov	ecx,maxfile
									push	edi
									call	escfile
									pop	edx
									pop	ebx
									.if edi!=edx
										mov	al,0
										stosb
										push	ebx
										mov	lvit.imask,LVIF_TEXT or LVIF_PARAM or LVIF_STATE
										mov	eax,diridx
										dec	eax
										mov	lvit.iItem,eax
										movzx	eax,byte ptr forums[eax]
										mov	lvit.iSubItem,0
										and	eax,1
										shl	eax,10+1+1+1
										.if eax==0
											mov	eax,4096
										.endif
										mov	lvit.state,eax
										mov	lvit.stateMask,LVIS_STATEIMAGEMASK
										lodsd
										mov	lvit.pszText,offset defdir
										mov	lvit.cchTextMax,256
										mov	lvit.lParam,esi
										invoke	SendDlgItemMessage,maxfsize,400,LVM_INSERTITEM,0,addr lvit
										mov	lvit.imask,LVIF_TEXT
										pop	ebx
										push	ebx
										lea	edx,[ebx]._addr
										mov	lvit.iItem,eax
										mov	lvit.iSubItem,1
										mov	lvit.pszText,edx
										invoke	SendDlgItemMessage,maxfsize,400,LVM_SETITEM,0,addr lvit
										mov	lvit.iSubItem,0
										invoke	SendDlgItemMessage,maxfsize,400,LVM_SETITEMSTATE,lvit.iItem,addr lvit
										pop	ebx
										inc	diridx
									.endif
									pop	edi
									pop	dword ptr[edi]
								.endif
								assume	ebx:nothing
								call	GlobalFree
								pop	edi
								.break
							.endif
							inc	esi
						.endw
					.endif
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	ebx
	pop	edi
	pop	esi
	ret



get_topics	PROC	uses esi edi ebx lParam:DWORD
	local	r_buf:DWORD,didx1:DWORD,didx2:DWORD
	push	diridx
	invoke	GlobalAlloc,GPTR,8192
	mov	r_buf,eax
	mov	edi,lParam
	mov	diridx,1
	call	phpset
	mov	fsize,0
	indexdownload
	.if fsize==0
		mov	[edi]._loc,0
		invoke	getfile,addr r_buf,1,0,8192
		.if hfile==-1
			mov	hfile,0
		.endif
		.if blogdet==3
			mov	esi,r_buf
			call	bs_adj
		.endif
		indexdownloadcomplete
	.endif
	.if fsize==0
		pop	diridx
		ret
	.endif
	mov	edi,lParam
	mov	esi,r_buf
	call	get_format
	mov	edx,tblforum
	mov	eax,tblforum[4]
	mov	edi,lParam
	lea	esi,[edi].tables
	.while dword ptr[esi]
		.if (eax==[esi+8])&&(edx==[esi+4])
		.else
			mov	dword ptr[esi+4],0
		.endif
		lea	esi,[esi+16]
	.endw
	push	ebp
	mov	eax,diridx
	mov	didx1,eax
	mov	didx2,eax

n_page:
	mov	eax,diridx
	mov	didx2,eax
	mov	eax,didx1
	mov	diridx,eax
	mov	esi,r_buf
	mov	edi,lParam
	lea	edx,defdir
	.while byte ptr[edx]
		inc	edx
	.endw
	.while byte ptr[edx-1]<=32
		dec	edx
	.endw
	mov	byte ptr[edx],0
	push	dword ptr[edx]
	push	edx
	mov	edi,lParam
	mov	ebx,edi
	lea	edx,r_buf
	lea	ebp,createdir
	mov	initbuf,edx
	call	testfs
	pop	edx
	pop	dword ptr[edx]
	.if eax==0
		pop	ebp
		push	ebp
		mov	edi,lParam
		lea	edx,[edi].tdtbl
		mov	stbl,edx
		mov	esi,r_buf
		lea	ebp,chkdirs
		call	checkdirs
		pop	ebp
		push	ebp
		mov	edi,lParam
		lea	edx,[edi].tdtbl
		call	scantbl
		pop	ebp
		push	ebp
		mov	edi,lParam
		lea	edx,[edi].tdtbl
		mov	stbl,edx
		mov	esi,r_buf
		lea	ebp,createdirs
		lea	edx,defdir
		.while byte ptr[edx]
			inc	edx
		.endw
		push	dword ptr[edx]
		push	edx
	;	inc	dirs
		call	savedirs
	;	dec	dirs
		pop	edx
		pop	dword ptr[edx]
	.endif


;n_page:
	pop	ebp
	push	ebp
	mov	eax,diridx
	mov	didx1,eax
	mov	eax,didx2
	mov	diridx,eax
	mov	esi,r_buf
	lea	edx,r_buf
	mov	initbuf,edx
	mov	edi,lParam
	call	testtopics
	.if eax==0
		mov	esi,r_buf
		mov	edi,lParam
		push	edi
		call	get_format
		pop	edi
		push	edi

		.if tbltopicf==0
			push	0
			push	0
			mov	ecx,3
			xor	ebx,ebx
			.while ecx<20
				xor	ebp,ebp
				.while ebp<5
					call	get_max
					.if edx>ebx
						mov	dword ptr[esp],ebp
						mov	dword ptr[esp+4],ecx
						mov	ebx,edx
					.endif
					inc	ebp
				.endw
				inc	ecx
			.endw
			pop	eax
			pop	edx
			.if (edx==tbltopic)&&(eax==tbltopic[4])
				mov	tbltopicf,edx
				mov	tbltopicf[4],eax
			.else
				mov	tbltopic,edx
				mov	tbltopic[4],eax
			.endif
		.endif

		.if tbltopicf
			mov	edx,tbltopicf
			mov	eax,tbltopicf[4]
		.else
			mov	edx,tbltopic
			mov	eax,tbltopic[4]
		.endif
		pop	edi
		lea	esi,[edi].tables
		.while dword ptr[esi]
			.if (eax==[esi+8])&&(edx==[esi+4])
			.else
				mov	dword ptr[esi+4],0
			.endif
			lea	esi,[esi+16]
		.endw

		pop	ebp
		push	ebp
		mov	edi,lParam
		lea	edx,[edi].tdtbl
		mov	stbl,edx
		mov	esi,r_buf
		lea	ebp,chktopics
		call	checkdirs

		pop	ebp
		push	ebp
		mov	edi,lParam
		lea	edx,[edi].tdtbl
		xor	ecx,ecx
		push	edx
		.while ecx<100
			.if (dword ptr[edx]==4)||(dword ptr[edx]==5)
				mov	byte ptr[edx],0
			.elseif dword ptr[edx]==3
				pop	edx
				push	edx
				xor	ecx,ecx
				xor	eax,eax
				.while ecx<100
					.if eax
						mov	dword ptr[edx],0
					.elseif dword ptr[edx]!=3
						mov	[edx],eax
					.else
						inc	eax
					.endif
					lea	edx,[edx+4]
					inc	ecx
				.endw
				.break
			.endif
			lea	edx,[edx+4]
			inc	ecx
		.endw
		pop	edx

		pop	ebp
		push	ebp
		mov	edi,lParam
		lea	edx,[edi].tdtbl
		mov	stbl,edx
		mov	esi,r_buf
		lea	ebp,createtopics
		call	savedirs
	.endif
	pop	ebp
	push	ebp
	mov	esi,r_buf

	push	esi
	mov	edi,lParam
	indexnextpagesearch
	pop	edx
	.if (labelex!=0)
		.if (esi!=edx)&&(byte ptr[esi]!=0)
			push	edi
			jmp	_fnext
		.else
			jmp	fnopage
		.endif
	.endif
	.if (fflag&8)&&(flink4!=0)
		push	edi
_nnpage1:	lea	edx,flink4
		call	_seek
		.if (byte ptr[esi]!=0)
			.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
				dec	esi
			.endif
			.while (byte ptr[esi-1]>='0')&&(byte ptr[esi-1]<='9')
				dec	esi
			.endw
			.if (byte ptr[esi]=='0')||((byte ptr[esi]=='1')&&((byte ptr[esi+1]>'9')||(byte ptr[esi+1]<'0')))
				inc	esi
				jmp	_nnpage1
			.endif
			.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)
				inc	esi
			.endw
			.if byte ptr[esi]==34
				dec	esi
				.while (byte ptr[esi]!=34)&&(esi!=r_buf)
					dec	esi
				.endw
				.if byte ptr[esi]==34
					inc	esi
					mov	edx,esi
					isforumsaved1
					.if edx
						.while byte ptr[esi]!=34
							inc	esi
						.endw
						jmp	_nnpage1
					.endif
					jmp	_fnext
				.endif
			.elseif byte ptr[esi]==39
				dec	esi
				.while (byte ptr[esi]!=39)&&(esi!=r_buf)
					dec	esi
				.endw
				.if byte ptr[esi]==39
					inc	esi
					mov	edx,esi
					isforumsaved1
					.if edx
						.while byte ptr[esi]!=39
							inc	esi
						.endw
						jmp	_nnpage1
					.endif
					jmp	_fnext
				.endif
			.endif
		.endif
		pop	edi
	.else
		call	scanpage
	.endif
	.if (word ptr[esi]=='a<')||(word ptr[esi]=='A<')
		call	forbid_anchor
		.if eax
			jmp	fnopage
		.endif
		.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
			mov	eax,[esi]
			or	eax,20202020h
			.if eax=='erh '
				push	edi
				lea	esi,[esi+4]
				mov	al,[esi]
				or	al,20h
				.if al=='f'
					inc	esi
				.endif
				.while (byte ptr[esi]=='=')||(byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==39)||(byte ptr[esi]==34)
					inc	esi
				.endw
_fnext:				mov	ebx,lParam
				assume	ebx:ptr foruminfo
				mov	edx,f_info
				assume	edx:ptr foruminfo
				lea	edx,[edx]._addr
				assume	edx:nothing
				lea	edi,[ebx]._addr
				call	copyedx
				mov	al,0
				stosb
				mov	edx,f_info
				assume	edx:ptr foruminfo
				lea	edx,[edx]._dns
				assume	edx:nothing
				lea	edi,[ebx]._dns
				call	copyedx
				mov	al,0
				stosb
				lea	edi,[ebx]._addr
				mov	eax,dword ptr[edi]
				or	eax,20202020h
				.if (eax=='ptth')&&(word ptr[edi+4]=='/:')&&(byte ptr[edi+6]=='/')
					lea	edi,[edi+7]
				.endif
				mov	eax,[esi]
				or	eax,20202020h
				.if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+6]=='/')
					lea	esi,[esi+7]
				.elseif byte ptr[esi]=='/'
					.while (byte ptr[edi]!='/')&&(byte ptr[edi]!=0)
						inc	edi
					.endw
				.else
					mov	edx,edi
					push	edi
					.while byte ptr[edi]
						.if byte ptr[edi]=='/'
							mov	edx,edi
						.endif
						inc	edi
					.endw
					pop	eax
					.if edx==eax
						.if byte ptr[edi]!='/'
							mov	al,'/'
							stosb
						.endif
					.else
						mov	edi,edx
						mov	al,'/'
						stosb
					.endif
				.endif
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
					lodsb
					.if al=='&'
						mov	eax,[esi]
						or	eax,202020h
						.if eax==';pma'
							lodsd
						.endif
						mov	al,'&'
					.else
						mov	eax,[esi-1]
						or	eax,20202020h
						.if eax=='=dis'
							.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
								inc	esi
							.endw
							.continue
						.elseif eax=='sphp'
							mov	eax,[esi+3]
							or	eax,20202020h
							.if eax=='isse'
								.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
									inc	esi
								.endw
								.continue
							.endif
						.endif
						mov	al,[esi-1]
					.endif
					stosb
				.endw
				.if byte ptr[edi-1]=='&'
					dec	edi
				.endif
				mov	al,0
				stosb
				pop	edi
				mov	edi,lParam
				call	phpset
				mov	fsize,0
				indexdownload
				.if fsize==0
					mov	[edi]._loc,0
					invoke	getfile,addr r_buf,1,0,8192
					.if hfile==-1
						mov	hfile,0
					.endif
					indexdownloadcomplete
				.endif
				jmp	n_page
				assume	ebx:nothing
			.endif
			inc	esi
		.endw
	.endif
fnopage:mov	al,duptopics
	invoke	GlobalFree,r_buf
	pop	ebp
	pop	diridx
	ret
get_topics	ENDP

known1	db	'forumdisplay.php',0
known2	db	'viewforum.php',0
known3	db	'showforum',0
known6	db	'forum_desc.php',0
known7	db	'forum.php?f=',0
known8	db	'?f=',0
known1a	db	'mark=',0
known1b	db	'start=',0
known1c	db	'page=',0
known1d	db	'markread',0
known1g	db	'&amp;p=',0


forum_add	PROC	uses ebx
	.if (fflag&7)||(labelex==1)
	.else
		.if forum_sim
			push	esi
			push	edi
			lea	edi,forum_sim
			mov	edx,esi
			.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
				.if (byte ptr[esi]=='/')&&((byte ptr[esi+1]>='a')&&(byte ptr[esi+1]<='z'))||((byte ptr[esi+1]>='A')&&(byte ptr[esi+1]<='Z'))
					mov	edx,esi
				.endif
				inc	esi
			.endw
			mov	esi,edx
			.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
				.if (byte ptr[esi]<='9')&&(byte ptr[esi]>='0')
				.else
					mov	al,[esi]
					mov	ah,[edi]
					.break .if al!=ah
					inc	edi
				.endif
				inc	esi
			.endw
			mov	al,0
			.if byte ptr[edi]==0
				mov	al,2
			.endif
			pop	edi
			pop	esi
			.if al==0
				ret
			.endif
		.else
			push	esi
			push	edi
			lea	edi,forum_sim
			mov	edx,esi
			.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
				.if (byte ptr[esi]=='/')&&((byte ptr[esi+1]>='a')&&(byte ptr[esi+1]<='z'))||((byte ptr[esi+1]>='A')&&(byte ptr[esi+1]<='Z'))
					mov	edx,esi
				.endif
				inc	esi
			.endw
			mov	esi,edx
			.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
				.if (byte ptr[esi]<='9')&&(byte ptr[esi]>='0')
					inc	esi
				.else
					movsb
				.endif
			.endw
			mov	al,0
			stosb

			pop	edi
			pop	esi
		.endif
	.endif
	invoke	GlobalAlloc,GPTR,sizeof foruminfo
	push	eax
	mov	ebx,eax
	assume	ebx:ptr foruminfo
	mov	[ebx]._next,0
	mov	[ebx].histptr,0
	mov	edx,f_info
	assume	edx:ptr foruminfo
	lea	edx,[edx]._addr
	assume	edx:nothing
	lea	edi,[ebx]._addr
	call	copyedx
	mov	al,0
	stosb
	mov	edx,f_info
	assume	edx:ptr foruminfo
	lea	edx,[edx]._dns
	assume	edx:nothing
	lea	edi,[ebx]._dns
	call	copyedx
	mov	al,0
	stosb
	lea	edi,[ebx]._addr
	mov	eax,dword ptr[edi]
	or	eax,20202020h
	.if (eax=='ptth')&&(word ptr[edi+4]=='/:')&&(byte ptr[edi+6]=='/')
		lea	edi,[edi+7]
	.endif
	mov	eax,[esi]
	or	eax,20202020h
	.if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+6]=='/')
		lea	esi,[esi+7]
	.elseif byte ptr[esi]=='/'
		.while (byte ptr[edi]!='/')&&(byte ptr[edi]!=0)
			inc	edi
		.endw
	.else
		mov	edx,edi
		push	edi
		.while byte ptr[edi]
			.if byte ptr[edi]=='/'
				mov	edx,edi
			.endif
			inc	edi
		.endw
		pop	eax
		.if edx==eax
			.if byte ptr[edi]!='/'
				mov	al,'/'
				stosb
			.endif
		.else
			mov	edi,edx
			mov	al,'/'
			stosb
		.endif
	.endif
	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
		lodsb
		.if al=='&'
			mov	eax,[esi]
			or	eax,202020h
			.if eax==';pma'
				lodsd
			.endif
			mov	al,'&'
		.else
			mov	eax,[esi-1]
			or	eax,20202020h
			.if eax=='=dis'
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
					inc	esi
				.endw
				.continue
			.elseif eax=='sphp'
				mov	eax,[esi+3]
				or	eax,20202020h
				.if eax=='isse'
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
						inc	esi
					.endw
					.continue
				.endif
			.endif
			mov	al,[esi-1]
		.endif
		stosb
	.endw
	.if byte ptr[edi-1]=='&'
		dec	edi
	.endif
	mov	al,0
	stosb
	lea	edx,[ebx]._addr
	isforumsaved
	mov	[ebx].histptr,eax
	.if edx==0
		lea	edi,defdir
		.while byte ptr[edi]
			inc	edi
		.endw
		push	dword ptr[edi]
		push	edi
		push	ebx
		.if byte ptr[edi-1]!='\'
			mov	al,'\'
			stosb
		.endif
		mov	eax,diridx
		call	w2
		mov	al,32
		stosb
		.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
			inc	esi
		.endw
		.if byte ptr[esi]=='>'
			inc	esi
		.endif
		mov	ecx,maxfile
		push	edi
		call	escfile
		pop	edx
		pop	ebx
		.if edi!=edx
			mov	al,0
			stosb
			call	ebp
		.endif
		pop	edi
		pop	dword ptr[edi]
	.endif
	call	GlobalFree
	ret
forum_add	ENDP

lvins_:	push	ebx
	mov	lvit.imask,LVIF_TEXT or LVIF_PARAM or LVIF_STATE
	mov	eax,diridx
	dec	eax
	mov	lvit.iItem,eax
	movzx	eax,byte ptr forums[eax]
	mov	lvit.iSubItem,0
	and	eax,1
	shl	eax,10+1+1+1
	.if eax==0
		mov	eax,4096
	.endif
	mov	lvit.state,eax
	mov	lvit.stateMask,LVIS_STATEIMAGEMASK
	lodsd
	mov	lvit.pszText,offset defdir[1]
	mov	lvit.cchTextMax,256
	mov	lvit.lParam,esi
	invoke	SendDlgItemMessage,maxfsize,400,LVM_INSERTITEM,0,addr lvit
	mov	lvit.imask,LVIF_TEXT
	pop	ebx
	push	ebx
	lea	edx,[ebx]._addr
	mov	lvit.iItem,eax
	mov	lvit.iSubItem,1
	mov	lvit.pszText,edx
	invoke	SendDlgItemMessage,maxfsize,400,LVM_SETITEM,0,addr lvit
	mov	lvit.iSubItem,0
	invoke	SendDlgItemMessage,maxfsize,400,LVM_SETITEMSTATE,lvit.iItem,addr lvit
	pop	ebx
	inc	diridx
	ret

createdir:
	mov	eax,diridx
	dec	eax
	movzx	eax,byte ptr forums[eax]
	.if eax
createdr:	push	ebx
		call	escdir
		invoke	CreateDirectory,addr defdir,0
		pop	ebx
		inc	dirs
		.if eax==0
			invoke	GetLastError
			.if eax!=ERROR_ALREADY_EXISTS
				lea	edi,buftmp
				push	edi
				lea	edx,errdir
				call	copyedx
				lea	edx,defdir
				call	copyedx
				mov	ax,0a0dh
				stosw
				mov	al,0
				stosb
				pop	edx
				call	showmsg
			.else
				idx_start
				push	stbl
				invoke	get_topics,ebx
				pop	stbl
				idx_end
			.endif
		.else
			idx_start
			push	stbl
			invoke	get_topics,ebx
			pop	stbl
			idx_end
		.endif
		dec	dirs
	.endif
	inc	diridx
	ret
	assume	ebx:nothing

testforums:
	mov	esi,recvbuf
	lea	edx,recvbuf
	mov	initbuf,edx
testfs:	push	esi
	.while 1
		push	esi
		push	ebx
		forumsearch
		pop	ebx
		pop	eax
		.if labelex==0
			mov	esi,eax
			.break
		.endif
		.if ((word ptr[esi]=='a<')||(word ptr[esi]=='A<'))&&(eax!=esi)
			call	forbid_anchor
			.if eax
				inc	esi
				.continue
			.endif
			.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
				mov	edx,[esi]
				or	edx,202020h
				.if (edx=='ferh')
					lodsd
					.while (byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]=='=')
						inc	esi
					.endw
					.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
						inc	esi
					.endif
					mov	eax,[esp]
					push	ebp
			;		mov	eax,initbuf
					.if (ebp==offset createdir)&&(eax!=recvbuf)
						lea	ebp,createdr
					.endif
					push	ebx
					push	esi
					push	edi
					push	initbuf
					call	forum_add
					pop	initbuf
					pop	edi
					pop	esi
					pop	ebx
					pop	ebp
					.break
				.endif
				inc	esi
			.endw
		.else
			pop	eax
			xor	eax,eax
			inc	eax
			ret
		.endif
	.endw
	pop	esi
	.if ((fflag&1)&&(flink1!=0))||((fflag&2)&&(flink2!=0))||((fflag&4)&&(flink3!=0))	;||((fflag&8)&&(flink4!=0))
		push	ebx
		push	esi
		.while byte ptr[esi]
			.if fflag&1
				lea	edx,flink1
				call	_seek
			.endif
			.if byte ptr[esi]
				mov	ecx,esi
				xor	ebx,ebx
				.if fflag&2
					lea	edx,flink2
					call	_seek
					.continue .if byte ptr[esi]==0
					.if fflag&1
_retry0:					push	esi
						lea	esi,[ecx+1]
						lea	edx,flink1
						call	_seek
						pop	edx
						.if (byte ptr[esi]!=0)&&(esi<edx)
							mov	ecx,esi
							mov	esi,edx
							jmp	_retry0
						.else
							mov	esi,edx
						.endif
					.endif
				.endif
				.if byte ptr[esi]
					.if fflag&4
						lea	edx,flink3
						call	_seek
						.if byte ptr[esi]
							.if (fflag&1)
_retry1:							push	esi
								lea	esi,[ecx+1]
								lea	edx,flink1
								call	_seek
								pop	edx
								.if (byte ptr[esi]!=0)&&(esi<edx)
									push	esi
									mov	esi,edx
									.if fflag&2
										lea	esi,[ecx+1]
										push	edx
										lea	edx,flink2
										call	_seek
										pop	edx
										.if (byte ptr[esi]!=0)&&(esi<edx)
											mov	esi,edx
											pop	ecx
											jmp	_retry1
										.else
											pop	eax
											mov	esi,edx
										.endif
									.else
										pop	ecx
										jmp	_retry1
									.endif
								.else
									mov	esi,edx
								.endif
							.endif
							.if fflag&2
_retry:								push	esi
								lea	esi,[ecx+1]
								lea	edx,flink2
								call	_seek
								pop	edx
								.if (byte ptr[esi]!=0)&&(esi<edx)
									mov	ecx,esi
									mov	esi,edx
									jmp	_retry
								.else
									mov	esi,edx
								.endif
							.endif
							.if (byte ptr[ecx]==34)||(byte ptr[ecx]==39)
								dec	ecx
							.endif
							mov	eax,[esp]
							.while (byte ptr[ecx]!=34)&&(byte ptr[ecx]!='>')&&(byte ptr[ecx]!='<')&&(byte ptr[ecx]!=39)&&(byte ptr[ecx]>32)&&(eax!=ecx)
								dec	ecx
							.endw
						.endif
						mov	ebx,esi
					.endif
					.if byte ptr[esi]
						mov	esi,ecx
						.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)&&((ebx==0)||(esi<ebx))
							mov	eax,[esi]
							or	eax,20202020h
							.if eax=='ptth'
								jmp	_http
					;		.elseif eax=='erh '
					;			lea	esi,[esi+4]
					;			mov	al,[esi]
					;			or	al,20h
					;			.if al=='f'
					;				inc	esi
					;			.endif
					;			.while (byte ptr[esi]=='=')||(byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==39)||(byte ptr[esi]==34)
					;				inc	esi
					;			.endw
_http:								push	ebp
								call	forbid_anchor
								.if eax==0
									mov	eax,[esp+4]
									.if (ebp==offset createdir)&&(eax!=recvbuf)
										lea	ebp,createdr
									.endif
									mov	ebx,[esp+4+4]
									call	forum_add
								.endif
								pop	ebp
								xor	eax,eax
								inc	eax
								.break
							.endif
							xor	eax,eax
							inc	esi
						.endw
						.if eax==0
							mov	esi,ecx
							.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)&&((ebx==0)||(esi<ebx))
								mov	al,[esi]
								.if al==34
									inc	esi
									.if fflag&2
										push	esi
										lea	edx,flink2
										call	_seek
										.if byte ptr[esi]==34
											dec	esi
										.endif
										mov	eax,[esp+4]
										.while (byte ptr[esi]!=34)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='<')&&(byte ptr[esi]!=39)&&(byte ptr[esi]>32)&&(eax!=esi)
											dec	esi
										.endw
										.if (byte ptr[esi]==34)
											inc	esi
											pop	eax
											push	ebp
											call	forbid_anchor
											.if eax==0
												mov	ebx,[esp+4+4]
												mov	eax,[esp+4]
												.if (ebp==offset createdir)&&(eax!=recvbuf)
													lea	ebp,createdr
												.endif
												call	forum_add
											.endif
											pop	ebp
											.break
										.else
											pop	esi
										.endif
									.else
										push	ebp
										call	forbid_anchor
										.if eax==0
											mov	eax,[esp+4]
											.if (ebp==offset createdir)&&(eax!=recvbuf)
												lea	ebp,createdr
											.endif
											mov	ebx,[esp+4+4]
											call	forum_add
										.endif
										pop	ebp
										.break
									.endif
								.elseif al==39
									inc	esi
									.if fflag&2
										push	esi
										lea	edx,flink2
										call	_seek
										.if byte ptr[esi]==39
											dec	esi
										.endif
										mov	eax,[esp+4]
										.while (byte ptr[esi]!=34)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='<')&&(byte ptr[esi]!=39)&&(byte ptr[esi]>32)&&(eax!=esi)
											dec	esi
										.endw
										.if (byte ptr[esi]==39)
											inc	esi
											pop	eax
											push	ebp
											call	forbid_anchor
											.if eax==0
												mov	eax,[esp+4]
												.if (ebp==offset createdir)&&(eax!=recvbuf)
													lea	ebp,createdr
												.endif
												mov	ebx,[esp+4+4]
												call	forum_add
											.endif
											pop	ebp
											.break
										.else
											pop	esi
										.endif
									.else
										push	ebp
										call	forbid_anchor
										.if eax==0
											mov	eax,[esp+4]
											.if (ebp==offset createdir)&&(eax!=recvbuf)
												lea	ebp,createdr
											.endif
											mov	ebx,[esp+4+4]
											call	forum_add
										.endif
										pop	ebp
										.break
									.endif
								.else
									inc	esi
								.endif
							.endw
						.endif
					.endif
				.endif
			.endif
			inc	esi
		.endw
		pop	eax
		pop	ebx
		xor	eax,eax
		inc	eax
		ret
	.else
	push	esi
	push	0
	push	0
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			inc	esi
			mov	ax,[esi]
			or	ax,20h
			.if (ax==' a')&&(!(dword ptr[esp+4]&2))
				call	forbid_anchor
				.continue .if eax
				.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
					mov	eax,[esi]
					or	eax,20202020h
					.if eax=='erh '
						lea	esi,[esi+4]
						mov	al,[esi]
						or	al,20h
						.if al=='f'
							inc	esi
						.endif
						.while (byte ptr[esi]=='=')||(byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==39)||(byte ptr[esi]==34)
							inc	esi
						.endw
						lea	edx,known1a
						call	_scan
						.break .if eax
						lea	edx,known1b
						call	_scan
						.break .if eax
						lea	edx,known1c
						call	_scan
						.break .if eax
						lea	edx,known1d
						call	_scan
						.break .if eax
						lea	edx,known1g
						call	_scan
						.break .if eax
						lea	edx,known1
						call	_scan
						.if eax
							push	ebp
							mov	eax,[esp+4+4+4]
							.if (ebp==offset createdir)&&(eax!=recvbuf)
								lea	ebp,createdr
							.endif
							call	forum_add
							pop	ebp
							.if dword ptr[esp+4]&1
								or	dword ptr[esp+4],2
							.endif
							mov	dword ptr[esp],1
							.break
						.endif
						lea	edx,known2
						call	_scan
						.if eax
							push	ebp
							mov	eax,[esp+4+4+4]
							.if (ebp==offset createdir)&&(eax!=recvbuf)
								lea	ebp,createdr
							.endif
							call	forum_add
							pop	ebp
							.if dword ptr[esp+4]&1
								or	dword ptr[esp+4],2
							.endif
							mov	dword ptr[esp],1
							.break
						.endif
						lea	edx,known3
						call	_scan
						.if eax
							push	ebp
							mov	eax,[esp+4+4+4]
							.if (ebp==offset createdir)&&(eax!=recvbuf)
								lea	ebp,createdr
							.endif
							call	forum_add
							pop	ebp
							.if dword ptr[esp+4]&1
								or	dword ptr[esp+4],2
							.endif
							mov	dword ptr[esp],1
							.break
						.endif
						lea	edx,known6
						call	_scan
						.if eax
							push	ebp
							mov	eax,[esp+4+4+4]
							.if (ebp==offset createdir)&&(eax!=recvbuf)
								lea	ebp,createdr
							.endif
							call	forum_add
							pop	ebp
							.if dword ptr[esp+4]&1
								or	dword ptr[esp+4],2
							.endif
							mov	dword ptr[esp],1
							.break
						.endif
						lea	edx,known7
						call	_scan
						.if eax
							push	ebp
							mov	eax,[esp+4+4+4]
							.if (ebp==offset createdir)&&(eax!=recvbuf)
								lea	ebp,createdr
							.endif
							call	forum_add
							pop	ebp
							.if dword ptr[esp+4]&1
								or	dword ptr[esp+4],2
							.endif
							mov	dword ptr[esp],1
							.break
						.endif
						lea	edx,known8
						call	_scan
						.if eax
							push	ebp
							mov	eax,[esp+4+4+4]
							.if (ebp==offset createdir)&&(eax!=recvbuf)
								lea	ebp,createdr
							.endif
							call	forum_add
							pop	ebp
							.if dword ptr[esp+4]&1
								or	dword ptr[esp+4],2
							.endif
							mov	dword ptr[esp],1
							.break
						.endif
					.endif
					inc	esi
				.endw
			.elseif ax=='rt'
				.if dword ptr[esp]
					mov	dword ptr[esp+4],1
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	eax
	pop	edx
	pop	ecx
	.endif
	ret


topic_add:
	.if tflag&7
	.else
		.if topic_sim==0
			push	esi
			push	edi
			lea	edi,topic_sim
			mov	edx,esi
			.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
				.if (byte ptr[esi]=='/')&&((byte ptr[esi+1]>='a')&&(byte ptr[esi+1]<='z'))||((byte ptr[esi+1]>='A')&&(byte ptr[esi+1]<='Z'))
					mov	edx,esi
				.endif
				inc	esi
			.endw
			mov	esi,edx
			.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
				.if (byte ptr[esi]<='9')&&(byte ptr[esi]>='0')
					inc	esi
				.else
					movsb
				.endif
			.endw
			mov	al,0
			stosb

			pop	edi
			pop	esi
		.endif
	.endif
	invoke	GlobalAlloc,GPTR,sizeof foruminfo
	push	eax
	mov	ebx,eax
	assume	ebx:ptr foruminfo
	mov	[ebx]._next,0
	mov	[ebx].histptr,0
	mov	edx,f_info
	assume	edx:ptr foruminfo
	lea	edx,[edx]._addr
	assume	edx:nothing
	lea	edi,[ebx]._addr
	call	copyedx
	mov	al,0
	stosb
	mov	edx,f_info
	assume	edx:ptr foruminfo
	lea	edx,[edx]._dns
	assume	edx:nothing
	lea	edi,[ebx]._dns
	call	copyedx
	mov	al,0
	stosb
	lea	edi,[ebx]._addr
	mov	eax,dword ptr[edi]
	or	eax,20202020h
	.if (eax=='ptth')&&(word ptr[edi+4]=='/:')&&(byte ptr[edi+6]=='/')
		lea	edi,[edi+7]
	.endif
	mov	eax,[esi]
	or	eax,20202020h
	.if (eax=='ptth')&&(word ptr[esi+4]=='/:')&&(byte ptr[esi+6]=='/')
		lea	esi,[esi+7]
	.elseif byte ptr[esi]=='/'
		.while (byte ptr[edi]!='/')&&(byte ptr[edi]!=0)
			inc	edi
		.endw
	.else
		mov	edx,edi
		push	edi
		.while byte ptr[edi]
			.if byte ptr[edi]=='/'
				mov	edx,edi
			.endif
			inc	edi
		.endw
		pop	eax
		.if edx==eax
			.if byte ptr[edi]!='/'
				mov	al,'/'
				stosb
			.endif
		.else
			mov	edi,edx
			mov	al,'/'
			stosb
		.endif
	.endif
	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)
		lodsb
		.if al=='&'
			mov	eax,[esi]
			or	eax,202020h
			.if eax==';pma'
				lodsd
			.endif
			mov	al,'&'
		.else
			mov	eax,[esi-1]
			or	eax,20202020h
			.if eax=='=dis'
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
					inc	esi
				.endw
				.continue
			.elseif eax=='sphp'
				mov	eax,[esi+3]
				or	eax,20202020h
				.if eax=='isse'
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
						inc	esi
					.endw
					.continue
				.endif
			.endif
			mov	al,[esi-1]
		.endif
		stosb
	.endw
	.if byte ptr[edi-1]=='&'
		dec	edi
	.endif
	mov	al,0
	stosb
	lea	edx,[ebx]._addr
	istopicsaved
	mov	[ebx].histptr,eax
	.if edx==0
		lea	edi,defdir
		.while byte ptr[edi]
			inc	edi
		.endw
		push	dword ptr[edi]
		push	edi
		push	ebx
		.if byte ptr[edi-1]!='\'
			mov	al,'\'
			stosb
		.endif
		mov	eax,diridx
		call	w5
		mov	al,32
		stosb
		.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
			inc	esi
		.endw
		.if byte ptr[esi]=='>'
			inc	esi
		.endif
		mov	ecx,maxfile
		push	edi
		call	escfile
		pop	edx
		pop	ebx
		.if edi!=edx
			mov	eax,'mth.'
			stosd
			mov	ax,'l'
			stosw
			push	stbl
			invoke	save_topics,ebx
			pop	stbl
			inc	diridx
		.endif
		pop	edi
		pop	dword ptr[edi]
	.endif
	assume	ebx:nothing
	call	GlobalFree
	ret


known4	db	'viewtopic.php',0
known5	db	'showthread.php',0
known10	db	'showtopic',0
known9	db	'?t=',0
known1e	db	'&amp;act=',0
known1f	db	'&act=',0

testtopics:
	.while 1
		push	esi
		topicsearch
		pop	eax
		.break .if labelex==0
		.if ((word ptr[esi]=='a<')||(word ptr[esi]=='A<'))&&(eax!=esi)
			.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
				mov	edx,[esi]
				or	edx,202020h
				.if (edx=='ferh')&&(byte ptr[esi+4]=='=')
					lea	esi,[esi+5]
					.while (byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)
						inc	esi
					.endw
					.if (byte ptr[esi]==34)||(byte ptr[esi]==39)
						inc	esi
					.endif
					push	ebp
					mov	eax,initbuf
					.if (ebp==offset createdir)&&(eax!=recvbuf)
						lea	ebp,createdr
					.endif
					push	esi
					push	edi
					push	initbuf
					call	topic_add
					pop	initbuf
					pop	edi
					pop	esi
					pop	ebp
					.break
				.endif
				inc	esi
			.endw
		.else
			xor	eax,eax
			inc	eax
			ret
		.endif
	.endw
	.if ((tflag&1)&&(tlink1!=0))||((tflag&2)&&(tlink2!=0))||((tflag&4)&&(tlink3!=0))	;||((tflag&8)&&(tlink4!=0))
		push	ebx
		push	esi
		.while byte ptr[esi]
			.if tflag&1
				lea	edx,tlink1
				call	_seek
			.endif
			.if byte ptr[esi]
				mov	ecx,esi
				xor	ebx,ebx
				.if tflag&2
					lea	edx,tlink2
					call	_seek
					.continue .if byte ptr[esi]==0
					.if tflag&1
_retry0a:					push	esi
						lea	esi,[ecx+1]
						lea	edx,tlink1
						call	_seek
						pop	edx
						.if (byte ptr[esi]!=0)&&(esi<edx)
							mov	ecx,esi
							mov	esi,edx
							jmp	_retry0a
						.else
							mov	esi,edx
						.endif
					.endif
				.endif
				.if byte ptr[esi]
					.if tflag&4
						lea	edx,tlink3
						call	_seek
						.if byte ptr[esi]
							.if (tflag&1)
_retry1a:							push	esi
								lea	esi,[ecx+1]
								lea	edx,tlink1
								call	_seek
								pop	edx
								.if (byte ptr[esi]!=0)&&(esi<edx)
									push	esi
									mov	esi,edx
									.if tflag&2
										lea	esi,[ecx+1]
										push	edx
										lea	edx,tlink2
										call	_seek
										pop	edx
										.if (byte ptr[esi]!=0)&&(esi<edx)
											mov	esi,edx
											pop	ecx
											jmp	_retry1a
										.else
											pop	eax
											mov	esi,edx
										.endif
									.else
										pop	ecx
										jmp	_retry1a
									.endif
								.else
									mov	esi,edx
								.endif
							.endif
							.if tflag&2
_retrya:							push	esi
								lea	esi,[ecx+1]
								lea	edx,tlink2
								call	_seek
								pop	edx
								.if (byte ptr[esi]!=0)&&(esi<edx)
									mov	ecx,esi
									mov	esi,edx
									jmp	_retrya
								.else
									mov	esi,edx
								.endif
							.endif
							.if (byte ptr[ecx]==34)||(byte ptr[ecx]==39)
								dec	ecx
							.endif
							mov	eax,[esp]
							.while (byte ptr[ecx]!=34)&&(byte ptr[ecx]!='>')&&(byte ptr[ecx]!='<')&&(byte ptr[ecx]!=39)&&(byte ptr[ecx]>32)&&(eax!=ecx)
								dec	ecx
							.endw
						.endif
						mov	ebx,esi
					.endif

					.if byte ptr[esi]
						mov	esi,ecx
						.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)&&((ebx==0)||(esi<ebx))
							mov	eax,[esi]
							or	eax,20202020h
							.if eax=='ptth'
								jmp	_httpa
					;		.elseif eax=='erh '
					;			lea	esi,[esi+4]
					;			mov	al,[esi]
					;			or	al,20h
					;			.if al=='f'
					;				inc	esi
					;			.endif
					;			.while (byte ptr[esi]=='=')||(byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==39)||(byte ptr[esi]==34)
					;				inc	esi
					;			.endw
_httpa:								call	topic_add
								xor	eax,eax
								inc	eax
								.break
							.endif
							xor	eax,eax
							inc	esi
						.endw
						.if eax==0
							mov	esi,ecx
							.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)&&((ebx==0)||(esi<ebx))
								mov	al,[esi]
								.if al==34
									inc	esi
									.if tflag&2
										push	esi
										lea	edx,tlink2
										call	_seek
										.if byte ptr[esi]==34
											dec	esi
										.endif
										mov	eax,[esp+4]
										.while (byte ptr[esi]!=34)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='<')&&(byte ptr[esi]!=39)&&(byte ptr[esi]>32)&&(eax!=esi)
											dec	esi
										.endw
										.if (byte ptr[esi]==34)
											inc	esi
											pop	eax
											call	topic_add
											.break
										.else
											pop	esi
										.endif
									.else
										call	topic_add
										.break
									.endif
								.elseif al==39
									inc	esi
									.if tflag&2
										push	esi
										lea	edx,tlink2
										call	_seek
										.if byte ptr[esi]==39
											dec	esi
										.endif
										mov	eax,[esp+4]
										.while (byte ptr[esi]!=34)&&(byte ptr[esi]!='>')&&(byte ptr[esi]!='<')&&(byte ptr[esi]!=39)&&(byte ptr[esi]>32)&&(eax!=esi)
											dec	esi
										.endw
										.if (byte ptr[esi]==39)
											inc	esi
											pop	eax
											call	topic_add
											.break
										.else
											pop	esi
										.endif
									.else
										call	topic_add
										.break
									.endif
								.else
									inc	esi
								.endif
							.endw
						.endif
					.endif
				.endif
			.endif
			inc	esi
		.endw
		pop	esi
		pop	ebx
		xor	eax,eax
		inc	eax
		ret
	.else
	push	0
	push	0
	.while byte ptr[esi]
		.if byte ptr[esi]=='<'
			inc	esi
			mov	ax,[esi]
			or	ax,20h
			.if (ax==' a')&&(!(dword ptr[esp+4]&2))
				.while (byte ptr[esi]!='>')&&(byte ptr[esi]!=0)
					mov	eax,[esi]
					or	eax,20202020h
					.if eax=='erh '
						lea	esi,[esi+4]
						mov	al,[esi]
						or	al,20h
						.if al=='f'
							inc	esi
						.endif
						.while (byte ptr[esi]=='=')||(byte ptr[esi]==32)||(byte ptr[esi]==13)||(byte ptr[esi]==10)||(byte ptr[esi]==9)||(byte ptr[esi]==39)||(byte ptr[esi]==34)
							inc	esi
						.endw
						lea	edx,known1a
						call	_scan
						.break .if eax
						lea	edx,known1b
						call	_scan
						.break .if eax
						lea	edx,known1c
						call	_scan
						.break .if eax
						lea	edx,known1d
						call	_scan
						.break .if eax
						lea	edx,known1e
						call	_scan
						.break .if eax
						lea	edx,known1f
						call	_scan
						.break .if eax
						lea	edx,known4
						call	_scan
						.if eax
							call	topic_add
							.if dword ptr[esp+4]&1
								or	dword ptr[esp+4],2
							.endif
							mov	dword ptr[esp],1
							.break
						.endif
						lea	edx,known5
						call	_scan
						.if eax
							call	topic_add
							.if dword ptr[esp+4]&1
								or	dword ptr[esp+4],2
							.endif
							mov	dword ptr[esp],1
							.break
						.endif
						lea	edx,known9
						call	_scan
						.if eax
							call	topic_add
							.if dword ptr[esp+4]&1
								or	dword ptr[esp+4],2
							.endif
							mov	dword ptr[esp],1
							.break
						.endif
						lea	edx,known10
						call	_scan
						.if eax
							call	topic_add
							.if dword ptr[esp+4]&1
								or	dword ptr[esp+4],2
							.endif
							mov	dword ptr[esp],1
							.break
						.endif
					.endif
					inc	esi
				.endw
			.elseif ax=='rt'
				.if dword ptr[esp]
					mov	dword ptr[esp+4],1
				.endif
			.endif
		.else
			inc	esi
		.endif
	.endw
	pop	eax
	pop	edx
	.endif
	ret
