whex	PROC
	xor	ecx,ecx
	.while ecx<8
		rol	eax,4
		push	eax
		and	al,0fh
		or	al,30h
		.if al>39h
			add	al,7
		.endif
		stosb
		pop	eax
		inc	ecx
	.endw
	ret
whex	ENDP

w2:	.if w2num==0
w2a:		.if eax>99
			push	ebx
			push	edx
			call	itoa
			pop	edx
			pop	ebx
		.elseif al>9
			mov	cl,10
			mov	ah,0
			div	cl
			or	ax,3030h
			stosw
		.else
			mov	byte ptr[edi],30h
			inc	edi
			or	al,30h
			stosb
		.endif
		ret
	.elseif w2num==1
		jmp	w3
	.elseif w2num==2
		jmp	w4
	.else
		jmp	w5
	.endif

w3:	push	edx
	push	ecx
	.if eax>999
		push	ebx
		call	itoa
		pop	ebx
	.else
		mov	ecx,100
		xor	edx,edx
		div	ecx
		.if al>9
			mov	al,9
		.endif
		or	al,30h
		stosb
		mov	eax,edx
		mov	cl,10
		xor	edx,edx
		div	cl
		or	al,30h
		stosb
		mov	al,ah
		or	al,30h
		stosb
	.endif
	pop	ecx
	pop	edx
	ret

w4	PROC
	push	edx
	.if ax>9999
		push	ebx
		call	itoa
		pop	ebx
		pop	edx
		ret
	.endif
	.if ax>=1000
		xor	dx,dx
		mov	cx,1000
		div	cx
		or	al,30h
		stosb
		mov	ax,dx
	.else
		mov	byte ptr[edi],30h
		inc	edi
	.endif
	.if al>=100
		mov	cl,100
		mov	ah,0
		div	cl
		or	al,30h
		stosb
		mov	al,ah
	.else
		mov	byte ptr[edi],30h
		inc	edi
	.endif
	pop	edx
	jmp	w2a
w4	ENDP

w5	PROC
	push	edx
	.if ax>=10000
		xor	dx,dx
		mov	cx,10000
		div	cx
		or	al,30h
		stosb
		mov	ax,dx
	.else
		mov	byte ptr[edi],30h
		inc	edi
	.endif
	.if ax>=1000
		xor	dx,dx
		mov	cx,1000
		div	cx
		or	al,30h
		stosb
		mov	ax,dx
	.else
		mov	byte ptr[edi],30h
		inc	edi
	.endif
	.if ax>=100
		mov	cx,100
		xor	dx,dx
		div	cx
		or	al,30h
		stosb
		mov	ax,dx
	.else
		mov	byte ptr[edi],30h
		inc	edi
	.endif
	pop	edx
	jmp	w2a
w5	ENDP

copyedx:.while byte ptr[edx]
		mov	al,[edx]
		stosb
		inc	edx
	.endw
	ret
itoa:	push	ecx
	push	edx
	mov	ecx,10
	xor	edx,edx
	div	ecx
	.if eax
		call	itoa
	.endif
	or	dl,30h
	mov	al,dl
	stosb
	pop	edx
	pop	ecx
	ret

atoi:	xor	eax,eax
	xor	ebx,ebx
	push	edx
getdec0:mov	bl,[esi]
	sub	bl,'0'
	cmp	bl,10
	jnc	_getdec
	inc	esi
	push	ebx
	xor	edx,edx
	mov	bl,10
	mul	ebx
	pop	ebx
	add	eax,ebx
	jmp	getdec0
_getdec:pop	edx
	ret

w_ip:	push	ebx
	push	ecx
	push	edx

	push	eax
	movzx	eax,al
	call	itoa
	mov	al,'.'
	stosb
	pop	eax
	push	eax
	shr	eax,8
	movzx	eax,al
	call	itoa
	mov	al,'.'
	stosb
	pop	eax
	push	eax
	shr	eax,16
	movzx	eax,al
	call	itoa
	mov	al,'.'
	stosb
	pop	eax
	push	eax
	shr	eax,24
	movzx	eax,al
	call	itoa
	pop	eax

	pop	edx
	pop	ecx
	pop	ebx
	ret

is_ip	PROC	public
	push	ebx
	push	esi
	xor	eax,eax
	xor	ecx,ecx
	mov	esi,ebx
	.if (byte ptr[esi]<'0')||(byte ptr[esi]>'9')
		pop	esi
		pop	ebx
		xor	eax,eax
		ret
	.endif
	call	atoi
	.if eax>255
		pop	esi
		pop	ebx
		xor	eax,eax
		ret
	.endif
	mov	cl,al
	.if (byte ptr[esi]!='.')&&(byte ptr[esi]!=' ')
		pop	esi
		pop	ebx
		xor	eax,eax
		ret
	.endif
	inc	esi
	.if (byte ptr[esi]<'0')||(byte ptr[esi]>'9')
		pop	esi
		pop	ebx
		xor	eax,eax
		ret
	.endif
	call	atoi
	.if eax>255
		pop	esi
		pop	ebx
		xor	eax,eax
		ret
	.endif
	mov	ch,al
	.if (byte ptr[esi]!='.')&&(byte ptr[esi]!=' ')
		pop	esi
		pop	ebx
		xor	eax,eax
		ret
	.endif
	inc	esi
	.if (byte ptr[esi]<'0')||(byte ptr[esi]>'9')
		pop	esi
		pop	ebx
		xor	eax,eax
		ret
	.endif
	call	atoi
	.if eax>255
		pop	esi
		pop	ebx
		xor	eax,eax
		ret
	.endif
	shl	eax,16
	or	ecx,eax
	.if (byte ptr[esi]!='.')&&(byte ptr[esi]!=' ')
		pop	esi
		pop	ebx
		xor	eax,eax
		ret
	.endif
	inc	esi
	.if (byte ptr[esi]<'0')||(byte ptr[esi]>'9')
		pop	esi
		pop	ebx
		xor	eax,eax
		ret
	.endif
	call	atoi
	.if eax>255
		pop	esi
		pop	ebx
		xor	eax,eax
		ret
	.endif
	shl	eax,16+8
	or	ecx,eax
	xor	eax,eax
	inc	eax
	pop	esi
	pop	ebx
	ret
is_ip	ENDP


sub20:	mov	ecx,3
	.while ecx>0
		.if al>20h
			sub	al,20h
		.else
			mov	al,0
		.endif
		ror	eax,8
		dec	ecx
	.endw
	ror	eax,8
wcolor:	push	eax
	xchg	al,ah
	rol	eax,16
	xchg	al,ah
	mov	ecx,6
	.while ecx>0
		rol	eax,4
		push	eax
		and	al,0fh
		or	al,30h
		.if al>'9'
			add	al,7
		.endif
		stosb
		pop	eax
		dec	ecx
	.endw
	pop	eax
	ret

getrng:	xor	ecx,ecx
	.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
		inc	esi
	.endw
	xor	ebx,ebx
	dec	ebx
	xor	edx,edx
	.if (byte ptr[esi]<='9')&&(byte ptr[esi]>='0')
		push	ebx
		push	edx
		call	atoi
		pop	edx
		pop	ebx
		.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
			inc	esi
		.endw
		mov	bl,al
		mov	dl,al
		.if byte ptr[esi]=='.'
			inc	esi
		.endif
		.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
			inc	esi
		.endw
		.if (byte ptr[esi]<='9')&&(byte ptr[esi]>='0')
			push	ebx
			push	edx
			call	atoi
			pop	edx
			pop	ebx
			.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
				inc	esi
			.endw
			mov	bh,al
			mov	dh,al
			.if byte ptr[esi]=='.'
				inc	esi
			.endif
			.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
				inc	esi
			.endw
			.if (byte ptr[esi]<='9')&&(byte ptr[esi]>='0')
				push	ebx
				push	edx
				call	atoi
				pop	edx
				pop	ebx
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endw
				rol	ebx,16
				rol	edx,16
				mov	bl,al
				mov	dl,al
				rol	ebx,16
				rol	edx,16
				.if byte ptr[esi]=='.'
					inc	esi
				.endif
				.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
					inc	esi
				.endw
				.if (byte ptr[esi]<='9')&&(byte ptr[esi]>='0')
					push	ebx
					push	edx
					call	atoi
					pop	edx
					pop	ebx
					rol	ebx,16
					rol	edx,16
					mov	bh,al
					mov	dh,al
					rol	ebx,16
					rol	edx,16
				.endif
			.endif
		.endif
	.endif
	mov	eax,edx
	ret
;esi=src
;eax=start, ebx=end
getrange:
	.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
		inc	esi
	.endw
	call	getrng
;	dec	esi
	.while (byte ptr[esi]==32)||(byte ptr[esi]==9)||(byte ptr[esi]=='*')
		inc	esi
	.endw
	.while byte ptr[esi]=='-'
		inc	esi
		.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
			inc	esi
		.endw
		push	eax
		push	ebx
		call	getrng
		pop	ecx
		pop	edx
		.if eax>ebx
			xchg	eax,ebx
		.endif
		.if eax>ecx
			xchg	eax,ecx
		.endif
		.if eax>edx
			xchg	eax,edx
		.endif
		.if ebx<ecx
			xchg	ebx,ecx
		.endif
		.if ebx<edx
			xchg	ebx,edx
		.endif
		.while (byte ptr[esi]==32)||(byte ptr[esi]==9)
			inc	esi
		.endw
	.endw
	ret


trtbl1	db	'AAAAAAECEEEEIIII'
	db	'DNOOOOOxOUUUUYpB'
	db	'aaaaaaeceeeeiiii'
	db	'dnooooo-ouuuuypy'
rustbl	db	'A B V G D E ZHZ I J K L M N O P '
	db	'R S T U F H TZCHSHSH',39,' YI',39,' YEYUYA'
	db	'a b v g d e zhz i j k l m n o p '
	db	'r s t u f h tzchshsh',39,' yi',39,' yeyuya'

escfile:idx_title
	mov	ah,0
	.while (word ptr[esi]!='/<')&&(ecx!=0)&&(byte ptr[esi]!=0)
		lodsb
		.break .if al=='>'
		call	esc_chr
	.endw
	ret

esc_chr:movzx	eax,al
	call	get_utf
	.if eax>0ffh
		jmp	testutf
	.endif
	.if al=='&'
		mov	eax,[esi]
		or	eax,20202020h
		.if ((eax=='touq')||(eax=='sopa'))&&(byte ptr[esi+4]==';')
			mov	al,39
			mov	ah,al
			stosb
			lea	esi,[esi+5]
		.elseif (eax=='psbn')&&(byte ptr[esi+4]==';')
			mov	al,32
			.if ah!=32
				stosb
			.endif
			mov	ah,al
			lea	esi,[esi+5]
		.elseif eax==';pma'
			mov	al,'&'
			mov	ah,al
			stosb
			lea	esi,[esi+4]
		.elseif ((ax=='tl')||(ax=='tg'))&&(byte ptr[esi+2]==';')
			mov	al,32
			.if ah!=32
				stosb
			.endif
			mov	ah,32
			lea	esi,[esi+3]
		.elseif byte ptr[esi]=='#'
			inc	esi
			push	edx
			call	atoi
			pop	edx
			.if byte ptr[esi]==';'
				inc	esi
			.endif
testutf:		.if (eax<256)&&(al>32)&&(al!='<')&&(al!='>')&&(al!='*')&&(al!='?')&&(al!='/')&&(al!='\')&&(al!='|')&&(al!='"')&&(al!=':')
				mov	dl,al
				stosb
				dec	ecx
			.elseif eax>255
				push	ecx
				push	edx
				movzx	eax,ax
				push	eax
				mov	edx,esp
				mov	ecx,edi
				invoke	WideCharToMultiByte,CP_ACP,0,edx,1,edi,6,0,0
				pop	edx
				pop	edx
				pop	ecx
				.while (eax!=0)&&(ecx!=0)&&(byte ptr[edi]!=0)
					.if (byte ptr[edi]=='<')||(byte ptr[edi]=='>')||(byte ptr[edi]=='*')||(byte ptr[edi]=='?')||(byte ptr[edi]=='/')||(byte ptr[edi]=='\')||(byte ptr[edi]=='|')
						mov	byte ptr[edi],'_'
					.elseif (byte ptr[edi]==34)||(byte ptr[edi]==':')
						mov	byte ptr[edi],'_'
					.endif
					inc	edi
					dec	ecx
					dec	eax
				.endw
			.elseif al>7fh
				mov	ah,al
				.if translit&1
					.if (al>0c0h)
						sub	al,0c0h
						movzx	eax,al
						mov	ax,word ptr rustbl[eax*2]
						.if ah!=32
							stosb
							.if ecx>1
								dec	ecx
							.endif
							mov	al,ah
							.if al<='Z'
								.if (byte ptr[esi]>0e0h)||(byte ptr[esi]==0b8h)
									or	al,20h
								.endif
							.endif
						.endif
					.endif
					stosb
				.elseif (pflag&128)&&(al>127)
					.if al>(128+64)
						sub	al,128+64
						push	ebx
						lea	ebx,trtbl1
						xlat
						pop	ebx
					.else
						mov	al,'_'
					.endif
					stosb
				.else
					stosb
				.endif
				dec	ecx
			.else
				mov	al,'_'
				stosb
				dec	ecx
			.endif
		.else
			mov	al,'&'
			stosb
			dec	ecx
		.endif
		mov	ah,al
	.elseif al=='<'
		.while (byte ptr[esi]!=0)&&(byte ptr[esi]!='>')
			inc	esi
		.endw
		.if byte ptr[esi]
			inc	esi
		.endif
	.elseif al=='>'
	.elseif al<=32
		mov	al,32
		.if ah!=32
			stosb
		.endif
		mov	ah,32
	.elseif (al=='*')||(al=='?')||(al==':')||(al==34)
		mov	al,'_'
		mov	ah,al
		stosb
		dec	ecx
	.elseif (al=='/')||(al=='\')||(al=='|')
		mov	al,'-'
		mov	ah,al
		stosb
		dec	ecx
	.else
		mov	ah,al
		.if (translit&1)
			.if (al>0c0h)
				sub	al,0c0h
				movzx	eax,al
				mov	ax,word ptr rustbl[eax*2]
				.if ah!=32
					stosb
					.if ecx>1
						dec	ecx
					.endif
					mov	al,ah
					.if al<='Z'
						.if (byte ptr[esi]>0e0h)||(byte ptr[esi]==0b8h)
							or	al,20h
						.endif
					.endif
				.endif
			.endif
			stosb
		.elseif (pflag&128)&&(al>127)
			.if al>(128+64)
				sub	al,128+64
				push	ebx
				lea	ebx,trtbl1
				xlat
				pop	ebx
			.else
				mov	al,'_'
			.endif
			stosb
		.else
			stosb
		.endif
		mov	ah,al
		dec	ecx
	.endif
	ret

get_utf:.if al<80h
		ret
	.endif
	push	eax
	mov	ah,[esi]
	and	ax,1100000011100000b
	.if ax==1000000011000000b
		and	ax,0011111100011111b
		xchg	al,ah
		shl	al,2
		shr	ax,2
		inc	esi
		add	esp,4
		ret
	.endif
	mov	ax,[esi]
	shl	eax,8
	mov	al,[esp]
	and	eax,110000001100000011110000b
	.if eax==100000001000000011100000b
		and	eax,110000001100000011110000b xor -1
		inc	esi
		inc	esi
		xchg	al,ah
		rol	eax,16
		xchg	al,ah
		ror	eax,8
		shl	al,2
		shl	ax,2
		shr	eax,4
		add	esp,4
		ret
	.endif
	mov	eax,[esi]
	shl	eax,8
	mov	al,[esp]
	and	eax,11000000110000001100000011111000b
	.if eax==10000000100000001000000011110000b
		and	eax,00111111001111110011111100000111b
		xchg	al,ah
		rol	eax,16
		xchg	al,ah
		rol	eax,16
		shl	al,2
		shr	ax,2
		rol	eax,16
		shl	al,2
		shl	ax,2
		shr	eax,4
		add	esi,3
		add	esp,4
		ret
	.endif
	pop	eax
	ret


escfile1:
	push	edi
	lea	edi,buftmp
	push	esi
	push	edi
	mov	ah,0
	.while (word ptr[esi]!='/<')&&(ecx!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)
		lodsb
		call	esc_chr
	.endw
	mov	edx,ecx
	pop	ecx
	pop	eax
	.if edx==0
		.while (word ptr[esi]!='/<')&&(ecx!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)
			inc	esi
		.endw
		.while (esi>eax)
			.break .if byte ptr[esi]=='.'
			dec	esi
		.endw
		mov	eax,edi
		.while (edi>ecx)&&(byte ptr[edi]!='\')&&(byte ptr[edi]!='.')
			dec	edi
		.endw
		.if (byte ptr[edi]=='\')||(edi==ecx)
			mov	edi,eax
		.endif
		mov	ah,0
		.while (word ptr[esi]!='/<')&&(ecx!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)
			lodsb
			call	esc_chr
		.endw
	.endif
	mov	al,0
	stosb
	pop	edi
	push	edx
	lea	edx,buftmp
	call	copyedx
	pop	edx
	ret

escdir:	push	esi
	push	edi
	lea	esi,defdir
	.while byte ptr[esi]
		inc	esi
	.endw
	.while (byte ptr[esi]!='\')&&(esi!=offset defdir)
		dec	esi
	.endw
	.if byte ptr[esi]=='\'
		inc	esi
	.endif
	push	esi
	lea	edi,buftmp
	mov	dl,0
	mov	ecx,maxfile
	mov	ah,0
	.while (byte ptr[esi]!=0)	;&&(ecx!=0)
		lodsb
		call	esc_chr
	.endw
	mov	al,0
	stosb
	.while edi!=offset buftmp
		dec	edi
		.break .if (byte ptr[edi]!='.')&&(byte ptr[edi]!=' ')
	.endw
	.if edi!=offset buftmp
		inc	edi
		mov	al,0
		stosb
	.endif
	lea	edx,buftmp
	pop	edi
	call	copyedx
	mov	al,0
	stosb
	pop	edi
	pop	esi
	ret

_scan:	push	esi
	push	edx
	mov	edx,esi
	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
		.if (byte ptr[esi]=='/')&&((byte ptr[esi+1]>='a')&&(byte ptr[esi+1]<='z'))||((byte ptr[esi+1]>='A')&&(byte ptr[esi+1]<='Z'))
			mov	edx,esi
		.endif
		inc	esi
	.endw
	mov	esi,edx
	pop	edx
	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
		xor	ecx,ecx
		.while byte ptr[edx+ecx]
			mov	al,[esi+ecx]
			mov	ah,[edx+ecx]
			or	ax,2020h
			.break .if al!=ah
			inc	ecx
		.endw
		.if byte ptr[edx+ecx]==0
			pop	esi
			mov	al,[edx+ecx+1]
			ret
		.endif
		inc	esi
	.endw
	xor	eax,eax
	pop	esi
	ret

_seek:	push	ecx
	push	ebx
	push	0
	.while (byte ptr[esi]!=0)
		xor	ecx,ecx
		xor	ebx,ebx
		.while byte ptr[edx+ebx]
			mov	al,[esi+ecx]
			mov	ah,[edx+ebx]
			.if (ah=='?')&&(al!=0)
			.else
				.if ah=='*'
					lea	edx,[edx+ebx+1]
					xor	ebx,ebx
					.continue
				.elseif ah=='#'
					.break .if (al<'0')||(al>'9')
					.while (byte ptr[esi+ecx]<='9')&&(byte ptr[esi+ecx]>='0')
						inc	ecx
					.endw
					dec	ecx
				.elseif ah=='@'
					.if ((al>='0')&&(al<='9'))||((al<='a')&&(al>='f'))||((al<='A')&&(al>='F'))
						.while ((byte ptr[esi+ecx]<='9')&&(byte ptr[esi+ecx]>='0'))||((byte ptr[esi+ecx]>='a')&&(byte ptr[esi+ecx]<='f'))||((byte ptr[esi+ecx]>='A')&&(byte ptr[esi+ecx]<='F'))
							inc	ecx
						.endw
						dec	ecx
					.else
						.break
					.endif
				.elseif ah=='|'
					.break .if (al!=34)&&(al!=39)
					lea	eax,[esi+ecx]
					mov	dword ptr[esp],eax
				.elseif ah=='$'
					.if al=='&'
						push	ecx
						inc	ecx
						mov	eax,[esi+ecx]
						or	eax,202020h
						.if eax==';pma'
							lea	ecx,[ecx+4]
						.endif
						.if ((byte ptr[esi+ecx]>='a')&&(byte ptr[esi+ecx]<='z'))||((byte ptr[esi+ecx]>='A')&&(byte ptr[esi+ecx]<='Z'))
							.while ((byte ptr[esi+ecx]>='a')&&(byte ptr[esi+ecx]<='z'))||((byte ptr[esi+ecx]>='A')&&(byte ptr[esi+ecx]<='Z'))
								inc	ecx
							.endw
							.if byte ptr[esi+ecx]=='='
								inc	ecx
								push	edx
								xor	edx,edx
								.if ((byte ptr[esi+ecx]<='9')&&(byte ptr[esi+ecx]>='0'))||((byte ptr[esi+ecx]>='a')&&(byte ptr[esi+ecx]<='f'))||((byte ptr[esi+ecx]>='A')&&(byte ptr[esi+ecx]<='F'))
									.while ((byte ptr[esi+ecx]<='9')&&(byte ptr[esi+ecx]>='0'))||((byte ptr[esi+ecx]>='a')&&(byte ptr[esi+ecx]<='f'))||((byte ptr[esi+ecx]>='A')&&(byte ptr[esi+ecx]<='F'))
										inc	ecx
										inc	edx
									.endw
									.if edx>15
										mov	[esp+4],ecx
									.endif
								.endif
								pop	edx
							.endif
						.endif
						pop	ecx
					.else
						push	ecx
						.if ((byte ptr[esi+ecx]>='a')&&(byte ptr[esi+ecx]<='z'))||((byte ptr[esi+ecx]>='A')&&(byte ptr[esi+ecx]<='Z'))
							.while ((byte ptr[esi+ecx]>='a')&&(byte ptr[esi+ecx]<='z'))||((byte ptr[esi+ecx]>='A')&&(byte ptr[esi+ecx]<='Z'))
								inc	ecx
							.endw
							.if byte ptr[esi+ecx]=='='
								inc	ecx
								.if ((byte ptr[esi+ecx]<='9')&&(byte ptr[esi+ecx]>='0'))||((byte ptr[esi+ecx]>='a')&&(byte ptr[esi+ecx]<='f'))||((byte ptr[esi+ecx]>='A')&&(byte ptr[esi+ecx]<='F'))
									push	edx
									xor	edx,edx
									.while ((byte ptr[esi+ecx]<='9')&&(byte ptr[esi+ecx]>='0'))||((byte ptr[esi+ecx]>='a')&&(byte ptr[esi+ecx]<='f'))||((byte ptr[esi+ecx]>='A')&&(byte ptr[esi+ecx]<='F'))
										inc	ecx
										inc	edx
									.endw
									mov	eax,edx
									pop	edx
									.if eax>15
										.if byte ptr[esi+ecx]=='&'
											inc	ecx
											mov	eax,[esi+ecx]
											or	eax,202020h
											.if eax==';pma'
												lea	ecx,[ecx+4]
											.endif
										.endif
										mov	[esp],ecx
									.endif
								.endif
							.endif
						.endif
						pop	ecx
					.endif
					dec	ecx
				.else
					or	ax,2020h
					.break .if al!=ah
				.endif
			.endif
			inc	ebx
			inc	ecx
		.endw
		.if byte ptr[edx+ebx]==0
			pop	eax
			.if eax
				mov	esi,eax
			.else
				lea	esi,[esi+ecx]
			.endif
			mov	al,1
			pop	ebx
			pop	ecx
			ret
		.endif
		inc	esi
	.endw
	pop	eax
	pop	ebx
	pop	ecx
	xor	eax,eax
	ret

sidcmp:	push	ebx
	.while edx
		lea	edi,[edx+4]
		xor	ebx,ebx
		xor	ecx,ecx
		mov	eax,[esi]
		or	eax,20202020h
		.if eax=='ptth'
			mov	eax,[edi]
			or	eax,20202020h
			.if eax=='ptth'
				jmp	s_http
			.endif
			.if byte ptr[edi]=='/'
				lea	ebx,[ebx+4]
				.if byte ptr[esi+ebx]==':'
					inc	ebx
				.endif
				.if byte ptr[esi+ebx]=='/'
					inc	ebx
				.endif
				.if byte ptr[esi+ebx]=='/'
					inc	ebx
				.endif
				.while byte ptr[esi+ebx]!='/'
					inc	ebx
				.endw
				jmp	s_http
			.else
				.while byte ptr[esi+ebx]
					.if byte ptr[esi+ebx]=='/'
						lea	ecx,[ebx+1]
					.endif
					inc	ebx
				.endw
				mov	ebx,ecx
				xor	ecx,ecx
				jmp	s_http
			.endif
		.endif
		mov	eax,[edi]
		or	eax,20202020h
		.if eax=='ptth'
			.if byte ptr[esi]=='/'
				lea	ecx,[ecx+4]
				.if byte ptr[edi+ecx]==':'
					inc	ecx
				.endif
				.if byte ptr[edi+ecx]=='/'
					inc	ecx
				.endif
				.if byte ptr[edi+ecx]=='/'
					inc	ecx
				.endif
				.while byte ptr[edi+ecx]!='/'
					inc	ecx
				.endw
				jmp	s_http
			.else
				.while byte ptr[edi+ecx]
					.if byte ptr[edi+ecx]=='/'
						lea	ebx,[ecx+1]
					.endif
					inc	ecx
				.endw
				mov	ecx,ebx
				xor	ebx,ebx
				jmp	s_http
			.endif
		.elseif (byte ptr[edi]=='/')&&(byte ptr[esi]!='/')
			.while byte ptr[edi+ecx]
				.if byte ptr[edi+ecx]=='/'
					lea	ebx,[ecx+1]
				.endif
				inc	ecx
			.endw
			mov	ecx,ebx
			xor	ebx,ebx
		.elseif (byte ptr[edi]!='/')&&(byte ptr[esi]=='/')
			.while (byte ptr[esi+ebx]!=0)&&(byte ptr[esi+ebx]!=34)&&(byte ptr[esi+ebx]!=39)
				.if byte ptr[esi+ebx]=='/'
					lea	ecx,[ebx+1]
				.endif
				inc	ebx
			.endw
			mov	ebx,ecx
			xor	ecx,ecx
		.endif
s_http:		.while byte ptr[edi+ecx]
esi_scan:		mov	eax,[esi+ebx]
			or	eax,20202020h
			.if eax=='=dis'
				.while (byte ptr[esi+ebx]!=0)&&(byte ptr[esi+ebx]!=34)&&(byte ptr[esi+ebx]!=39)&&(byte ptr[esi+ebx]!=62)&&(byte ptr[esi+ebx]!='&')
					inc	ebx
				.endw
			.elseif eax=='sphp'
				mov	eax,[esi+ebx+4]
				or	eax,20202020h
				.if eax=='isse'
					.while (byte ptr[esi+ebx]!=0)&&(byte ptr[esi+ebx]!=34)&&(byte ptr[esi+ebx]!=39)&&(byte ptr[esi+ebx]!=62)&&(byte ptr[esi+ebx]!='&')
						inc	ebx
					.endw
				.endif
			.elseif ax=='=s'
				lea	eax,[ebx+2]
				.while ((byte ptr[esi+eax]>='0')&&(byte ptr[esi+eax]<='9'))||((byte ptr[esi+eax]>='a')&&(byte ptr[esi+eax]<='f'))||((byte ptr[esi+eax]>='A')&&(byte ptr[esi+eax]<='F'))
					inc	eax
				.endw
				.if eax>8
					.while (byte ptr[esi+ebx]!=0)&&(byte ptr[esi+ebx]!=34)&&(byte ptr[esi+ebx]!=39)&&(byte ptr[esi+ebx]!=62)&&(byte ptr[esi+ebx]!='&')
						inc	ebx
					.endw
				.endif
			.endif
			.if byte ptr[esi+ebx]=='&'
				.while byte ptr[esi+ebx]=='&'
					inc	ebx
					mov	eax,[esi+ebx]
					or	eax,202020h
					.if eax==';pma'
						lea	ebx,[ebx+4]
					.endif
				.endw
				jmp	esi_scan
			.endif

edi_scan:		mov	eax,[edi+ecx]
			or	eax,20202020h
			.if eax=='=dis'
				.while (byte ptr[edi+ecx]!=0)&&(byte ptr[edi+ecx]!=34)&&(byte ptr[edi+ecx]!=39)&&(byte ptr[edi+ecx]!=62)&&(byte ptr[edi+ecx]!='&')
					inc	ecx
				.endw
			.elseif eax=='sphp'
				mov	eax,[edi+ecx+4]
				or	eax,20202020h
				.if eax=='isse'
					.while (byte ptr[edi+ecx]!=0)&&(byte ptr[edi+ecx]!=34)&&(byte ptr[edi+ecx]!=39)&&(byte ptr[edi+ecx]!=62)&&(byte ptr[edi+ecx]!='&')
						inc	ecx
					.endw
				.endif
			.elseif ax=='=s'
				lea	eax,[ecx+2]
				.while ((byte ptr[edi+eax]>='0')&&(byte ptr[edi+eax]<='9'))||((byte ptr[edi+eax]>='a')&&(byte ptr[edi+eax]<='f'))||((byte ptr[edi+eax]>='A')&&(byte ptr[edi+eax]<='F'))
					inc	eax
				.endw
				.if eax>8
					.while (byte ptr[edi+ecx]!=0)&&(byte ptr[edi+ecx]!=34)&&(byte ptr[edi+ecx]!=39)&&(byte ptr[edi+ecx]!=62)&&(byte ptr[edi+ecx]!='&')
						inc	ecx
					.endw
				.endif
			.endif
			.if byte ptr[edi+ecx]=='&'
				.while byte ptr[edi+ecx]=='&'
					inc	ecx
					mov	eax,[edi+ecx]
					or	eax,202020h
					.if eax==';pma'
						lea	ecx,[ecx+4]
					.endif
				.endw
				jmp	edi_scan
			.endif

			mov	al,[esi+ebx]
			mov	ah,[edi+ecx]
			or	ax,2020h
			.break .if al!=ah
			inc	ecx
			inc	ebx
		.endw
		.if ((byte ptr[edi+ecx]==0)||(byte ptr[edi+ecx]==34)||(byte ptr[edi+ecx]==39))&&((byte ptr[esi+ebx]==0)||(byte ptr[esi+ebx]==34)||(byte ptr[esi+ebx]==39))
		;	xor	edx,edx
			.while (byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=0)
				inc	esi
			.endw
			pop	ebx
			ret
		.endif
		mov	edx,[edx]
	.endw
	pop	ebx
	ret

phpset:	.if (fflag&16)&&(flink5!=0)
		push	ebx
		lea	ebx,flink5
		assume	edi:ptr foruminfo
		lea	edx,[edi]._addr
		.while (byte ptr[edx]!=0)&&(byte ptr[edx]!='?')
			inc	edx
		.endw
		.if byte ptr[edx]=='?'
			inc	edx
			.while byte ptr[edx]
				.if byte ptr[edx]=='&'
					inc	edx
				.else
					xor	ecx,ecx
					.while (byte ptr[ebx+ecx]!=0)&&(byte ptr[ebx+ecx]!='&')&&(byte ptr[ebx+ecx]!='=')
						mov	al,[ebx+ecx]
						mov	ah,[edx+ecx]
						or	ax,2020h
						.break .if al!=ah
						inc	ecx
					.endw
					.if (byte ptr[ebx+ecx]==0)||(byte ptr[ebx+ecx]=='&')||(byte ptr[ebx+ecx]=='=')
						push	esi
						push	edi
						mov	edi,edx
						.while (byte ptr[edx]!='&')&&(byte ptr[edx]!=0)
							inc	edx
						.endw
						.if byte ptr[edx]=='&'
							inc	edx
						.endif
						mov	esi,edx
						.while byte ptr[esi]
							movsb
						.endw
						mov	edx,edi
						movsb
						pop	edi
						pop	esi
						.break
					.else
						.while (byte ptr[edx]!='&')&&(byte ptr[edx]!=0)
							inc	edx
						.endw
					.endif
				.endif
			.endw
		.else
			mov	ax,'?'
			mov	word ptr[edx],ax
			inc	edx
		.endif
		push	edi
		.if byte ptr[edx]!=0
			int 3
		.endif
		.if byte ptr[edx-1]=='&'
			dec	edx
		.endif
		.if byte ptr[edx-1]!='?'
			mov	word ptr[edx],'&'
			inc	edx
		.endif
		mov	edi,edx
		lea	edx,flink5
		.if byte ptr[edx]=='&'
			inc	edx
		.endif
		.while byte ptr[edx]
			mov	al,[edx]
			stosb
			inc	edx
		.endw
		mov	al,0
		stosb
		pop	edi
		assume	edi:nothing
		pop	ebx
	.endif
	ret

s_err0	db	'Error, code: ',0
s_err1	db	'WSANOTINITIALISED - A successful WSAStartup must occur before using this function.',0
s_err2	db	'WSAENETDOWN - The network subsystem has failed.',0
s_err3	db	'WSAEADDRINUSE - The specified address is already in use.',0
s_err4	db	'WSAEINTR - The (blocking) call was canceled through WSACancelBlockingCall.',0
s_err5	db	'WSAEINPROGRESS - A blocking Windows Sockets 1.1 call is in progress, or the service provider is still processing a callback function.',0
s_err6	db	'WSAEALREADY - A nonblocking connect call is in progress on the specified socket. Note: In order to preserve backward compatibility, this error is reported as WSAEINVAL to Windows Sockets 1.1 applications that link to either WINSOCK.DLL or WSOCK32.DLL.',0
s_err7	db	'WSAEADDRNOTAVAIL - The specified address is not available from the local machine.',0
s_err8	db	'WSAEAFNOSUPPORT - Addresses in the specified family cannot be used with this socket.',0
s_err9	db	'Connection refused by target machine.',0
s_err10	db	'WSAEFAULT - The name or the namelen argument is not a valid part of the user address space, the namelen argument is too small, or the name argument contains incorrect address format for the associated address family.',0
s_err11	db	'WSAEINVAL - The parameter s is a listening socket, or the destination address specified is not consistent with that of the constrained group the socket belongs to.',0
s_err12	db	'WSAEISCONN - The socket is already connected.',0
s_err13	db	'WSAENETUNREACH - The network cannot be reached from this host at this time.',0
s_err14	db	'WSAENOBUFS - No buffer space is available. The socket cannot be connected.',0
s_err15	db	'WSAENOTSOCK - The descriptor is not a socket.',0
s_err16	db	'Connection timeout.',0
s_err17	db	'WSAEWOULDBLOCK - The socket is marked as nonblocking and the connection cannot be completed immediately.',0
s_err18	db	'WSAEACCES - Attempt to connect datagram socket to broadcast address failed because setsockopt SO_BROADCAST is not enabled.',0
s_err19	db	'WSAENETRESET - The connection has been broken due to the remote host resetting.',0
s_err20	db	'WSAENOTCONN - The socket is not connected.',0
s_err21	db	'WSAEOPNOTSUPP - MSG_OOB was specified, but the socket is not stream style such as type SOCK_STREAM, out-of-band data is not supported '
	db	'in the communication domain associated with this socket, or the socket is unidirectional and supports only receive operations.',0
s_err22	db	'WSAESHUTDOWN - The socket has been shut down; it is not possible to send on a socket after shutdown has been invoked with how set to SD_SEND or SD_BOTH.',0
s_err23	db	'WSAEMSGSIZE - The socket is message oriented, and the message is larger than the maximum supported by the underlying transport.',0
s_err24	db	'WSAEHOSTUNREACH - The remote host cannot be reached from this host at this time.',0
s_err25	db	'WSAECONNABORTED - The virtual circuit was terminated due to a time-out or other failure. The application should close the socket as it is no longer usable.',0
s_err26	db	'Connection reset by server.',0
s_err27	db	'WSAHOST_NOT_FOUND - Authoritative Answer Host not found.',0
s_err28	db	'WSATRY_AGAIN - Non-Authoritative Host not found, or server failure.',0
s_err29	db	'WSANO_RECOVERY - Nonrecoverable error occurred.',0
s_err30	db	'WSANO_DATA - Valid name, no data record of requested type.',0
s_err31	db	'WSAHOST_NOT_FOUND - No such host is known.',0

wsaerr:
	invoke	WSAGetLastError
wserr:	push	eax
	.if eax==WSANOTINITIALISED
		mov	ax,'( '
		stosw
		lea	edx,s_err1
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAENETDOWN
		mov	ax,'( '
		stosw
		lea	edx,s_err2
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAEADDRINUSE
		mov	ax,'( '
		stosw
		lea	edx,s_err3
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAEINTR
		mov	ax,'( '
		stosw
		lea	edx,s_err4
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAEINPROGRESS
		mov	ax,'( '
		stosw
		lea	edx,s_err5
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAEALREADY
		mov	ax,'( '
		stosw
		lea	edx,s_err6
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAEADDRNOTAVAIL
		mov	ax,'( '
		stosw
		lea	edx,s_err7
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAEAFNOSUPPORT
		mov	ax,'( '
		stosw
		lea	edx,s_err8
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAECONNREFUSED
		mov	ax,'( '
		stosw
		lea	edx,s_err9
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAEFAULT
		mov	ax,'( '
		stosw
		lea	edx,s_err10
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAEINVAL
		mov	ax,'( '
		stosw
		lea	edx,s_err11
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAEISCONN
		mov	ax,'( '
		stosw
		lea	edx,s_err12
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAENETUNREACH
		mov	ax,'( '
		stosw
		lea	edx,s_err13
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAENOBUFS
		mov	ax,'( '
		stosw
		lea	edx,s_err14
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAENOTSOCK
		mov	ax,'( '
		stosw
		lea	edx,s_err15
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAETIMEDOUT
		mov	ax,'( '
		stosw
		lea	edx,s_err16
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAEWOULDBLOCK
		mov	ax,'( '
		stosw
		lea	edx,s_err17
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAEACCES
		mov	ax,'( '
		stosw
		lea	edx,s_err18
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAENETRESET
		mov	ax,'( '
		stosw
		lea	edx,s_err19
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAENOTCONN
		mov	ax,'( '
		stosw
		lea	edx,s_err20
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAEOPNOTSUPP
		mov	ax,'( '
		stosw
		lea	edx,s_err21
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAESHUTDOWN
		mov	ax,'( '
		stosw
		lea	edx,s_err22
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAEMSGSIZE
		mov	ax,'( '
		stosw
		lea	edx,s_err23
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAEHOSTUNREACH
		mov	ax,'( '
		stosw
		lea	edx,s_err24
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAECONNABORTED
		mov	ax,'( '
		stosw
		lea	edx,s_err25
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAECONNRESET
		mov	ax,'( '
		stosw
		lea	edx,s_err26
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSAHOST_NOT_FOUND
		mov	ax,'( '
		stosw
		lea	edx,s_err27
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSATRY_AGAIN
		mov	ax,'( '
		stosw
		lea	edx,s_err28
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSANO_RECOVERY
		mov	ax,'( '
		stosw
		lea	edx,s_err29
		call	copyedx
		mov	al,')'
		stosb
	.elseif eax==WSANO_DATA
		mov	ax,'( '
		stosw
		lea	edx,s_err30
		call	copyedx
		mov	al,')'
		stosb
	.elseif (eax==WSAHOST_NOT_FOUND)||(eax==11001)
		mov	ax,'( '
		stosw
		lea	edx,s_err31
		call	copyedx
		mov	al,')'
		stosb
	.else
		lea	edx,s_err0
		push	eax
		mov	ax,'( '
		stosw
		call	copyedx
		pop	eax
		push	ebx
		push	ecx
		call	itoa
		pop	ecx
		pop	ebx
		mov	al,')'
		stosb
	.endif
	pop	eax
	ret

copyfilename:
	.while (byte ptr[edx]!=0)
		mov	al,[edx]
		.if al==13
			mov	al,32
		.elseif al==10
			mov	al,32
		.elseif (al=='*')||(al=='?')||(al=='+')||(al=='|')||(al=='/')||(al=='\')
			mov	al,'#'
	;	.elseif al=='.'
	;		mov	al,','
		.elseif al==':'
			mov	al,';'
		.elseif al=='>'
			mov	al,')'
		.elseif al=='"'
			mov	al,39
		.endif
		stosb
		inc	edx
	.endw
	ret

;esi,ebx
;returns eax
esccmp:	.while (byte ptr[ebx]>32)&&(byte ptr[esi]>32)
		mov	al,[esi]
		inc	esi
		.if al=='%'
			mov	dl,[esi]
			.if (dl>='A')&&(dl<='F')
				sub	dl,'A'-10
				inc	esi
			.elseif (dl>='a')&&(dl<='f')
				sub	dl,'a'-10
				inc	esi
			.elseif (dl>='0')&&(dl<='9')
				sub	dl,'0'
				inc	esi
			.else
				mov	dl,16
			.endif
			.if dl<16
				mov	al,dl
				mov	dl,[esi]
				.if (dl>='A')&&(dl<='F')
					sub	dl,'A'-10
					inc	esi
					shl	al,4
					or	al,dl
				.elseif (dl>='a')&&(dl<='f')
					sub	dl,'a'-10
					inc	esi
					shl	al,4
					or	al,dl
				.elseif (dl>='0')&&(dl<='9')
					sub	dl,'0'
					inc	esi
					shl	al,4
					or	al,dl
				.endif
			.endif
		.endif
		mov	ah,[ebx]
		inc	ebx
		.if ah=='%'
			mov	dl,[ebx]
			.if (dl>='A')&&(dl<='F')
				sub	dl,'A'-10
				inc	ebx
			.elseif (dl>='a')&&(dl<='f')
				sub	dl,'a'-10
				inc	ebx
			.elseif (dl>='0')&&(dl<='9')
				sub	dl,'0'
				inc	ebx
			.else
				mov	dl,16
			.endif
			.if dl<16
				mov	ah,dl
				mov	dl,[ebx]
				.if (dl>='A')&&(dl<='F')
					sub	dl,'A'-10
					inc	ebx
					shl	al,4
					or	al,dl
				.elseif (dl>='a')&&(dl<='f')
					sub	dl,'a'-10
					inc	ebx
					shl	al,4
					or	al,dl
				.elseif (dl>='0')&&(dl<='9')
					sub	dl,'0'
					inc	ebx
					shl	al,4
					or	al,dl
				.endif
			.endif
		.endif
		or	ax,2020h
		.if al!=ah
			xor	eax,eax
			ret
		.endif
	.endw
	xor	eax,eax
	.if byte ptr[esi]<33
		inc	eax
	.endif
	ret

copylink:
	mov	eax,[esi]
	or	eax,20202020h
	.if eax!='ptth'
		.if byte ptr[esi]=='/'
			push	ebx
			assume	ebx:ptr foruminfo
			mov	ebx,f_info
			lea	edx,[ebx]._addr
			mov	eax,[edx]
			or	eax,20202020h
			.if eax=='ptth'
				stosd
				lea	edx,[edx+4]
				.if byte ptr[edx]==':'
					mov	al,[edx]
					stosb
					inc	edx
				.endif
				.if byte ptr[edx]=='/'
					mov	al,[edx]
					stosb
					inc	edx
				.endif
				.if byte ptr[edx]=='/'
					mov	al,[edx]
					stosb
					inc	edx
				.endif
			.endif
			.while byte ptr[edx]
				mov	al,[edx]
				.break .if al=='/'
				stosb
				inc	edx
			.endw
			pop	ebx
		.else
			push	ebx
			mov	ebx,f_info
			lea	edx,[ebx]._addr
			mov	ecx,edi
			push	edi
			.while byte ptr[edx]
				mov	al,[edx]
				.if al=='/'
					mov	ecx,edi
				.endif
				stosb
				inc	edx
			.endw
			pop	eax
			.if ecx==eax
				.if byte ptr[edi]!='/'
					mov	al,'/'
					stosb
				.endif
			.else
				mov	edi,ecx
				mov	al,'/'
				stosb
			.endif
			pop	ebx
		.endif
	.endif
	.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='#')
		lodsb
		.if al=='&'
			mov	eax,[esi]
			or	eax,202020h
			.if eax==';pma'
				lodsd
			.endif
			mov	al,'&'
		.else
			mov	eax,[esi-1]
			or	eax,20202020h
			.if eax=='=dis'
				.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
					inc	esi
				.endw
				.continue
			.elseif eax=='sphp'
				mov	eax,[esi+3]
				or	eax,20202020h
				.if eax=='isse'
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
						inc	esi
					.endw
					.continue
				.endif
			.elseif ax=='=s'
				mov	eax,2
				.while ((byte ptr[esi+eax]>='0')&&(byte ptr[esi+eax]<='9'))||((byte ptr[esi+eax]>='a')&&(byte ptr[esi+eax]<='f'))||((byte ptr[esi+eax]>='A')&&(byte ptr[esi+eax]<='F'))
					inc	eax
				.endw
				.if eax>8
					.while (byte ptr[esi]!=0)&&(byte ptr[esi]!=34)&&(byte ptr[esi]!=39)&&(byte ptr[esi]!=62)&&(byte ptr[esi]!='&')
						inc	esi
					.endw
					.continue
				.endif
			.endif
			assume	ebx:nothing
			mov	al,[esi-1]
		.endif
		stosb
	.endw
	.if byte ptr[edi-1]=='&'
		dec	edi
	.endif
	mov	al,0
	stosb
	ret
